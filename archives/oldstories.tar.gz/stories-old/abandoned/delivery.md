# Delivery
_an erotic tale by TransGirl_

## Chapter One
The sun was setting on the barren lands of Migdrassyr, it was the time for the
autumn storms to come. All over the land the farmers were hurrying to harvest
their crops on the few patches of fertile lands there were. It had been almost
75 years since the Collapse and everybody was still doing their best to
overcome what was lost. Migdrassyr had been a prosperous land before, now it
was just a phantom of what it used to be.

But despite all the despair, all the hardships there was a glimmer of hope. As
the prophets not only had foreseen the Collapse, they also told about the one
who would bring back prosperity and restore Migdrassyr to its former glory,
those prophesies gave the people hope enough to go on, to endure everything
this harsh land threw at them.

We embark this story in the small town of Ravenswood near the open sea, the
only town with some sort of prosperity. Compared to towns across the water
Ravenswood was nothing more than a slum, but for Migdrassyr it was a beacon of
light showing all that live could be better than it was at the moment. The
houses were repaired and the ruins were cleared when the Collapse stopped.
They were even building new houses on the clearings left behind. In one of
those new houses there was a small shop selling wonderful items of magic and
mystery. Hardly anyone was ever seen inside, so many wondered how it could
still exist as it did.

Behind the counter of the shop sat an elderly man, his hair almost white, a
beard that reached his stomach. Behind a small pair of glasses were two very
bright, blue eyes. You could clearly see they reflected a sharp mind and an
even sharper mouth. Rune was one of the elders in town, one of the last
surviving people who actually were alive during the Collapse, albeit he was
only two years old at the time.

Rune looked up from his book when he heard the bell chime, a customer entered
the store. Slowly he closed his book and looked up at the stranger standing
before him. A dark cloak covered his clothes, the hood mad it almost impossible
to see his face. The stranger didn't look like any other man Rune had ever
encountered and something just looked off.

"Welcome, how can I help you?" Rune asked.

It was quiet for a while and the stranger replied with a question. "Do you have
any information about the prophecies?" Suddenly it became clear to Rune, this
man wasn't a man at all, she was a woman! Women hardly ever entered his store
as they would be seen as witches and witches were responsible for the Collapse,
although no longer prosecuted it was still dangerous to be a witch.

"What do you want to know?" Rune asked.

"Anything." the woman was short in her answers as she kept on looking back at
the door expecting anyone to come in at any moment.

"Well, I could tell you what I know, but I think it will be the same to what
you already do. The prophecies are nothing more than legends told by people who
needed them to continue living, nothing more nothing less."

"I was told you knew more," the stranger replied, "I was told to come here and
ask for --" the woman bent over forward and whispered "I was told to ask for
_deliverance_."

Rune's eyes suddenly popped wide open. It had been years since anyone had asked
for that, he couldn't even remember who it was the last time. How could this
woman know? Who had told her? Rune stood up, suddenly showing his true height.
He stepped from behind the counter, walked over to the door, shut the blinds
and locked it. He turned around and said with a stern voice "Who are you? Show
yourself!"

"Not here," the woman replied, "please, don't make me do it here."

Rune looked at her from the bottom up deciding what to do. Then he relaxed as
if the stranger wanted to do him harm, she would have done it already. "Follow
me." he said as he walked towards the back of the store. Once there he made a
gesture in the air and a dark blue glow emanated from his hands striking the
wall in front of him. With a loud creak a part of the wall subsided and started
to move to the right. Behind it a sparsely lit hallway appeared and Rune
stepped in bending his head down as not to bump it. After a few steps he looked
back to see if the woman had followed him, when he saw she did he made the same
gesture and the wall closed back again.

Together the walked until they reached a chamber lit by oil lamps with every
wall covered by racks of books, potions and other magical items. In the center
of the room was a desk covered with parchments, trinkets and other materials
needed for some kind of magic. Rune sat down on the chair behind the desk and
said "You are safe here, this is the last reminisce of what was before. I'm am
the protector of this knowledge and now I demand to know who you are."

The woman waited for a few seconds before she slowly took back the hood. Rune
gasped when he saw her long red hair. The prophecy! The prophecy had told about
the one with red hair who would guide Migdrassyr to prosperity again and there
were no people in the lands with red hair as far as Rune knew. But then again
here she was standing in front of him, her red hair shining in the light of the
lamps.

"It can't be." Rune stuttered.

"This is why I need to know everything," she said, "I've been ridiculed,
prosecuted, imprisoned and I do not know why? All I know about the prophecy is
that one day someone will guide us. Only three days ago someone told me about
the red hair. Suddenly everything made sense, but I'm not the one. I can't be,
I'm an artist, a painter not a soldier. The prophecy must be wrong."

"Who told you about the red hair?" Rune asked as that part of the prophecy was
a well kept secret. There were only a few who knew all the details of the
prophecies.

"That doesn't matter. What matters is that I know." she replied.

Rune offered the woman a chair which she gladly accepted. He could see on her
face she was still very anxious about all of this. "Don't worry, you are safe
here. You have me at a disadvantage as I know nothing about you and you clearly
know all about me. So tell me, please, who are you?"

"I am Magdalinne, Magda for short, and I was born in a small dwelling in the
north almost 20 years ago. My parents were hard workers and they gave me a very
pleasant childhood. It all started to go wrong when I wanted to go to
university, suddenly people started to treat me different, as if I was a freak,
a leppar or something. When someone suddenly died in the hostel I was staying
at I was tried and convited. Only recently someone came forward and I was
released. It was during that period I met someone who told me about the
prophecy and to come here."

Magda clearly felt relieved she had finally told someone her story and her face
relaxed a little. Rune was quiet for a moment and then said "I should have know
it was Yuna. She just can't keep her mouth shut sometimes." He looked at Magda
who clearly was shocked by this revalation. "Oh, relax. She told me she met
someone important and how I might soon change my mind. I laughed it off as I
never would have expected this."

"Now, there is just one more thing I need to verify before I can continue.
Please show me your back, I will make sure to explain after I have confirmed."
he said with that stern voice of his.

Magda slowly rose up from her chair and took off her cloak revealing a simple,
dishoveled dress underneath. Her wellformed body became clearly visible, she
turned around slowly and unbuttoned the front of ther dress, slid it from her
shoulders to reveal her back as she held it up to cover her front. Rune got up
and close to her inspecting her back until he saw what he needed to see, the
birthmark near her right hip shaped like a dragon.

"Put your dress back on," he said as he walked back to his chair. Magda did as
she was told, when she was done she sat down again.
