# A Sons Love
_an erotic tale by TransGirl_

## Chapter One
As often is the case I can't really point to a specific moment it changed for
me, the only thing I know is that from a certain point it just was different
for me. I tried to suppress it for as long as possible and act like nothing had
changed, but the longer it lasted the harder it got. But I just couldn't give
in, it just wasn't right. It just wasn't done. So I started avoiding specific
situations just to make sure it didn't happen. But that day it was unavoidable,
I just had nowhere to go.

It was my sons birthday, he turned 18 and he insisted to have his party at the
pool. He had set his mind on a pool party and everybody needed to be there in
swimwear. "And I mean trunks for the guys and bikini's for the girls. Not those
ugly bathing suits. I hate those." he had said. When I protested he just said
"Well, you're a girl too, aren't you mom? And don't worry, I've invited the
parents too. I want a big party for everybody and I've invited the parents so
they know nothing is going to happen if they are concerned about that."

He had always been a responsible boy, but inviting the parents of his friends
to his birthday party was on another level. And somehow his friends had
accepted it. He had fully organized it all: the barbecues, the music, the
drinks and snacks, everything. All I had to do was pay for it, but the boy
turned 18 only once in his life so I gladly did. He even had picked it up with
the help of some of his friends.

Now I was watching them setting it up, the boys did the heavy lifting, the
girls were decorating the place. In the end the backyard had a strong Hawaii
vibe and it was just beautiful. One of his friends started setting up his DJ
equipment and soon the beats of music flowed through our backyard. I was happy
he had informed the neighbors about the party and they had said it wouldn't be
a problem.

Slowly the party started and they all retreated to put on their swimming gear.
I had made my room available for the girls to change and when I entered it
sounded like a real chicken coop. They all changed into their bikini's and one
of them, April, said "You too Mrs Davis, I know you've got a bikini somewhere."

"Oh, you don't want to see this old body," I said, "I will change when you are
gone."

April said "Why? No, show us. We want to see what you'll be wearing. Come on,
Mrs Davis. We will see it later anyway." The other girls chimed in and I had no
way our anymore. I opened a drawer and got a pair out that I thought were
appropriate and April just said "Those? No. No. Not those. Let me see." She
rummaged in the drawer and got a pair that I hadn't worn in years.

"Oh, I can't wear those! They are way to small, I wore those when I was in
college."

"They are so nice and look so good on you," April said, "Please just try them
on for us. So we can decide."

I took a deep breath and took of my dress, when I wanted to turn around to take
off my bra April said "Oh as if we haven't seen breasts in out life." I looked
at her, took a deep breath and took off my bra. April said "I don't know what
you are complaining about, you have an amazing body Mrs Davis."

"Now you've seen me naked, pleas call me Angela." I replied, "Mrs Davis is my
mother and believe me she wouldn't have been here at all."

The girls giggled and April said "Now put the bikini on Angela so we can see."

I put it on and all the girls cheered, April said "It's perfect. It looks so
good on you, Angela. Now," she turned to the group again, "I've got a little
surprise for all of you." She opened a bag she had brought, got out Hawaiian
grass skirts and handed them out, followed by flower crowns. The girls all
giggled and started putting them on, I followed them and started getting into
it too. April placed her phone on my vanity and said "Time for a group photo,
you too Angela." We all took a place on my bed and waited for the photo to be
taken.

One of the girls looked out my window and said "I think the boys are all
outside, lets just wait for a few minutes for people to arrive. It's just 2 so
they should arrive soon."

"Oh, but I need to welcome them. So I --"

"No," April interrupted me, "that's all arranged. Todd's your son and you don't
have to do a thing today. It's all been taken care off, you just have to
party."

We stayed in my room for another half an hour or so and the girls got more
excited the longer it took. At some point April texted something and said
"Okay ladies, it's time. Quiet now and wait for my sign."

We all went downstairs as quiet as possible and April signaled to wait in the
small hallway leading to the living room. She texted on more thing and suddenly
the music changed into Hawaiian drum beats and the girls in front of me stepped
forward moving their hips to the beats. I followed them and did the same, we
moved their arms sensually and our hips popped from side to side. I felt
embarrassed at first, but when we stepped into the backyard the people started
to cheer to see us dancing into the party.

The DJ shouted "Ladies and Gentlemen, the girls!" Another cheer sounded and we
formed a group out on the lawn and kept belly dancing. I got into the fun and
participated the best I could. Some of the other mothers joined in and that's
when I really let go. We all just had some fun with it.

When the music changed again one of the boys jumped into the water making sure
the splash hit a few of us, with that the party had truly started. April handed
out some more skirts and crowns as we mingled. One mother walked up to me and
said "Who had that idea? That was go great."

"That would be April. Trust me they didn't allow me to do anything."

"April? My April? Wow. Well, it was a lot of fun. Can we do it again?"

The party was a huge success and as April had said I didn't have to do
anything, I wasn't even allowed to fill the dishwasher. I just gave in and had
me some glasses of wine. I sat down on one of the tanning chairs and just had a
good time. After another glass or two I knew I had to stop or I wouldn't be
able to control myself anymore and I still was responsible for all the people
here. I just laid down on a tanning chair and watched the girls dance and the
boys who were jumping in the pool trying to get them wet. Suddenly there was a
scream and I saw how Todd threw April in the water.

I got up and joined the dance floor, I was having fun when suddenly I felt
someone putting his arms around my waste. "Your going in mom," I heard Todd say
and before I could do anything I landed in the water. "Todd!" I yelled when I
got up again, "You are in so much trouble young man. Throwing your mother in
the water like this."

There went an "oooh" through the crowd and people started to laugh when they
saw Todd run away from me. I got a towel and dried my hair. "Well, that crown
is ruined," I said giggling. At some point Todd returned laughing is ass off
and I vowed revenge. Which came a few hours later when he stood near the pool
talking to one of his friends. I walked up with a plate of food and asked his
friend what he thought of the party. Without warning I pushed Todd who lost his
balance and fell into the pool. "That's for throwing me in earlier," I said and
walked away.

Around 9 in the evening the party wound down and people started to leave. Todd
said goodbye to them all and about an hour later he and his friends started to
clean and I still wasn't allowed to move a finger. Around midnight everything
was packed up, the house was clean again and the last of his friends left.

I was still in the backyard, with another glass of wine. Todd sat down next to
me and said "That was a heck of a party. Thanks for allowing it mom. It was the
best. Especially when you all came dancing in, I never knew you could move like
that."

"Oh, there's a lot you don't know about me," I replied.

"Oh? Like what?"

"Like the things I'm never going to tell you." I said.

"Ah, come on mom. What were you like in college? You never told me about
college."

"Because there's nothing to tell. I was quite boring in college."

"There must have been something you can tell." he turned to me and my eyes fell
on his young, muscular torso. He had grown into a well proportioned young man
and I felt myself getting aroused. Normally I would have gotten up and just
walked away, but the wine had loosened the breaks and I turned over to him.

"Well, there was this one time," I started, "I went to this party. You know,
like at a fraternity. I was really excited to go, they always had the best
parties. So I walked up to the door and this guy opened up the door, he was one
of the hottest boys on campus and I was totally smitten by him."

"Yes, and?"

"Well, three years later we got married and had you. Now he's just a rotten
bastard who left us for a younger woman. That's how I met your father."

"Ahw, that's all? What happened on that party?"

"Nothing. We talked, had some drinks and I went home. That's all. It took him a
month before he dared to ask me out on a date. True story."

"There must be more to that story than you're telling me."

"Ah, and if it was I am not telling you, young man." I got up and walked into
the house. I went into the kitchen and poured myself another glass of wine.
Todd followed a few seconds later, placing his hand on my hip as he reached to
get a glass from the cupboard. His touch sent thrills through my body and I
felt my nipples getting hard. He stepped away and got a soda from the fridge, I
tried to push my feelings away and said "I think I will get into something
different. I'm still wearing this --"

"It looks good on you mom. All my friends said so. You were the hottest mom on
the party."

I blushed and said "You're just saying that. And besides, it's way
inappropriate to say that to your mother." I took a sip of wine and Todd leaned
back at the fridge. I just couldn't look at him and turned away, took a gulp
from my glass and walked away to go upstairs. Once in my bedroom I put the
glass down and fell on my bed. "Oh my Lord," I thought, "Why am I thinking this
way? What is happening to me? Angela, he's your son!"

"I'm gonna take a shower," I heard Todd shout from the landing and I replied
with an okay. A few seconds later I heard the shower starting. I placed my hand
on my forehead and shook my hand "No, Angela, no." I got up, picked up my glass
and emptied it in one go. Took a deep breath and just walked over to the
bathroom. The door was slightly ajar. After another deep breath I opened the
door and stepped in. Todd looked over his shoulder and didn't say anything.

I took another two steps, took of my top and panties and just stood there naked
in front of my own son. I opened the door to the shower and stepped in with
him. With my finger I gestured to be quiet and I placed my hands on his torso,
slowly going down until I touched his penis. I took it in my hand and stepped
closer to him, letting the water fall on me.

Carefully he put his arm around me and pulled me closer, all this time we were
staring at each other and I felt him getting hard in my hand. I pressed my body
against his and we kissed. His hands went to my breasts and I moaned. He went
down with one hand and placed it between my legs. I spread them slightly and he
touched my clit. "Put out your tongue" I whispered and as soon as he did I
sucked on it, pushing mine in his mouth after. I felt him push a finger inside
my wet cunt and I moaned harder.

"Oh Todd," I moaned, "I wanted this for so long. But it's so wrong."

He slipped another finger inside me and just moaned "Oh mom." I stopped the
water, grabbed a towel and dried him off. He did the same to me and I grabbed
his hand to guide him to my bedroom. I fell on the bed, spread my legs and Todd
got on top of me. "I can't take it anymore," I whispered, "I want you to fuck
me, son. Come and fuck your mother." I took his cock and guided him inside me.

With one push he went all the way in and I moaned "Oh yes. Finally! Oh Todd,
fuck me, fuck me hard. Make your mother come all over your cock."
