# Summercamp
_an erotic story by TransGirl_

## Last days before summer break
"Luna!" the teacher shouted when she caught me daydreaming again. I shook my
head as I returned to reality. "I know it's almost summer break, but please try
to pay some attention to me" she said. The class snickered when they saw how my
face turned red. _I really dont' want to be here anymore_ I thought, but there
were still a few hours to go before summer break finally started. I turned my
attention to the book in front of me and did my very best to pay attention. A
few minutes later the bell indicated the end of class and the hallways filled
with students who all were looking forward to the break.

I went over to my locker and just as I opened it my best friend bumped me
saying "Hey there, looking forward to going to camp? I am so happy you are
coming this year." Summer was as cheery as she always was, I just grunted "I
just want this day to be over."

The rest of the day seemed to take ages until finally the final bell sounded
and summer break had officially started. Summer rushed up to me shouting "Just
another week until camp!" Her smile was wide, her long blond hair waved behind
her as she ran towards me. We got in my mothers car, Summer chatted all the way
over. When my mother parked the car in the driveway Summer got out and ran over
to her room shouting "Thanks Miss Davis!" My mother just waved and we went into
the house. After I had put my backpack away for the last time this school year
we sat down at the kitchen table for some tea.

"So," my mother asked, "any plans before you go to camp?"

"Nothing in particular." I replied.

"Well, maybe you could help dad in the store." she said, "Just an idea."

"Hm, maybe. But I really want to sleep in for a couple of days." I replied.

My mother got up laughing "You always sleep in, Luna."

After I changed into a bikini I laid down on one of the chairs near the pool in
the backyard and just enjoyed the sun on my skin. A few minutes later my mother
sat down next to me. As we both enjoyed the silence we didn't talk, my mother
got her book from the table in between us and started to read. "Those are
getting a little small, aren't they?" she said after a few minutes, "Maybe we
could go shopping for new ones tomorrow."

I looked down and thought it was perfectly fine, but I knew my mom loved to
take me shopping and, although I would never admit it, so did I. Almost an hour
later the silence was disturbed when my brother came home. "Hey there," he
said, "Who is happy summer break has started? I am! I'm off to Brandon's, I
will be back for dinner. See you two later." With that the silence returned and
my mother said "Sometimes I wonder why he even bothers to come at all." I
giggled and didn't answer her as it seemed he stayed over at Brandon's more
often than he was at home.

The next day I woke up around ten in the morning, after taking a shower I stood
in front of my closet deciding what to wear. I finally decided on a nice summer
dress and flipflops. When I walked into the kitchen my mother said "Good
morning, sleepy head. Want some pancakes?" I shook my head, grabbed a bowl,
cereal and the milk from the fridge. It was at that moment I noticed the noise
coming from the backyard. I looked outside and saw my brother was with a couple
of friends making a mess by doing stupid things in and around the pool. "Oh
God, why?" I said. My mother chuckled "Brandon's parents have the pool cleaned,
so now they're here."

"Oh, before I forget. Work called and I need to come in this afternoon. Can we
go shopping tomorrow?" My mother was a head-nurse in the local hospital and
when there wasn't enough staff she was called in. I just shrugged my shoulders
and said as I ate my cereal "It's okay, let's go tomorrow. It will be quieter
anyways."

A few hours later my mom was off to work, it was just me and the boys in the
backyard now. I went into my room, changed into my bikini and walked out into
the backyard laying down on the lawn chair. I knew some of them were looking
and I couldn't help but smile a little. Trent, a boy I had a crush on a year
ago, walked up to me and said "Hey there Luna, want to go into the water?" I
shook my head and said "No, thanks." He sat down next to me "If you are going
to lay here it's better to use some sun block. Want me to help you?"

I lifted my sunglasses and looked at him. After a few seconds I said "Sure, why
not?" Trent got the bottle and poured some block on my belly, gently smearing
it all over me. When he went up to my breasts I stared at him and felt a thrill
when he touch the lower parts. I looked over at the other boys and back to
Trent. With every pass he got a bit bolder until he slid his hands underneath
the cloth, cupping my breasts. Pushing the top off as he did so. Trent started
to squeeze my breasts and with his fingers he pinched my nipples.

The other boy, Dontrell, walked up to us and he also started to smear sun block
on to me. Feeling those four hands on my body aroused me and as Dontrell
started to smear my legs I couldn't help but open them slightly. Trent pushed
his hands on my back and I raised up a little as he undid the bow on my back.
After he removed my top I laid down again and he started to suck on my breasts.
Dontrell removed my panties and placed his hand on my slit, slowly pushing a
finger inside me.

My brother just stood there looking at us and when our gazes met I just kept
looking at him. Slowly he made his way over and sat down on a chair. Trent
offered his cock and I took it in my mouth, in the mean time Dontrell pushed
his big black cock inside me. I moaned loudly as I felt him slide into me, when
I opened my eyes again I saw my brother sitting there, he had taken out his
cock and was jerking. Seeing him jerk to me being fucked by one of his best
friends really excited me. Trent and Dontrell switched places a few times
before Dontrell helped me get up. Trent laid down on the chair and I got on top
of him, guiding his cock into my ass. Slowly I went down on him, opened my legs
as wide as I could to give Dontrell enough space to slide his cock in my pussy.

I looked over at my brother and his eyes were wide from amazement seeing his
little sister being double penetrated. "Oh yes," I shouted, "fuck me. Fuck my
ass and my pussy. Do you like it, brother?" I could feel Trent twitch and throb
in my ass. "Oh God," he grunted, "I'm coming..."

"Oh yes," I whispered, "Come for me, come in my ass. Fill my ass with your cum"
With that Trent grunted loud and I could feel him explode inside my ass, at
that some moment Dontrell came deep inside my pussy. "Oh yes," I moaned, "Oh
yes, fill me up with your cum. Yes, yes!"

After Dontrell regained his stamina he pulled out and I got off Trent. I looked
over at my brother and made my way over to him. His eyes were wide open as if
he knew what was about to happen. I straddled him, with my hand I pushed his
rod against my slit. "Do you feel that, brother?" I whispered, "Do you feel
that cum drip out of me?" While I said that I lifted my hips and guided his
cock inside my cum filled pussy. "Oh yes, brother," I whispered in his ear,
"this is happening. You are going to fuck your sister." I slid over his cock
and pressed my breasts in his face.

I rode him until he came inside me. "Oh yes brother, come inside your sister.
Fill her up." Feeling him come sent me over the edge too and I orgasmed. After
we both returned to earth I got off my brother and saw Dontrell laying on the
chair. His cock was all hard again and I sat down on top of him, guiding his
cock inside me again. I was so sensitive by now that I almost instantly came on
his big black cock. But I rode him until he came again, filling me up even
more. The rest of the day we spent at the pool, having sex a couple of times
more. The top was having Dontrell inside my pussy, my brother in my ass and
Trent in my mouth.
