# Dormitory Days
_an erotic tale by TransGirl_

In high school I was one of the gray mice that roamed the hallways and I
preferred it that way. And although I didn't belong to any of the groups during
my high school years I had my share of friends. I wasn't very interested in
going to parties or going to games. I preferred being at home with my computer
and the internet. Most of my friends were on there as I was part of an online
community playing Dungeons and Dragons.

Although it might have been on a distance, some of the people online knew me
better than anyone closer to me. My mother quite often said I needed to get out
more and make some friends until I finally gave in and joined the school
newspaper. We met after school two times a week and wrote dumb articles about
whether the lockers needed to be replaced. An article about the metal detectors
creating a false sense of safety was declined by the school. Being part of the
newspaper did spark my interest in journalism and I applied to a college in
journalism in my senior year.

Durint that summer break I worked at my father's store to earn some money
before I went to college. I worked full days and did my best not to spend any
of it. As I worked all day the summer went by quickly and the day I moved out
arrived fast. My mother had a hard time that day, she was very emotional all
day. "Oh please mom, stop crying. I'm not dead, I will be back during the
holidays and breaks." I said. She hugged me and I joined my dad in the car to
drive to my new home, the dorms of college.

After a three hour drive we arrived and I registered myself at the table with
the _new admissions_ sign. The woman behind the desk handed me my badge and the
key to my assigned room "Ah," she said, "your room mate has already arrived, so
it's nice for the both of you to meet." Instantly I got nervous, sure I had
know I was to meet new people but I hadn't realized I actually would share a
room with one. My father walked with me to my new room and saw that the door
was open. As I walked in my room mate was busy putting away her clothes.

"Hi," I said, "I'm Luna, your room mate?"

"Ah," she replied, her long blonde hair waved as she turned to me, "I'm Summer,
pleased to meet you. Oh, I already chose a bed, hope you don't mind. I'm used
to having my bed to the left of the room, we can switch if you really want to."

"That's fine," I replied, "I don't really care. What's your major?"

"Audio Visual, I want to be a photographer." she replied, "and yours?"

"Journalism, I like to tell stories."

"Ah, maybe I could shoot some pictures to your stories. Or we could work on a
story together one day."

My father said he had to leave and after a last hug he walked out the door, he
had insisted I staid in my room. "Maybe we could explore campus for a bit,"
Summer suggested. I dropped the bag I was holding "I thought you'd never ask."

We went down to the lobby where there were a lot of people signing in and
searching for something. Summer and I walked outside onto the central plaza. In
the middle was a large tree with benches around it. The grass around it was
littered with groups of people chatting and enjoying the sun. We walked around
the plaza, found the buildings where our classes would be and finally the
library. Next to the library was a coffee shop and we sat down on the patio,
Summer got us two latte's and we just sat there chatting.

She was very easy to get along with and I was hoping she was thinking the same
about me. When we finished our drinks we strolled along the other side of the
plaza where there was a pizza place, a Mexican restaurant and a small
supermarket. Finally there was the dining hall, on the sign near the entrance
was a sign stating _Welcome first year students! For 30 dollars a month you can
get one free lunch or dinner a day. Subscribe for your cheap meals now!_ A boy,
clearly a senior, said "That's a really good deal, trust me. You might want to
sign up for that." We thanked him for the information and walked in to sign up,
the money would be withdrawn automatically each month.

After about an hour we walked back to our room and I continued unpacking my
bags. Summer talked about a hundred words a minute as I did and I just enjoyed
her company. She was totally different from me in every sense of the word. As I
was unpacking she said "What? No dresses, skirts or sexy shirts? Are you even a
girl? I've never seen someone with so many pants. I really need to teach you
some fashion sense." I tried to protest but she interrupted with a "Challenge
accepted!" She smiled and walked away.

The next day was orientation day, we spent all day roaming the halls going from
introduction class to orientation class, I couldn't remember half of the
professor's names. The list of books I needed to get just kept on growing. At
the end of the day there was a full page of titles in my notepad. During lunch
I met Summer in the dining hall and she had the same amount of titles in her
notepad. "Let's get them together," she said, "but it can wait until tomorrow.
This afternoon is the extra curricular market, we can join a fraternity or a
club or anything else. Let's just enjoy our last day of freedom."

That afternoon we went from stall to stall and there wasn't anything that
peeked my interest until I came across a stand with a sign I recognized
_Treadmill RPG_. I had heard of them online and walked over. Behind the stand
stood Trevor. "Hi, interested in RPG? That stands for --"

"Role Playing Games, yes I know." I interrupted him.

"Ah," he said, "you played before."

"Yes, I'm a member of the _Mildew Guild_."

"The Mildew Guild? Oh man, you guys rock. That last raid you did? Man, pure
elegance. Especially that one action, the way she mislead that hag, legendary."

"Ah," I replied, "spur of the moment. I was just lucky with the dice."

"That was you? My god. You want to join us? It would be our honor to call you a
member."

"I'll think about it. It would mean I have to leave Mildew."

"No it wouldn't. We only play once a month and can easily change it to
accommodate you."

"Again I will thing about it. Thanks."

As I walked back to Summer she said "You're not thinking about joining the
geeks are you?"

"I'm thinking about it. I love playing Dungeons and Dragons and I am a member
of one of the leading guilds now. But they are all on the internet and my
mother always said I need to get out and meet people."

Summer laughed "Never got the lure of it. You're just playing a game."

"Oh, it's more than just a game. You know what? I'm joining them and when you
want to you can join us sometime, just to sit in and see what it's all about.
Yeah, hold on I will be right back." I walked back to the stand and joined
Treadmill. Trevor was elated and said the first session would be in two weeks.

Summer laughed when I returned "Never saw anyone so happy by joining the geek
squad. I love it."

We browsed the other stands and Summer joined the photography club and although
there were fraternities doing their best to get us to join we both resisted.
"My mother warned me against it," Summer said, "she was part of one and always
told me how great it was. It just made me not want to join one, ever." We
strolled the marked for a while and Summer joined the photography club, just
for giggles as she said it.

During the next few weeks we got settled in, started our classes and did our
best to find a rhythm between school, studying and the things we did next to
school. One of the things Summer did was going to study in the library. "Then
I'm near the books I need anyway." was her explanation. It was rather nice to
be able to study on my own and sometimes with a study group that I joined.

For one of my classes we needed to write an article about anything school
related, a so called human interest article. I decided to do one about the head
of the dining room. She was an Iranian refugee with a very interesting story.
She had fled her country when the Christians started to get persecuted.
Especially the part where some of the students called her a Muslim terrorist
when they didn't get their ways. I had asked Summer to take some photo's of
her, the article almost wrote itself and I got an A+ for it, thanks to the
photo's of Summer who used the photo's for her portrait classes.

The more time we spent together the closer we got, after a few months some
would call us best friends even. During the weekends we would go out to eat or
go shopping. She started to buy me things and when I asked how she could afford
it all she just waved it away. "I've gotten a good job," she said, "Don't worry
about it." I started to get concerned she was doing something she might regret
or illegal even so one evening I decided to press through.

"Summer, I'm worried," I said, "You're gone almost every night, you take some
very sexy dresses with you and do not come back until late. I just want to know
you're not doing something stupid."

"It's nothing," she protested, "don't worry about it."

"Too late," I replied, "I'm already worried. Do you even study anymore? I've
heard you've fallen asleep during classes. What's going on Summer?"

Summer sighed deeply and said "It's not what you think. I'm not a prostitute.
It's --"

"It's what?"

"Maybe I can better show you." she said and just looked at me with these sad
eyes. She got her laptop from her bag and put it on my desk. She opened it up
and opened a website, called _CamGirls_. "This is what I'm doing," she said,
"it's a website where you sit in front of the camera and do challenges. Some
nights I get over 5000 coins, which translates to almost 500 dollars."

"What? Where do you do these _challenges_?"

"Anywhere, mostly in the library."

"What?! You have to be joking. Are you crazy? What if you get caught?"

"That's what's so exciting about it. It's the adrenaline as well as the money."

"Oh my God Summer. Is that what you are doing every night?"

"Yes, it's just so -- addicting. Every day I tell myself not to do it that
evening, but during the day I get the itch and then just have to go."

I sat down, not believing what I just had heard. Summer begged me to not tell
anyone, to keep it between us and I looked at her. "Only if you promise me to
slow down. The more you do it, the bigger the chance you get caught." Summer
nodded and whispered "Will you help me with it?"

"Just tell me when you get that _itch_ and I will find something to do for us."
I promised her and we hugged. Summer thanked me and we went off campus to get
something to drink. Summer talked about what the site was all about, she also
told me how many girls were on there doing the same thing she did. Some did it
at home, others just like Summer in public.

"It all started when I talked to an old friend of mine," Summer explained, "She
was doing this and told me how much money she earned. She earns more in one
night then I did in a week. I know that's no excuse, but I come from a poor
family. I'm the first to go to college, ever. The scholarship I got is hardly
enough to pay for everything and the job at the restaurant hardly made me
anything. And the customers were just rude at some times, I got so sick of
waiting tables."

She looked down and continued "Then one evening I was in the library studying
and I remembered the story I was told. I opened the site and registered an
account. As I sat at a rather secluded area of the library I went live for the
first time. It didn't take long for the first people to show up. One of them
offered 500 coins to flash my boobs. I looked around a few times, got up and
checked if anyone was close, sat down and flashed them. Just by doing that I
had made 50 dollars. Then someone else offered double if I kept them out for a
full minute and I did. In just 10 minutes I had made more than I ever could
with waiting tables. I wrote it was my first time on a piece of paper held it
up and promised I would be back soon."

"Weren't you scared?"

"Yes, but that's part of the rush. The risk of getting caught."

"But if you do get caught, you will get expelled Summer. You have to be
careful."

"I know, that's why I don't do it at the library on campus. I go to the library
downtown. Not only is it bigger, it has spots where hardly anyone goes on the
times I go there."

"But the library closes at nine, where do you go then?"

"Anywhere else. I've been to bars, coffee shops, malls."

"Oh my God, Summer. This is unbelievable."

I sat down and was quiet for a while, then I said "I want to write a story
about this. From your point of view. From the girls who choose to do something
like this. Why they do it and such."

"You can't use my name, though."

"I promise."

Summer agreed and logged into the site. She went to a section that wasn't
available for the general public, it was meant for what the site called
_performers_. She left a message that a friend of hers wanted to write a story
about cam girls, to tell the story from their point of view. She asked for
anyone who was interested to contact her.

"And now we wait," she said, "but it might be easier if we create an account
for you, so you can talk to them via the site. It might be more comforatble for
them too." I agreed and we created an account for me. After we logged in Summer
talked to the main modderator of the chat and convinced her to grant me acces
to it after she vowed I was legit.

"Don't betray me," she said, "or I will get banned from the site." She giggled
a little "Feels like we're investigating a crime."

"Well, we are investigating but it's hardly a crime." I chuckled.

During the next few weeks I talked to several girls and after I promised not to
use their names the opened up to me and told me some really personal things.
One girl was the mother of three kids, had trouble making ends meet and doing
cam work solved a lot of problems. Another girl just did it for the kicks.
After a couple of interviews I wrote a story and let Summer read it.

"It's good, but I think it's missing something. It's all just so clinical, so
told from the sidelines. Maybe it might be good if you see it for yourself. To
see how it is from this side of the camera, so to say."

"What do you mean?"

"Well -- and don't get mad -- maybe you should try it one time. Just to see how
it is to go online for the first time. To actually experience it."

"Oh, I couldn't do that? What if someone recognizes me? Some girls told me they
were recorded and now they're on all kinds of porn sites. I couldn't risk that,
it's just too dangerous." I protested.

Summer was quiet for a while, then said "Yes it is. Never mind. It was just a
thought."

For the rest of the night I couldn't stop thinking about what Summer had said
and reached the conclusion that she might have been right. The fact that I
already had an account made the step even easier for me. It still took a few
days before I actually worked up the nerves to do it. Summer had a late class
and I sat at my desk deciding whether I should actually do this. My laptop was
open and I was logged into the site. All I had to do was click on the _GO LIVE_
button. My nerves were like piano strings and I felt nauseous. I looked at
myself in the mirror and thought "What the hell are you doing?" I closed the
site and shot down my laptop. I was just too scared.

When I reread my article I had to agree with Summer once more, the article
needed the view from someone who knew what it was like to _preform_. I made
some notes in the notebook with all the interviews. _One of the girls told me
the article might benefit from being told by someone with an inside
perspective, therefor I've decided to try it for myself. But I'm too scared to
actually go through with it. What if someone recognizes me? Or records me? It's
on the internet and as they say once it's on the internet..._

I looked up and continued writing: _But I feel it in my bones that I actually
have to do this. This needs to be a risk I am willing to take. And if I do, do
I actually want to write an article about this? That would mean I tell everyone
I am one of the girls who do expose themselves on the internet. Is this a risk
I am willing to take? I don't have an answer to this question yet._

I kept on writing for half an hour and thought it was a great introduction to
the new version of the article, maybe even a book. I leaned on the desk, put
my head in my head and just didn't know what to do. When Summer returned I
talked to her.

"I almost went live tonight," I said, "I almost did it. I was so close."

"That's how I felt before my first time. I struggled hard before I actually did
it. That's an insight you didn't have when you wrote the article."

"You're right," I replied, "but I still need to take the next step I feel."

As classes got busier I had to put writing that article on the back burner,
midterms were closing int and I had to study hard as I really didn't want to
study during the holidays. During the week my time was spent in books and the
internet. During the weekends Summer and I spent time doing fun stuff like
going shopping or going to a movie. As the weeks passed by we got closer than
we've ever been, we even told each other about passed flings with boys.

Being home for the holidays felt wierd, I had gotten used on doing my own thing
and now I had to take my parents into account. My mother said it was a sign of
me growing up and gave me the space I needed. We spent Christmas at my
grandparents place with the rest of the family, my uncle joined via Skype as he
lived in Europe. It was a wonderful time and in the new year I returned to
campus. 

After midterms we were off for a week, during this break Summer went home to be
with her parents. For me it was just too expensive to go home, so I decided to
stay at college. My parents were disappointed but they understood why I
couldn't come. I spent the days by exploring the surroundings of the college
some more and successfully applied for a job at a local restaurant, but that
wouldn't start for another week.

I decided to do some research for an article I had to write for class. As it
just was easier I spent my days in the library, where the books were close by.
On the second day in the library my thoughts went back to the article I wanted
to write about the world of _cam girls_. Just to have a break from collecting
data I opened my browser and the streaming site. I logged in and read some new
replies I had gotten on my previous and only post on the site.

The red _GO LIVE_ button was very tempting and after checking if I was really
alone where I sat I clicked it. A new page opened with a large chat box on the
left, a list of participants on the right and in the red top corner I saw
myself through the webcam built in the laptop. It wasn't the best quality and I
just stared at my screen, I couldn't believe what I was doing.

Before I knew it some people entered the chat to say hello and I replied with
"Hi, sorry it's my first time doing this. So please be patient with me, I am
very nervous." The reaction was heartwarming and one of them said "I can see
you're nervous. Are you in a library?"

"Yes, I was studying but I got bored."

"Studying can be boring, how old are you?"

"Rather not say, I want to keep some things private."

We just chatted about anything and everything, someone even donated 100 coins
just because I was so nice. Nothing really happened otherwise, it was just so
pleasant to chat with people from all around the world. When I checked the time
I was surprised it had lasted for almost two hours. "Sorry guys, but I have to
go. It was so very nice to meet you all and I think I might do this again some
day. Bye all and have a great day."

On my way over to my room I stopped in the dining hall for my dinner and when I
was back I laid down on my bed to watch some episodes of my favorite series. I
must have fallen asleep because I woke up very early the next day. As I walked
over to the showers I noticed how quiet it was, most of the students had left
for the week and the others were still asleep. It felt like I was the only one
there. After taking a shower I noticed I had forgotten to take new clothes with
me and the towel I brought was just a bit too small.

I peeked around the door to see if the halls were still empty. I bound the
towel around myself the best I could and slipped out the bathroom. I tiptoed to
my room as fast as I could, halfway to my room the towel slipped and fell on
the floor. There was nothing left to do but pick up my towel and rush to my
room totally in the nude. I stepped into my room as quick as I could, closed
the door and leaned against it when it was closed behind me. I took a deep
breath and just hoped nobody had seen me.

As I got dressed the adrenaline was still rushing through my veins, I started
to giggle thinking back at the moment my towel dropped. As it was still very
early I didn't really know what I should do. I walked to the central area where
the coffee machines were and got myself a latte. Sat down near the window and
just looked outside at the empty plaza. It felt nice being up this early and to
watch the world wake up. A girl walked came over from one of the other hallways
and said "Good morning, you're up early." I wished her a good morning and then
just nodded.

Although it was only February it looked like it was going to be a beautiful
day, it was only 8am and it was already 61 degrees. Way warmer then I was used
to where I grew up. I looked at my phone and the weather report said it could
rise to 68. I stood in front of my closet, not able to decide what to wear. I
looked over to Summer's closet and opened it. On one of the hangers I saw a
dress, I had never ever decided to wear a dress on my own. I had only worn them
when my mother made me wear one, but now I wanted to.

I closed her closet and decided to go to the mall in stead. I wasn't planning
to wear Summer's clothes and run the risk of ruining hers. Once in the mall I
went into Target and went over the clothes section. The had a myriad of dresses
and I had a hard time choosing one. Then I saw one I really liked, it was a bit
loose and the lower part was wide and pleated with a large print of a sunflower
on it. I loved sunflowers, after trying it on I decided to buy it. As I walked
out of the dressing rooms there was a rack of one-size-fits all dresses, I
looked at them for a while and then put two of them in my basket, a red and a
black one.

Walking over to the registers I came across the electronics isle and noticed
the webcams being on sale. I read the back of the packaging and decided to take
one of them too. As I didn't want to wait in line I used the self checkout isle
and paid for everything. It was more than I wanted too, but as every year my
parents had given me my _new years bonus_, this year they had increased it to
150 dollars. And, as was tradition, I did my best to decline it, but they
always insisted on me taking it. And I hadn't spent a penny of it until then.

When I was back in my room, the sun was way up in the sky and I put on my new
dress, the one with the sunflower. I brushed my hair and instead of putting it
in a ponytail or a bun, I decided to let it loose this time. I put on my
sneakers and felt a bit elated as I walked out my room. It was the first time
for me to willingly wear a dress outside.

As I sat on one of the benches I watched the people walk by, some of the girls
were wearing dresses too and when I got up to walk towards the dining hall to
get a latte I could feel some of the boys looking at me. For the first time in
my life I felt them looking at me and it felt nice. The rest of the day I spent
with doing nothing really. In the evening I watched some more episodes of my
favorite series before I fell asleep.

When I woke up it was still dark outside, my phone told me it was just past
5am. I got up, walked over to the coffee machine and got myself a latte. I got
startled a bit when the sound of the machine shredded the cloud of silence
hanging in the halls of the dorms. I was grateful when my latte was ready and
the silence returned, I was hoping I hadn't woken up anyone and just waited for
anyone to react but everything staid quiet. I walked over to my room and sipped
from my latte.

It was almost six when I decided to head for the showers and to get ready for
another day. I washed my hair, blow dried it and then just looked at myself in
the mirror. I looked over at the door and back to my reflection in the mirror.
I gathered my belongings and just walked over to the door. I peeked outside
into the empty hallway and then just stepped outside. I walked towards my room
in a normal pace and giggled from the excitement of being totally naked.
Halfway down the hall I spun around with my arms wide and giggled some more.

I went into my room, placed my stuff on the bed and then just looked out into
the hallway again. For the second time that morning I stepped outside naked and
walked towards the central area, all the way to the coffee machine. Being naked
felt freeing and I started to enjoy myself. When I heard a noise coming from
one of the other hallways, I turned around and ran back into my room.

Once inside I couldn't stop laughing, it had all been so exciting. Not only
being in the nude, but also the rush of not getting caught. The adrenaline was
still pumping through my veins and I just couldn't stop giggling. I put on my
new dress and sat down at my desk. I took my notebook and started writing
everything down. I ended with:

_The adrenaline rush it gave me just feels so good. It's not the being nude
that is so exciting, it's the not getting caught doing it. And I can't believe
I'm saying this: but I want to feel it again._

When I was finished writing I got the new webcam from my bag and connected it
to my laptop. On the CD that came with the camera was a simple program that
enabled you to record from the camera. I started it up and pointed the camera
at me, the quality was surprisingly good and gave me an idea what I wanted to
do that day. After I got dressed I looked at the clock, it was still an hour
until I could execute my plan. I gathered some stuff and put them in a bag, got
myself another latte and sat down in the central area.

When it was time I got my bag, put my laptop and camera in it and walked over
to the library. As it was still quite early the librarian was a bit surprised
when I walked in. "You're early," she said. "Yes," I replied, "I'm working this
afternoon and I really need to finish my assignment." She nodded and went back
to do whatever she was doing. This early she was the only employee there and
the rest of the library was empty.

I walked up the stairs to the third floor and found a table that was rather
secluded from the rest of the library. To the left of the table were large
windows overlooking the woodlands next to campus and to the right were just
racks of books. The other side was mirrored with a gap of a few feet between
them. I placed down my laptop and powered it up. Then I connected my webcam to
it and sat down. After starting the recording I got up and walked down the isle
looking at myself on the laptop.

Then I started the recording and I walked a few steps away from the table. I
turned around and slowly lifted my dress. I kept on checking if anyone was
there to see me and then just took my dress off. I held it in my hand for a
short while before quickly putting it on again. I giggled and sat down at the
table again. I stopped the recording and watched it back. After I had watched
the short video I got up again after starting a new recording. This time I
walked over to the other side, closely looking if anyone was there when I
crossed the gap. I took off my dress when I was near the other table and
started walking back, I paused in the gap for a while before continuing to my
desk. Then I turned around and walked back to the other table. Put my dress
back on, grabbed a random book and walked back.

After watching the videos I couldn't stop giggling. I collected my stuff and
put the book back where I got it. As I walked back to the stairs I saw another
table, this one was a bit more in the open and I decided to sit down at it. Got
out my laptop once more and after connecting the webcam I opened the recording
software. I looked around and saw a chair in the middle of the space, facing
the stairs. After starting the recording I walked over to the chair, took off
my dress and walked down an isle again. From one point I could see the
librarian downstairs and my heard pounded in my chest because if she looked up
she could have seen me.

Slowly I walked back to the chair where my dress was laying and I put it back
on. But somehow I didn't want to stop, I wanted more. Back at that chair I
turned it around so it was facing the camera, I took of my dress again and sat
down, I put my legs on the rests exposing my vagina to the camera. With two
fingers I spread my lips showing the pink within. With the other hand I
squeezed my breast and tried to stare sensually into the camera. Then I heard a
noise coming from the stairs, quickly put on my dress again and walked back to
the table with my laptop. Stopped the recording and opened the browser to act
if I was looking something up.

When I heard the footsteps behind me my heart was racing, I looked over my
shoulder and it was the librarian with a load of books in her arms. "Oh here
you are," she said, "why don't you spend the day outside. It's such a lovely
day." I looked up and said "I'm almost ready, just a few more things to do and
then I got to go to work." I smiled as I spoke and she nodded as she went on
her way placing the books where they belonged.

I removed the webcam from my laptop and put it in my bag. The librarian saw me
do it and said "Had a meeting online?" she asked, "It's the thing nowadays,
when I was your age we actually met somewhere. Now you just open your computer
and talk to each other. Such a shame. But hey, nobody can stop progress." She
smiled once more and went back down to her desk at the entrance. I sighed from
relieve and shutdown my laptop. I felt like I had used up all my luck for one
day.

It was Friday when Summer returned and we went out to get a bite to eat
together, she told me everything about her week and how boring it all had been,
I told her it was even more boring on campus. I really wanted to tell her about
my adventures but I didn't dare to, so I kept it to myself. We walked back to
our room and I had a hard time keeping it a secret between us, we had be so
open and honest with each other and I really wanted to keep it that way.

Once we were back in our room I closed the door and said "Summer, you know I
trust you, right?" Summer nodded and before she could speak I said "I really
need to show you something. But before I do I need you to promise to keep it
between us."

"Luna," Summer said, "I've told you my deepest secret. Now you can tell me
yours. I won't tell anyone."

"Okay, so I got bored and one day it was such a beautiful day that I wanted to
really wear a dress for the first time in my life. So I went to Target and
bought one. I also bought a webcam --"

"Oh no," Summer said, "Did you --"

"No," I interrupted, "I didn't yet. But one morning I woke up early, very
early." I told her the story about how my towel dropped and how I did it on
purpose the next day. Summer's jaw fell on the floor, especially when I said
"Then I went to the library and did this." I showed her the videos, all of
them. "They are just recordings. I didn't broadcast it or anything." Summer
was glued to the screen and watched how I walked around the library naked. She
gasped when she saw what I had done in that chair.

After watching all of the videos Summer just stared at me in disbelieve.
"Wow," was all she could utter. I just looked at her waiting for a reaction
until she finally said "I can't believe you wore a dress of your own fruition.
That's progress, girl." I was stumped by her answer and said "That's all you
take from it? That I wore a dress?"

Summer started laughing "This is just -- if you hadn't recorded it I would
never have believed you. How as it? Exciting?"

"I can't believe I'm saying this, but yes it was _so_ exciting. Especially that
moment I got up real quick? Yeah, the librarian was walking up the stairs so I
had to react quickly. My heart was racing, I was so sure she had seen me."

"I know! That's the part that gets me every time," Summer responded, "I really
like it when that happens. Oh Luna, I think it's so much fun you're into it too
now. I love it, something we can share. Now let's watch that last one again."
As we watched me walking around the balustrade Summer said "You have such a
nice body, Luna. You could make some serious money if you started broad-
casting."

The thought had crossed my mind but something was still holding me back, what I
had done were just recordings. Something totally different from actually
sending those images over the internet. We decided to get some Mexican food in
the city. When we walked back to the car Summer looked at a dress in the
window, it was rather sexy "That dress would look so nice on you." she said. I
looked at the price tag "Yes, if only I had 1500 dollars." We both chuckled as
we continued on towards our room.

The next morning Summer woke me up early. "Luna, wake up." she whispered as I
slowly opened my eyes. "Wake up" she whispered again. "I am awake," I answered
and turned towards her. She sat next to my bed and whispered "Let's get some
coffee." she winked as she said it. I sat up and automatically whispered "What?
It's only 5 in the morning. What?" Summer stood up and took of her nightgown
revealing her naked body. "Let's get some coffee." she whispered again.

"Why are we whispering?" I replied

"I don't know. It's just so exciting. I couldn't stop thinking about what you
told me and I want to do it too." Summer kept on whispering.

I got up and just looked at her "Are you serious?" I said softly.

"Yes, are you coming or am I going alone?" she replied as she opened the door
to peek into the hallway to see if anyone was there. Doing this was way more
risky now most of the students had returned. I was in turmoil, just couldn't
decide what to do. On one hand it was very exciting, on the other it was just
too dangerous. Summer looked back at me from the door "It's empty, coming?"

Summer opened the door a bit further and tiptoed outside, on a whim I took off
my gown and followed her. Together we slowly walked through the hall towards
the central area, after a few steps we started walking normally and Summer held
her hand in front of her mouth to muffle her giggle. I looked back over my
shoulder to see if anyone was there, we kept on walking towards the coffee
machine. In the central area Summer walked around, still softly giggling. Then
she walked over to the window, stepped on the sill and pressed her body against
the glass. "Come on," she whispered, "this is fun. If anyone who walks down
there looks up --"

My heart started pounding as I stepped on the sill next to Summer, the glass
felt cold against my skin as I pressed my body against it. If anyone looked up
they would see two naked girls with their bodies pressed against the glass.
Summer stepped off the sill and walked towards one of the other hallways.
"Always wanted to know where these led," she said as she started to walk into
one.

"Summer!" I whispered loudly, "let's go back."

But Summer didn't listen and I ran after her. We walked the hallway to the end,
took a left and walked to the end of that hallway too. After taking another
left turn we saw another hallway leading to the central stairway, we looked
through the glass of the door to see if anyone was there. When we saw it was
all empty Summer opened the door and we stepped into the stairway, quickly
walking towards the doors leading to our hallway.

With my heart pounding in my chest we got back into our room and Summer started
laughing uncontrollably. "We forgot our coffee," she said through her laughter.
I burst into laughter too and said "Let's get some." I stepped outside again
and walked towards the machine. I got two latte and wished the machine was a
bit faster. When they were done I walked back and once back in the room I
handed one to Summer. "You did know you were still naked, didn't you?" Summer
giggled when she took the cup from me.

"Oh, I totally forgot about that," I giggled. We sat down on her bed and drank
our latte's. As Summer drank her coffee she said "This is just as exciting as
streaming. This is so much fun. I'm so glad I met you Luna. Finally someone who
understands where I am coming from."

I looked at my feet "I don't know. For me it just happened because I was bored
and then I thought about what you had told me and how I should experience it
for myself. You know, for the article. Then I just did it, I can't really
explain why, but I did."

Summer bumped me with her shoulder "I think I just tapped something that was
already there, you just didn't know it yet." I nodded, maybe she was right.
Maybe it was time to be more _girly_. I stood up "I think I'm hitting the
shower. Let's go somewhere now we are up."

Summer nodded "Yes, let's look for a nice spot to make that glamour series I
have to do for class. I would love to take your photo's" I nodded as I put my
gown back on, grabbed a towel and other things I needed in the shower. Summer
did the same and we walked over to the showers. I stepped into a stall and
almost screamed when Summer got in the same one as me. She just gestured for me
to be quiet and locked the stall.

I started the shower and when the water was warm enough I stepped in, let the
water hit my skin and watched Summer step in after me. Our bodies nearly
touched, Summer poured some shower gel on a sponge and started to wash my back.
Feeling that sponge on my skin sent jolts through my body, especially when she
got lower and started to wash my butt. Automatically I pushed my hips backwards
a little. Summer took a step closer and started to wash my belly. I bent my
head backwards and couldn't help moaning when she moved up until she soaped my
breasts.

A thrill went up and down my spine when I felt her breasts touch my back,
Summer pressed her body firmly against mine. After soaping all my body she
dropped the sponge and touched me with her hands. She cupped my breasts and
softly squeezed them. She kissed my neck and softly bit my earlobe. It all just
felt so good, I turned around and our breasts touched. I looked into her eyes
and softly our lips met. We started kissing and I slowly opened my mouth to let
her tongue in. My tongue made circles around hers, she tasted so sweet. I put
my arms around her and pulled her close.

Our hands went all over each others body and I panted as I softly squeezed her
breasts. "Oh Luna," Summer panted, "I wanted to do this for so long. I dreamed
about this and now finally it's happening." She kissed me and pushed her tongue
into my mouth. I kissed her back and let our tongues dance around each other.

Suddenly we heard the door open and we both startled, trying our best to be as
quiet as possible. The girl outside clearly stepped into the stall right next
to ours and when her shower started, Summer kissed me again pressing me against
the wall that separated our stall from hers. She went down on me and started to
suck on my breast, while she was squeezing the other. Her left hand went up my
inner thigh and softly she touched my clit, I felt myself getting wetter as she
started to rub it. I pressed my hand against my mouth to muffle my moaning, it
was all just so exciting. Here I was being touched by my room mate while there
was a girl showering in the stall next to us.

Suddenly she pushed two fingers inside me, I let go of a moan. "Shh", Summer
whispered while she giggled. But I couldn't help it, Summer slid her fingers in
and out of me while she sucked my breasts. I pushed my hips forward to give her
better access and spread my legs a little. The girl in the next stall started
humming a song while Summer pushed her finger deep inside my wet cunt. The
water of the shower felt like needles on my skin as every muscle tensioned up,
I was about to have an orgasm. "Oh yes," Summer whispered in my ear, "come for
me, girl. Come for me." It felt like an explosion went off inside me and my
legs buckled. Summer pressed her hand against my mouth to muffle the groan I
let go. She pulled out of me and my legs gave way.

It took me quite some time to regain myself and to get up on my feet again. The
girl in the next stall stopped her shower and a few minutes later she left the
bathroom. Summer stopped ours and we dried ourselves. After we were ready we
walked as casual as we could back to our room. When the door was closed we
started kissing again, I pushed Summer on the bed and kissed her breasts. With
my hand I spread her legs and placed my hand on her vagina. With my palm I
rubbed her mount and Summer began to moan a little. I felt her getting wet and
finally slid a finger inside her, after a few minutes I added a second and a
third. Summer grabbed my hand and pulled it deeper inside her. I moved my arm
faster and faster until Summer orgasmed.

I lay next to her and we kissed softly, with my nails I slid over her body and
Summer pulled her sheets over us. I pressed my body firmly against hers as I
put my arms around her. We laid there for a while slowly falling asleep again.

After a few hours we woke up again and Summer turned over to me and whispered
"I'm not a lesbian." I giggled and answered "Neither am I, but this still feels
nice." Summer giggled and said "It sure does" as she started kissing me again.
I placed my leg in between hers pressing my leg against her crutch, slowly
Summer began to grind on my leg and she started to moan. She moved her hips
faster and faster on my leg and I pushed my tongue deep inside her mouth. After
a few minutes she tensed up, pressing her body firmly against mine and came
again.

We got up, brushed our hair and got dressed. On the plaza we found a nice spot
in the sun and Summer walked off to get us a latte. When she sat down next to
me she said "You are so beautiful out here in the sun. I still need to shoot
that glamour series for class. Sure you won't be my model? You would be perfect
for it."

I giggled, almost said no but then I changed my mind and said "Sure, why not?"

"Really? We got the rest of the day in front of us. Should we do it? We could
get some of my dresses, I could do your makeup and hair. We could look for a
nice spot, the light is great today." 

I was nice to see Summer so excited and I gave in. We got up and ran back to
our room. She gathered some of her dresses, her camera and other stuff she
needed. I opened my wardrobe and got the red dress I had bought earlier. Summer
saw it and said "I didn't know you had that one. It's nice bring it with you."
I giggled and packed some stuff to take with us.

After an hours drive we saw a sign pointing to _the old Mill_. Summer took a
left turn and after about twenty minutes we parked near a ruined watermill. On
the sign the history of the mill was explained, we took some time reading and
strolled the sight for a while. Not only to look around but also to wait for
the family who were there before us got in their car and left. It gave us some
time to find the perfect spots to take the photo's. I walked back to the car
and changed into my red dress as quickly as I could. When I got out Summer
said "Oh no, lose your bra and panties, they leave such ugly lines." I looked
at her like she just told me someone had died, but finally did as she had
asked. Summer did my makeup "Look, it's a bit heavier than normal, but on the
photo's it will look better."

We walked to the first spot she wanted me to be and I put on the heels she
handed me. I hardly ever wore heels, let alone high ones like these. I stumbled
to the wall she wanted me in front off and followed her instructions on how to
pose. The shutter sounds coming from her camera told me she had taken a few
pictures. "Arc your back a little more," Summer said, "yes, make those girls
show a little more. Okay, look over your shoulder and stare into the distance.
Like that yes." I had to admit I was starting to have fun with it, at some
points I even stared straight into the camera.

After changing my clothes and shoes we moved to another spot, this time I was
wearing a croptop, a skirt and a nice pair of sneakers. We went around the mill
where the waterwheel was and Summer made me pose again. "Just act like we're
selling these clothes," she said, "Just make it look a little more sporty. Like
that, yes. Good." At one point I looked straight into the camera and undid
the first few buttons of my shirt, showing more cleavage. Summer didn't say
anything and kept on shooting. I lifted on side of my shirt just so it still
covered my nipple but was showing my underboob. With the next shot I lifted my
shirt all the way, exposing my breast. Summer pressed the button on her camera
and took the photo.

For the next one I lifted the other side too, pressed my arms together so my
breasts got squeezed a little and tried to look as innocent as possible into
the camera. Summer just pressed the button without saying a word. I took off my
shirt all the way and posed topless for the next few pictures. I leaned back on
the waterwheel making it creek a little. Summer never said a word, just kept on
taking pictures. When we heard another car arrive I put on my shirt as quick as
possible. And we walked back to our car. "I could not believe you actually did
that," Summer said, "taking off your shirt like that."

"You _can't_ use those for your series," I replied, "promise." Summer nodded "I
promise. They are just so nice." Summer looked at them on the small screen on
the back of the camera. The clock in the car indicated it was time to head back
to campus, on the way back we sang along our favorite songs. "We should do this
again sometime," Summer said, "I had so much fun."

"Me too," I replied.

Back in our room I realized I was still wearing Summer's clothes and wanted to
change. "No," Summer said, "they look so good on you. Just keep them, I hardly
wear them anyway." I looked at myself in the mirror and had to agree with her,
on my own I would never had worn anything like this. We had dinner, Summer
spent some time editing the photo's and I opened up my books to study. It felt
nice to be in the same room with her as we did our own thing. When we went to
bed I had a hard time catching my sleep, which went easier when Summer crawled
into bed with me and put her arms around me.

For the next few days Summer worked hard on the photo's and when she showed me
the series she wanted to submit they were just beautiful, I don't know what to
she did but the colors were so vibrant and deep. They looked like the photo's
you saw in magazines and I was totally smitten by a photo she took of my face
close. I knew I was topless at that moment, but the way she had cropped it.
"Oh, you gotta give me a copy of that one," I said, "my parents would love that
one."

The rest of the week I had to study hard and spent some time in the library,
during the moments I was bored I thought back to the time I ran around there
naked and softly giggled. But I didn't have the time so I concentrated on my
studies. It was just a few weeks until we had another round of tests and I
simply had to pass. As I sat there with the books around me I heard a voice
behind me say "You are allowed breaks, you know that right?". I looked over my
shoulder and saw Trevor standing behind me. We followed some of the same
classes together, "I know but I have to get this done," I replied.

He sat down on the chair opposite of me and smiled. "Ah, psychology 101. Tough
class." he said.

"And boring," I replied, "but I really need to get through this, so if you
don't mind."

"I don't mind at all," he said, "it's just you've been her for almost 5 hours
now and the library is about to close. So I thought I walk you home."

"What?" I shouted, "is it that late already?" I started gathering the books to
put them back, Trevor got a few of the too. Together we put them back, when we
were done I gathered my belongings and put them in my bag. Trevor threw is
backpack over one shoulder and together we left the library.

"So," he started the conversation, "what is a nice girl like you doing in a
darn place like this."

"Do those ever work?" I replied.

"I don't know, never tried them before. Just wanted to break the silence."

I giggled and Trevor said "See, they _do_ work."

"Apparently," I giggled, "thanks for warning me. I really lost track of time."

"You're welcome. Maybe we could get a coffee sometime or maybe even dinner?"

I looked at him, he looked so handsome and just a few months back a guy like
him would never ever had asked my out. I felt elated and said "Maybe, just ask
me again someday." I turned around and walked into the dorm. When I was out of
sight I even skipped a little, I couldn't believe a guy like Trevor had asked
me on a date. Me, geeky Luna!

As I entered the room I said "Summer, you won't believe what just happened."
and I told her all about Trevor. Summer looked up from her books "Are you
kidding? Trevor is such a geek, he would have liked you no matter how you
dressed. Don't get me wrong that outfit helps, but he wouldn't have cared."

"You know him?"

"Yeah, he's in my video class. I don't really know what his major is, but we do
have some audio/video classes together and he sure is cute."


