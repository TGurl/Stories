# Our Own Place
_an erotic tale by TransGirl_

Third year was about to start and I was looking forward to seeing Summer again,
we had been apart to spend the summer break with our families. I had been
working at my fathers store again, like I did every year. My parents still had
no idea what I was up to and I wanted to keep it that way for a while longer, I
was still _daddies little girl_.

This year would be different though as Summer had moved out of the dorms as she
was expelled and had rented an apartment downtown. As I drove back to campus I
was a little nervous, I had been informed that I would get a new room mate this
year and I was eager to meet her. We had made contact with each other through
the internet and she seemed like a nice girl, but she still wasn't Summer and
how was I going to explain to her what Summer and I had done the past two
years. I had no clue and a little afraid she wouldn't agree to it at all. As I
got closer to campus I got more and more anxious.

When I arrived I parked the car, went into the office to get my new pass for
the year and slowly walked over to the dorms. As I crossed the plaza I looked
up at the window, it was still dark indicating she hadn't arrived yet. Or maybe
she just hadn't turned on the light, either way meeting her in real life was
going to happen now. I pressed the button in the elevator and waited for the
elevator to rise. A girl came running, shouting "Hold the elevator! Please!". I
pressed the button to open the doors and the girl smiled thanking me. She
pulled her suitcase into the elevator and said "Thank you so much. I'm new,
transferred over and I'm moving in. Ah, that is the floor I need to go to."

I looked at her and asked her "You wouldn't be Nina, are you?" The girl looked
at me and I said "I'm Luna." The girls face lit up and she said "Ah, never
would have thought we would meet in the elevator." Her white teeth were in
sharp contrast with her ebony skin, her brown eyes had a little sparkle in
them. "It might be easier to tell her than I thought" went through my head.
When the elevator doors opened we both got out.

I opened the door for her and pointed to the bed where Summer used to sleep.
"Sorry about the mess," I said as I looked at my desk, "I had to leave in a bit
of a hurry." Nina waved it away and opened her wardrobe. "So you transferred?"
I asked. Nina looked up and said "Yes, I always wanted to come here, but I
couldn't for private reasons. Now there became a spot available and my grades
were thus that they offered me the spot."

Sadness came over me because I knew whose spot she was taking over. Summer had
been caught doing her thing in the library and the administration had expelled
her immediately. But Summer hadn't been sad at all, her photography had taken
off and she made enough money to support herself in her endeavors. The whole
situation had made me a little more cautious, I couldn't afford to be expelled
and from my job at the restaurant I couldn't support myself. Above that the odd
modeling job didn't earn enough either.

Nina finished unpacking and sat down on her bed. "Did you know the girl who was
expelled?" Nina asked, "I've heard some wild stories." I smiled slightly and
answered "As she used to sleep in that bed, you could say I knew her, yes."
Nina apologized "Oh, I didn't want to be rude. I am so sorry." I waved it away
saying "Don't be. It's water under the bridge now. But don't believe the wild
stories they told you, it wasn't as bad as they tell you it was."

Nina stopped asking questions about it but I could feel she had tons of them.
Maybe one of them was how involved in it I had been. "Ah, I don't really care,"
Nina said after a while, "it's her life and she can do with it what she wants.
I don't judge people on first sight, I would like to know them first."

"Well, if you want to I could introduce you to her. She lives downtown now and
she has a studio somewhere. She has contracts with some major magazines and
she's really nice." I said.

Nina looked up and said "I would really like that. I don't know anyone here,
except for you that is." I smiled and thought this might be going to work after
all.

"Come let me show you around campus," I said. We got up and walked outside to
the plaza where I pointed out the different buildings, ending with the Dining
Hall. "Just get pay that fee for dinners," I said, "It's quite good and not
that expensive if you check it." Nina said she would do it and we sat down
beneath the central tree after we bought some coffee. Nina talked about her
previous school and how she felt out of place there. "One time a girl told me
to go back to where I came from," she said, "and when I replied with Tennessee
she got mad." I felt disgusted by her story "If anything like that happens
here, just tell me and I will give them a piece of my mind."

"That's nice of you to say," Nina replied, "but I can fight my own battles." I
immediately realized what I actually had said and apologized. "Oh," Nine
replied, "I didn't mean it that way. I know it comes from a good heart and I
thank you for it." I smiled but still felt bad about what I had said "Just to
be sure, I didn't mean anything by it. I just get angry when someone attacks my
friends."

"So what you're saying is that I'm your friend?" Nina said with a smile.

"If you want to be." I replied with a blush on my face.

"Then you have to be honest with me," Nina said, "I looked up what happened and
in one of her streams I saw you. So, have anything to confess?"

I felt my face turning white. "She knew!" was all I could think. I just stared
at her but couldn't tell how she felt about it. My heart slowly started beating
again before I answered "You saw me?"

"Yes," Nina replied, "and like I said I first want to get to know someone
before I pass judgment. So, again, anything to confess?" Her face was stern and
didn't reveal anything. My eyes went down a little and fell on the little gold
cross on her necklace. Fear gripped my heart and my mouth was dry.

"Oh," was all I could utter, "maybe not here. Too many people around." We got
up and walked back to our room. To me it felt like the walk of the condemned as
we made our way. We were quiet until we got back in the room. I sat down on my
bed and stared at my feet. I had no idea how or where to start.

"Well," I finally started, "You clearly know what Summer does for a living
besides her day job. And on one or two occasions I've joined her streams yes.
At first it was for an article I was writing, but it became addicting and I
started streaming on my own too." When I had started telling her everything
came out, it just felt so good to tell someone. When I was finished I looked at
Nina who still had a very stern face.

It was quiet for quite some time until Nina said "Okay, um, I don't know how to
react if I'm honest. But I respect your honesty. So now it's my turn to be
honest. I'm a good Christian girl and simply can't condone such behavior. That
being said, can I show you something?" I nodded and she sat down next to me,
unlocked her phone and showed me some photo's of her at church, at home with
her mother and then she said "But this is me too."

The next photo was of her with a big black cock in her mouth, the one after was
her spreading her legs with a cock between her lips. She then showed me a video
where she was being fondled by a white man. "He's my sugar daddy," she said,
"he makes it possible for me to be here. We get together twice each month and
he pays tuition, in return he has his way with me."

I couldn't stop staring at her, I couldn't believe this nice conservative girl
next to me was doing this. Nina smiled and said "Surprise!" I felt the urge to
kiss her, but resisted. I had so many questions, but couldn't find the words. 
