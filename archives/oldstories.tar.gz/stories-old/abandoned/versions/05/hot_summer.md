# Hot Summer
_an erotic tale by TransGirl_

## Chapter One
Ever since I was little I wanted to become a veterinarian and now had graduated
I got ready to go to college. My father had a really hard time with it. Ever
since my mother passed away eight years ago it had just been the two of us. He
had never remarried and buried himself in work. Despite him working hard he
always took the time for me. He was at every recital, every game and supported
me in everything. This was just a bit too much for him.

"Why can't you go to a college near home," he had asked. But the college of my
choice was seen as the best veterinary school in the country and the mere fact
that I was accepted to it was an honor on it own. He just had to accept that
his little girl was growing up, there was nothing else to it.

During one of our many discussions I had offered a compromise. "I could live
with uncle Dave. It's closer to college and I would be with family." Dave was
my mothers twin brother and he owned a farm about an hours travel from college.
Even though I had wanted to live in the dorms, this might be something my
father could accept. "Sure, that would be real nice and I could use the help on
the farm," my uncle had said when we asked him.

"Look dad," I said, "I could stay with him for a while and then we can always
see where it goes. I could get my own place, whatever." My father had slumped
his shoulders and said "I know I've got to let you go. I know, but it's so
hard. Ever since we lost your mother it was all up to me to protect you, to
nurture you and this feels like I failed you somehow."

"Oh dad," I whispered as I laid my arm over his shoulder, "you never failed me.
You were always there when I needed you. You came to my recitals, to my games
and when I needed you you always listened. You are responsible for who I've
become, that's all because of you, dad. I love you dad and I can't ever repay
you for what you did for me. But this is something I really want to do, it's
the best school in the country. And on the farm I can get some good experience
too. The best thins however is I won't be in a dorm." I bumped his shoulder and
he chuckled. He hugged me and the deal was made.

Now it was time for me to leave home. My father stood in the kitchen, not able
to speak. I could see the tears in his eyes. "Come on dad," I said, "I will be
back for the holidays and stuff. And maybe it's time for you to get a new
friend, a girlfriend preferably." He smiled slightly and whispered "I couldn't
do that, it feels like I'm betraying your mother."

"What?" I said, "No, no. If she was here she would tell you to move on. To let
her go. It doesn't mean you love her any less, it just means you make space to
let someone else in. Dad, promise me. That Denise is a nice woman, she always
comes straight to you. Why don't you just ask her out one day and see where it
goes." My father just nodded and hugged me. "It's so hard to let you go," he
said, "but you have to. Go, now. Or I might stop you." I turned around and got
in my car. He didn't step outside but I knew he would be watching me from the
window.

After two hours I stopped at a roadside diner and ordered something to eat whie
I rested. To make sure he was okay I texted my father. "I'm two hours in.
Eating in a diner. How are you?" A few minutes later he responded with "I'm
okay. Thanks for texting me. Have good lunch." Twenty minutes later I was on
the road again, the highway was like a straight arrow and it was easy to loose
your concentration. I turned on the radio and sand along to some of my favorite
songs. I stopped three more times before I finally hit the last stretch. My
back was starting to hurt and I started to get tired.

Finally I drove through the small town near my uncle's farm. I looked at the
convenience store, the coffee shop and the small restaurant as I drove by. It
was a typical farmers town. On the outskirts of town was my destination and I
sighed from relieve when I noticed the gate stating _Wild Rose Farm_. I smiled
because those flowers where my mothers favorite, wild and soft pink. I turned
in on the access road and drove towards the house which was barely visible in
the distance. I knew it was a large farm, but every time I was impressed.

As I parked the car my uncle came rushing out. "Luna!," he shouted, "You're
finally here." I got out of the car, stretched and embraced his hug. "Oh my
Lord, do you look like your mother. Come in, come in. We can unpack the car
later, you need to rest and I will grill some steaks. It's so nice to have you
here. How are you?"

"I'm fine uncle Dave," I replied, "just a bit stiff from the trip. I need to
call dad and tell him I've arrived. He's worried sick and will get a heart
attack if I don't call him." I got out my phone and rang my father. He was so
relieved to hear my voice when I told him I had arrived safely. "The house is
so quiet without you Luna. But I know this is for the best. I love you." I told
him I loved him too and hung up.

I looked at my uncle who held up his finger and said "Don't ever call me uncle
Dave again, makes me feel old." He was quiet for a second and continued "Please
sit down on the patio in the back, I will make us some fresh lemonade. Relax a
little, it was a long drive for you."

From the kitchen I walked through the dining room into the very large living
room, the doors to the back yard were wide open and I stepped onto the patio.
It was all just beautiful, in the back I saw bushes of wild roses. The ones my
mother liked so much. "Yes," he said, "I planted those eight years ago. After I
renamed the farm in her honor." I walked over to them and smelled one of the
flowers, suddenly I understood why my mother liked them so much. "How do you
like your steaks?" my uncle shouted bringing me back to reality.

"Medium rare," I answered.

"Just like your mother," he replied, "it's amazing how much you are like her."

I hadn't seen my uncle in a couple of years. I was busy at school and all the
things I did next to school that we hardly ever got around to visit. I looked
at my uncle and tried to imagine how my mother would have looked. My uncle
notice I was staring at him and said "What?"

"Nothing I just tried to imagine how mom would have looked. You being the same
age as her."

"No, I'm five minutes older than her. I was the big brother." he smiled.

I chuckled remembering their _fights_ about that simple fact. He always told my
mom she was the _little sister_ and she replied with "For a whole 5 minutes."

The house was beautiful as I walked in again. I had sat enough for one day and
just needed to stretch my legs. On the ledge of the fireplace was a photo of my
mom standing in front of their parents house. She looked so happy in that
photo. "Yes, that was one year before she married your father. She was so in
love with him that she moved to LA just to be with him. It was also two years
before you were born. She always said there were two best days in her live: her
marriage and the day you were born."

At that moment I missed her very much and pinked away a tear. I hadn't realized
until now how much my uncle had loved his twin sister. I looked around the rest
of the house and was just struck by how big it was and so nicely decorated.

I sat down next to my uncle and asked "When can we unpack my car, I really want
to get settled into my room." My uncle looked at me and said "Before we do,
come follow me." He got up and walked towards the end of the back yard, hidden
by the rose bushes was a gate to a path. We walked down the path until we
reached a small wooden house like you see in old westerns. The planks on the
back were halfway painted and it was clear the house was being restored.

"About half a year ago I expanded to here," he said, "this used to be the house
of Miss Jada. She was the last descendant of the slaves working this farm when
it still was a plantation, as she never married she didn't have any children.
So we cleared the house, donated everything to goodwill. At first I wanted to
take everything down, but the town protested. So now I let them restore it to
it's former glory. It should be finished in about 3 months."

He opened the back door and we stepped in. "Careful, the floor isn't done yet.
On the outside we will make it look old, but inside will be completely updated
to our needs. A kitchen over there, with a small bar. The living area will be
here. This door will lead up to the second floor with a master bedroom, a
bathroom and two other rooms. One could be an office, maybe. As you can see,
the ceiling needs to be restored still. Then in front a patio where you could
sit and look out over the fields. I should be beautiful."

"It sure will," I replied, "but why are you showing me this?"

"Because when it's done," he said turning to me, "You could be the first
tenant."

"What?!"

"Yes," he said, "in stead of paying you, you could move into this house. You'd
have privacy and still have easy access to the farm. We'd be neighbors. Imagine
it a clean canvas for you to decorate."

"On one condition," I said, "I get to name the house when it's ready."

My uncle stuck out his hand and I shook it. "There is still a lot to be done,"
I said, "are you sure it will be ready in three months?"

"Yes, I already told them I had a tenant waiting." he smiled, "so they will
resume work tomorrow. Until then we can store your stuff in one of the sheds
until you can finally move in here."

I looked around and tried to imagine how it would look when the house was
finished and started to look forward to decorating it. We walked back to the
farm and I got my suitcase with my clothes from the car. The rest we stored in
a shed closest to my home to be. After carrying my bags upstairs and started
unpacking, took a quick shower and turned in to get a good nights sleep.

## Chapter Two
The next morning the rays of the sun shining through the window woke me up. My
uncle had told me to take a few days to get to know the town and to integrate
somewhat. "You've earned a short holiday," he had said. I could hear him
working outside, I got up and went into the bathroom. I started to run the
shower and got undressed. After the water was warm I got into the shower to
wash my hair. When I was done I dried myself and wrapped the towel around my
body, another one around my head to cover my hair. I picked up my nightgown and
walked over to my room.

I blow dried my hair while I brushed it and then looked out the window. Down by
the shed my uncle was bent over a tractor doing something technical. He had
taken off his shirt and I could see his muscular torso, his strong arms and I
felt something that I shouldn't feel. I shook my head to dismiss my thoughts
and put on a pair of jeans, a shirt and some sneakers.

I went into the kitchen, found the serial and a bowl to have some breakfast.
After I cleared the table I went outside "Good morning uncle Dave!" I shouted.
He rose up and just said "Don't call me uncle!" and he continued doing what he
was doing. I strolled over the farm and made my way to the horses. I patted
their noses and decided to go riding soon. My thoughts went back to the last
time I went riding with my mom, she was so patient with me. It is then my love
for horses really started.

After spending some time in the stables I got back in the house, washed my
hands, grabbed my purse and got into my car. As I stepped in I shouted "I'm
going into town. Need anything?" My uncle just shouted "No, we're good."

It wasn't a large town, just the main street and a couple of side ones. On the
main street there was a convenience store, a coffee shop and the good will. I
walked towards the convenience store and a bell rung as I entered it. An
elderly woman looked up from reading her book and said "Welcome, welcome. How
can I help?" I just said I was browsing and she said "Ah, new to town?"

"I'm Dave's niece," I said, "arrived yesterday."

"Ah, so you are the famous Luna. He couldn't stop talking about you ever since
you decided to come here. Pleased to meet you. My name is Rosa."

"Pleased to meet you too, Rosa."

I looked at some of the clothes she had for sale and while I was doing that
Rosa said "You should meet Summer, my daughter. She's about your age and she
doesn't really have any friends her age living in town. It would be nice for
the both of you."

I walked over to her "That would be nice."

"She's over at the coffee shop now, she works there two days a week." Rosa said
hinting I should go there. I chuckled "Understood."

"Those dresses are 50% off today," Rosa said, "just today and just for you."

I smiled and took another look at them, they were one-size-fits all and would
be very tight. I never wore tight clothes and couldn't imagine myself in them.
I thanked Rosa for the offer. "The offer still holds for the rest of the day if
you change your mind. They would look very nice on you."

The bell connected to the top of the door rung again as I left the store. I
walked over to the coffee shop and saw a girl my age behind the counter. That
should be Summer, she had long blonde hair and a radiant smile. She wore a
tight shirt on top of a tight pencil skirt. I walked over to the counter "Hi,
I'm Luna your mother sent me to meet you."

"Ah, my mother. Always meddling in my affairs," she chuckled, "I'm Summer,
pleased to meet you. You are Dave's niece right?"

"News travels fast," I replied.

"What do you want, it's a small town." she laughed, "What can I get you?"

"A nice latte would be nice."

I sat down on one of the stools at the counter. "So you work here for two days
a week I heard," I said. Summer looked at me while she was making my latte.

"My mother really doesn't know when to shut up," she said, "Yeah, just for the
summer though. I'm attending college at the end of break, going to be a
beautician and you?"

"Oh, veterinary school."

"A vet? Nice, why a vet?"

"Oh, my mom always wanted to be one. But she never could and when she passed
away I swore to make her dream come true."

"I'm so sorry to hear about your mom."

"That's okay, it's been almost 9 years ago. Did you know she was my uncle's
twin sister?"

"No," she said, "Dave never told us. That explains a lot."

"Explains what?"

"Well, my mother told me that back then he totally retracted himself to the
farm, became somewhat of a recluse. It was my mother and the reverent to make
him come into town again. He always said my mom saved his life."

"Oh wow," I replied, "I never knew that. I knew he took it hard, but this
hard?"

"Ah well," Summer said as she placed down my latte, "water under the bridge,
right?"

"Right, so you have to work all day?"

"Nah, I'm off in a few. Thinking about going swimming, want to come?"

"Ah, no bathing suit."

"Then we should get you one. We could go to the mall in _Freemont_, that could
be fun."

"I've never been there, yes it would be fun."

"Great, let me ask Loretta." Summer went into the back and a few minutes later
she returned. "Okay, Loretta is letting me off the day if I work tomorrow. So
I'm good to go."

About half an hour later I parked the car near the _Freemont Mall_, it was a
very large mall. When we walked inside I was simply amazed by how beautiful it
was inside. There was a large garden with huge plants and trees in the center,
surrounded my escalators leading to the second floor. Everything was just so
nice, through the speakers music was played at a low volume. "Welcome to one of
my favorite places on earth," Summer said.

She took my hand and took me directly to _Woman's World_, a store totally
dedicated to the female needs. It had clothes, shoes, accessories and beauty
related merchandise. "This is my favorite store," Summer said, "It simply has
everything." I chuckled to see her so happy, I never had that feeling. Maybe
because my mother died so young, but I never had a affiliation to fashion. I
even had to beg my father to get my ears pierced. But that was as girly as I
got, except for my long hair.

Summer walked over to the swim wear section and looked at some bikini's while I
went over to the swimsuits. "No, no, oh no. You're not getting one of those.
We're getting you a nice bikini or two. With a nice wrap skirt it would be
beautiful on you. You're a girl and you should use those assets you got. I'm
thinking your dad didn't teach you how to be a woman, but who blames him."

"But I'm comfortable in this," I protested.

"Sure, but you can still be feminine and comfortable."

Summer grabbed a few bikini's and we went over to the changing rooms, on our
way over she grabbed a semi opaque wrap skirt and giggled a little. After I put
on the first of the bikini's I felt really uncomfortable and just popped my
head out the booth. "I really don't know Summer," I said, "it feels so --
naked."

"That's exactly why you should get it," Summer replied, "come on, show me."

Reluctantly I stepped out and Summer's mouth dropped to the floor. "Wow girl,
why are you hiding that body. You're amazing. Take off those glasses and let
your hair go. Just for fun." I did as she asked and said "I'm near sighted, so
I need my glasses."

"Ever thought about contacts?" she asked, "I'm wearing contacts, changed my
life."

"Contacts?" I replied, "Really?"

"Yes, you have a beautiful face and with contacts you can play with your looks.
Use glasses as an accessory instead of a necessity. We can go to the optician
next."

She handed me the wrap skirt and after I had put it on I looked at myself in
the mirror, it did look nice. "But," I said, "I'm afraid the top with move when
you go swimming in this."

"Girl, there's a solution for that too: bikini glue. You just spray it on,
place your top just right and wait for a minute. Your top than sticks to your
skin, it will feel a little uncomfortable at first but after a few minutes you
don't feel it anymore. Your top will stay in place until you actively remove
it."

I smiled and looked at myself again. Seeing myself like this started to feel
nice and comfortable. "Try on the pink one," Summer said. I stared at her for a
second, got in the both and tried on the pink bikini. The triangles were way
smaller and just about covered my areolae. The bottoms were just as small with
only a string to the back. "This is way to small," I said through the curtain,
"I can't wear this in public." Summer popped in her head "Turn around, let me
see."

Slowly I turned and she said "Wow, that looks so good on you. Maybe not that
color, but a darker one would be very nice. Come and look at yourself in the
mirror." Now I was even more reluctant to step out the boot, but I did and saw
myself in the mirror. Although it looked good, I was still apprehensive.

"Let's just get them both," Summer said, "and the skirt with them. Now just
some flipflops and were ready with this part. Wait here a minute, I will be
right back." Summer disappeared and just stood there looking at myself in the
mirror. I couldn't believe I was actually wearing such a small bikini. I took
it off and waited for Summer to return. Standing there naked in a changing
booth, while others were occupying the booth next to me somehow felt exciting.

A few minutes later Summer got back and handed my a very tight red dress. "Try
this on, just for giggles. And I got you these too." She handed me three crop
tops and a couple of mini skirts. "What size shoes you have?" she asked.

"Six, why?" I replied.

"I'll be back."

I took the dress of the hook and put it on, it was very tight and I pulled it
up a little to cover my breasts. I looked at myself in the mirror in the booth
and was a bit embarrassed by the curves it showed. It didn't feel that
uncomfortable though. Suddenly a hand holding heels popped in. "I thought you
might like these."

I sat down and put the shoes on. As I stood up I felt a little wobbly as I
never had worn heels before. Carefully I stepped out to look at myself in the
mirror from a larger distance, instead of a girl a woman looked back at me.

Summer said "You should definitely get that. That one is nice. And those shoes
just complete the look."

I took a few steps and was amazed by how quickly I adjusted to these shoes. For
the first time I felt really feminine. Summer just smiled from ear to ear and
said "I think someone is opening up to this." I just giggled and acknowledged
she was right about that. After the dress I tried on the crop tops and skirts,
in the end we got almost everything. We also got me a new pair of sneakers, a
new purse, some necklaces and earrings, all in all a complete new wardrobe.
Summer dropped a bottle of glue in my basket and we went over to the counter to
pay for it all.

With three bags full of new clothes we left the store. Then she pulled me to
the optician and we informed about contact lenses. The man said I should make
an appointment to have my eyes checked before he could give a good advice. I
made one for the next day.

After the optician we sat down at the coffee shop for a coffee and a snack. We
chatted like we knew each other whole our lives. When we got in the car Summer
said "Although I hate my mother meddling with my affairs, I'm really glad she
did it this time."

"So am I," I replied.

I dropped Summer off at her house and drove back to the farm. My uncle whistled
when he saw all the bags I had in my arms. "Look someone's been shopping," he
said.

"Yes," I replied, "I met Summer and we really hit it off. She took me to
Freemont and we had the best time at the mall."

"Good on you," he said, "It's nice for the both of you to get to know each
other. She's a nice girl."

The next day I went back to the mall for my appointment with the optician. I
walked over to the woman behind the counter to tell her I was there. "Ah," she
said, "yes, Ryan? Can you take over please. Miss, follow me." We walked to the
back of the store and she opened the door for me. "Please sit down," she said,
"I see here you wanted information about contacts. Well, that we can do." She
told the pros and cons of contact lenses and how it all I needed to do.

"Let's do some measurements," she said and asked me to sit down at one side of
a machine while she sat down on the other. "Rest your chin on the stand and try
to keep your eyes open as long as possible." A bright light shun in my eyes as
she did those measurements. After a few minutes she said she was done and we
sat down at the table again.

"Yes," she said as she went over the results, "Contacts are surely possible,
but you could also think about Lasic surgery. What I see can easily be repaired
with such surgery. But it's expensive, in your case it might be around $2000
per eye."

"I don't have 4000 dollars," I replied, "let me think about it."

"Sure, we need to make an appointment in a clinic anyway. Here, this is our
number just call is when you've decided to go through with it. If you still
decide to get contacts you can just come here again."

I walked out the store and felt confused, had no idea what to do. If I did the
surgery I didn't need glasses or contacts, but 4000 dollars? I decided to call
my dad. "Oh hey dad, you got a minute? Yes? Thanks. Look I've been thinking to
get contacts lately and I just left the optician. She told me lasik surgery
could really help me."

"Surgery?" my father replied.

"Yes, she said it would take about 10 minutes and is painless. But the problem
is that it costs about 2000 per eye and our insurance doesn't cover it."

"4000 dollars? That's a lot of money, but do you really want to do it?"

"I'm thinking about it, yes."

"Well, if you really want it than just send the bill to me. I will pay it for
you."

"Oh no, that's too much dad. I can't accept that."

"You're just as stubborn as your mother. She didn't want any help either, ever.
Even when she got sick she didn't want my help. You are the same way. You
didn't want me to pay for your license, didn't want me to give you a car. If it
hadn't been for the trust fund we set up for you, you wouldn't even let me pay
for college, would you? No. If your mother hadn't told you to take it -- never
mind. This time I can give you something meaningful, your sight. So please,
Luna, let me give this to you, please."

I felt tears in my eyes and whispered "Okay dad, thank you." I walked back into
the store and together with the optician we made an appointment for the
following day. The clinic accepted my father paying for it after they had
confirmed it with him.

The next morning I woke up nervous in just a few hours I had to be at the
clinic. I got up, showered, dressed and walked into the kitchen. "Good morning,
nervous?" my uncle asked. I just nodded and poured myself a cup of coffee, sat
down for a few minutes before I had to get in the car for the two hour drive.

I got there in time and sat down in the waiting area. I tried to read a
magazine while I was waiting but couldn't really concentrate on it. After 15
minutes I was called and the nurse guided me into the surgery. A handsome
doctor shook my hand and said "So, they've explained everything about this,
right?" I nodded and he said "Just lay down on the table and we will numb your
eyes. We can start after a few minutes."

The whole process took about 10 minutes per eye and when he was finished he
administered some antibiotics and asked me to close me eyes. I had to lay there
for half an hour to make sure the medicine did it's work. Half an hour later he
ased me to sit up and to read the chart on the wall. I was amazed, the lines I
could never read were so clear now. "Let me take a look," the doctor said and
looked into my eyes, "it all looks very good. Now, just use these drops for the
next week, 3 times a day 2 drops per eye and all should be good."

I thanked him and he confirmed where he could send the bill one more time
before I left. Sitting in my car I was still amazed, I had my glasses in my
hand and still everything was sharp. On the drive home I stopped a few times
just to look at the landscape, for the first time in a very long time I could
see everything without my glasses.

When I got home my uncle was amazed too, he pointed to several things far away
and every time I read the words he said "Simply amazing." I called my father
"Dad, everything went okay. Yes, it's more than okay. I can see everything,
don't need my glasses anymore. Thank you so much, dad. This has changed my
life. Thanks for insisting."

"You're so welcome baby girl," he said, "It's the least I could do. Thank you
for accepting my help."

For the next week I kept to my regime of taking two drops in each eye three
times a day. During the return visit the doctor said that it all was healed and
I could stop with the drops. "I give you a clean bill of health," he said, "at
least for what your eyes are concerned."

I felt elated when I drove home again. "Home?" I thought, "Did I just call the
farm home?" I giggled and thought "Well, if I'm going to live there for the
next few years I might as well call it home." I chuckled and enjoyed the drive. 

For the next couple of weeks it still felt a bit weird to not put on my glasses
in the morning. And for the first time in my life I needed to get sunglasses as
I normally would have darkening lenses in my glasses. It all was so new to me.
Just as I sat down in the kitchen for breakfast my phone rang.

"Hey Summer," I said, "how are you doing?"

"I'm fine, haven't seen you in a while. Thought I'd check if you still like
me."

I laughed and answered "Oh, no. I hate you so much. Are you working today?"

"No," Summer replied, "why?"

"Can I come over real quick? I've got something to show you."

"Can't wait."

Twenty minutes later I rang the doorbell and Summer opened the door. She
noticed the lack of glasses immediately and shouted "You got contacts! Nice."

"No," I said, "no contacts. Surgery, laser."

"What? Wow, you're looking good girl. Come on in. Mom? Luna is here."

When her mother walked into the hallway I knew where Summer got her looks from,
she was a gorgeous woman. "Luna. So nice to finally meet you. Summer talked so
much about you. Come in dear."

We went into a very nicely decorated living room and I said "It's so nice to
meet you too Mrs Davis."

"Oh, just call me Violet. I haven't been Mrs Davis since that good-for-nothing
husband left us. Want some lemonade? I made it fresh last night."

"Yes, please. Thank you so much, Mrs -- sorry Violet."

"Yes," Summer said, "my dad left us when I was two. I've never known him until
I started to search for him. When I found him he blatently told me he didn't
want anything to do with me, he even said he wasn't sure he was the father at
all."

Violet handed us our glasses and sat down across from us. "Yes," she said, "I
never hid the fact that I wasn't always faithful to her father, but at the time
she was concieved I was. Two years after her birth he thought I was cheating
again, just because I was close to a man at work. He packed his bags and left.
I never got to tell him that the guy I was close with, and still am, is as gay
as they come." Violet chuckled and said "At the time I didn't know that him
leaving us was one of the best things he could ever do for us."

"Yes," Summer continued, "my mom never talked bad about him. She told me what a
good father he was to me, how he sang me to sleep and comforted me when I
cried. I was so torn when he told me he didn't want any contact. But I got over
it and now it's just as it is. If he doesn't want it, why should I?"

"Wow," I said, "I thought I had it hard when my mother passed. But this is a
whole other ballgame."

"Oh yes, I felt so sorry when Summer told me," Violet said, "So your dad is
alone now?"

"Yes, that was the hardest part of coming here. He doesn't have anybody there
now and I'm afraid he's going to burry himself in work all over again. Just
like he did when my mom died."

"Well, we could invite him over one day," Violet said, "Maybe to the dance next
month. It's a tradition it's opened with a father-daughter dance."

"That would be a great idea," I replied, "I will make sure he comes."

"And who knows," Violet responded with a smirk on her face, "maybe even I could
get a dance out of him."

I laughed and replied "It would be a mirracle if even I could get one."

"Oh, before I forget," Summer shouted, "there's this party tonight and I wanted
to ask if you would like to come too. You could wear that red dress we bought
the other day."

"Oh, I don't know," I protested, "a party? I don't really know anyone here."

"That's exactly why you should come. Just get your clothes, we could dress here
and I could do your hair and makeup. It would be really fun." I gave in and
agreed to come back that evening at six.

The rest of the day I spent feeding the horses, brushing them and packing my
clothes for the party. When it was time I drove to Summer and we got ready for
the party. After I had put on the dress, Summer did her magick and when I
looked in the mirror I was stunned by the result. I didn't look like a girl
anymore, I was a woman. Summer got herself ready too and we were off to the
party.

We got in the car and drove to the next town. We stopped at a house and the
music told us the party was in full swing. Summer walked in the house and
greeted some people. "Hey, this is Luna. She's new around here." I greeted some
of them and we walked towards the table with the drinks on it. As I was going
to drive us back I got myself a soda, Summer got herself a wine. I talked with
a few people and saw Summer enjoy herself on the improvised dance floor.

When the birthday boy walked in Summer hugged him and introduced him to me.
"Michael this is Luna, Luna Michael." she said. "Pleased to meet you Luna,"
Micheal answered, "and welcome to my party." We talked for a while and he was
very nice to me. When he asked me to dance with him I accepted the invitation,
I had never done anything like this in my life and really enjoyed myself.

After about half an hour I didn't see Summer anymore, I excused myself and
started looking for her. Finally I went up the stairs and gasped when I looked
in one of the rooms. Summer was laying half naked on a bed with a boy on top of
her, he was sucking her breasts and when she looked over and saw me she just
smiled. With her left hand she reached into his pants and she was clearly
touching his penis.

I held my hand in front of my mouth when I saw her guiding it inside her, I
just stood there watching them having sex. I just couldn't stop watching, it
was like I was hypnotized. Summer looked at me again, with her hand she invited
me to come closer. She patted on the bed to indicate I should sit right next to
her. In a daze I did and could clearly see him sliding in and out of her. I
could hear her moan, she looked at me and said "He's so big, Luna, this is so
good." I felt myself getting aroused, just couldn't believe what I was seeing.

The boy reached for my breasts and I slapped him away. "It's okay Luna," Summer
panted, "just relax and let it happen." When the boy reached out again I
stormed out the room. In a daze I walked back to the car and just sat in it. I
texted Summer I wanted to go home and waited for her. After about 10 minutes
Summer got in the car and said "What's wrong?"

"I can't believe you just did that?"

"What? Having fun?" Summer shouted, "It doesn't mean anything. We're just
having fun, you really have to lighten up a little."

"Lighten up? Lighten up? You were about to let him grope me!"

"Sorry about that. I thought you wanted it too, at least you looked like you
wanted it. I'm so sorry."

"Did I? Really? What gave you that impression?"

"Oh, just the way you looked at his dick. You looked like you wanted to touch
it, your mouth was a little open, you just wasn't drewling. But, to me at
least, it was clear you were getting aroused by watching us."

I sagged back in the chair, stunned by what she just said and whispered "I have
to admit it did something with me. It's just that I've never done anything like
this before. This was my first time at a party like this. I just felt so
cornered."

"And as I said I am so sorry. We good?"

I nodded and said "Yes, we are good."

"Want to go back inside?"

I said yes and back inside Summer got herself another wine and I sat down on
the couch, still a bit stunned by everything that happened. Michael saw me
sitting there alone and sat down next to me. "Everything okay?" he asked. I
looked at him and said "I don't know. This is all so new to me."

"I could see that," Michael said, "Just remember it's all about having fun.
You're only young once and that's why we party."

I thought about his words and said "You might be right, but still it's all a
bit of an overload for me. Summer there, she's having fun. She can let go,
that's something I can't do. There's always something holding me back."

"I know what you mean," Michael said, "that's why there's alcohol."

"Maybe," I replied, "but I'm the designated driver."

"Ah," he said, "you could also choose to sleep over."

I turned to him and suddenly realized what he was doing. "No," I said, "I
can't. If I don't come back home my uncle will come here and drag me away. And
rest asured you don't want that to happen. Trust me. If you think fathers can
be protective, you've never come across an uncle and the daughter of his twin
sister." I got up and told Summer I wanted to go.

On the way back I told her what Michael said to me. "Is that all?" she asked,
"I don't get it. Why was that so offensive?"

I said I didn't know but it just didn't feel right. We arrived at her home and
in her bedroom Summer said "Luna, I really like you. I might even love you a
little, but you really need to loosten up a little and have some fun."

"You're right," I said, "but it all just went too fast for me. As I said this
all is new to me. Me dressed this way, with makeup and stuff. I never been like
this, the parties I went to were tame compared to this."

Summer hugged me and said "It's alright, I'm not angry. At least I got a little
fun, right? Right?" She bumped me and I giggled "You could say that again."

A few minutes later I got in the car and drove home. When my uncle saw me walk
in wearing that red dress he whistled. "You clean up nicely girl," he said with
a smile. I had totally forgotten I was still wearing the dress. "Ah yes, forgot
about that."

"How was the party?"

"Good I guess."

"What happened? Did some boys bother you?"

"No, nothing I couldn't handle. Ah, just let it go. I'm going to take a shower
and go to bed. I'm tired."

As I stepped into the shower my thoughts went back to that bedroom and how
Summer was having sex with that boy. I could see it as clear as day and without
thinking I started to masturbate. As I started to moan I suddenly remembered
where I was and stopped. I shook my head and got out of the shower. When I
finally laid my head on my pillow I smiled a little when I thought about Summer
in that bed.

The next morning I woke up when I heard the shower. I looked out the window and
saw it was a beautiful day. I threw on a long shirt and went out my room, as I
walked down the stairs I could see the door of the bathroom being ajar. Through
the slid I could see my uncle under the shower. I just stood there staring at
him until he turned around and I saw his lid between his legs. I turned my head
away and quickly went down the stairs.

The moment he walked into the kitchen I looked down at his crutch and the image
of him under the shower came flooding back. I quickly turned my head away
saying "Good morning." Dave just smiled and said "Morning niece. Any plans for
today?"

"I might be going over to Summer later."

"Why don't you ask her to come over here. I'm going to _Freemont_ to get some
supplies for the renovation. I also need to get some other stuff, I might be
home for dinner at the earliest."

"Yes, I might do that."

Dave poured himself a cup of coffee and some toast. He sat down at the kitchen
table and browsed the news on his phone. I walked upstairs and got in the
bathroom. I looked at myself in the mirror and whispered to myself "Get it out
of your head girl. It's wrong to think like that." I started to run the water
and took off my shirt. Just as I wanted to step in I changed my mind and opened
the door a little.

I stepped into the shower and started to wash my hair. After a few minutes I
felt like I was being watched, I turned my back to the door and smiled a
little. I bent my head backwards and slowly turned towards the door. As I
straightened my head, I moved my hands towards my breasts and massaged them a
little. I grabbed the shower gel and poured it on my skin, with a sponge I
started to wash my self, paying special attention to my boobs. When I turned
around again I couldn't help myself to smile. It was all just so exciting, I
couldn't believe how much I liked it.

After a few minutes I heard my uncle shout "I'm off. See you tonight." His
voice clearly came from downstairs and I was a little confused by it all. I
decided the feeling of being watched had all been in my head and chuckled that
I even felt that way.

As I got out of the shower I looked out the window and saw my uncle's car was
gone. As I stood in front of my wardrobe I wasn't sure what to wear. I decided
to wear a bikini as I was all alone for the day. When I walked down the stairs
I decided to get some sun in the back yard.

I got a lawn chair from the patio and placed it on the grass. As I laid down
my thoughts went back to what I had seen in the shower. I just couldn't believe
I even had them. Feeling very confused I got up and walked into the house. I
got my phone and called Summer.

