# Hot Summer Nights
_an erotic tale by TransGirl_

## Chapter One
My parents weren't the strictest there were, but they made sure both my brother
and I grew up to be responsible people. Sure we went to parties and stuff but
we never broke their trust in us. I think this is because they laid a large
part of the responsibility with us that we made sure we kept that trust. Even
when my brother went to college he didn't break that trust my parents had
bestowed upon him. Now it was my turn to show them I was trustworthy too.

That is maybe part of why my choices were so hard on them, but ultimately they
saw how happy I was with the choices I made and that the people who I
surrounded myself with were doing their best to make it as safe as they could.
But it has been a hard road to get there.

It all started after I graduated high school. As always I would spend my summer
break at the farm of my uncle Dave. Ever since I was little I loved going there
for the summer, he had dogs, chickens and the best horses. During one summer I
helped him when a new foal was being born. When she stood up for the first time
he said "Well, what's her name?" As I was totally into _the little Mermaid_ at
the time I chose _Ariel_. "You know that now you've named her, she is your
right?" my uncle said. I was elated, I owned my own horse! During the next few
summers I watched her grow up and now she was a mother of her own.

But that wasn't the only thing that excited me about visiting my uncle. Near
his farm was what the locals called _the swimming pool._ It was a large body of
water, just within the woods. Every child from town went over there to go
swimming and to swing of the large tree only to land in the middle of the pond.
It was just a magical place for me as a city girl, over there I could just be
myself and let it all go.

This would be the first year I would go there on my own, in my own car that got
as a present from my parents for graduating. The six hour drive made me a bit
nervous, but I was also excited to go. My father had showed me the best route
to follow on the map, when he was ready I told him I knew how to work the
navsat in the car. He almost blew a casket and I ran away laughing. My mother
had a little more problems with me going on my own, but she knew it was time to
let me go as I would be moving to college real soon and this was just a first
test for her.

While I was packing for the trip to my uncle she came into my room and just
hugged me. "Oh Luna, why did you grow up so fast?" she said with tears in her
eyes. She had a serious case of _empty nest syndrome_. I just hugged her back
and said "I will be back in a few weeks." "Yes," she said," I know, but then
you're off to college. Can't you just go to community college here, so you can
stay with us?"

"Mom!", I said, "I didn't do my best at school to go to community college if I
am accepted to Cal Sci." She just hugged me harder and then said "I know, I
know honey. Just text me on the way over, when you arrive. No, scrap that. Text
me every 10, no 5 minutes. I want to know where you are every second. Oh, I
love you so much, Luna."

"I love you to mom, but that will not last long if you keep squeezing me like
this. I'm suffocating." I chuckled. My mother let me go and apologized. She
then helped me packing and we chatted like we had always done. "Oh, when you
see that good-for-nothing brother of mine," she said, "tell him to call me once
in a while." They were a lot alike my mother and her brother, I suppose the
same goes for my brother and me, there was just one difference: both my uncle
and me were the younger ones or the pairs.

When my phone rang, the screen lit up stating it was _scrappy_. I had given my
brother that nickname when we were younger and somehow it sticked. "Hey
brother," I said. "Hey sis, is mom around?" I held up the phone and said
"Someone needs his mommy." My mother chuckled and took the phone from me and
walked into another room while I continued packing. I got my camera, laptop and
everything else I needed for my biggest hobby: photography.

My mom came back in the room still talking to her son "No, you can't. Because
your father and I are going with Luna to California. What do you mean who's
Luna? Oh you. Darn it. Now say goodbye to your sister. Why? Because your mother
says so, that's why." She handed me the phone and all I heard was "Goodbye
sis." and he hung up. I didn't even get to say something back to him. So I
dialed his number and when he answered I said "Goodbye brother" and hung up
again. My mother chuckled and said "Some things never change."

The next morning it was time to go. My father helped me pack the car and I said
goodbye to my parents. The waved until I turned the corned and disappeared from
their sight. My navigation showed me the road to follow and soon enough I
joined the highway out of town. I turned on the radio and started to sing along
with my favorite songs. The weather was really nice and I made decent progress. 

Three hours in I stopped at a roadside diner to get something to eat. I sat
down in one of the booths and placed my order. While I waited I called my
mother to tell her where I was and that everything was okay. "Nice, thanks for
calling," she said, "Oh, look in the front of your purse. There's a small
present for you." I checked my purse and found a prepaid credit card. "What's
this?" I said. "That's for your gas," she said, "there's 2000 dollars on it. In
case you need repairs, but mostly it's for gas." I was stunned and thanked her
"But it really isn't necessary mom, you know Dave pays me for working on the
farm." Dave hated to be called uncle so I only said it to tease him.

"Yes, I know. But we gave Joshua the same when he moved to college. We gave
yours just a few weeks earlier." she said, "now have a good lunch and call me
when you get there." I hung up and ate my burger with fries. After lunch I
decided to change my navigation settings and turned off _using highways_. I
wanted to see more than just the highway. This meant I would arrive an hour or
two later, so to be sure I texted my uncle to tell him so. He texted back that
he would be waiting for me.

Leaving the highway was one of the best choices I had made on this trip, I
stopped a few times to take a photo of the landscape, especially when I drove
through the desert with it's brown and red colors. It was just all so
beautiful. I drove through small towns, stopping at a convenience store in one
of them to get a soda. I really enjoyed driving along the country roads.
Finally I arrived in _Highland Falls_, the small town near my uncle's farm. I
saw the school, the convenience store and the local police station. The farm
was on the outskirts of town and on the last intersection I turned left. Just a
few more miles.

Finally I parked my car near the house and my uncle came running out the front
door. "Luna!" he shouted, "You're finally here. Your mother has called a
million times to check if you were here already. Please call her so she stops
bothering me." I laughed, got my phone and talked to my mother. "Yeah mom,
everything is fine. I just turned off the highway and it was just beautiful
mom. I took some nice photo's and saw some awesome small towns. It was the
best. Okay, love you too mom." When I hung up my uncle hugged me and took me in
the house.

"Oh yes," I said, "My mother told me to tell her good-for-nothing brother to
call her more often. So there, job done."

"Oh, did she now," Dave chuckled, "well, if you're back you can tell this
sticky nose sister of mine to get off my back." He poured us some freshly made
lemonade and we sat down at the kitchen table. I showed him the photos I had
taken along the way and he was simply amazed by them.

"So, you decided to go to Cal Sci?" he said.

"Yes, they have an awesome multimedia program," I replied, "not only audio,
photo and video, but also digital forensics and things like that. In the first
year it's all round and then you can specialize in one of them. It's just the
best."

"I have no clue what you are talking about, but I know Cal Sci is a good
school. Your mother wanted to go there once. Did you know that?"

"No, she never told me."

"Well, it's a long story. Maybe one time. Let's get your stuff from the car
and get you settled in. Your room is waiting."

When I came to stay with him the first time he had given me a room and ever
since then it was mine. I was really fun to return there every year and see
what I liked a year earlier. I started to laugh when I saw the boy band
posters on the wall. I was so over that and made a mental note to remove them.

On my laptop I had a whole series of the room from the moment I started taking
photo's. To continue that tradition I took a photo from the room as it was this
year too. It was nice to see the changes the room went through year after year.

I was unpacking my suitcases and bags as Dave brought the last ones up. "So, I
guess the room will change again?" he said. I nodded and said "I might even
paint the walls, it that's okay? Make it a but more mature."

Dave nodded and said "That's a good idea. When I have friends over the men do
have a little problem sleeping in a girls room." He chuckled as he walked out
and he said "Dinner in twenty, I'm grilling steaks." I continued unpacking and
placed my laptop on the desk near the window. As I looked out I saw another car
driving up. A beautiful blonde woman got out and walked to the front door.

Downstairs I could hear Dave say "Hey, yes she's here. Upstairs in her room.
Okay, sure." I heard footsteps coming up the stairs and then she appeared in
the doorway. She looked at me with a radiant smile and said "Hi, I'm Summer,
nice to finally meet you. So you are that mysterious niece of Dave."

I shook her hand and said "Nice to meet you too. Sorry, but he didn't tell me
anything about you."

"Typical," she said as she sat down on the bed, "I'm Summer and I just moved
here from LA. I'm a teacher at the local high school and I met Dave a few weeks
back. We became friends and now he invited me to come over to meet you."

"Oh," I replied, "just friends?"

"For now," Summer laughed, "for now."

I chuckled and started to like her. "Well, I'll leave you to it. I think you
want to freshen up before dinner." She got up and walked out. I went into the
bathroom and freshened up a little. Then I changed into a comfortable dress and
my flipflops. When I walked onto the back patio Summer sat there with a glass
of wine in her hand. She handed me a glass and said "You're 18 right? So here
you are." She poured me a little wine, took a sip, acted like I didn't like it
and said "That's nice, now a decent glass please."

Summer chuckled and poured me a normal glass. "I like her Dave, spunky." she
said. Dave just nodded and said "If she drinks like her mother than I need to
get some more wine tomorrow." I giggled and said "Oh no, I enjoy a wine but one
is more than enough for me."

During dinner Summer convinced me to have another glass of wine and we had a
really good time. "So I hear you like photography," Summer asked. I nodded and
said "Yeah, I got a camera for my 13th birthday and ever since then I loved it.
But I'm branching out to video too. That's one of the reasons I want to go to
Cal Sci."

"Wow, that's a good school," Summer said, "I went to Brown, more because my
father wanted me to. I had a good time there, but it wasn't my first choice."

"And then there's me who went to farmers college," Dave chuckled, "But hey see
what I own now." We laughed and cheered to him. After dinner it was time to
visit the stables. Summer joined me as I greeted Ariel, who whinnied loudly
when she saw me come in. "She knows you are here," Summer said, "that's
amazing. She looks like a totally different horse." I nodded and just had tears
in my eyes as I patted her nose. "Yes," I whispered, "I am here. I haven't
forgotten about you. I never will. I love you so much, Ariel."

"It so nice to see, the love between a girl and her horse." Summer said as she
did her best to keep it dry. I patted Ariel, grabbed a brush and started
brushing her. Ariel just kept on whinnying. I refreshed her water and gave her
some new hay. "I will be back tomorrow morning," I said to her, "Goodnight
Ariel."

Summer walked over to one of the other stables and I said "That's Sebastian,
Ariel's son." I said. I was amazed by how big he had gotten. Summer replied
"Yes, I know. I love riding him."

"You ride? Maybe we could go riding some day." I said and Summer nodded her
head saying "I would like that." We walked back to the house and sat down on
the front patio overlooking the farm. "I love being here," Summer said, "It's
so peaceful. I really had to unwind when I moved here. I was so used to the
pace of LA, but out here it's just way more relaxed. It's -- I can't really
explain it, it's just magical to me."

"Yeah, I feel the same. That's why I come here every year, not only to help
Dave out as he's busy harvesting and stuff. At first I took care of the
chickens, then the dogs and finally the horses too. Now he leaves the animals
up to me as he's on the fields. It's hard work, but I like it."

"That leaves you no time for fun," Summer said, "when are you having some fun?"

"Oh, cleaning the stables takes an hour or two. Feeding the chickens is ten
minutes and the dogs take even less time, if I don't loose the time playing
with them." I giggled, "So I get up at 6 or 7, do my chores and the rest of the
day it's up to me. I also do things around the house from time to time. This
year I will be changing my room once again. I want to make it a bit more
mature."

"Oh, can I help? I love decorating." Summer said.

"Sure, I can use all the help I can get." I replied.

"Oh there you two are," Dave said as he appeared in the door, "I was wondering
where you were. It couldn't be the stables anymore. Looks like you two are
getting along." He smiled and sat down next to Summer. It was something in his
eyes that betrayed him to me: he felt something more than just friendship for
Summer. And I knew Summer felt something form him too. I had to makes sure they
sealed the deal during the weeks I would be here.

It was getting dark when Summer went home. We waved her off and Dave said he
would take a shower. After I cleared everything I went up the stairs and
noticed the door to the bathroom wasn't quite shut. I walked over to close it
when my eyes fell on my uncle in the shower, the glass wasn't quite fogged up
and I saw his muscular body. I knew I shouldn't but I couldn't stop watching,
when he turned around I quickly turned away and pressed myself against the
wall. Very carefully I peeked in again and my eyes fell on what he had between
his legs. Now I had seen them before, but never this big. I turned my head away
and very quietly made my way into my room.

When I closed the door behind me I guess he must have heard it as I heard the
bathroom door close and being locked. "I guess he's not used having someone
else in the house" I thought. Laying on my bed I couldn't get rid of what I had
seen and my head starting going places where it shouldn't go. When I heard my
uncle get out of the bathroom I waited for a few minutes until I heard him
going down the stairs. A few minutes after that I grabbed a towel and went into
the bathroom. Brushed my hear and teeth, stared at the shower where I had seen
my uncle just a few minutes before. I put my hair in a bun, dropped my dress
and started the shower.

Just before I stepped in I walked over to the door and opened it just enough so
if it were the case my uncle could see me. With a smile on my face I stepped
into the shower and started washing my body. At a certain point I heard my
uncle say "Please close the door." I shouted back "Oh sorry, I was sure it was
closed. I'm so sorry." I turned my back to the door and couldn't help but
smile. I wondered if he had seen me and felt really excited by the idea, more
than I should do.

The next morning my alarm woke me at six and I heard my uncle getting in the
bathroom. When I peeked around the corner of my door I was a little
disappointed to see he had closed the door. I waited for him to finish and then
got up, took of my gown and bound a large towel around me. I stepped on the
landing just as he was coming out his room. I acted like I was startled, said I
was sorry and rushed into the bathroom. Once in there I held my mouth not to
burst into laughter. I knew he always saw me as his little niece, but now he
had seen me as a woman. I stepped under the shower and got ready for the day.
As I was brushing my teeth I got my birth control strip from my bag, looked at
it and decided to put it back. I finished my morning routine and just as I
wanted to leave the bathroom, I grabbed the strip and swallowed the pill.

Back in my room I looked out the window and it promised to be a wonderful day.
I put on my old jeans and a simple shirt. In the kitchen Dave was preparing
breakfast and asked if I wanted some coffee. "Oh yes," I replied, "cafeine.
Please." We enjoyed breakfast and he said "I will be on the fields all day, if
you need me you know the number. I will try to be here around noon for lunch,
maybe we could have it together." I nodded and said "That would be nice."

He got up and wanted to clear the table, but I said I would do it. He looked at
me and said "Okay, thanks." He walked over to the shed where he kept his heavy
machinery and a few minutes later I saw him drive off in one of them. I walked
over to the chicken coop to feed them, then I checked on the dogs. Gave them
fresh water and fed them. Then is was time to clean the stables, feed the
horses and give the fresh water too. It was almost 11:30 when I was done for
the day and I decidedm to treat my uncle with a nice lunch.

I baked some croissants in the oven, tossed together a nice salad, set the
table and then quickly went upstairs to my room. I put on a bikini as I wanted
to go swiming, bound a long slightly translucent skirt around my waist and
completed the look with a crop top. I checked myself in the mirror and smiled
when I saw the result. I returned to the kitchen just in time to take the
croissants out of the oven, put them in a basket and placed it on the table.
Now I had to wait for my uncle to return. I sat down at the table and was about
to text him as he walked in all dusty from the field.

He smiled when he saw the table and quickly freshened himself at the small sink
in the pantry. He came in again and said "This is a treat." I nodded and sait
"Just sit down. Coffee?" He nodded and as I poured him one I could see him
looking at me. I put just a small extra hop in my gate to make my boobs bounce
a little more. As I did so I couldn't believe I was actually doing it, but I
just couldn't help it. "Orange juice?" I asked and poured two glasses. When I
sat his down in front of him I bent over a little more so he could see my
cleavage and then I sat down next to him. I could see he was a bit
uncomfortable with it all and I thought "Mission acomplished, he's seen I am a
woman now."

After lunch he got up to go back to work. "This was nice," he said, "but don't
do it every day, please. I don't really have the time for it. But thank you."
He turned around and went back to work. After clearing the table and starting
the dishwasher, I walked over to the _swiming pool_. I could hear the sounds of
children playing from far away.

When I arrived I found a nice more quiet spot, laid down my blanket and watched
the children play in the water. The more daring were swinging from the tree and
let go in the middle. I enjoyed watching them have fun. After about half an
hour, I took off my skirt and got in the water just to take a few laps. When I
got out I saw Summer approaching. "Oh hey," she said, "I was hoping to find you
here." She spread her blanket next to mine and we laid down. We chatted for a
bit and watched the children play. A few boys walked by and I was sure they
were looking at us.

"If I only were a bit younger," Summer said as a muscular boy walked by. I
giggled and she just smiled. Then she said "Oh my, I am sure he's looking at
you. Turn on your back, lean on your arms and arc your back a little. Make
those girls pop a little." I giggled and did as she said. "Yes, he saw them and
he doesn't know where to look." I burst into laughter, it was nice to have
someone like Summer. We stayed there for a while until she said "I know a more
quiet spot. It's not far from here. Want to go there?" We got up and I followed
Summer. We walked over a small path until we came to a clearing. There was a
smaller pond and there was nobody there but us. "Come," she said, "I know the
perfect spot."

A few minutes later we arrived at a spot that was rather well hidden from view
and we laid down our blankets. I placed my bag next to me and lay down, to
protect me from the sun I rubbed some sun block on my body and started bathing
in the sun. Summer did the same and we just enjoyed being there, there was no
need to talk. At some point I heard Summer say "I think we have an audience.".
I wanted to look around but Summer said "No, just ignore it. Let them watch,
it's all okay."

I giggled softly and couldn't believe I was allowing this. Just a few minutes
later a boy walked up to us and said "Ahum, excuse me." I looked up at him and
he continued "I couldn't help but see you here. Um, well, it's just that those
bushes are poisoned ivy and you both are almost touching it. So, I guess, I
just wanted to warn you. Okay, well that's it. Bye." And he rushed off.

Summer shouted "Thanks for the warning!" then turned to me and said "He just
wanted to get a better look." I burst into laughter, but we did get a little
closer to the water. After another 15 minutes Summer said "I'm getting bored,
let's do something else. Up for it?"

"Up for what?"

"Anything but this."

We gathered our things and walked back. "My car is just over there," Summer
said and we got in. She drove back into town and went into her house. Once
inside the cool air felt so good. "Long live air conditioning," I said. Summer
agreed and asked if I wanted a soda. We sat down on her couch and I asked what
she wanted to do. "Ever since I first layed my eyes on you I wanted to do
this." She leaned forward and kissed me. I shrugged back and just stared at
her. She took the glass from me, leaned over and kissed me again. Her kisses
felt soft and gentle, I squeeled as I felt her hands touch my breast. "Shh,"
she said, "just let it happen." We kissed some more and then she opened her
mouth slightly and pushed her tongue inside mine. Our tongues met for the first
time and I started to pant a little.

Then I lost myself and started kissing back, my hands in her neck, pressing my
mouth firmly against hers. Summer put her hand underneath my top and pinched my
nipple. I moaned and didn't want her to stop. She leaned back and said "Oh,
finally. You are so sexy and beautiful, I just wanted to kiss you when I saw
you in your room." She kissed my neck, then my shoulder and slowly made her way
down. When she kissed my nipple I moaned loudly, especially when she bit them
softly. A thrill went down my spine when her hand touched my crutch.
Automatically I spread my legs a little. She procedeed to go underneath my
panties and with her middle finger she touched my clit. I pushed my hips
upwards and felt her hand glide over my slit, her middle finger in between my
lips and I started to breath heavily.

Summer started into my eyes and the slid one finger inside me. "Oh," she said,
"someone likes this." She pushed another finger inside me and I spread my legs
wider. She started rubbing my clit with her palm as she slid her fingers in and
out of me. Then she got up, pulled my panties down and I took off my top. She
undressed to and we laid down on her couch naked. Her hands went all over my
body and mine over hers. We kissed and I kissed her everywhere, grabbing her
breasts as I sucked on them. Then she went down, looked me in the eyes as she
touched my clit with her tongue. I groaned as she did so and thought I would go
insane when she started licking my vagina. She pushed her tongue inside me as
far as she could and I panted "Oh yes, lick me, eat me. Oh yes, yes, right
there, don't stop, don't stop, I'm almost there, yes, I'm coming, oh my God,
I'm coming, don't stop." I grabbed her had and pulled it closer to me. I wanted
her tongue inside me as deep as it would go, then I had a huge orgasm. All my
muscles contracted and my whol body tingled.

Summer stopped what she was doing and slowly came up to my mouth, she pressed
hers firmly against mine and I put my arms around her. Pressing our breasts
agains each other. I rolled her over on her back and slowly went down on her. I
stared into her eyes and started licking her pussy. I had never done it before
and it tasted so good. I pushed my tongue deep inside her and licked her,
sucked on her clit until she came too. Afterwards I laid down next to her and
we kissed, stroking each others hair.

"Oh Luna," she said, "that was so good. You must have been with a girl before."

I shook my head and said "No, never."

"I can't believe it. This was so good."

"Trust me, I am no virgin with boys. But with girls I was."

Summer smiled and then got up. Placed one leg underneath me, the other one over
me. Slowly she sat down and pressed her wet vagina against mine. She then
started moving her hips and when our clits touched it send a huge sensation
through my body, my fluids started flowing and Summer started grinding faster
and faster. "Oh Luna," she panted, "I love fucking you. Oh my God, this feels
so good." I panted and said "Yes, yes, make me come again Summer. Yes, oh yes,
almost. Keep going." After a few minutes we both came and for the first time in
my life I even squirted a little.

Summer sagged down on me and said "Not a word to your uncle about this." I
swore not to say a word. After we regained our breath we got up to finish our
drinks and then just giggled. "Can I be honest with you?" Summer asked, "and I
mean totally honest. Pinky swear to keep it between us." We crossed our pinkies
and I said "I pinky swear."

"I want to fuck your uncle so much," Summer blasted out, "Oh my God, do I want
him." I blushed as she said so and I really struggled telling her I felt the
same way. But I didn't say a thing but "I know, I could see it." Summer started
laughing and said "What's up with him? Should I wait for him to make the first
move or should I just go for it?"

"Knowing Dave, go for it." I replied.

Again Summer started laughing. "But that doesn't mean I don't want this
anymore, because I do. I love having sex with you, Luna. I've always been into
boys and girls."

"I don't know. This was the first time for me, but I do like it. It's just
different than being with a boy."

"Isn't it? I love both, very much. If I weren't a teacher here I would do every
boy here."

I had never talked so openly about sex in my life and it felt freeing to do so.
"Summer," I said while I was staring at my feet, "I like talking with you about
this. I can't really talk with my mom about it, she's just so protective of me.
But I feel like I can really be open and honest with you."

"Sure you can, I've told you my secrets. Well almost all my secrets."

"Well, there's this thing I discovered lately and I really don't know how to
deal with it. I don't want to, but somehow I just can't help myself. It makes
me feel good when I'm doing it, but afterwards I feel ashamed of myself."

"What is it? You can tell me, I won't tell anyone. Please trust me."

"Well, I --" I turned to Summer and said "the other day when I went up to my
room Dave was in the shower. The door wasn't quite closed and as I walked up to
close it I saw him."

"What?"

"Yes, and I saw _it_ too."

"Wow, how was _it_?

"What? I don't understand."

"Was it big? Small? Just the right size?"

I laughed and said "It was _huge_."

Summer smiled and said "I always thought so, I could see it by the bulge in his
pants. Now I want him even more."

"Aren't you angry? Because I'm his niece, I shouldn't be thinking like that."

"Why? You are a woman aren't you?"

"Yes, but --"

"No buts," Summer interrupted, "you really need to keep it a fantasy. There's
nothing else to it. Fantasizing about it is one thing, acting on it is a whole
different ballgame." I agreed with her and we started to talk about other
things.

## Chapter Two
The next morning I woke up a bit late, my uncle was already on the fields. I
walked through the house just not really knowing what I wanted to do. After a
simple breakfast I got dressed and did my chores for the day. When I was done I
took a short shower and got dressed. I decided to go play with the dogs for a
while.

They jumped against the fence as I walked up to them, wagging their tails and
barking loudly. Boomer was a Golden Retriever and Jet a Rottweiler, they were
the best of friends. Although the couldn't roam the farm, they had free access
to some fields behind the kennels. I opened the gate, stepped in and petted
them for a while. Jet jumped against me almost making me fall, he was the kind
of dog that really didn't understand how strong he was.

I stepped through the back gate and the dogs ran way in front of me. Boomer
found an old ball he likes to play with and came running towards me. He dropped
the ball in front of me, waiting for me to throw it. When I did he ran after it
only to bring it back again. In the pasture next to the field I was in the
horses were running enjoying their day out of the stables. I decided to see how
far this field would go and started walking. The dogs followed me, their tails
wagging from the attention they got. Halfway the field stood and old water
trough with just a little water still in it.

After a short walk I came across the fence and walked towards the gate. I
looked around thinking hard whether I should go further, decided against it and
made my way back to the kennels. On the way over I threw the ball a few times
and the two dogs raced after it, most of the times Jet won the race. Near the
kennels I started petting Jet and he got a bit excited. He jumped up to me and
pushed me over, before I knew what was happening he jumped on my back and
started humping me. I tried hard to get him off me, but then I felt something
soft and wet slam against my ass cheeks. Instinctively I understood what it was
and shouted "Jet, no. Down Jet, Down." Jet got off me and I could see his pink
meat between his back legs. I was huge and I felt myself getting aroused a
little. Jet jumped on me again, but this time I was able to get up and out of
the kennels.

I walked back to the house not knowing what I should do, should I tell my
uncle? Or should I just shrug it off? I decided to do the latter. Once back in
the house I saw Summer had texted me. "Hey Luna, there's a dance tomorrow
evening. Maybe you and Dave could come too? Would love to see you there.
Summer." I thought it was a wonderful idea and texted back I would make sure my
uncle would go too. Summer just replied with a heart emoji. I giggled a little
and thought back to the day we had together. I was sure I would regret it at
one point, but I just didn't. I sat down on the patio and started reading the
book I had brought with me.

After having lunch with my uncle I had to drive to the town 24 miles down the
road to go to the supermarket to get the groceries. It was one of those
one-store-for-everything type of stores. I filled my cart with the groceries I
needed to get and as I made my way over to the cash registers I walked passed
the clothes and couldn't help browsing a little. I saw a nice plaid mini skirt
and a really short crop top. I walked towards the changing rooms just to see
how they looked, not planning on buying them. But I thought they were nice and
put them in the cart. On another rack I found stockings and took them too.

When I got home I put away the groceries I went into my room and put on my new
clothes. Because my uncle would be working still I decided to take off my
panties and walked down the stairs. When I got outside I felt really excited,
it would just take a small breeze to expose my naked butt. It just felt so
nice, walking across the farm with the risk of being exposed. I walked towards
the field my uncle was working on and stood there just out of sight.

The dogs saw me and started barking for attention. My thoughts went back to
what had happened that morning and I felt myself getting excited even more
thinking about it. Carefully I stepped into the kennels again and made my way
just behind the dog house where they could sleep. Jet jumped up against me
again and this time I let myself go down. Jet got on my back again and started
humping. With my left hand I went down and felt his manhood growing in my hand,
then I guided it and with another hump I felt him enter me. I squealed as his
canine lid entered me, he humped harder and I felt him grow inside me. "Oh my
God," I panted, "oh yes baby, fuck me." His lid kept on growing bigger and
bigger. Until it was almost locked inside me. His lid started throbbing and
twisting and it just felt so good. At a certain point I could feel his canine
sperm starting to drip out of me. Without warning Jet wriggled off me and I
felt his lid pop out of me. I turned around and saw how big it was and on the
end it was even thicker.

Then suddenly Boomer jumped on me and started humping too. I repeated what I
did with Jet and guided Boomer inside me too. "Oh yes, yes," I panted, "Fuck me
Boomer, oh yes. It feels so good, baby." Boomer stopped moving and his sperm
entered my now cum hungry pussy, it was just so much it spurted out of me as
Boomer pulled away. When I got up, I straightened my skirt and could feel all
that canine cum drip down my legs. As quick as I could I left the kennel and
walked towards the house. As I walked back I knew I wanted to do that again,
feeling those canine cocks in my pussy was just so exciting to me.

After dinner I asked my uncle if I could take the dogs for a walk. Dave told me
were I could find the leashes and gave me the commands for them to come back to
me. During this whole time I hadn't changed or cleaned myself. Knowing that I
didn't wear panties, feeling that dry cum on my legs while I was near my uncle
aroused me. With the leashes in my hand I walked over to the kennel, put them
on the dogs and took them out. I went to the back of the farm and opened the
gate, my uncle had told me there was a nice trail to walk the dogs.

After about 20 minutes I came across a clearing with a small pond. The dogs
pulled me towards it and I let them free so the could roam a little bit. I
tried the command Dave had taught me and the both of them came back to me. I
felt so proud when they did. I started walking further down the trail until I
felt totally alone, I sat down on a bench that was placed to look out over the
landscape. It was just beautiful. The dogs sat down next to me and I checked if
I really was alone.

I spread my legs a little and started rubbing my clit, then I bend over forward
to pat the dogs. Jet stood up and without thinking I grabbed that hump between
is legs, Jet got excited and I went down on my hands and knees. Jet jumped on
my back and with my hand I stimulated him, as soon as I felt his lid come out I
guided it inside me once more. This time I moaned out loud and shouted "Oh yes,
Jet. Fuck me, push it inside me. His cock started growing again and soon enough
I could feel him pumping is canine sperm inside my wet cunt. When Jet was done
I repeated the process with Boomer and again the canine sperm spurted out of me
as he pulled out.

When I got up I straightened my skirt again and started walking back to the
farm. Halfway back Jet jumped me again and made me stumble. Before I knew it I
could feel him entering me again, I arced my back to give him better access and
this time he got in a little deeper. I grabbed is back legs to not have him
pull out and I moaned loudly as his cock throbbed pumping his sperm inside me.

After a few minutes I let him go and squealed as he popped out of me. I got up
again and we made it to the farm, where I put them in the kennel and went back
into the house. I was so exciting, I kissed my uncle on the cheeks while the
canine sperm dripped down my legs. "I'm going to take a quick shower, playing
with the dogs made me really dirty." As I walked up the stairs I giggled softy
as I was the only one who understood the double meaning of my words.

After my shower I put on a dress and sat down next to my uncle on the patio, he
was drinking a beer and I had gotten a soda from the fridge. "Oh, Summer texted
me today. She invited us to the dance and she wanted us to go too. Please,
uncle Dave, can we go? Please, please, can we uncle Dave?"

"First you must stop calling me that, second I don't dance. But if you want to
go, we can."

I jumped up and said "I'm going to text her right away."

The next morning I got up early to get my chores done and watched my uncle
working on the machines. He wasn't going to work on the fields and there were a
lot of machines that needed maintenance. From a distance I looked at the dogs
and went into the kennels at first I just played with them, then I hid behind
the doghouse again, stimulated Boomer, spread my legs and guided him inside me.
This time I even took out my boobs and pushed my hips as high as they could go,
pushing them against Boomer crutch. He pumped his cum inside me again and I
quickly straightened my panties and got out of the kennel. The risk of being
caught having sex with a god felt so exciting. I could feel the adrenaline
rushing through my veins.

After a hot day the evening of the dance had arrived. We both got ready and I
put on a tight dress with a low cut. I put on some nice heels and completed my
look with matching necklace and earrings. As I walked into the kitchen my uncle
whistled and said "You clean up nicely, niece."

I looked at his clean shaven face and nice suit. "So do you, uncle Dave." "Stop
calling me that," he replied and we got in the car. A few minutes later we
parked at the park where the dance was being held. A sign said _First annual
summer dance. All proceeds go to the your program of the local police
department._ We paid for our tickets, which also were for the raffle. Near the
bar we saw Summer, she wore a nice long white dress, her hair was immaculate an
d her makeup was even better.

We sat down at one of the tables and Dave got us something to drink: two wines
and a beer. When the music started Summer was asked to dance by the sheriff and
I watched how Dave was watching her. "Just tap in," I said, "I'm sure she would
love to dance with you." Dave just smiled, sighed and the walked towards the
dancing pair. He tapped in and took Summer into his arms. I watched them dance
for a while when I felt I needed to use the restroom. As I sat there I took my
panties off and put them in my purse.

As I walked back to the table I tried to find my uncle and Summer, but they
weren't on the dance floor. Back at the table only my glass was left on the
table and I took it. Walking around I still couldn't find them. As I was
looking around I talked to some of the locals and did my best not the get
disgusted at the attempts of the local football hero to seduce me. At the
entrance I asked if anyone had seen them. The woman said "Sure, they walked of
in that direction. I said they were leaving to early, but they clearly had
something else in mind." She chuckled as she spoke those last words and I
excused myself and went after them.

When I got near Summer's house I slowed down and peeked into her window. They
were standing in the middle of her room, kissing. "Finally!" I thought. I tried
the gate leading to the back of the house and to my surprise it wasn't locked.
I went in and closed it behind me. I took off my shoes and tiptoed to the back
of the house. I peeked in and all I could see was the kitchen, I tried the door
and it wasn't locked either. I snuck in and tried to be as quiet as possible.
Through the door I could hear them kiss and when I peeked in I saw how Dave
unzipped her dress. I watched as it slid down her body, revealing that
beautiful body of hers. She then helped Dave out of his clothes and went down
on him to start licking that big cock of his. I couldn't stop watching. Dave
closed his eyes and Summer turned her head, looked straight at me and winked. I
shrugged back realizing she knew I was there.

Summer stood up, took his tie in her hands and said "Let's make it a little
more exciting." She blindfolded Dave with his tie and led him to the couch, as
Dave sat down she turned to me and winked for me to get closer. Slowly I stood
up and tiptoed in. I slid the straps down my shoulders and took off my dress.
Now there were two naked women in the room. Summer whispered something in
Dave's ear and knelt down, I got closer too. She took his cock in her hand and
said softly "Let me suck it again." She placed her hand on my head and pushed
me closer. The tip of my uncle's cock touched my lips and I slowly opened my
mouth. Summer pushed me down more and I started circling my tongue around his
shaft. When I took it out Summer moaned "Oh it tastes so good." I understood
what she was doing and smiled. I took his cock in my mouth again and Summer
made slurping sounds. My uncle's cock just tasted so good.

Then on an urge I straddled him and placed his cock against my wet cunt. I slid
his crown along my lips. Summer said "are you ready for it?" Dave nodded and I
slowly went down on his cock. "Oh yes," I thought doing my best not to make a
sound. Summer panted "Just let me do the work baby, just enjoy it. Remember how
it feels. I started bouncing on his cock, then without warning Summer took off
the blindfold. Dave opened his eyes and when he saw who was fucking him he
shouted "Luna! What are you doing?"

I placed my finger against his lips and said "Just relax, let it happen. I
wanted to do this for so long. I've been dreaming of this. Just fuck me, uncle
Dave, take me. Make me your whore."

Dave placed his hands on my hips and looked at Summer who just smiled, leaned
back and started masturbating. Dave looked back at me and started moving his
hips, he then threw me on my back, spread my legs wide and plunged his huge
cock deep inside me again. "Oh yes, fuck me Dave, take me hard." I shouted.

After a while he pulled out and got on top of Summer, who spread her legs and
guided him in her. I got up and sat down on Summers face. She started licking
me and I stared into Dave's eyes before we kissed as lovers would do. Then he
got up, pulled me over to a chair, bent me over it and pushed his cock into my
wet cunt. "Oh yes, yes, yes," I shouted, "Fuck me, fuck me hard. Oh Dave, I
want you to come inside me. Give me that cum, fill me up. I am yours, you can
fuck me anytime you want. Oh yes, yes. I'm coming all over that cock of yours,
yes, just a bit longer, keep going, yes, I'm COMMMMIIIIINNNNGG!" Dave started
to breath heavily and I could feel him throb inside me just before he blew
sending his sperm deep inside my pussy.

He sagged down on me and pulled out. The three of us fell down on the couch, my
uncle in the middle. After we all kissed Dave said "Not a word to your mother,
she would kill me." Summer got us all something to drink and about 15 minutes
later she started to suck Dave again, he got hard almost immediately and Summer
got on top of him. I sat down in another chair and watched them having sex,
while I masturbated.

That night we spent at Summer's place and all slept in one bed. In the morning
I woke up to Summer riding Dave again, I got close to her and started sucking
her breasts then proceeded to kiss Dave. "Oh yes," I whispered in his ear,
"yes, make her come. Fuck her hard like you fucked me." Dave and I kissed some
more, out tongues touching and I sat down on his face so he could lick my slit
and suck on my clit. I leaned forward to kiss Summer who almost immediately had
an orgasm. I followed her example and Dave exploded inside Summer.

We all showered together and it was time for us to get back to the farm.
