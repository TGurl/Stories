# Hot Summer
_an erotic tale by TransGirl_

## Chapter One
My teacher was rounding up the curriculum for the year, just another 40 minutes
until summer break would finally begin. And just another day before I would go
and visit my uncle's farm to finally see my horse _Ariel_ again. I really was
looking forward to riding again. Ariel was born while I was at my uncle's farm
and I had helped her getting born. When she stood up for the first time my
uncle said "This is your horse now, what should we name her?" As I was full of
the _little mermaid_ at the time I named her Ariel.

"Luna? Luna! Still with us?" my teacher said waking me up from my daydreaming.
"What are you going to do during summer break?" she repeated the question. I
had to shake my head to wake up and said "I'm going to the farm and visit my
horse again, as I do each year during break." The rest of the class chuckled a
little and my teacher called them to order. "Now," she said, "it's pretty nice
that Luna does that. I had a horse when I was a girl and it's really nice to
have a friend like that."

Finally the last bell rung and all the kids gathered their stuff to run out. I
on the other hand walked slower out of school. My mother was waiting on the
parking lot and I got into the car. "How was your day?" she asked and I just
said "Boring." My mother chuckled and started the car. There was a lot of
traffic on the way home and it took a little longer than it normally would.
When we got home I threw my backpack in a closet in the pantry, walked into the
kitchen to get a soda and dropped on the couch in the living room.

My mother sat down next to me and said "Luna, your strangely quiet. What's
going on?" "Nothing," I replied, "there's nothing going on." My mother just
looked at me, said nothing. "It's just --" I started. "Yes, tell me. Talk to
me." she said. "It's just -- I don't know," I continued, "I feel different
than the other girls in school. When I told them I was going to visit Ariel,
the all chuckled. They all are into fashion and stuff, things that don't
interest me at all."

"Oh Luna," my mother took me in her arms, "Luna, my sugar. I was the same way
when I was your age. It can change, and when it doesn't, it doesn't. It's all
okay, you're Luna and you're unique. Don't let that get to you." I smiled a
little and felt a little better. "You're going to see Ariel tomorrow," she
said, "just concentrate on that. You can go riding tomorrow and the day after
and the day after that." That made me feel a lot better and she was right, I
shouldn't care about the other girls at all.

"Come on," she said, "let's pack for your trip." We got up, walked to my room
and started packing. An hour later we were ready and I got my book to sit down
on the back yard patio to read. My mother went into the kitchen to prepare
dinner. An hour or so later my father got home from work. We sat down for
dinner and he asked "Ready for your trip?" I nodded and said I was looking
forward to it.

The next day we got up early to get start the trip. My father loaded my bags in
the car and I hugged my mother before we started the 4 hour trip. "Okay," he
said, "let's have some fun." and he turned on the radio. We sang along to our
favorite songs, before we knew it we arrived at my uncle's farm. As my father
was parking the car my uncle came out the front door, waving to us. I got out
of the car and hugged him "Hi," I said, "I'm happy to see you again."

My uncle replied with "Same here, Ariel has been restless all day. It's like
she knows you're coming." From the stables I could hear her whinny and I ran
over to her. The moment Ariel saw me, she stomped the floor with her feet and
whinnied some more. I patted her white bless on her nose and told her we would
go riding the next day. After getting her some fresh water and some hay I
walked back to the house.

My father sat at the kitchen table talking to my uncle when the back door
opened and a beautiful blonde woman walked in. "Darn," she said, "you've
arrived already. I was so hoping to be here when you arrived." She walked up to
me and we shook hands. "I'm Summer, you must be Luna. And you are her father,
pleased to meet you." she said. We sat down and talked for a bit. Summer told
us she had met my uncle a few months back when she moved to town, they started
dating a few weeks later. Summer also told she worked as a teacher at the local
high school and volunteered at the local police station.

She seemed to be a nice girl and I started to like her. "Maybe we could go
riding tomorrow," Summer said. "That would be nice," I replied. My uncle asked
if my father would stay for dinner. "No," he said, "I should be going, it's a
long drive home and my wife is waiting on me." He got up, hugged me and got in
the car. I waved to him until he was out of sight. "Let's go inside," Summer
said, "Dave can start grilling the stakes I bought for us."

Half an hour later we sat down in the back yard to have dinner, I started to
like it even more. After dinner I helped clearing the table and I went into the
stables to brush Ariel. Summer accompanied me and brushed one of the other
horses. After I finished brushing I walked towards the kennels behind the
stables, in there were two Golden Retrievers. Usually they would roam the farm,
but it was almost harvest time and as my uncle was operating heavy machines he
put them in the kennel to keep them safe. I played with the dogs for a while
before I got back into the house. An hour or two later Summer went home and I
went into my room. I unpacked my bags, took a short shower and got ready for
bed.

The next morning I got up early to take care of the horses as I did every year,
after a few minutes my uncle came into the stables saying "This is great, I
love when you are here. Makes my life a little easier. Now, I'll be on the
fields all day, are you good on being alone for a while?" I nodded and said
"Sure, I think I'll go riding later. Maybe I could give Summer a ring to see if
she wants to come."

"That's a great idea," my uncle reacted, "I'll leave her number by the phone.
If there's anything you need, just call me okay?" I nodded again and my uncle
walked off. A few minutes later I watched as he made his way over to the fields
in a rather large machine. I went into the house, took a short shower and got
on my riding outfit. In the pantry I found my boots and was hoping they still
fit. As expected they were on the small side now, which basically meant I had
to get new ones again.

"Luna?" Summers voice startled me and I shouted "I'm in the pantry!" When
Summer popped in she saw me struggling getting my boots on. "No, no, stop. They
are clearly too small. Let's get into town, I'll buy you a new pair. Come on."

We got in her car and drove into town. We stopped at a pet shop and walked
through it to where they had the items for horses. The had caps, boots, saddles
and much more. We tried on different boots until I found a pair that I liked.
Summer pointed to a rack with riding pants and said "Should we get a pair of
those too? And maybe this shirt too, it's nice. You could complete it with this
jacket too." I was a bit blown away by all the stuff she pointed out and was a
bit horrified when I noticed the shirt she held in her hands was one-size-
fits-all and rather tight. "Come on, try them on," she said.

Hesitantly I got into one of the dressing rooms and when I saw how tight the
shirt was I literally shivered a bit. But after putting on the pants and the
jacked I had to admit it looked rather nice. Slowly I pulled the curtain to the
side and Summer squealed a little when she saw me. "Oh yes, that's nice. You
look so good." she said, "just try the boots with them." I sat down and put the
boots on. When I looked in the mirror I was smitten by how I looked.

Summer reached for a riding cap and put it on my head. "That completes it, come
lets go. The horses are waiting, I turned to go back into the changing room to
change into my own clothes, but Summer beat me, gathered my clothes, pulled of
the tags on everything I was wearing and walked over to the counter. The woman
behind it smiled and said "Wow, you look like a proper Amazon. Really nice."
Summer turned to look at me and said "Yes, we just need to braid her hair and
we can go riding." Summer paid the woman who said "Well girls, have fun."

As we were about to go back to the farm, Summer stopped at her house and said
"I feel underdressed, I'll be right back." About 10 minutes later she appeared
from her house in almost the same gear that I was wearing. Back at the farm,
she braided my hair and we were ready to go. We saddled the horses and as we
passed the field where my uncle was working we waved to him as our horses went
into a gallop. Summer was riding Thunderstruck, a mare that usually was a bit
quicker than Ariel. Today it was like Ariel didn't stand for that and actually
gained on Thunderstruck. We had a really nice time riding through the fields
surrounding my uncle's farm and after half an hour we stopped at a rather large
pond. Summer dismounted and bound her horse to a tree, I followed her example
and together we walked to the edge of the water.

We sat down to get a short rest. Summer said "This is where we used to go
swimming when I was young. Over there was I large tree, one of the farmers had
put a rope in it with a tire below. We would swing to the middle of the pond
and then just drop into the water. It was so much fun."

"But I thought you recently moved here?" I asked.

"That's true, my grandparents used to live here and just like you I would come
here every summer. When I saw they were looking for a teacher I applied and
moved here. I used to live in L.A."

"Wow, that's quite the change," I replied, "Why? I would love to live in L.A."

"So did I," she said, "but this is nicer. The pace is slower and people
actually takes time to actually live. Like today, I actually had to prepare for
school today, but I can do that tomorrow and just go riding with you."

"Ah," I said, "I love it over here too. I don't really like where I live.
People are nasty and I hate going to school."

"Why?"

"It's just my class mates. I don't really fit in, I guess. I never really did,
I don't do the _girly_ things, like fashion, hair, makeup."

"And you don't have to," Summer said, "You just be you. But be honest with me,
how do you like what you're wearing now?"

"It's okay, I guess," I said, "It's nice and comfortable --"

"And it's _girly_," Summer bumped my arm and smiled.

"It is?"

"Yes," Summer replied, "it shows your curves and with your hair braided like
this I would say you are a bit _girly_."

I blushed a little as I never had worn anything as tight as this and now Summer
had pointed out that my curves were showing I felt a bit embarrassed. It was
like Summer picked on up on it and said "Don't feel embarrassed. You should be
proud of your curves, you have a really nice body and you should show it. You
have a really pretty face and having your hair braided like this you show it.
You should never be ashamed of it."

I blushed as she complemented me like that and it did make me feel good. Summer
bumped me and indicated we should go riding again. We got on our horses and
slowly made our way further down the trail. "There's another thing I would like
to show you." We rode for another 20 minutes or so and then arrived at an old
derelict mill. "This used to be my grandfather's mill. Right there, were you
see those poles used to be their house. I loved being here. Everyday the
farmers would come to bring their grains and a few days later the would come
again to pick up the milled flour. And over there that old barn we kept the
horses. It was so nice being here, it felt so free."

"When did they leave?"

"Oh, that's almost 40 years ago, I think. Maybe even longer. My father sold the
land a few years ago. I pleaded him not to do so, but he said we could use the
money. When I came hear I learned that the buyer wants to remain anonymous, so
I guess I will never know."

"That's really sad," I replied. Ariel whinnied as if she agreed as we moved on
in a very slow pace.

"I should have brought my camera," Summer sad with a sad tone in her voice, "it
looks like everything could be gone in a few years. At least I will have
something to look at when it's all gone."

We kept quiet for a while as we passed the ruins of what once was her
grandparents abode. "Right there," Summer said, "right there was the first time
I ever kissed a boy, Luke Tomlinson. Oh boy was I excited after that." I
giggled and Summer turned to me "Don't you laugh at me!" She slapped the back
of Ariel who went into a gallop, Summer spurred Thunderstruck and sped after
me. We kept on racing until Summer reached me and we rode along side each other
for some miles.

Summer told me to go left and so we did. The trail kept on winding until I saw
something familiar to me. It was the windmill at the far end of my uncle's
farm. Summer opened the back gate and we slowly made our way back to the
stables. My uncle sat on the patio and waved as we guided the horses back into
the stables. After taking the saddles off, brushing them and refreshing their
water and hay the both of us walked up to the house.

"The year is 1827. And in a lawless town two female sheriffs do their best to
uphold the law. Their nemesis One eyed Dave was the manace of the town. Will they
succeed in their mission? This is the story of Luna's Summer." Summer said in a
deep voice. I did my best not to burst in laughter, but my uncle got up and
shouted "You might be the new sheriff in town, but I am the law!" At that
moment I couldn't hold it anymore and burst into laughter. Summer joined in and
my uncle just said "Yeah, go ahead and laugh. But I, One eyed Dave will have the
last one. WHUHAHAHAHAHA!"

We sat down and Summer got us some freshly made lemonade. "How was the ride?"
my uncle asked.

"It was wonderful," I replied and I told him all about the pond, about the old
mill and I said "Oh yes, I got these from Summer." as I stood up and did my
best impersonation of a model.

"That's really nice," my uncle said, "but the old mill you said? Why go there?
It's all but fallen down. I wanted to take it down last year, but never got
around to it."

"Wait?" Summer shouted, "You wanted to do what?"

"No you can't take it down," I yelled, "Summer tell him."

Summer looked at me and then back at my uncle. "You mean you bought it?"

"Yeah, sure. For when I needed or wanted to expand. But first that old thing
needs to be taken down. What's it to you?"

"That was my grandfather's mill. I basically grew up there. Every summer I
would visit them, much like Luna does with you."

"Oh," my uncle replied, "I didn't know. I thought you grew up in L.A. You never
told me that."

"No, it never came up, but this afternoon we rode to the pond and then I just
couldn't stay away. I had to see it."

My uncle was quiet for a moment and said "I understand. Well, it doesn't look
like I'm expanding that way any time soon. You know what? Why don't you check
how much it would take the restore it, the mill I mean. The houses and barns
were to far gone to save them. A storm a few years back flattened them and I
needed the planks for that barn over there."

"I can look into that," Summer said, "but why did you want to stay anonymous?"

"Ah, that was something I thought was right. But I wasn't, but I couldn't
change it anymore, according to the bank."

Summer stayed for dinner and we just had a wonderful time. I saw how much the
two of them liked each other and I also saw they kept to themselves because of
me. "Okay," I said with a seriousness in my voice, "I will look it the horses
are okay. Not that it's necessary, but I will give you two some time alone so
you can kiss." I got up and walked away, but as I entered the stables I hid
behind the door and peeked around it at them. I could hear the laugh and then
they kissed. From the patio I could hear my uncle shout "It's okay now Luna,
you can come back now. You don't have to peek any longer."

I walked back with a big smile on my face and said "Please don't hide it from
me. I'm so happy you two are together." We sat on the patio for a few hours
longer until Summer had to go home. "Maybe you could come by to visit me
tomorrow?" she said as we walked towards her car. "That would be a great idea,"
my uncle said, "say around 10." "Make it 9," Summer answered, "I've got some
plans."

The next morning my uncle dropped me off and Summer took me into her house. It
was a little smaller than the farm, but it was very cozy. "Okay," Summer said,
"I'm almost ready and then we can go."

"Go where?" I asked.

"You'll see, it's a surprise."

A few minutes later we got in her car and drove out of town. The luscious
fields made way to the browns and reds of the desert. We drove for almost two
hours singing along to the radio. "When are you getting your license?" Summer
asked. It had never come up before and thus I didn't know. "But you're almost
17? Isn't it time? You really have to ask your parents." Summer said.

We entered a large city and I looked my eyes out. There just was so much to
see. We finally parked on a large parking lot and started walking to a huge
shopping mall. It was the biggest one I'd ever seen, there was a huge center
plaza with plants and trees. Around the plaza were all kinds of stores and in
the corners were escalators to the second floor. I looked up and it looked like
there even was a third one. We sat down at one of the coffee shops and Summer
ordered a coffee for her and a hot coco for me.

After drinking our beverages we wandered through the mall until Summer seemed
like she found what she was looking for. We entered a smaller store selling
jewelry. It wasn't really busy at that moment and the moment we walked in the
woman behind the counter said "Oh, good morning miss Summer, so nice to see
you. How's your father? I heard he wasn't well."

"Thank you Doris, he's okay now."

"How can I help you today?"

Summer laughed and said "Relax Doris, I'm not here to inspect anything, didn't
my father tell you. I left the company, I'm a teacher now."

Doris seemed confused and said "A teacher? But --"

"What's wrong with being a teacher?"

"Oh nothing at all. But why?"

"Well, that's more or less private and not of your concern. Let's just say, my
father agreed and my brother took my place. I'm just on the board and don't
have an official function anymore."

"Ah, enough said. And who might this be?"

"Oh, this is Luna. She's the niece of my boyfriend. We're just out shopping and
I wanted her to see the store. Thank you so much, Doris."

As Doris walked away I whispered "What's this all about?"

She smiled and said "Oh, my father owns this store along with all the others in
the US. I'm what you call a rich kid, but I never wanted to work for my father,
I always wanted to teach. So we made a deal, my father and I, if I would work
for the company for 10 years I could then become a teacher. Or if I would
expand by 50% I could leave earlier. Now you can say a lot about my father, but
he sure does respect a deal made and now I'm here. My father still respects and
loves me, if he's capable of love that is."

"But if your father is so rich, why didn't he just buy your grandparents'
land?" I asked her. Summer turned to me "That's a good question. He said it was
too expensive, but I know we could easily have afforded it. I might have to ask
him again someday, but for now let's do some shopping."

We went back to the first floor of the mall and went into another store. Summer
pointed out some dresses, shoes and even showed me makeup. "Makeup? I don't do
makeup." I said. But Summer just smiled and said "That can be changed." She
handed a couple of dresses and shorts to me and said "Now, go try them on." 

The dresses were nice, tight but they were really nice. I started to have fun
trying them on. The first few we dismissed immediately, the others looked
great. Summer completed the look with some necklaces, scarfs and earrings. Then
it was time for the shorts, the button was way up to my belly button and one
even showed the lower parts of my butt cheeks. Summer handed me some shirts to
go with them, one of them was really short and hardly covered my boobs. Just
for fun I tried them on and Summer said it looked great.

To make my new outfit complete we looked at some bikini's and Summer showed me
one that was really small. The top hardly covered my areolae and didn't dare to
come out of the booth. Summer peeked in and said "That color looks nice on you,
we should get it."

"Really?" I said, "it's so small."

Summer just smiled saying "That's just why you should get it. With those shorts
and a nice pair of sneakers you look great."

We left the store with three bags full of clothes for me, Summer just bought
one dress. In the shoe store we got a new pair of pink sneakers for me, I had
never owned anything pink before, but these were really nice sneakers. Summer
then showed me a pair of heels. "Just try them on," she said, "these are just
perfect for you." I had to get adjusted to the heels, but they felt really nice
and we left the store with another two bags.

It was time to go home and at Summer's house we unpacked everything we had
bought. I put on one of my new dresses, completed the look with the necklace
and earrings. Summer did my makeup and I felt really feminine. The Summer
walked over to her office and returned with her camera. "Go stand over there,"
she said, "Let's make some photo's of you in your new outfits." She started
snapping pictures and I posed as best I could. "You're a natural," Summer said,
"these are just great. You should really think about modeling. Check these
out." She showed me the photo's om the small screen of the camera.

"You know what? The lighting is really bad in here. Let's go somewhere with
better light. She packed all my new clothes and we got in the car. About twenty
minutes later we stopped on the parking lot of the nature reserve nearby.
"There are some nice trails here, but I know the perfect spot that isn't on the
trials. Come on." Summer said after she had parked the car.

After a brisk hike Summer said "Follow me." We walked down something that
hardly could be called a track, but it was clear some people had walked along
here. After about ten minutes we arrived at a large slab of rock, it was hardly
a mountain. With the reds and browns the colors were amazing. Summer had been
right, it was very beautiful out there. "Put on your heels," she said, "then
just lean against the rock." I did so and Summer took a few photo's.
"Beautiful, now just look to your straight ahead into the distance. Yes, just
like that. This is so good."

When she showed me the results I was amazed, the looked professional. "Now
let's do something more daring, shall we? Put on that small bikini with the
shorts and the crop top."

"But there's nowhere to change," I protested.

"Ah, just do it here. I've seen it all before." Summer laughed.

A little embarrassed I took off my clothes, turning my back when I removed my
bra. A few minutes later I wore the clothes Summer had suggested. "Go stand
over there, in the middle of those rocks. A little more to the left, your hands
on your hips and just look straight into the camera. Like that, yes. It's so
good, pop out your hips a little, yes, like that. Great." Summer took picture
after picture, guiding me on how to pose.

"Now one step further, take of that top." I just stared at her, she couldn't be
serious. I protested, but Summer said it would be okay. "Be proud Luna, you
have such a great body. Be proud." Those words made me feel good and I just did
what she asked, took of my top and placed it on the bag. I adjust the small
pieces of cloth covering my areolae and stood at the spot Summer wanted me to
stand. "Oh yes, turn your upper body a little. Yes like that." As Summer took
more pictures I got more comfortable and then she said "Take off those shorts
and just hold them on a finger and just smile into the camera."

I couldn't believe I was actually thinking about doing it, stared at her for a
while and then just did as she asked. I held up my shorts with my right index
finger and smiled into the camera. I started to have fun with it and started to
play with my poses. Summer noticed it and said "Someone is starting to like
this. Go girl, have some fun with it. This is just great."

I felt myself getting excited and started to stand in other places as Summer
took photo's of me. Then on an urge I did something I thought I would never do,
without telling Summer I placed my hands on my boobs and stared sensually into
the camera. Summer didn't say anything she just kept snapping pictures. Then I
hooked my fingers underneath my top and pulled the cloth covering my breasts
aside. I posed for a few photo's with my breasts exposed, then I took off my
top and held it up between my teeth and my right hand.

I threw my top towards the bags and started posing topless. With my left hand I
pulled on one of the bows of my bottoms, a few pictures later I had it in my
hand and I was naked except for my sneakers. I leaned against the rocks once
more and Summer just kept taking photo's. I couldn't believe what I was doing,
the shy girl from school was standing naked in the desert while someone was
taking pictures of her. But it felt good, it felt nice.

After another ten minutes Summer stopped taking photo's, walked up to me and
said "You are just so beautiful." I felt something strange within me and didn't
protest when Summer kissed me. Softly at first just on the lips, but it got
more erotic as we kept kissing. I opened my mouth and our tongues touched for
the first time. She tasted sweet, like strawberries. I felt her hand softly
touch my breast and moaned softly when she squeezed it.

Then she urged back and whispered "We can't be doing this, you're a minor and
I'm a teacher. This is just wrong, but I can't help myself. You are so
beautiful, Luna. But we have to go, go get dressed and I will take you home."

Half an hour later we drove back to town and I said "What about the photo's?"
Summer turned to me and said "I will give you the disk they're stored on.
Don't worry. I can't be caught with them, you're a minor. You can do with them
whatever you want. Just promise me not to post the _special_ ones online, it's
not actually legal because of your age."

I told her I understood and when she dropped me off at the farm, she handed me
the disk from her camera. My uncle was still working the fields and we went
into the house, I carried the bags to my room and put on the mini skirt we had
bought together with a tight crop top. I looked in the mirror and went through
my hair a little. As I got back in the kitchen my uncle just walked in, he
whistled as he saw me. "Now that's a change," he said, "who are you and what
have you done with my niece?" I giggled and felt myself blushing.
