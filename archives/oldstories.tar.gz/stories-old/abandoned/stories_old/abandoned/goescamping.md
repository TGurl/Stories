# Laura goes Camping
_an erotic tale by TransGirl_

## Disclaimer
_This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as possible, forgive me any (scientific) mistakes or freedoms taken._

## Chapter 1
Laura knew protesting wouldn't help anymore so so simply gave up, looked like
she would be going to camp this summer. "Look Laura," her dad said, "I've been
to the same camp and I know you'll have fun there. You can play volleyball, go
swimming, kayaking all kinds of fun stuff." Laura huffed, if there were things
she really didn't like it were those. Ever since her mother passed her dad did
his best to care for a 16 year old, but there were things he just didn't
understand. Like when she got her first period, sure he did his best but it was
her aunt who had explained it best.

Suddenly she didn't look forward to summer-break any more. She had hoped to stay
home and maybe even help her dad at the store. But these were the busiest weeks
for him during the year, together with the holidays that is, so he wouldn't be
home most of the time. In one way she understood why her going to camp was best
for him, but still this was camp they were talking about.

The last week went by quicker than Laura had hoped for and soon she was packing
for _six weeks of fun_. It wasn't like she hadn't left home for for a longer
period of time, it was the general idea of camp that Laura didn't like. Her
father had given her a checklist of what to pack and she knew he would check if
she had it all later so she did her best. Finally she had it all and dropped on
her bed. _I will miss you the most_ she thought while she stroked her bed.

After a restless night Laura and her dad got in the car to drive the 400 miles
to camp _Mountain view_. This camp was beautifully situated in the mountains
surrounded by forest at he large lake, at least that was what the internet site
said. According to Laura it would be just two trees and a leaking swimming pool.

Both had been quiet almost all the way to camp and when they arrived Laura had
to admit she had been wrong: it was beautiful out here. A girl with a huge smile
on her face came up to the window on Laura's side: "Hello! Welcome to camp! And
you are?"

"Laura, Laura Bailey"

"Ah Laura, welcome. My name is Ashley. Just drive up to cabin 14. Your cabin 
lead is Marisha. She will tell you more. Again welcome Laura, Welcome to Camp
Amore 2021."

Laura was a bit mystified by the name the Ashley had used but she didn't ponder
long about it. Her father parked the car near cabin 14 and a girl with long red
hair walked up. "Hi, I'm Marisha and you are?"

"Laura"

"Ah, Laura, welcome. Come on in. This is our cabin and there are already a few
girls here. We're the Cupids during this camp and it's our task to save Amore.
But all will become clear during the opening tonight. Just grab a shirt, grab
your stuff and walk on in. And you sir, thank you for dropping her off. If you
would please check if all the information I have is correct I believe it's time
to say goodbye." She was all cheery when she spoke.

Laura threw a bag over her shoulders, grabbed a shirt and walked into the cabin.
There were already 5 girls in there, most of them were busy putting their
clothes in a locker. "Oh hi, I'm Rose. Welcome to the Cupids. Please take a bunk
and a locker."

"Laura, thank you." Laura walked up to a bunk and chose the lower one. She threw
her bag on it and her father placed the other two next to it. She hugged her dad
and whispered "Please, take me with you." Her dad chuckled and hugged his
daughter. He knelt and said "See you in six weeks, pumpkin." He kissed her and
walked away. Laura stood in the doorway and watched until the car was out of
view.

"First time to camp?" a voice behind her said. Laura turned around and saw a
thin girl with raven black hair stand behind her. Laura nodded and the girl
continued "We've all been there. But it's fun. It's always a surprise what theme
they've picked. But we will know soon. I am Nico by the way." Laura introduced
herself and started unpacking her stuff. Almost 20 minutes later
