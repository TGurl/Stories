# Mother of a Marine
_an erotic tale by TransGirl_

## Disclaimer
_This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as possible, forgive me any (scientific) mistakes or freedoms taken._

## Chapter 1 : Letting go
With tears in my eyes I watched my son step on the bus which would bring him to
basic training. There he was, my son, just 18 years old on his way to become a
marine. I felt proud and scared at the same time. My son had chosen not to go to
college but to protect his fellow citizens against all dangers, foreign and
domestic. Although I would have preferred him going to college I never felt
prouder than on the day he received his acceptance letter.

He jumped into my arms and kissed me on the cheeks. It was the first time I felt
my nipples harden and I started to jump with him. The weeks after we prepared
for him to leave the nest; making what I felt even stronger. It was just that I
couldn't tell him. Now I watched him step on that bus and it would be at least 6
weeks before I would see him again.

"Just call me as often as you can." I had whispered before he took his first
steps to his destination. He just nodded and kissed my cheeks. "Thanks mom for
letting me do this." he had said.

The sound of the engines woke me from my daydream and together with other moms I
watched them drive off. I cried all the way home and the house felt eerily
silent when I got there. I had always known this day would arrive but I never
though it would feel like this. After his father passed away it had always been
just the two of us, now it was just me. Numb as I was I walked through the house
and ended up in my sons room. His clothes still smelled of him and I took one of
his sweaters, pressed it against my face and lay down on his bed.

The next morning I had to get ready for work, but I totally didn't feel like it.
My co-workers noticed I wasn't myself and did their best to comfort me but I
just missed my son. The simple fact he wouldn't come home that evening, the
reality I had to make dinner for just me almost was too much for me to bare. I
did my best not to let it influence my job, even my boss told me that it would
get better. Her children had left the house a few years earlier, she understood
what I was going through. 'You at least have your husband, still' I thought.

I have to admit it got easier as the weeks went on. I started to feel a certain
freedom as I didn't need to be home at a certain time anymore. I could go home
whenever I wanted to. But one night it all came crashing down. In the grocery
store I had caught a glimpse of a young man looking just like my son. My heart
skipped a beat as I almost waved to him realizing he was just another boy. The
feeling I got was so strong I could not deny it anymore.

I rushed home, stormed into his bedroom only to find it as my son had left it. I
dropped on his bed and cried my eyes out. I held the sweatshirt in my arms, just
smelling my son calmed me down. I felt something I had never felt before, his
scent made me moist between my legs: I felt sexually attracted to him. I threw
the shirt on the floor, got up and rushed into my bedroom. I couldn't feel this
way, he's my son. It is just wrong for me to feel like this.

That feeling only got stronger and by the time he was to come home from training
I had a full blown crush on my son. He had texted me when I could pick him up at
the airport as he was coming home for a few days, until he had to report at his
assigned post and start training to become a marine.

I felt butterflies everywhere as I stood there in the airport staring at the
escalators waiting for my son. Suddenly I saw the shoes and pants of a soldier
and I knew it was him. I bent my knees as a giddy schoolgirl who got some
attention from one of the football players on the field. I felt butterflies
everywhere and I just couldn't wait to hold him in my arms.

Then I saw him, his head shaved, his broad shoulders even seemed broader. He
looked so handsome in his uniform. With his smile he showed his pearly white
teeth and he waved when he saw me. I jumped a little when he walked up to me and
I took him in my arms. As far as anyone, including my son, knew I was just a
happy mother holding her son, but on the inside I wanted to kiss him on the
mouth and rush back home so he could make me his.

The next few days we spent as much time together as we could. I tried to tell
him how I felt a few times and even got close once, but I just couldn't. On the
second to last day I walked passed the bathroom. The door was ajar but left just
enough room for me to see him. He just got out of the shower and was drying
himself. I was mesmerized when I saw his body, especially what was between his
legs. I had never known he had grown to become so big. I couldn't stop staring
at it and stopped myself from running in and grabbing it.

I had to pull myself away and ran into my bedroom. After closing the door behind
me I slid my hand inside my pants and panties to feel how wet I was. When I
touched my clit the floodgates where opened and I started to masturbate,
fantasizing how it would be if my son took me right there and then. I startled
myself when I whispered his name "oh Travis."

I took off all my clothes and leaned against the door again. With one foot on
the small table next to me I drove my fingers deep inside my wet cunt. I started
to breath heavily but did my best not to make a sound. "Mom? Where are you?" it
sounded from the other side of the door.

"I'm in my bedroom getting dressed. Don't come in, unless you really want to see
your mother naked." I shouted back, trying my best to sound as normal as
possible. Deep inside me I wanted him to burst in and see me naked. I would
spread my legs for him and just beg for him to take me. "Ew," I heard him say,
"never mind. Want eggs for breakfast?" "Eggs would be lovely." I shouted back.
The thought of him standing just a few feet from me while I stood there
masturbating send me over the edge. I had to hold my hand against my mouth to
muffle the scream.

I walked into the small bathroom connected to my bedroom. Washed my hands, did
my hair and makeup and threw on a somewhat tight dress. As I walked out the door
I noticed my nipples where clearly visible through the fabric. I shrugged my
shoulders and walked towards the kitchen.

"Good morning" I said

"Morning mom," Travis reacted, "oh wow, going somewhere special?" He whistled
softly when he saw the dress.

"No, just work later." I lied as I had put this dress on for him. I bent over
the bar separating the livingroom from the kitchen. I pressed my arms together a
little bit so my cleavage would be clearly visible. "Are the eggs ready yet?" I
asked.

"Almost," he replied, "just sit down and I will bring them." He looked at me and
I could see he had noticed, he shifted his feet a little bit. Internally I felt
so happy when I saw it and I had to fight the urge to just flash him right there
and then. After breakfast I got a matching blazer and some heels from my
bedroom, kissed my son goodbye and drove off to go to work.

When I got home again I noticed the lights weren't on, something was different.
On the bar I found a note from my son.

_Mom,

I got a call and have to report early. I will call you as soon as I can to tell
you where I am stationed. I gotta go now.

Love you,

Travis._

I was confronted with being a marine's mother at lightning speed. I felt tears
rolling over my cheeks as I read the note over and over again. The bags were
gone and he had taken all the clothes he could bring. His closet was almost
empty. I was alone again and I just couldn't take it at that moment. I needed a
drink or two. I called for a cab and ended up in a bar downtown.

I sat at the bar with a nice drink in front of me. The bartender noticed me and
asked me what was going on. "Ah, just empty-nest-syndrome. I thought I was used
to it by now, but I'm not." I replied. It felt really nice to talk to him and I
told him about my son becoming a marine and how I was alone in that stupid big
house.

I really didn't want to go home that night and I sat at that bar for quite some
time when a rather handsome man approached me. "Do you come here often?" he
asked. From all the openings he had chosen the lamest one and I burst into
laughter. He asked me why I laughed and I said "Well, that opening shows me you
aren't that creative." He laughed too and we sat next to each other for a while.

I don't know what came over me but I asked "Would you like to take me home? My
son isn't home and won't be for quite some time." He blushed as he asked for the
bill. I couldn't believe myself as I sat down next to him in his car. On the way
over I was sucking his cock and at home we didn't even make it to the bedroom.
He pulled up my dress and took me right there in the kitchen.

I moaned deep as I felt this mans dick enter my wet cunt, this guy who I had
just met a few hours earlier. "Oh yes, fuck me," I moaned, "I want you to fuck
me all night long." And we did, it was almost 5 AM when he gathered his stuff
and left. "Thank you for a lovely night." he said. I had never had a
one-night-stand before but I had loved every second of it.

I was so happy I had the late-shift that day so I could at least get some sleep.
My best friend, who also worked at the same company, knew something was up and
she whispered "Someone had sex and it wasn't me," she said with a smile. I
whispered as I told her what had happened and she just said "You go, girl. You
deserve it. Finally you are letting yourself go a little bit. I am so proud."

During the day I had received a text message from Travis where he was stationed
and it was almost 1000 miles away. It was Friday night and I didn't want to be
alone so I invited Marisha, my best friend, to come over for dinner. She glady
accepted as it had been a while since we had done anything like this. She called
her husband and told him not to wait up: "Laura and I are having a girls night."
Through the speaker I could hear him say "Oh well, have fun! I'm gonna watch the
game anyway with Brad and Cooper." "Oh," Marisha said as she winked to me, "then
I am so happy not to be there."

Matt had dropped her off at work that morning so Marisha got into the car with
me. We decided to stop at the mall to get wine and cheese. But we ended up
shopping and I left the mall with 2 dresses, 3 pairs of shoes, loads of makeup
and 5 pairs of earrings. "Treat yourself for once," Marisha had said. At home I
went into the pantry to wash my new dresses. The one was tighter than the other
and the last one just about covered the important bits. Whatever made me want to
buy this one? I thought to myself. Marisha shouted from the livingroom "Pizza
will be here in 20." "Okay," I shouted back.

We sat down on the couch, we both crawled under a comfortable blanket and
searched Netflix for a movie to watch. After the pizza we had more glasses of
wine and just talked.

"Look Laura," Marisha said, "How long do I know you? 30, 35 years? You've never
been alone. From high school you went straight to college, after collage you
moved in with Brian, you got married, had Travis and you were Brian's wife or
Travis' mother. You never were just Laura. I say you sell this house and buy
yourself a nice apartment downtown or wherever you want to go to. You could even
buy one with a room so Travis has somewhere to sleep."

'He could just sleep in my bed," I thought. Marisha continued "This house is
full of memories and way to big for a woman alone. You got to face the fact:
Travis isn't coming home. He lives on the barracks now, he might even meet a
nice girl and get married. Either way he isn't coming home any time soon."

We were quiet for a while and I knew Marisha was telling the truth. But I
couldn't sell this house, could I? What would Travis think of me? "But, " I
stuttered, "this is Travis' home. I can't sell this. This is the first house
Brian and I bought after we were married."

"Sure, I understand. But that's how long ago now? Look, Laura, I love you to
bits, but I wouldn't be a friend if I didn't tell you how I feel about all of
this. You need to talk to Travis and tell him how you feel, how this house makes
you feel lonely and alone. How all the memories are holding you back. You're not
even 40, Laura. And with God willing you're not even halfway your life. I urge
you, no, I implore you to go find yourself. You're still Travis' mother, but he
moved out. It is time to discover who Laura is."

Deep in my heart I knew Marisha was right, although it was painful to hear, she
was right. I had never been on my own. I had always been a wife and a mother,
after Brian passed away I became a full time mother. "But, how can I tell
Travis? I can't just call him and talk to him. And I really don't want to text
him with this."

"Why not record a message? Just record a video on your phone and explain what
you feel. Just don't forget to tell him to watch it when he's alone. You could
even ask him to send you a video back."

That was a great idea, that way I could just speak freely and Travis could watch
it whenever it was suitable for him. I thanked Marisha for the great idea and we
drank some more wine, chatting about anything but the current situation. The
next morning Marisha hugged me and said "Thank you for a lovely evening, but I
got to go home. Matt will be waiting, we have to do this again. Soon, you hear?"

I nodded and watched as Marisha got in the cab. I waved as she drove off and
suddenly the silence in the house felt heavy to me. "Oh Brian, if only you were
here," I said, "You could tell me what to do. I am so torn, Brian, I feel so
empty and alone in this house. I know Travis won't come home again, maybe just
to visit, but not really come home. What should I do, Brian?"

I felt an urge come over me, got dressed and drove to the place where we had
shattered his ashes. It was where Brian used to love to come and just hike
through the mountains. I stopped the car at a viewpoint and leaned against it.
Tears rolled over my cheeks as I remembered that night. Two police officers
stood at the front door with their hats under their arms "Mrs. Bailey?"
Immediately I knew something was wrong. The only thing I heard was "We're so
sorry to inform you..." I just screamed and fell to the floor. Travis came up
running when he heard me. He took me in his arms and we both just were numb.

A drunk driver had run a red light and hit Brian's car. The impact had been so
hard they couldn't get him out for at least 2 hours. The paramedic told me it
was impossible to survive such an impact and I still hope she was right.

I opened my eyes and dried my tears. I watched a butterfly as it landed on a
flower nearby. A sudden feeling of peace came over me, it was the same feeling I
felt whenever I was near Brian. I was sure he was with me at that moment. I am
sure he gave me his blessing that day and told me to move on. I felt loved at
that moment and I started to cry again, this time of happiness. "Thank you
Brian" I whispered, "I love you and I always will."

I got in the car and felt a whole lot better. I had made a decision and all that
was left to do was to inform Travis. I got out my phone and started recording:

_Hey Travis,

Look where I am. I am with dad right now. It might seem silly, but I really feel
he is with me. I record this because I need to tell you something, something
important. So it's best to watch this when you are alone. And if you want to
respond just send me a video. Don't text me about this, that feels even more
impersonal than this does.

So here it goes.

Almost every mother feels this when the last chick leaves the nest. And as you
were my only chick I feel it even more. Ever since your father passed away I've
been your mother. Don't get me wrong I wouldn't have wanted it any other way,
but now I am alone. For the first time in my life I am alone. And I need to find
my own way. I can't do that at home. Everything reminds me of you and of your
father, no matter where I turn something reminds me of you guys. The only two
men who matter to me. I need to find my own place, I need to find out who I am
or who I am going to be without you directly in my life.

I feel like I am not explaining myself. You will always be welcome, day or
night, you will always be my son and I will always be your mother. But I need to
sell the house and move on. I came here to talk to your father and somehow, I
can't explain, a feeling of ultimate love came over me. That's how I know your
father was with me and he gave me his blessing. I love you so much, Travis, you
will never know how much I do. But it's time for me to find my own place in this
world.

I hope you understand, please let me know.

Love you._

I stopped the recording and saved it on my phone, started the car to go home.
Once there I sat on the couch staring at the recording. I renamed it _Please
watch alone_ and sent it. Instantly regretting that I did. What would he think?
How would he react? Half an hour later my phone rang, it was Travis.

"Hey mom," he said. I asked him how he was and how training was.

"Oh, it's fine. It's hard but I'm coping." he answered, "We're off duty right
now and I saw the video." Something squeezed my heart and I almost threw up. "I
just wanted to say, go for it mom. Sell the house, put my stuff into storage and
do whatever you need to do, mom. I will support you in any way I can." I sighed
with relieve.

"Oh Travis," I replied, "you don't know how relieved I am right now. So you
really don't mind?"

"No mom," he replied, "it's your house and you're right. I've moved out and it's
time you do something for yourself. You've been my mom forever and you deserve
it. I am so grateful you are my mother and that's one of the reasons I joined.
Just let me know when you are going to move, if possible I will come to help.
Okay?"

"That would be nice," I replied, "How did you like the video? Should I do more
of them? Showing you how it all went and goes?"

"I would like that," he replied, "lot's of people here get video messages from
home. It's so nice just to see you, even if it's on a video, it still feels
good."

"Okay, I will send you some more. I will tell you all about my days or weeks.
You will get so bored with it, but I will keep sending you them."

"That's alright, mom. I will love them. But I have to go now. Talk to you soon."
he hung up before I could say goodbye. But my heart had grown twice it's size
now that I got my sons blessing too.

It took me almost two months to find an apartment I liked and when I finally
found it I recorded a video for Travis. "Look, it's so nice. We're in the old
part of town right now and there are boutiques, bars, a mall is nearby. It's
just perfect. This could be your room when you come over, this will be my
bedroom and this is the bathroom. Sure, it needs some TLC but that isn't a
problem. Matt, Marisha's husband, told me he would help. This is the kitchen and
this is the livingroom. And just look at the view! Did I mention the balcony? Oh
Travis I fell in love with this apartment the moment I walked in. They will put
a reserve on it so I can buy it as soon as I have sold the house. I am so
excited, Travis, I am so excited to have my own place. I can't explain it. Oh,
this wall would be great for your fathers photo. Yes, and your photo underneath
it. Oh this going to be great. Let me know what you think of it, love you."

It only took me two weeks to sell the house and I had two months to move out.
Marisha helped me packing and we made Goodwill happy with a lot of stuff I
didn't even remember I had. In the mean time Matt was busy with the bathroom in
my new apartment and he would install the new kitchen. Of all the furniture I
had I only kept the couch. The rest I sold or stored together with Travis'
belongings.

Slowly the new apartment was decorated to my taste, with almost all new
furniture. The couch stood proudly against the longest wall which I had painted
a nice shade of salmon, with some broke white diagonal stripes. One of the walls
was painted in a darker shade and I hung Brian's and Travis' pictures on it.
Underneath a table with some candles and other trinkets.

In my bedroom Marisha and I assembled a new king size bed, which was ready just
in time when the new mattress arrived. The smallest room we changed into a
walk-in closet, closing the door to the hallway and adding a new one from my
bedroom. It's always handy if you know someone in construction. Matt only asked
for me to pay for the materials. Two of his employees came over to paint the new
wall in the hallway and it looked like it had always been like that.

On the day I had to hand over the keys I walked through the old house one more
time and thanked it for all the memories. I made another short video for Travis
showing him the empty house. He had tried but he couldn't come to help. I told
the real estate agent I was making a video for my son and said "Well, Travis,
this is it. Our house isn't ours anymore." as I let go of the keys which landed
in the hands of the agent. She smiled and said "But don't worry the new owners
will take good care of it and thank you so much for your service." Those last
words brought tears in my eyes as I could see she meant them.

After I stopped recording she explained her brother was in the navy and she knew
how it felt to have a loved one serve. I hugged her and whispered "Thank you for
you brothers service. Just tell him that. Send him a video too, I am sure he
will love it." She said she would send him a video. I got in my car and drove
over to my new home. My own place. A new chapter in my life was about to start.

## Chapter 2 : My own place
A few months had passed and I started to feel at home in my new apartment, the
fact my neighbor was very friendly helped a lot. His name was Sam and he was as
gay as gay could be. We became friends rather quickly and soon enough our doors
were always open for each other.

One Friday night we decided to go to one of the bars nearby and he walked in
just as I was doing my makeup. "Wow girl, you mean business tonight" he said as
soon as he saw my dress. "You better believe it. Just because we're going to a
gay bar doesn't mean I couldn't look my best." I replied.

"You will surely make the girls happy there." he laughed. I hadn't thought of
that and just stared at Sam. "No worries," he said, "just tell them you're
straight. You'll still have a good time. We can dance, drink and just stumble
home. It's going to be great."

I smiled, finished my makeup, grabbed a jacket and my purse as we went out the
door. We walked arm in arm towards the _the Duke_, the only gay bar in town.
Just before we entered Sam said "Okay, just to let you know. There is a door in
there with a golden plaque stating _Dark Room_. Don't go in there unless you
want to see people having fun with each other. When I say I will be back soon
you can be sure I am in there."

I blushed as he told me and said "Just don't leave me alone for too long."

"Oh, don't worry. You will have someone to talk to or dance with in no time with
the way you look." he smiled.

We went in and left our jackets with the girl at the door. She handed me two
tickets and smiled at me. As we walked off Sam whispered "She was interested in
you. So nice." I just punched him and told him to go somewhere else. We sat down
at the bar and Sam introduced me to the man behind the bar. "Mike this is Laura,
my neighbor I told you about, Laura this is Mike. His husband must be somewhere,
they own _the Duke_."

"Very pleased to meet you." I said.

"A mother of a soldier is always welcome here. He's in the marines I heard. So
was Jonah. He got kicked out when they learned about him being gay. Although he
might think otherwise, I am happy they did because I met him after he left."

"I am so sorry to hear that," I replied, "Such a dumb thing to do."

"It sure is, now what can I get you? The first round is on us, a way of thanking
you for letting your son become a marine."

"Sam told me you make a mean cocktail, just surprise me." I replied.

Sam and I chatted for a while and he introduced me to a lot of the patrons
there. Soon enough he was off to the dancefloor, leaving me alone at the bar.
The cocktail Mike had made me was one of the best I had ever had and I ordered
another one. As I sat there enjoying my cocktail a woman came up to me and said
"I could say a lot of things, but I won't because I hate opening lines." I burst
into laughter and she sat down next to me.

She was a very beautiful woman with long blonde hair and a very friendly face.
Her blue eyes twinkled as she looked at me. "Hi, I'm Ashley and you are?"

"Very straight," I replied, "and my name is Laura."

"Oh hi, straight Laura. What brings you to a gay bar?"

"My neighbor Sam."

"Ah Sam, you're the neighbor he can't stop talking about." she said as she bend
over to whisper in my ear "I'm his sister, that's why I know." I leaned back and
stared at her. She was his sister?

"Well, I'm not actually his sister. But we've know each other for so long it
feels like family. So we just call ourselves brother and sister." Ashley
explained. Sam had told me about her but I never knew she was this beautiful.

Sam joined us "Ah, you've met Ashley I see. She's my sister, not that.."

"She told me," I interrupted, "if she's your sister then who am I? Your mother?"

Sam burst into laughter. Ashley responded "No, you will be our older sister. If
that's okay with you?"

We chatted for a while and had a few more drinks. When suddenly Ashley got up,
took my hand and pulled me to the dancefloor. "This is such a good song." she
shouted. I tried to protest but to no avail and before I knew it was dancing
with Ashley to a song I had never heard before. The music slowly transitioned to
trance and I just followed Ashley in her moves. The beats soon took hold of me
and I really enjoyed dancing.

Ashley moved in close and turned her back to me. Her body almost touched mine
and I did my best not to touch her. She turned around once more and placed one
leg in between mine. She placed her hands on my hips and I could feel her crutch
almost touching my thigh. Our lips were so close together I could feel her
breath. On the beat of the music we moved as if we were one. My heart started
beating faster and I couldn't resist anymore: I kissed her.

It was the first time I ever had kissed a girl. I was shocked from what I did
and rushed back to the bar. Sam was sitting in my place and he saw the shock on
my face. "What happened?" he asked. I just grabbed my cocktail and downed it in
one go. "We need to go." I said.

Before Sam could ask why Ashley caught up, pressed me against the wall and
kissed me. I felt her tongue enter my mouth and I just gave in. I placed my arms
around her neck and kissed her back. Ashley pressed her body against mine and
with her hands she pulled my hips against hers. I felt my nipples harden. Ashley
took my hand and pulled me. "I will be right back." I said to Sam who just
smiled the biggest smile I had ever seen.

Ashley opened the door to the _Dark Room_ and pulled me into a small room. She
closed the door behind us and locked it. She walked up to me and whispered "I
know you are straight, but I really want you. I wanted you since the moment I
saw you."

I hesitated and said "But I am not gay."

"Who cares?" Ashley said and kissed me again. Her hands went all over my body
and when she squeezed my breasts I couldn't help but squeal a little bit. She
took off my dress and marveled when she saw my triple-D breasts. She started to
suck on them and my breath went a bit deeper. I was so nervous and torn between
stopping her and letting her continue. She kissed me everywhere and I just
melted in her arms. I took of her shirt and squeezed her breasts. When we were
both naked we lay down on the bed in the room and just kissed. I felt her warm,
wet pussy push against my thigh and Ashley started to slide against it. I could
feel her labia open against my flesh.

I pressed my mouth against hers and our tongues just danced around each other.
Suddenly she got up, placed on of her legs under me and pressed her warm, wet
pussy against mine. She started to grind against my wet cunt and I just moaned
loudly as she did it. I could feel her labia against mine. I could feel our
fluids mix and Ashley moaned as loud as she could. "Oh Laura, this feels so
good." she shouted, "I'm coming Laura, I'm coming all over that wet pussy of
yours. Oh Laura, yes, yes, YEEESSSS!"

At almost the same moment I felt an orgasm take hold of me too and pressed my
wet cunt against hers as hard as I could. Ashley sagged down on top of me and we
just kissed. We lay in each others arms for a while and just enjoyed feeling
each others bodies. "Ashley?" I whispered, "would you like to stay at my place
for the night?"

Ashley just looked at me and said "I would love to."

We got dressed and walked back into the bar. Had another few drinks and I kissed
Sam "Thank you so much for bringing me here. I have to go now. Ashley is
bringing me home." I winked at him and Sam just smiled. "Have fun" he said. Oh I
was sure of it.

That night we both didn't get much sleep. Ashley showed me how good a woman
could make another woman feel. She licked me, fingered me and at the end of the
night she was able to push her whole hand inside me. And I did the same to her.

The next morning we showered together. At the breakfast table I was feeling
confused. "Ashley? Does this mean I am a lesbian now?" I asked. Ashley burst
into laughter. I looked at her not understanding why she laughed. "No, Laura,
you are still as straight as they come. You couldn't resist a dick if you'd
tried. Me on the other hand: I almost puke thinking about it."

"No Laura, you just explored your sexuality and you now know lesbian sex isn't
that bad. That's all."

"So, it meant nothing to you?"

"I wouldn't say that. I would love to be your friend, maybe even one with
benefits. But I could never be your girlfriend, simply because you are not a
lesbian. But I would love to be in your bed now and again."

Somehow I felt relieved. I thought about it and Ashley was right. I had for the
first time experienced how it was being with a woman. And I had loved it, but I
loved being with a man more. We talked for a bit and when she left I told her
that my door was always open for her.

Twenty minutes later Sam stormed in "How was it? How did you feel? Was it good?
I've got so many questions." I laughed and told Sam almost everything that had
happened between Ashley and I. He was so excited to hear it and when I was
finished he said "Yep, she is right. You are still straight and always will be.
I just so happy that you opened yourself up for the experience."

He kept me company for a little bit and then went off to his work. I just
couldn't stop smiling and decided to make another video for Travis.

_Hey son,

I've just had the best night in a long while. I've told you about Sam, my
neighbor? Well we went to the bar last night and we had a wonderful evening. And
I don't know whether I should even tell you this, let alone if you even want to
hear, but I just have to tell you. I met a wonderful girl there, Ashley. We
chatted and danced. Well one thing led to another and, Travis, she spent the
night with me.

Please let me know what you think. I just had to let you know. I love you and
hope to see you soon._

I stared at my phone for a while deciding whether I should send it. At that
moment I decided against it and just saved the video on my phone. In stead of
sending it I called Marisha and asked her if she wanted to come over. Thirty
minutes later she sat on the couch next to me. She listened intensely as I told
her everything about last night. She just smiled and was quiet for a minute when
I was finished.

"Oh Laura, I am so happy for you. You finally are doing the things you should
have done in college. You are finally having fun. This is the best thing I've
ever heard you say, besides getting married and having Travis that is.". She
clapped her hands and giggled "This is so exciting."

"I made a video for Travis telling him about this. Should I send it?"

"Depends on what you said."

"I can show you. Would you like to see it?" We watched the video I had recorded
earlier and afterwards Marisha grabbed my phone. She pressed send before I could
stop her. I just looked at the _Message sent_ pop-up on my phone. I turned to
Marisha and whispered "Thank you. I would have never sent it myself."

Marisha stayed for a while until she had to go home. I walked over to the wall
where Brian's photo hung and whispered "I still love you so much, Brian, but I
must let you go. I need to live again. But this candle will always burn for you,
so you can find your way back to me. I will always be your wife, but I need to
start and live mine."

The flame flickered a bit but there wasn't a draft. I could feel his presence
once more and again I could feel this almost overwhelming love come over me. I
knew Brian was okay with it and I just smiled. The rest of the day I was on
cloud nine and felt happy. I put some new sheets on my bed and did the washing.
After I cleaned the kitchen I decided to order in for dinner.

The sound of trumpets calling reveille indicated Travis had sent a message.
Instantly I got nervous and saw he had sent me a video. When the video started I
saw my sons face.

_Hey Mom,

So good to hear you had a nice time. We've been on training for the past couple
of days and just returned. I wasn't allowed to bring my phone and was happy to
see your videos. About the last one you sent. Did you mean to tell me you were,
um let's say, with that woman? If so, I don't mind. Just want to be sure you
meant what I think you meant.

I am just happy to see you happy again. You haven't been this happy in a long
time and I am so happy for you. Wow, that's a lot of happy I just said there.
But I still meant what I said.

Just tell me everything, okay? I want to know everything you do. I love you,
mom. Hope to see you soon._

My heart melted as I watched him. I watched his video over and over again. I
connected my phone to my laptop and stored the video in a special folder where I
kept all his videos. 'I should by a decent camera' I thought and before I knew
it I was out the door, walking over to the mall. A nice boy helped me pick a
camera, the one I chose was a bit more expensive than I had planned but the boy
had assured me it was the best. I also got a tripod and a circular light, again
on the advice of the boy helping me. He had advised me to charge the camera
before I used it and he showed me the basic workings of the camera.

When I got home I connected the charger to the wall socket and placed the camera
on top of it. The indicator showed me it was charging and it would take almost
three hours to fully charge. I sat down on the couch and read the manual a bit.
Watched a movie until a beep indicated the camera was fully charged.

I took some random photo's with it and was amazed at the quality of them. My
laptop detected the camera and I copied the photo's over to my laptop. On the
screen the photo's were even better and I was so happy the boy had pushed me to
buy this camera. Time to try the video settings.

After connecting the camera to the tripod I placed them a few feet away from me.
I started the recording and sat down on my chair. I didn't say anything and
after a minute or so I stopped the recording. When I saw the result on my laptop
I was a bit disappointed and then remembered the light. I opened the box,
clipped the light to the tripod as indicated in the manual and connected the
light to my camera. _Using the internal power of the camera will make your
camera last shorter. It is better to connect it to it's own power source by
utilizing the power adapter which is sold separately_ the manual stated.

As I didn't have that extension camera power would have to do. When I turned on
the camera the light almost blinded me, but the result was way better and I was
glad I had decided to purchase that ringlight. I played with the camera some
more and afterwards I went to bed.

The next morning I got up early, grabbed a few things and my new camera. I had
decided to walk the trail Brian had loved and to take some stills of the
environment. I got in my car and drove over to the trial. Once there I got out,
grabbed my backpack, hung the camera on my neck and started walking. A sudden
warm breeze made me feel like Brian was with me. After about half an hour I
stopped to enjoy an amazing view. Even better then the one at the sightseeing
place where we had scattered his ashes. I finally understood why Brian loved to
come here.

I took a couple of photo's and pressed on. I was determined to walk the entire
trail. Halfway there was another amazing view over the valley below and the
mountains behind it. I was all alone with just nature around me. I took off my
backpack and sat down to enjoy the view. I ate something and drank some ice tea
from the flask I had brought with me. I lay down and just looked at the sky. I
felt at peace for the first time in years.

After about 10 minutes I took out the tripod and started recording a video.

_Hi Travis,

You said to tell you everything I did. So here I am on the trail dad used to
walk, remember? It's so beautiful out here and I finally understand why he loved
to come here. I just don't understand why it took me so long.

Well, as you might notice I am not recording this on my phone any more. I've
bought a good camera and it's one of the best things I have ever bought. So I
will be recording these on the new camera from now on, I guess.

Anyways, I just needed to tell you where I was and how happy I feel. How much I
love you and I need to open up to you. Travis, I need to tell you how I feel. I
just don't know how. I can't hide it anymore but I don't want to hurt you
either. So if you really want to know what I feel tell me. Tell me you want to
see what I feel. I love you so much and I miss you. Bye honey, see you soon._

My heart was beating fast in my chest. I had almost told him what I really felt.
But I just couldn't conquer that imaginary wall just yet. I packed my stuff and
walked the rest of the trail. Tired but happy I got back in my car and drove
home. After dinner I loaded the photo's and videos I took onto my laptop and
sent the video to Travis. Nerves ran through my body as I did so.

A few days went by without any reaction from Travis and I felt sure I had gone
too far. I was sure he was mad at me. It was another Friday when the doorbell
rang. I wasn't expecting anyone and almost fainted when I saw who had rang the
bell. A soldier in an immaculate uniform stood there, his cap underneath his arm
and standing proud. It was Travis, he had changed so much. He was even broader
then I remembered and he saluted when I opened the door. "Bailey, Travis.
Reporting for duty, ma'am." he said.

I jumped into his arms and kissed his cheeks. I cried as hard as I could, my son
had come home. Sam even opened to door to see what was happening and he shook my
sons hand to thank him for his service. Travis just nodded and said "You must be
Sam I've heard so much about. Pleased to meet you, sir."

"The pleasure is all mine." Sam giggled as he went back into his apartment. I
pulled Travis inside and closed the door. Travis put down the duffer bag he had
carried and walked through the apartment. "Very nice mom," he said, "very nice."
He walked into the livingroom and stopped when he saw the photo of his dad.
"That's nice too" he said. He opened his jacket and asked if he could take a
shower. I showed him where the towels were and waited in the livingroom.

After a few minutes he joined me wearing a USMC shirt and a pair of comfortable
pants. "I was so free to put my stuff in the guest bedroom" he said. I laughed
and told him "It's your bedroom and guests can stay there if they want to. But
it's still your room." I smiled. I just couldn't stop holding his hand, I was so
happy to see him again.

"You look great," I said after a while, "it's so nice to finally see you again.
It's been so long."

"Yeah, we got leave for a few days." he said as his face turned serious. "Mom, I
am graduating next week and I would love if you could be there..."

"Just tray and stop me." I interrupted.

"I know, I know, but mom, I have to go on my first mission after that.
Afghanistan is all I am allowed to tell you. My first deployment for a year."

My heart sank as I heard him say that. "When did you hear this?"

"Two days ago, but I couldn't tell you over the phone or in a video. I had to
tell you in person. That's why I requested leave for this weekend. All of us got
leave and I need to get back on Sunday."

"When will you have to go?"

"Two days after graduation. But right after grad I need to go into quarantine.
So I can just see you there for about half an hour after grad."

"Travis, nothing can keep me from being there. I will book a flight right away.
When is this?"

"On the 18Th."

"Okay, the 18th. Ah, there it is. Now where is my credit card?" I got my purse
and booked a return flight for the 18Th. I also booked a hotel room as the
return flight was the next day.

"So that's done. I will be there."

"Thank you mom."

We just chatted for a while and went out for dinner. On Travis' request we
invited Sam, Ashley, Marisha and Matt to join us. When Marisha heard about
graduation and the deployment she vowed to be there too. As did all of them. I
could see Travis was really touched by the gestures and thanked them all. We had
a lovely evening and I held my sons arm as we walked back to the apartment.

"I am so proud to finally have met you, Travis. And I will see you on your
graduation." Sam said as he stood in his doorway. "I will be there for you and
for my sister." He looked at me when he spoke the last two words.

"It would be my honor to call you uncle." Travis replied. "Ah, just call me Sam,
uncle Sam is someone else." Sam laughed. Travis suddenly realized the comparison
he had made and burst into laughter. "Then Sam it shall be." he replied.

We sat on the couch for a while and Travis told me all about basic training and
what he had to do to become a marine. I felt so proud of him when he told me he
was one of the best in his class. He told me about this girl he had met and how
they had become very good friends.

"Is it more than just friends?" I asked with a sneaky smile.

"No," Travis blushed, "but I sure hope it will become a bit more."

"Do you have a picture of her?"

He reached for his phone and showed me a picture of a beautiful dark girl. She
had long black hair and a very beautiful smile. "What's her name?" I asked.

"Alisha," Travis replied, "she's just the best. She works at a law firm and is
putting herself through college. She comes from one of the poorest neighborhoods
in Chicago and is working so hard to make something of herself. I am so proud of
her." I could see the love in his eyes.

"Travis," I said, "you've got to promise me one thing. Tell her how you feel
before you have to go. Tell her you love her and how proud I will be to be her
mother too."

Travis looked at me and had tears in his eyes. I loved it when a man of the
caliber he had become wasn't afraid to show his emotions. "I will mom, I give
you my word as a marine."

A few minutes later we went to bed and I smiled hearing the noises coming from
his room. I opened the door and watched him doing push-ups. He had taken off his
shirt and I could see all his muscles as he went up and down. I waited for him
to finish and he smiled as he stood up. "Daily exercise," he said, "and then to
think that when I started basic training I could do just short of 40, now I do
200 every night." I smiled and wished him a good night.

When I lay in my bed I thought about his body and how muscular he had become. I
took off my nightgown and squeezed my breasts. I turned over and fell asleep
only to wake up when I felt someone entering my room. I looked at the clock and
saw it was 2AM. "Mom?" Travis whispered, "are you awake?"

There I was, totally naked underneath the sheets and my son was standing in my
room. The butterflies started flying again and I just wanted to enjoy the moment
for a while. "Mom?" Travis asked again.

"Yes," I finally answered, "I'm awake. What's wrong?"

"I'm scared mom. I am so scared to go. But I have no choice, do I? I joined to
become a marine and now I am one. But I feel so scared, mom."

I switched on a light and turned over. I held the sheets to cover me. Travis
stood there in just his boxers, a strong young man but with angst written all
over his face. "Come here," I said, "Come lay down next to me."

Travis slowly made his way over and laid down next to me. I opened my arm and he
snuggled against me. My heart pounded in my throat. My son was in my arms in
just his boxers and I was totally naked underneath the sheets. "Just come to
me," I whispered, "I can't tell you everything will be okay, because I can't. I
just can say you are safe for now. You are here with me and I will do my best to
keep you safe for as long as I can."

I hugged him and felt my nipples getting hard and my crutch getting moist. I
realized my son was in my bed. Travis rolled on his back with his head on a
pillow. "It's just the thought of going there. I know I've been trained well and
I know I can trust my fellow soldiers. I don't know, mom. Did I do the right
thing?"

"Are you happy being a marine?" I asked.

"Yes, I want to serve my country."

"Then you made the right choice. Sure I will be worried about you all the time,
but that shouldn't stop you. Just make sure your comrades are safe and they will
return the favor. Knowing that will ease my worries. And just remember you will
always have a home with me."

Travis turned his head towards me and just looked at me. I opened the sheets and
whispered "Come into my arms, my son, and rest your weary body against mine."

Travis gasped when he saw my naked body and I just said "Come to me, soldier,
come to your mamma." He slowly rolled over to me and I draped the sheets over us
and took him in my arms, resting his head on my naked bosom. My nipples got even
harder then they were before. "I love you, Travis, I love you so much."

Travis very carefully placed his arm around me and we stared into each others
eyes. My heart started beating faster as I felt his hand slowly touching my
breast. I opened my arms a bit and felt my nipple against his chin. Suddenly
Travis started sucking on it and I pressed his head against it. "Oh Travis, yes,
suck my boobs. Suck them like you did when you were little."

His hands went down my back and rested on my hips. I placed one leg in between
his and I could feel his lid throbbing against it. With my hands against his
cheeks I turned his head towards me and kissed him. At first with just my lips
but then with my mouth slightly open. Our tongues touched and I turned him on
his back. I crawled on top of him, pressing my full breasts against his muscular
torso. I kissed his neck, his torso and slowly made my way down.

With a smile on my face I pulled down his boxers and gasped when I saw his
erection. It was so big. I sniffed his lid and kissed it. Then I looked into his
eyes as I took it into my mouth. 'Finally,' I thought, 'finally I am sucking my
sons cock.' I took it in as deep as it would go, I gagged on it and wanted more.
I was so wet I could feel myself dripping. I went up again, kissing my sons
body, stopping at his mouth. He put his arms around me and I felt his throbbing
cock against my belly.

Slowly I rose up a bit, while I was staring into my sons eyes I placed his big
throbbing pole against my very wet pussy. I held my finger against his lips to
tell him to be quiet. I started moving my hips sliding my pussy against his
dick. Then in one move I placed his crown against my hole and sat down. I moaned
as I felt my sons cock slide inside me. "Oh Travis," I whispered, "you don't
know how long I have dreamed of this. Finally I can feel you inside me."

"Oh mom," was all Travis could muster to say.

"Just fuck me, my son. Fuck your mother. Make her your slut. I want to be your
slut, Travis. I wanted to be one for so long."

Travis started to pump and I matched his rhythm. I bounced on my sons cock and I
could not help but scream. He then turned me on my back, spread my legs and
thrust his cock deep inside me. "Oh yes, take control of this slut, fuck me,
fuck me as hard as you can." I panted, "Fuck your mother, son. Fuck her good,
make her come all over that big dick of yours."

After just a few thrusts I had my first orgasm of that night. One of many to
follow. Travis placed his hand on my throat, choking me. I closed my eyes and
just felt his big dick stretching me out. "Oh yes, Travis, harder, make me come
again. It feels so good, Travis." He released my throat and I inhaled deeply. He
then got up and pulled me out of bed. He placed me against the window and thrust
his cock inside me again. "Show the world what a slut you are." he hissed, "let
them see who you fuck your own son." He pushed me against the glass, flattening
my breasts against it. "Oh yes, yes, fuck me, my son. Fuck me hard. Let the
world see how much you love your mother."

With every thrust he pushed me hard against the window and I was a little scared
we would break it. When suddenly he pulled out, pushed me to the floor and
exploded all over my body. I was covered in my sons cum and the feeling of his
warm seed on my skin made me come again.

I dove on his cock and cleaned it with my mouth. I sucked every last drop of his
cum out of it and when I was done I just looked up at him. I wanted more, I
needed more. I wanted him to come inside me. I wanted to feel his seed drip out
of me.

We showered together and as I was washing his cock it got hard again. I lifted
one leg and guided him inside me again. "Oh, yes, yes, I can't get enough of you
son. Just come inside me, I want to feel you come inside me. Please. Come inside
your mother." Travis started moaning and with a groan he exploded inside me. I
could feel his cock throb and twist as he unloaded his cum inside my hungry
pussy. "Oh yes, Travis, yes, come inside your mother." I groaned and bit his
shoulder as another orgasm took control of my body.

Tired but satisfied we went to sleep, Travis next to me in my bed. The next
morning I woke to the feeling of Travis fucking me. I put my arms and legs
around him as I kissed him. Again he exploded inside me sending his your cum
deep inside my pussy. "This is the best way to wake up." I whispered when we
both had regained our breath.

We had sex multiple times that day and there isn't a room in my apartment where
we didn't do it. I rode him on the couch, he fucked me in the kitchen, I sucked
him in his room and we made love in my bed multiple times. Every time he
unloaded inside my cum hungry pussy, I didn't want it any other way.

The next morning Travis got up and took a shower. After half an hour he stood in
my bedroom fully dressed in his uniform. It was time for him to go. I got up and
kissed him. "I'll see you in a few days." I said. "Okay, mom. Thanks for
everything and this, this is our little secret, okay?"

"Okay." and I kissed him again this time with my tongue deep inside his mouth,
"Just remember, I will always be your slutty mom. You can fuck me any time you
want."

Travis blushed and walked out the door. I waited for him to appear on the street
below and quickly flashed him my boobs. I then just waved and watched him get
into his car and drive off. I felt so good that I almost skipped into the
shower. I had finally shown my son how much I loved him.

The graduation was bitter sweet. I felt so proud to see him march up and to
accept his badge. He was a marine now and he saluted the flag. He then took his
place in the squadron. During the national anthem we all rose. "Ladies and
gentleman," the announcer proclaimed, "we are proud to introduce to you the 18Th
squadron of the US marine core. Attention!" All the new marines stood in
attention as a high ranking officer walked up to the mike.

"At ease," the man said, "I am so proud of these marines. They came here as mere
boys and girls, now the are men and women. Proud marines. I am so proud to say
as my final proclamation to this class of marines: Dismissed!" All the new
marines threw their hats in the air and cheered "Ruh-ah. Proud marines. I am
so proud to say as my final proclamation to this class of marines: Dismissed!"
All the new marines threw their hats in the air and cheered "Ruh-ah"

I ran over to Travis and kissed him on the cheeks. I would have rather kissed
him somewhere else, but I knew that was not possible. "Oh I am so proud of you,
honey." I just said. Marisha and the others soon joined us and congratulated
Travis. He just looked so proud and honored.

From the corner of my eye I could see someone approaching. I turned my head and
saw it was Alisha. "Go to her, honey," I whispered, "go to her." Travis looked
and gasped when he saw her. "Alisha? You made it.". He took her in his arms and
lifter her in the air. She kissed him and I could not help but feel a little bit
jealous. But I smiled and walked towards them.

"Hi, Alisha. I'm Laura." I said.

"Oh hi, Mrs. Bailey." Alisha stuttered.

"No, just Laura will do. So very nice to finally meet you."

I just stared at this very beautiful dark girl, with her alabaster skin, her
dark eyes and black hair. She was just so beautiful and I fell in love with her
the moment I shook her hand. Alisha was a bit shy but that only made her more
appealing. Travis introduced her to the rest of the group and we enjoyed a
couple of minutes together.

"Did you tell her?" I whispered to Travis. He nodded and whispered "I wasn't
sure if she would come after I told her. But she's here, mom, she's here."

"Just take her hand and walk with her. No need to stay around, just come back
before you have to go. We will be right here."

Together with the group we watched them walk off. "She's so beautiful," Marisha
sighed, "he made a good choice." Sam immediately agreed and we sat down on a few
chairs. Sam looked at me with a certain look on his face. It felt like he knew
about Travis and me and I felt like something was squeezing my heart. I tried to
shake it off and when the two lovebirds returned I hugged my son for the last
time as I wouldn't see him for the next year.

In the distance we heard a bugle and Travis had to go. We all hugged him one
last time and watched him make his way to his squadron. "Attention!" it sounded
through the air. Everybody was quiet as the "March!" sounded. Everybody who was
there saw their son or daughter march of into the distance. The band played a
marching song as they marched into the sunset.

Suddenly it was all over. I cried when I realized I wouldn't see my son for a
whole year, that he would be sent into a war zone. Ashley and Marisha held me up
as the tears rolled over my eyes. I couldn't help it. All the tension that had
built up until this moment came out.

When I sat in the car Alisha came sitting down next to me. "Laura," she said, "I
just wanted to give you this." It was a piece of paper with her phone-number.
"Please call me any time you need to. I am in love with your son and I would
very much for you to accept me as your daughter." I cried even harder and
uttered, "You were from the moment I saw your picture, Alisha." I hugged her and
invited her to join us for the evening. She accepted and we drove off you our
hotel.

Despite all that happened that day we had a very lovely evening and I retired to
my room a bit earlier than I had expected. I just wanted to be alone for a
while. As I sat in my room staring out of the window towards where Travis was I
could not suppress a feeling of dread. In just two days Travis would fly into a
country at war.

A sudden knock on the door woke me from my nightmarish thoughts and I walked
over to the door. I was surprised to see Alisha standing there. "Can I come in?"
she asked. I stepped aside and said "I thought you went home already?" I
adjusted the robe I was wearing a little bit by closing it some more.

"Nah, I got a room in this hotel too. I will go back tomorrow, I just needed to
talk to you." she said holding up two bottles of wine.

I smiled as I said "I can get into that."

We sat down on the small couch and Alisha got two glasses from the small
kitchen. She opened a bottle and handed me a glass afterwards. She leaned
backwards and said "Here's to a safe return of the one we love."

"To the one we love" I repeated and took a sip of the wine.

"So," I started after we were silent for a moment, "how did you guys meet?"

"Oh, that's a funny story. I was working and a very annoying customer kept on
doing what he did. I warned him a couple of times before he just grabbed my ass.
I slapped him and emptied a pitcher of beer all over him. My boss wasn't pleased
with it and fired me right at that instance. I just shouted I was happy to go
and stormed out. As I ran out the door I literally bumped into Travis. He asked
my why I was in a rush and I just blurted it out. I don't know why, I had never
ever done that with a stranger, but somehow I knew I could trust him."

She took a sip of wine and continued "He not only told me to wait, but he went
in and gave my former boss a piece of his mind and walked out again. He handed
me his jacket and just took me for a cup of coffee. He was so kind and gentle to
me. We had the best first date I had ever had, although I didn't know it was a
date. A few days later he called me and asked me out for a second date. I told
him it would be our first, but he said no. He then said our first date was the
night I met you."

"We became friends and you have to understand I'm from Chicago. I would never
have thought to have a white friend. But he just was so kind to me and he
listened. I fell in love with him during that second date. I just didn't dare to
act upon it. And then after his visit with you, he came to my apartment and told
me he loved me. And asked me to come to his graduation. I told him I had to
think about it, I was very confused for a while. I knew I loved him, but I also
knew most of society wouldn't accept us. But I just couldn't stay away, I had to
be there. And I am so happy I did."

I smiled and replied "Alisha, I don't care about your looks. I care about who
you are and you are so good for my son. He loves you, he really does. A mother
can see that. And I am so happy that he chose you."

Alisha smiled her beautiful smile. She took another sip from her wine and placed
it on the table in front of us. She then leaned a bit forward and whispered "He
also told me a lot about you. About how good of a mother you are and how much
you love him." She kissed me and continued "He also told me all about that
weekend. He told me everything." She kissed me again pushing her tongue inside
my mouth.

My glass almost fell on the floor and Alisha took it from me to place it on the
table. Her hand than rested on my breast and I started to breath heavily. I put
my arm around her and started kissing her back. We kissed for a while and Alisha
held her hands on my cheeks. When she started kissing my neck I panted "Wait.
What will Travis think of this?"

"Don't worry about him," Alisha whispered, "he asked me to keep you company and
that's what I'm doing." She opened my robe and kissed my nipples sending thrills
down my spine. Her soft lips touching my skin felt so good. "Let's go to the
bed," I whispered, "this couch is too small." Alisha stood up and pulled me up
from the couch. She held me in her arms as we shuffled towards the bed. Standing
in front of it she opened my robe, pushing it off my shoulders it glided down my
body onto the floor. She kissed me and pushed me on the bed.

She just stood there and looked at me. She had a slight grin on her face as she
pulled up her shirt, revealing her beautiful, full, dark breasts. With her hands
behind her she unzipped her skirt and dropped it on the floor. Her hands glided
sensually all over her body and with two fingers she pulled down her panties.
Fully naked she crawled on top of me and we kissed, pressing our naked bodies
against each other.

"Oh, Laura, ever since Travis told me about that night you two had together I
wanted to do this. I was so aroused when he told me how you took him in your
arms, pressing his head against your naked bosom. How he sucked on your full
motherly breasts." She acted on everything she said and I moaned on almost every
word. Her hand slid down to my already wet pussy and pushed a finger inside me,
at the same time she whispered "How he pushed his big fat dick deep inside you,
his own mother." She added another finger and whispered "His big dick deep
inside his own mothers very wet cunt."

"Oh yes, I loved it, I love fucking my son." I panted as Alisha's finger slid in
and out of me. "I know," Alisha whispered as she spread my legs wide adding
another finger to the mix. Not for long she pushed her whole hand deep inside me
and made a fist. "Oh yes, Alisha, yes. Fist me, make me come," I panted. She
started going faster and harder. My vision turned black as an orgasm rolled
through my body. I grabbed her arm as I wanted her to stop, but she ignored it
and kept on going. Orgasm after orgasm rolled over me, until she suddenly pulled
out and just slid her finger nails over my now over sensitive body. Every touch
send spirals of thrills through my body.

She kissed me and whispered "Now you are my bitch too. Do you want to be my
bitch?" I nodded as I was still catching my breath. "Oh you need to speak up
now, bitch," Alisha hissed, "I asked you if you wanted to be my bitch?" Again
all I could do was nod. She suddenly slapped me in the face, the sudden feeling
of pain woke me up a little, "Do you want to be my bitch?" Alisha emphasized
every word as she spoke.

"Yes," I whispered, "I want to be your bitch." I could not believe I just spoke
those words. "Good," Alisha replied, "very good. Now get up and stand over there
in the corner. Your hands folded behind your back and stay there until I tell
you to do otherwise." She pulled me up from the bed by my hair and placed me in
the corner. She folded my arms behind my back and sat down on a chair in front
of me. "You are not allowed to look at me, look down at the floor. You are my
bitch now and you will refer to me as mistress. Do you understand bitch?"

I nodded slightly. A sudden sharp pain made me almost loose my balance. "Look at
me." Alisha almost shouted, "Look at me!" I looked up and saw she had a belt in
her hands. With a fling of her arm the leather belt slapped against my body. The
pain was almost unbearable and Alisha hissed "Do you understand?"

"Yes mistress." I cried.

"Okay then. Now stop crying and accept the pain. I will only punish you when you
don't do as I said. I will reward you if you do good. Do you understand me,
bitch?"

"Yes mistress."

"Now sit down on your knees, lean back and hold your arms on your legs, palms
upwards. Like this." Alisha positioned my body, "this is how you will present
yourself. Do you understand?"

"Yes mistress."

"Okay stand up in attention"

I got up, folded my arms behind my back and stared at the floor.

"Present yourself."

I sat down in almost the same position as Alisha had shown me. Another whip of
the belt send sharp pains through my body. "That's wrong. Do it again.
Attention". Alisha repeated this time after time until I had it correct and when
I did she rubbed my clit sending almost overwhelming thrills through my body.
"See," she whispered, "I am not so bad. You did good. Now, another rule. You are
not allowed to come, not until I give you permission to come. You will have to
ask nicely. Do you understand?"

"Yes mistress."

"Good, because every time you forget I will have to punish you. And I really do
not want to do that. I don't like punishing you, but if I have to I will. Do you
understand me, bitch?"

"Yes mistress."

Alisha got up and walked over to her purse. She got out a collar and placed it
around my neck. "This collar represents you being my bitch. You are not allowed
to take it off without my permission. You will wear this collar until you come
home and I want proof that you wore it all the way there. One photo every hour.
If you don't then I will come and teach you not to defy my orders. Do you
understand, bitch?"

"Yes mistress."

"Good. Now, one last thing. See that mat over there? The one near the door?
That's where you sleep tonight. Go to bed and sleep tight."

I crawled over to the mat and lay down on it. I went into a fetus position
otherwise I wouldn't fit. Alisha stood over me, petted my head and whispered
"That's a good bitch, good night." She walked over to the bed and went to sleep.
I hardly slept and the hours ticked away. I almost started to cry and wondered
how it could have gotten this way, when I heard Alisha whisper from the bed.
"Laura, you can come to bed now. It's been long enough."

Hesitantly I got up and walked over to the bed. "No, I mean it Laura. This all
is just role-play and I want you next to me. Please." I crawled into bed and
Alisha took me in her arms. "Okay, let us agree on a safe word. Whenever you say
that word I will stop doing whatever it is I am doing, okay? What word should we
use for that?"

I thought for a moment and whispered "Rosebud" Alisha asked my why that word and
I explained "I love roses, Brian would bring me a dozen each month we were
married." Alisha smiled and said "Then rosebud it shall be. I promise you, I
will stop whenever you say 'rosebud'. And I know you don't trust me now but I
will proof it to you."

"Can I take of the collar?" I asked.

"No, that stays on until you get home. You have to proof to me you will do as I
say and wearing this collar isn't that bad. It's a thin collar and looks just
like a piece of jewelry." Alisha explained. She held me close in her arms and I
rested my head on her shoulder. "We should go to sleep now," Alisha whispered,
"Good night Laura, sleep well"

The next morning Alisha showered and washed me. She told me what to wear and
left out any underwear. She instructed me to act as normal as possible, so I
packed my stuff and went down to the lobby. I checked out, paid my bill and sat
down at the breakfast table next to Marisha, who immediately asked about my new
piece of jewelry. "Oh, Alisha gave it to me," I said, 'isn't it wonderful. I
love it."

Marisha just smiled and continued eating. Alisha joined us a few minutes later
and we had a wonderful time. After I got in my car I received a text from
Alisha: _Remember a photo every hour. You can take it off when you get home._

As I drove to the airport I smiled as this was all so very exiting. The mere
fact of the collar and not wearing underwear somehow excited me. I returned the
car and walked over to check in. In the lobby I took a selfie and send it to
Alisha. During the flight I took another one and another one when I got in my
car. When I arrived home I send her the last one. But this time I added _Can I
take it off, mistress?_ and waited for the answer. After a few minutes Alisha
replied _Yes you can, bitch_. I unclasped the collar and massaged my neck. After
a few minutes my neck felt strangely naked. But I ignored it and went on with my
day.

At the end of the day I decided to make another video for Travis.

_Hey son,

The ceremony was so beautiful and I am so proud of you. But I do miss you, a
lot. Thank you for asking Alisha to keep me company and she did. She came over
to my hotel room and we had a wonderful time together. We drank some wine,
talked and laughed. If you want me to go into details, please let me know. I
don't want to embarrass you. Well, that's about it for today. I love you so much
and please come back home to me and Alisha. We both love you very much._

After I send the video I got in the shower and got ready for bed. The next
morning I had to go back to work. When suddenly my phone rang, it was Alisha.
"Oh hey bitch, you got home safely I see. Now here are your instructions for
tomorrow. Wear a sexy dress and heels for the entire day. No underwear, do you
understand?"

"Yes mistress."

The next morning I got up, showered and put on one of the dresses I had bought
the other day. I got my heels out of the closet, did my hair and makeup and went
to work. Some of my co-workers were amazed by my outfit, but I received so many
complements I started to feel good. Even my boss complemented me. I took a
selfie at my desk and send it to Alisha, who promptly complemented me too.

After work I felt an urge to do something I never would have thought I would
ever do. I went to the mall and bought a few extra sexy dresses, the one showing
more skin than the other. I also bought the highest heels I could find and when
I got home I put them on. With my camera I took a few pictures of me wearing my
new outfits and send them to Alisha. She approved of all of them and instructed
me to send the photos to Travis.

A few hours later Travis responded with an image of a large red heart. I felt
the butterflies again and texted _Want to see more like these?_, at which he
responded _Yes_.

This time I wore the dress that hardly covered me. Just to thin stripes of
fabric covered my nipples and the skirt was very, very short. I put on the heels
I had just bought and stood in front of the camera which snapped a picture very
10 seconds. In the last one I pulled the strips to the side exposing my boobs. I
felt so excited when I send them to my son.

He responded by sending me a picture of his fully erect penis and I masturbated
to it fantasizing he was fucking me. Thus started my slut life. During the day a
respectable woman with a good job, at home a slut for her son and his
girlfriend. The photos I send Travis got more and more explicit and ended with
me spreading my legs and holding my pussy open with my fingers.

In one of them I held up a sign stating _If you want to show these to your
friends over there, you are free to do so._.
