# Title
_an erotic tale by TransGirl_

## Disclaimer
This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate timelines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as posible, forgive me any (scientific) mistakes or freedoms taken.
