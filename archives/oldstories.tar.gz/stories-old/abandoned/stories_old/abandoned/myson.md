# My Son My Lover
_an erotic tale by TransGirl_

## Disclaimer
This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as possible, forgive me any (scientific) mistakes or freedoms taken.

## Chapter 1
"Travis? Where are you? Don't make me look for you. We need to go. Come on,
Travis, where are you?" It was his favorite game, hide-and-seek but this time we
didn't have time for it. We really needed to go. Finally I saw his shoes peeping
out the curtains, I chuckled and grabbed him. "There you are." I tickled him for
a bit then said "Now that I found you we need to go, come on."

I was 21 at the time and a mother of a five year old. Despite the original shock
of their daughter being pregnant my parents loved Travis and they offered to
baby-sit him anytime I needed them. That day I had a job interview so we really
needed to go if I wanted to be on time.

"I don't want to go." Travis protested as I grabbed his jacked and put it on
him. "Nanna always makes me eat veggies."

"Yes and I've told you, if you are with Nanna and Grandpa they are the boss
until I get there and pick you up." Travis protested some more but we got in the
car and drove to my parents. My mother opened the door as we drove up. I got
Travis out the back and he ran towards her "Nanna!". Every time it was like he
hadn't seen her in years. My mother complemented me on my outfit, I got in the
car and drove off.

Four hours later I came home again. "And? How did it go?" my mother asked and I
had the most disappointed face I could muster.

"Oh mom, what will I do now? I guess I'll have to drop Travis off every day as I
start on Monday!" I jumped for joy and my mother hugged me. "Laura! I thought
you didn't get it. Oh my, I am so happy for you. Finally a job you actually
like. Liam? Did you get that? She got the job."

My father was in the back-room playing with Travis. "Yeah, yeah, I heard.
Congratulations Laura, we both are very happy aren't we Travis?" My father had
always been a Stoic man who didn't show his emotions that easily. The only times
I had ever seen him cry was when he lost his parents and when he held Travis for
the first time. When I saw the tears in my fathers eyes as he looked at my son I
knew he would always love him.

My memory went back to the moment I had to tell him I was pregnant. We had used
protection, like we always did, but clearly it hadn't been enough. The father
broke off our relationship and his parents sent him off to military school. I
had never seen him again, his parents didn't want anything to do with Travis. So
there I was pregnant at 16 sitting on the couch expecting a barrage of anger
coming my way. But instead he sat down next to me and said "Okay, okay, you need
to finish school and go to college. We'll help you take care of the child when
it's born." I burst into tears and he comforted me in his arms. "Now," he said,
"for the mandatory scolding. How could you be so careless Laura?"

"I wasn't daddy, I mean, we weren't. We used protection but it broke, I guess. I
don't know. Oh daddy, what will become of me?"

"You're going to be a mother," he said. He took my head in his hands and kissed
me on the cheeks. "I love you Laura, we'll make this work." During my pregnancy
the got used to the idea and my mother was there during the birth. Afterwards my
father asked what I called him I answered "Travis, daddy, after your father." I
had decided on that name the moment I learned I was pregnant of a boy.

"Laura?" I shook my head and returned to the present. My mother looked at me
asking "Memories?"

"Yes," I shook my head once more, "Let's celebrate. Come let's go and get some
Mexican food." 

Years later I still worked for the same company and Travis was 16. He was almost
a senior in high school on his way to go to a good college. My father had opened
a trust fund in Travis' name so he could go to a good school and when he passed
away there was enough money so we didn't have to worry about paying for it. My
mom had sold the house and lived in a smaller apartment just a few blocks from
us. Just three years after my father passing she had met a new man and they had
become good friends, I always suspected it was a bit more than friendship but I
never dared to ask.

"Travis!" I shouted "You really need to get up. You need to go to school. Come
on Travis!" He was 16 and still I had to chase him, but at least now I knew
where he was: in his bed.

"Mom!" he shouted, "I've got another 10 minutes. Please."

"No, Travis. Get out and in the shower." I waited a minute and then "Travis?!"

I smiled as I heard stumbling coming from the hallway. "Yeah, yeah, I'm out
already. Jeez." Another few minutes later I heard the shower. The news was as
depressing as always so I switched to another channel. Travis appeared in the
kitchen and made himself some serial and poured a glass of orange juice. 'He
sure turned into a handsome boy.' I thought.

Ten minutes later he was out the door and I watched as he cycled to school.
Luckily we lived in a neighborhood were children could safely walk or cycle to
school. I turned and got ready for work. On my way to work I caught a glimpse of
my son playing football with his friends and I smiled.

When I got home Travis wasn't there yet and I made myself a cup of coffee, sat
down on the couch and turned on the TV. As the anchor spoke I dropped my cup,
grabbed my purse and ran to my car. There had been a shooting at his school,
just minutes before. As I drove my phone rang, it was my mother. "Is that
Travis' school?"

All I could say was "I'm on my way mom." and broke the connection. I parked my
car at the first spot available, I didn't care it wasn't allowed to park there.
I grabbed my purse and ran to the school. A police officer stopped me and I just
shouted "My son, my son is in there. Where's my son? Travis!?"

"Please, Miss, calm down. Just go over there and they'll help." She pointed me
to a table where two women were helping the other parents. I ran over and asked
"Travis? Where's my son?"

"Travis Willingham?" I nodded and she pointed me to one of the classrooms and
ran towards it "Travis?!" I yelled. From the corner of the classroom he looked
up and turned his attention to a girl with a red stained bandage around her leg
"Are you going to be okay, Lucy? That's my mom, I need to tell her I'm okay.
I'll be right back. Okay?"

"Please don't leave me." Lucy cried. I couldn't imagine what she was going
through let alone what she had seen. I walked over to Travis and placed my hand
on his shoulder. I watched him as he held her hand and did his very best to
comfort her. He turned his head and looked at me with tears in his eyes. I just
nodded and walked away. I had never seen him this caring and felt so proud of
him. From the principle I had learned what had happened and I asked her to tell
Travis I would be at my mothers place.

We waited for him to come and when he did he dove into my arms, crying his heart
out. "I was in the bathroom when I heard: pop pop pop. The it was quiet and
another round: pop pop pop. I looked in the hallway and saw him walking towards
another class I sneaked out and made my way into the principals office. Another
few pops and then I saw the gun. The principle wasn't there. I didn't know what
to do, I had never held a gun before. Than I heard something what sounded like
an explosion. The physics teacher had shot him with his shotgun. How he got that
I have no idea. Then it became quiet, eerily quit. When I heard voices say it
was safe I came out."

He stared at his feet and was quiet for a long time "In one of the classrooms I
saw people lying there. All that blood. Then I heard someone screaming for help
and I ran in. It was Lucy, she was shot but still alive. I held my hand on her
wound, took off my shirt and pressed on there. Mom, she was so scared. She asked
me to tell her parents she loved them. Just in case." He started crying again
and I comforted him. Not knowing what to say I just remained quiet. The
principle told me that if it hadn't been for him Lucy might have not survived,
he saved her life and I felt so proud.

That day he decided to become an EMT. He told me he had watched them doing their
work and how empathizing they were when they helped Lucy. "I stayed with her
until her parents came. Her father hugged me and thanked me." I hadn't done
anything special I couldn't leave her there, alone."

"That's the ting," I whispered, "most people would have. They would have gotten
out of there. Not that it's wrong or something. It's instinct. But you didn't,
you walked towards someone in need and that's special. I am so proud of you, my
son." My mother agreed and the three of hugged.

It took Travis some time to come to terms with what had happened, he reluctantly
accepted a medal for bravery from the police and he waved all the complements
away. He wasn't a hero he said, but to many he was. Especially to Lucy, who came
walking up the stage to hand him the medal. Travis cried when he saw her
walking. "Travis," she said, "you saved my life. And I don't know how to ever
repay you for that. All I can say is tank you, thank you so much."

My mother and I had tears in our eyes as did everybody else in the audience.
From all the people in those classrooms Lucy was the sole survivor. And although
it was very rough for her, she was determined to live and struggled her way to
be happy. Every year when we remember the shooting she's the guest of honor and
is know an advocate for stricter gun laws.

Months after the shooting Travis was getting ready for school and I passed the
shower. The door was ajar and I couldn't help but look. The mirror was a bit
foggy but I could clearly see his body and what was dangling between his legs. I
stopped walking and just stared at it. 'Wow, son, that's huge.' I thought
followed by 'You can't be thinking like that. Laura, he's your son.' I shook my
head and quietly went into my bedroom.

Travis determination to become an EMT had led him to take first aid classes and
he enrolled in a youth program at the hospital. I slightly opened my door and
watched him walk towards his room with a towel around his waist. He later
shouted he was going to school and I just answered "Okay honey. Have a good
day."

I didn't have to start work until later that day and put on some comfortable
clothes. All day long the image of my son in the shower popped into my head, I
just couldn't shake that image. 'Laura, what are you doing? He's your son.' but
I felt my vagina well up and getting wet. I leaned against the kitchen counter
and imagined him kissing me. Again I called myself to order, but the flood gates
had opened and I retreated to my bedroom. I dropped on my bed and squeezed my
breasts. What I wouldn't give to feel his penis in my hand on that moment. 'I
wonder what he tasted like,' I thought and spread my legs a little. I slid my
hand underneath my sweatpants and panties. 'Oh Travis, let me taste you' I
thought. As soon as I touched my clit I whispered "Oh yes, Travis, lick me. Suck
on that clit. Make your mother come. Oh yes son, fuck me. Fuck your mother."
With a soft scream I came, immediately feeling guilty about what I had done I
stepped into the shower and got ready for work.

The next morning when Travis was under the shower I felt disappointed when the
door was closed. I really wanted to see it again. For the next weeks I caught
myself looking at Travis differently I didn't just see my son anymore, I was
attracted to him. I wanted him to take me any time he wanted. As hard as I tried
to shake these feelings they only got stronger. I dressed more sexy around the
house, showing more cleavage and smiled slightly when I noticed Travis was
looking. Then one Saturday morning I got in the shower before Travis and
_accidentally_ left the door ajar.

It was a beautiful day and I decided to soak in the sun. After opening the
drawer I took out the smallest bikini I had, checking myself in the mirror I
thought 'I should buy some new ones. Maybe later today.' I put on my silky robe
and a pair of slippers and walked towards the garden. I pulled one of the lounge
chairs into the sun, rubbed my skin with sunblock and laid down.

Although it was early the sun burnt on my skin and I just relaxed. When I heard
Travis say "Good morning mom" I called him. As he stood next to me I handed him
the lotion and asked him to do my back. I couldn't resist a smile when he was a
bit hesitant to touch me, but he did sending all kinds of jolts through my body.
I felt my nipples harden with every stroke he made. I untied the strap on my
back so he could easily reach all the spots on my back. When he reached my waist
he had gotten a bit more confident and was really rubbing it in. A quick peek
showed me he was getting hard in a certain region and I smiled at the thought I
had that effect on him.

I know a mother shouldn't think that way and that it's wrong, but I had reasoned
that as long as it stayed at thoughts it was okay. For myself I had come to the
conclusion I would never act upon my thoughts. Travis stopped rubbing sunblock
when he had reached my hips and tied my top for me. I thanked him and he was off
doing whatever he wanted to do. His touch had excited me and after checking if
he was in sight I slid my hand in my bottoms and rubbed my clit. The risk of him
catching me helped me come so quickly. To mask the wet spot between my legs, I
dipped in the pool, swam a few laps and laid down on the chair again.

Later that day I went to the mall with my best friend Ashley and we had a great
time. I bought three new bikinis and when Ashley walked off to check a dress I
grabbed a fourth one, this on was really small and handed the girl my credit
card. As a gift I bought Travis some new shirts after which we decided to sit
down at one of the coffee shops. After checking my watch I realized it was time
to head home.

As I arrived I noticed it to be rather quiet in the house. There wasn't a note
from Travis which made me worry a little bit. The events of that day did have an
impact on him and there were days he just felt depressed. When I walked down the
hallway to check his room I heard noises coming out of it. Through the slit of
the slightly opened door I could see Travis laying on his bed. I moved my head
and caught a glimpse of a girl sitting on top of him: he was having sex with
Lucy, the girl he had saved. Her small, perky boobs bounced a bit as she slid up
and down his pole. "Oh Travis, you are so big" she moaned.

I leaned back against the wall and started to masturbate. I didn't feel jealous
at all, yet I would have given anything to be in her place right at that moment.
Biting my lip as I didn't want to make any sound. I lifted up my shirt and
squeezed my boobs, sliding two fingers inside myself with the other. Looking
back inside my sons bedroom I watched them and felt an orgasm coming. My legs
started to shake and my whole body trembled. I had to hold a hand against my
mouth not to scream. At almost the same time I heard Travis roar and watched as
he splattered all his seed against her Venus mound.

As quietly as I could a sneaked back to the kitchen grabbed my bags, opened the
back door and slammed it shut. "Travis? I'm home." I shouted and chuckled as I
imagined their reactions. Slightly flustered Travis came to the kitchen, it was
clear he had been in bed. "Where you sleeping?" I asked.

"Um, yes. Why?" he asked as his face turned a bit red.

"Oh nothing, it's just your hair is a bit of a mess." I said.

"Okay, I wasn't sleeping. Mom, um, there's a girl in my room. And she's a bit
scared to come out. Could you just go to your room, so she can leave. Mom,
please, she really doesn't want to come out otherwise."

"Nonsense, who is she? Is she cute?" I smiled.

"Yes, mom she is. Mom please, for me."

"No, who is she?" and I walked towards his bedroom, opened the door and saw Lucy
straightening her dress. "Lucy! So nice to see you. Come, darling, come. You
look wonderful." Lucy stared at me as a deer in headlights. "Ah, don't worry.
Your secret is safe with me. How are you?"

"I'm okay, Miss Willingham."

"Ah, Laura, please. Miss Willingham is my mother."

I put my arm around her and whispered "It's okay. I know you two had sex and I
don't care. I am happy for the both of you." and then louder "Come, let's get
something to drink. It's lovely outside." Lucy was still a bit shy, but she
relaxed a bit. She walked with me to the garden and we talked for a while. When
Lucy left I said "You can come at any time, you hear. You're my daughter now
too, if only for a little bit." Lucy thanked me for the lovely day and she
kissed Travis on the cheek. I turned to Travis hugged him and said "What a nice
girl." He nodded and said nothing.

Lucy came around more often and one day when Travis wasn't home yet she really
opened up to me. "Ever since that day I'm having night terrors. I want to wake
up but I can't. Every time I see that gun pointed at me and I feel the pain.
Then I see the others. I see the others," tears welled up in her eyes and I
could see the pain in them. I hugged her and tried to comfort her. "There is
no-one who understands, the only one who gets close is Travis. Before that day
he wouldn't have noticed me and I would have ignored him. We lived in two
different worlds, but that day our worlds collided and he came to help."

I kissed her fore-head and just held her in my arms. "Oh Lucy, I am so sorry you
had to go through all that." Lucy cried in my arms and as Travis looked around
the corner I gestured him to go away. Lucy said "Miss Willing, oh sorry, Laura
thank you so much for accepting me in your home. Ever since that day I felt so
lonely and Travis was the one who actually asked me how I felt. He was the one
who suggested counseling and pointed me to a site with other survivors. With
them I can really talk, the really understand. Laura, could it be I am in love
with your son?"

"Could be," I answered, "and if so, then I am so happy it's you. And if he loves
you then he made an excellent choice. Lucy, I am so proud of you and you don't
have anything to be ashamed of. Everything you feel is normal and you don't have
to hide it from me. Just be you and you'll always have a safe space here."

"Now I know where Travis got it from." she laughed as she said it.

"Thanks," I replied, "he is a good boy."

"He sure is."

We chuckled and went inside. Travis sat on the couch, impatiently waiting and
when he saw I was holding her hand he smiled. "What did you two talk about?" he
asked. I waved with my hand and answered "Just girl talk, you wouldn't
understand." He chuckled and I invited Lucy to stay for dinner. She said she
couldn't and had to get home. She kissed Travis on the cheek and went home.

It was football-weekend for Travis, he was playing a double-header almost 400
miles away. Which basically meant I had the house to myself for the weekend.
After dropping Travis off at school and waved the bus off I went home and put on
a bikini to soak in the sun. To my surprise the doorbell rang and Lucy was
standing there. "Come in, come in," I said, "something wrong?" Lucy shook her
head saying "No, nothing is wrong. I just wanted to come by, is that okay?"

"Sure," I said, "come in." We sat down on the couch in the living room and I
asked her who knew she was here. "Nobody," she said, "I told my parents I was
going to the mall." We just sat there looking at each other before we kissed.
With every kiss it became more passionate and soon we were naked. I kissed her
whole body and then took her hand an guided her to my bedroom.

I laid her down on my bed and kissed her all over. "Close your eyes," I
whispered and got some rope out of my nightstand. With it I tied her wrists to
the bed and proceeded to tie her feet too. She purred as I did it. With one hand
I rubbed her clit as I sucked on her perky tits. She moaned deeply and closed
her eyes. As I kissed her mouth I reached under the pillow and got out the belt
that was hidden under there. I wrapped it around her throat and pulled it tight.
In panic she opened her eyes and I licked her as I pulled it tighter. She
started to struggle and as the minutes went on I watched as life left her body.
I pulled the belt a bit tighter making sure she was dead.

I then placed my body so that my wet cunt was placed against her dead one and I
started to grind. The feeling of her dead pussy against mine made me orgasm
multiple times. I untied her and turned her a bit. That night I slept holding
her cold dead body against me. I made love to her a few more times grinding my
wet cunt on her cold dead face. Then on the Sunday afternoon I bathed and
cleaned her. I did her makeup and placed her in the back of my car as if she was
sleeping. I drove to a very remote location and dropped her into the ravine. I
took off the surgical gloves I was wearing and put them in my car.

When I got home I watched the news about her disappearance and when the police
came by I was just as shocked as anyone else. "No, I haven't seen her since last
week." I told them. When Travis got home I pulled him close and comforted him as
he learned the news. I took him to my bedroom and we lay in the bed where just
hours before Lucy's cold body had been.

I looked at him and grabbed his cock. He was in shock when I did it "It's okay,"
I whispered, "I wanted to do this for so long." And I pushed my hand in his
pants and smiled as I felt his hard cock. I kissed him and undressed him. I got
undressed too and sucked his big hard cock. I then got on top of him and guided
him inside me. I smiled and whispered "No, mommy is on control." With the same
rope I tied him up after which I rode him. I reached for the belt and put it
around his neck. I smiled and pulled it tight. Travis struggled the best he
could, but the knots only tightened up.

"I gave you life and I can take it away." I whispered with his hard cock sliding
in and out of me. Travis face turned red and I tightened the belt a bit more. He
fought hard but has arms lost power and after ten more minutes his body went
limb. When I was sure he was dead I rode his cock until I orgasmed.

That night I pulled his cold dead body on top of me and slid his dead cock
inside my wet cunt. I fucked his dead body for a few more days and then threw
him in the trunk of my car. I put on a nice summer dress, a pair of heels and
drove off as if I was going to the beach. A few hours later in the middle of the
desert I got my dead son out of the trunk of the car, dropped him and drove off.

I got home and the next morning I called the police as if I was in a panic. I
officially gave him up as missing. Three weeks later I was arrested for both
murders and tried. I admitted the murders and I am now the only woman on death
row. Do I regret what I did? No, I would do it again. And I almost did when I
strangled that guard.
