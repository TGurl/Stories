# Hopeful
_an erotic tale by TransGirl_

## Disclaimer
This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as possible, forgive me any (scientific) mistakes or freedoms taken.

## Chapter One
The night was quiet and all I could hear were the birds chirping on the forest
surrounding the cabin. I was deep in the woods with my father at the cabin he
was building. It wasn't finished for at all, but I loved going out there with
him. Jumper our dog was running through the brush in search of his toy I threw
in there, somehow he always managed to find it.

I was 17 when this took place and my body showed all the promises of a
voluptuous woman. My dad was on the roof doing whatever he was doing and I was
cleaning our plates for lunch. The fire was crackling behind me and the smell of
roasted sausages filled the air. It was the last day with just the two of us,
the next day my mother would arrive with that brat of a brother. The plates were
clean and as I dried them I called for my father to join me.

"Just two more shingles Laura, I'll be right there." he shouted back. With just
a few blows he nailed them two the roof, stood up and proudly he looked down on
his work. "That should do it. No more leaks. I hope." I smiled and once again I
called for him that lunch was ready.

As he came down the ladder I saw his shirt was drenched with sweat. "Ew, dad
please wash yourself a bit and put on a new shirt. You smell." He laughed and
went over to the temporary bathroom, basically just a water-bucket and a pole to
hang your towel on. As I turned the sausages one more time I watched my dad take
of his shirt and stretch his muscular upper body. He washed himself a bit and
went into the cabin to get a new shirt.

We enjoyed lunch together. "I might go swimming later. It's hot and the lake
seems so inviting." He nodded and answered "You do what you wan to do, honey. I
need to get the cabin ready for mom and Brian tomorrow." He looked at the sky
and continued "It might be raining again tonight." I have no idea how he did
that but most of the time he was right. "You've got to teach me that someday." I
said laughingly. He smiled showing his perfect teeth, at that moment I knew why
my mother had fallen in love with him.

After lunch my dad started working on the bedroom. He wanted to finish with the
last window and I cleaned our plates. There was nothing for me to do after I
finished, so I grabbed my bag and walked down to the lake. It was a beautiful
place far away from the world. There was just one dirt path leading from a small
country road to the cabin. My dad had bought this land almost 4 years ago and
started working on the cabin almost 1 year ago. At first he came alone and slept
in a small tent. He first built the base of the cabin and now he was expanding
rooms to it. The more he built the quicker he could build them. The bedroom only
took him a month or two.

He had shown me where he wanted to build the kitchen, one small one at the cabin
itself, a larger one in which you could cook on a large fire in a separate
building. The cabin itself would only have the basic necessities, everything
else would become their own structures. I couldn't wait for the bath-house to be
ready and he had promised me that would be next on his agenda. I convinced him
to build it on a spot where you could look out over the lake as you took a bath.
"It would be so lovely" I said and he just laughed mentioning the lack of
privacy. "Well, we could put up some curtains and if you have enough bubbles
that shouldn't be a problem, would it?"

In the distance I could hear my dad hammering away. The sounds were at some
moments replaced with the sound of his chain-saw. I put down my towel at my
regular spot, undressed and dipped into the water. We were so far away from
civilization that I trusted nobody could see me as I went into the water naked.

When I got out of the water I put on my bikini and lay down on my towel soaking
in the sun. I listened to the sounds my father made in the distance and closed
my eyes. I don't quite know how long it was but suddenly I was awakened by a
shadow lurking over me. When I opened my eyes I saw it was my dad. "I thought I
might take a swim too." he said, took off his shirt and plunged into the water.
I watched him go under and then pop-up somewhere else. "I thought you said the
water wasn't that cold." he shouted. "Don't be a wuss, dad." I shouted back.

I got up and walked into the water. I swam towards him. When I was near he
grabbed my head and pushed me under. When I came up he was swimming away from me
laughing. "ooh, dad." I whispered and did my best to catch up with him. I
managed to get hold of his foot and pulled him under. Now it was my time to swim
away but he caught up with me in no time. This time he pushed my down with my
shoulders. When I went under I quickly untied the straps around my neck and
pushed myself up. I launched as I breached the surface. My dad's face turned
red as he saw my top hanging down clearly showing my full, still growing
breasts. He turned away and I chuckled as I said "Oops, sorry." But instead of
tying the straps again I undid the straps around my back and swam towards my
towel. I threw my top over and swam back to my dad.

My dad had gotten the ball that laid near the water and threw it to me. I
grabbed it and made it to shallower water. I stayed under for the most part and
threw it back. As my dad threw it to me again I stood up, showing my dad I was
topless. "Laura!" he shouted as he turned away, "where is your top?"

"Who cares dad?", I said, "there's nobody here but us."

He didn't look at me "But Laura, it isn't appropriate."

I walked closer to him and asked "Why?"

"It just isn't. I'm your father and I shouldn't see you this way."

"Why? They're just boobs, dad. You changed my diaper when I was a baby, you saw
way more back then."

"That's different."

I put my hand on his shoulder and turned him towards me. "Do these excite you?"
I asked. With my left hand I rubbed them and just stared at him. He couldn't
stop watching. "Do you want to touch them?" I whispered, "If you want to I
wouldn't stop you." I took his hand and placed it on my left breast. I took a
step closer to him and looked him in the eyes. "Yes, daddy, touch me. Touch me
like you touch mommy." He just stared at me and slightly squeezed my breast. He
pulled away. "No Laura, we can't be doing this. This is highly inappropriate for
me to touch you this way.

He got out of the water, grabbed his towel and made his way back to the cabin. I
followed him and half way to the cabin I caught up to him. "Dad, please wait." I
said. He stopped and said "Laura, it's just not appropriate. You shouldn't do
such a thing. I don't, no, I can't touch you that way. You are my daughter and
besides that you are only 17."

"But daddy, don't you like what you see? Am I not pretty enough?"

"That's not what I mean, Laura. And you know that. This is just not appropriate,
a father should not touch his daughter that way." He just looked at his feet and
I took a few steps closer to him. "But dad, I don't mind. I want you to touch
me, I wanted this for a long time." I said. He shook his head at which I took
his hands and placed them on my breasts. "Just feel me daddy. Don't you like
what you feel? Aren't they soft?" I whispered. He turned his head to me and
stared into my eyes. "This is so inappropriate," he whispered, "I can't be doing
this. You are my daughter." He pulled his hands away from me and held them in
the air.

"But haven't you ever thought of me? Dreamed of me?" I took a step closer again
and placed my arms around his neck. My nipples touched his muscular torso.
Softly I kissed his torso "I can help you relax.", I whispered, "I could give
you a massage, just like mommy does." He grabbed my arms and started walking
again. I watched him for a short period of time, went back to the lake to grab
my stuff. I took off my wet bikini and put on my dress. Afterwards I ran back to
the cabin, just in time to see my father enter it with his head down.

He sat down on a chair. "Laura, you make me feel uncomfortable." I walked up to
him "I'm sorry daddy. I didn't mean to do that. It's just, you work so hard and
all I do is, well, nothing really. I want to feel useful and this is a way I can
be useful to you." With my hand under his chin I lifted his head. "I've been
dreaming about this for a long time, daddy. Just let me help you relax and let
me be of use to you." He stared at me and said nothing. I took a few steps back
and slid the straps from my shoulders. My dress dropped on the floor, revealing
my naked body. I stepped out of the dress and pushed his torso back against the
chair.

I crawled on his lap, both legs on either side of him and sat down. "Come daddy,
just touch me and relax. The only thing separating his crutch from mine was the
fabric of his swimming trunks. I moved my hips a little and could feel his pole
against my labia. I bent over and softly kissed him. He placed his hands on my
back and I whispered "Yes daddy, that's it. Touch me, relax and enjoy what I'm
offering."

He pulled me a bit closer and my nipples were near his mouth. "Suck on them,
daddy, just a little." I whispered. I could feel him getting harder and started
to move my hips. With my right hand I went underneath his trunks and touched his
penis. My dad immediately grunted and I looked him in the eyes as I took it in
my hand. "Oh daddy," I moaned, "how I longed for this. Ever since I was 14 I
fantasized about this moment." I got up and pulled down his swimming trunks.
When I sat down I pushed his rod against my labia, making it wet with my fluids.
My dad started to breath heavily and whispered "This is so wrong. We shouldn't
be doing this."

I put my finger on his lips and whispered "Don't speak, daddy. Just let it
happen." I lifted myself a bit, placed his crown against my entrance and slowly
sat down. "Oh yes," I moaned, "finally. How often have I fantasized being in
moms place when you were fucking her. Now it's finally my turn." I felt my labia
separate, my pussy stretch and inch after inch I felt his rod slide inside me.

"Oh daddy, it feels so good." I whispered, "you are so big, daddy." When I
finally reached the end I had to sit quietly for a while as the walls of my
vagina adjusted to the thickness of my fathers dick. Slowly I started moving my
hips which made me feel all of his manhood. My dad started sucking my breasts
and moving his hips too. "Oh yes, daddy, fuck me. Fuck me hard. Fuck me like you
fuck mommy. Make me scream." I shouted, "I want you to fuck me everywhere you
want to. In the cabin, out by the lake, in your bed. You can fuck me any time
you want to, daddy. I am your slut now."

He lifted me up and laid me down on the bed, he spread my legs and with one push
he entered me again. He pounded me and all I wanted was him to slam his rod
harder into me, I wanted him deeper inside me. "Oh yes daddy, fuck me, I'm
almost there, keep going, don't stop, almost there," I shouted, "oh yes daddy,
fuck your daughter, fuck this slut, oh God, I'm coming, I'm coming all over
your cock, daddy!" And with that an giant orgasm rolled over my body, all my
muscles tensed up and my vagina grabbed his rod tightly. With just a few thrusts
my father pulled out and exploded all over me. His seamen splattered over my
bally, my boobs and my face. He growled as he came, he then sagged down on me
and I could hear is heavy breathing in my hear. I put my arms around him and
locked my legs around his hips. I could feel his throbbing pole against my wet
slit.

After a few minutes he rolled off of me and I bent over to clean his dick with
my mouth. I licked it, took it all in. The taste of his dick covered in his and
my fluids tasted so good. He then raised my head and said "This can never happen
again. You hear? This didn't happen."

"Okay daddy, if you say so." I replied.

The rest of the day he did his best to act as if nothing had happened, but I
caught him staring at me a couple of times. I just chuckled and thought 'Sure
daddy, it will never happen again.'

It was almost noon the next day when my mother and that annoying little brother
of mine arrived. My brother started playing with Jumper and the both of them
disappeared in the brushes. My parents talked for a bit as I was cleaning the
plates from breakfast. My mother came up to me and said "Hey there daughter,
want to go sunbathe this afternoon?"

"Sure mom, I would love to." I replied.

"Let's find somewhere secluded," she said, "I told dad not to bother us. And he
will take Brian to the hardware store."

Immediately I understood what she meant: she wanted to go topless. "I know the
perfect spot." I replied.

An hour later we waved the boys off and put on our bikinis. We walked towards
the lake chatting about this and that. When we arrived at the spot I had in mind
we spread out a large blanket, put down the bags and basket we brought and laid
down. My mother removed her top and asked me to apply the sunblock. She lay on
her stomach and I applied the lotion everywhere on her back.

She then did the same to me and then we proceeded to smear the rest of our
bodies ourselves. I watched as she rubbed it in on her breasts and I wished I
was doing it to her. We then laid down and soaked in the sun.

"Any boys lately?" she asked.

"Mom! Don't want to talk about it." I replied.

"Well, you know I was your age when you were born. So we need to talk about it
and get you on the pill. Just as a precaution. I was lucky your father never
backed away and even asked me to marry him when you were 2. But you might not
be that lucky. Look when it happens we will always support you. But it's better
safe than sorry."

I knew she was right and she knew I was sexually active. I had told her months
ago during one of her annoying sessions of "you can tell me anything" and
"please talk to me, Laura". But this time I just couldn't tell her, it was
something between my father and me. "Okay, if I agree to see the doctor can we
stop talking about this?"

"Sure honey. That's all I wanted to hear anyway. By the way we need to get you
some new bikini's, these are getting way too small."

"Well, we both know who I got them from." I replied. My mother burst into
laughter and just said "Touche."

After laying in the sun for the best part of an hour we both wanted to cool off
a bit and went into the water. I swam up to her and pushed her under. She huffed
as she came up again with I look of _now you're going to get it_ on her face she
approached me. I tried to swim away but I didn't get far, she grabbed me and
pushed me under as well. Underwater I pulled the string of her bottoms and came
up again. "Laura! What did you do?" she yelled. I went under again and pulled
the other side as well and before she knew what was happening I grabbed it and
pulled it away. My mom was now fully naked in the water. I threw her bottoms as
far as I could.

"Laura!" she shouted as she watched her bikini bottoms flying through the air. I
chuckled and proceeded to remove mine as well. She was dumbfounded when she
watched mine land near hers. She just looked at me and started to laugh "Now
what do we do?" she asked.

"There's nobody here to see us. Dad and Brian won't be back for another hour or
two. Just relax." I said.

"But Laura..."

"No mom, just relax. We can put them on before they get back and it's just us
girls here right now. So who cares?"

"I haven't been skinny dipping since I was your age." mom said.

"Wow, long over due, I would say."

"It feels sort off nice," mom said, "but it's a bit inappropriate for me to be
naked in front of you."

"Why? It's not that I haven's seen a female body before. I see one every day."

My mom laughed "I guess that's true."

We got out of the water and at first my mom was a bit embarrassed but after
about 10 minutes she got used to it and we just chatted away. The sight of her
full boobs, her wide hips started to affect me and I had to admit to myself
seeing her naked excited me. I thought of all kinds of ways I could touch her,
all of her.

I grabbed the bottle of sunblock and said "Come let me apply a second layer of
this. Just lay down." My mother turned on her stomach and I smeared the sunblock
all over her back. When I reached her hips she protested a bit but I told her
not to complain. As I was rubbing her legs I slowly made my way up her inner-
thighs, stopping just short of her crutch.

I then told her to turn over and I applied the lotion all over her front. When I
reached her breasts I massaged it in. I could hear from her breathing that she
got excited. I then poured sunblock over my breasts and pressed them against
here belly. My mom opened her eyes wide not believing what I was doing. But I
just looked at her and moved up slowly. Rubbing in the lotion with my breasts.
When I reached hers I pressed down a bit harder and held my lips just short of
hers. After a few fake kisses I pressed my lips against hers and licked her lips
with my tongue. At the same time I pushed my hand against her labia, spreading
her lips with two fingers.

"Laura!" she panted. I ignored her protests and pushed finger inside her. "Oh
mommy, you are so wet." I whispered. She spread her legs a little and she asked
"What are you doing?"

"Just relax," I said, "just let it happen."

My mother moaned as I slid another finger inside her. I pressed my mouth against
hers and pushed my tongue inside her mouth. Our tongues met and my mom put her
hands on my head pulling me closer. She stuck her tongue deep inside my mouth
and spread her legs wide. I slid more fingers inside her until they were all in.
"Oh, Laura, yes, push your hand inside me. Oh, yes, fist me. Fuck me with your
fist, Laura. Oh yes, make me come. Oh Laura, I've dreamed of this. Never thought
it would actually happen. Oh yes, slide it in as deep as you can." she panted.

I made a fist when I was inside her and pushed it in deep, almost to my elbow I
was inside her. She screamed "Oh you're so deep. Oh god, I'm coming. I'm coming
all over your arm, Laura. Oh yes, keep going, harder, faster, keep going, almost
there." With an enormous scream she orgasmed and I pulled out. She grabbed my
head pulling it close to her and she kissed me, again with her tongue deep
inside my mouth.

With her left hand she pushed her fingers inside me and I spread as wide as I
could, she got to 4 when she whispered "Just relax your muscles, accept my hand,
don't fight it." I tried to relax and suddenly I felt her hand inside me. The
feeling of her making a fist almost send me over the edge. She slid in and out
of me and I thought I went crazy. "Oh mom, you're so deep. Oh yes, go deeper, go
as deep as you can, mom. Make me scream like you did." After just a few thrusts
my whole body started to spasm and I felt my vagina clamp around her fist. I
screams as I orgasmed. She pulled out and held me in her loving arms as the
orgasm just kept going. When I came to myself I kissed her and we rolled over
each other. When she was on her back, I placed on leg underneath her the other
one over her. I pressed my wet cunt firmly against hers and started to grind.

The both of us panted and yelled "Oh yes, god yes, yes". We both orgasmed at
almost the same time. I sagged down on top of her and said "This was even better
than with daddy." She was dumbfounded and said "What? What did you say?" I
realized my mistake and had to own up.

"Yes mommy, I had sex with daddy yesterday. I wanted it. I had dreams about it
for months and yesterday I acted upon it. Just like I did with you today."

"Oh wow," she held me a bit closer and whispered, "I guess I can't blame you. He
is well hung." We both burst into laughter.

"So you are not mad?"

"No Laura, how can I be after what we just did." she answered.

"Good, because I really want him to fuck me again."

"So do I."

We were both quiet for a while before I said "Maybe you can seduce him and I
could join. So he'll know it's okay."

"We'll see. Let's not push it. It's still very taboo what we just did and we
have to make sure it's a secret between us."

"Sure mom, I understand."

"Maybe it's time to get dressed and go back. The boys will be back soon, not a
word about this with either of them."

"Okay."

We both put or dresses on and I chuckled knowing we both didn't wear anything
underneath them. That evening we roasted marsh-mellows on the campfire and had a
wonderful evening. Brian and I slept in the living room of the cabin while my
parents slept in the bedroom. Brian fell asleep quite quickly and I just stared
at the ceiling. From behind the closed door I heard the familiar sounds of my
parents having sex. I got up and walked towards the door and just listened.
Brian was still sleeping and I masturbated to them having sex.

Suddenly the door opened and my mother pulled me in. Pulled my gown of me and
gestured for me to be quiet. My dad was on the bed with my mothers dress over
his eyes as a make-due blindfold. She took my hand and said "Oh wow, you're so
hard for me, honey. I just want to suck it."

I understood where she was going and took my fathers cock in my mouth. When I
got it out she said "oh honey, so good. How does it feel?" I took his cock
inside me again. This time as deep as it would go and I gagged. "Wow that was
deep. I love it. But you know what I like the most, don't you honey?" I held my
hand against my mouth not to giggle.

I crawled on top of him and guided his love pole inside me. "Yes, honey, that's
what I like best." she pulled away the dress and continued "seeing you fuck our
daughter. Oh fuck her baby, make her feel good. Make her feel as good as she
made me feel today. Yes, baby, she told me and I love it. Fuck your daughter any
time you want baby and when you're done with her you can fuck me."

My dad grabbed my hips and started to fuck me hard and fast. "Oh honey, it's so
nice to see you fuck her." She spread her legs and started to masturbate. "Think
of all the fun we can have. Especially after I've included Brian. We could be in
one bed all together. You fucking Laura, Brian fucking me, You fucking me, Laura
fucking Brian. Oh yes, I would love that." The thought of both Brian and my dad
fucking me send me over the edge and I had another rolling orgasm.

"Mom," I panted, "I want Brian and dad fuck me at the same time. One in my
pussy, the other in my ass. And I want to suck your breasts at the same time,
mommy. I want to be their whore, their slut, their sex toy. I want them to
degrade me, to use me, to abuse me, mommy. I want to be raped by them, I don't
want them to hold back. Beat me, knock me senseless and then fuck me."

Those words made me come all over again. Then I saw the door open and Brian
stood in the door. He saw me on top of my dad, his dick inside me. He walked up,
took off his pants and dove on top of my mother. He drove his cock deep inside
her and fucked her senseless. With just a few strokes he exploded inside her and
my mom orgasmed "Oh yes Brian, give me your seed son. Put it deep inside your
mother."

Thus our new way of life had started. A few days later my mom and me went to see
the doctor and I got a recipe for the pill. We agreed to only be that way at the
cabin and to restrain from it at home. As luck would have it we went to the
cabin almost every weekend.
