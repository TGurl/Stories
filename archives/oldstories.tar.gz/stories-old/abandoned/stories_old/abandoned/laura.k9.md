# How I Become Me
_an erotica tale by TransGirl_

## The Challenge
Would you believe I wasn't always like this? Would you believe that in high
school I was a shy little girl? Sure I had my friends at school, but we didn't
hang out after school or anything. My mom kept pushing me to join something,
from the girl-scouts to the cheer squad. Everything came by until she just gave
up, I guess.

At college it all started in the same way, until I met Marisha. She was, and
still is I might add, a very outgoing, happy-go-lucky type of girl. Until this
day I still wonder why she spoke to me that day, but she did and we became close
friends. She almost tore my out of my comfort zone and took me to parties,
events and other things that happened around campus. It was on one of those days
I met Travis, immediately I was blown away by him. He was part of the football
team, I knew that much, but he also took part in the local Dungeons and Dragons
guild? He studied computer sciences? He was a jock and a geek, rolled into one.

He saw me looking at him, got up and walked over to me. From the corner of my
eyes I could see Marisha smiling. He introduced himself and talked about the D&D
Guild and asked if I would be interested. I just shook my head.

"Ah, might the fair lady be interested in a cup of hot brew? It's an excellent
vintage and the master of this establishment, that would be me, took the utmost
care in brewing it." he said flowed by a whispering of "it's just coffee but go
with it."

I laughed and Travis shouted "At last the lady has a smile." If I told you I
fell for him right there and then it wouldn't be that hard to believe now, would
it? In the weeks after he started with tipping his make believe hat every time
we crossed paths in the hallways. Then he started a small conversation every
time we met. Those meetings became longer and I always looked forward to our
next get together. Then one evening a letter was shoved under my door.

It was a white envelope with nice writing on the front. 'To the esteemed Lady
Laura' it read. On the back the letter was closed by a real seal of red wax. I
opened the letter:

_Dear Lady Laura,

We've been meeting in the hallways of this palace for quite some time now and I
do believe you are as I always looking forward to those random rendezvous in the
hallways.

Now, the King has decided there to be a ball in a fortnight and you would make
me the happiest knight in this real if my Lady would be so kind to accompany a
simple knight to said ball.

If my Lady agrees just light a candle and put it in your window for me to see, I
will be standing outside for your answer. If my Lady hasn't answered within the
next 10 minutes, I will know enough and I won't be a bother to the fair Lady any
longer.

Waiting in anticipation,

Travis,
Knight of the ellipsoid table
Slayer of Dragons._

I rushed to find a candle and finally found on in a drawer. I lit it, made sure
it was secure on the dish and put it in the window. Within seconds I heard
someone yelling "She said yes, She said yes. I've got a date to prom!" And I
just giggling.

During that dance he was so respectful and kind to me. We danced, drank some
wine, talked, laughed and at the end of the night he walked me home. In front of
the girls dorm we kissed for the first time. After which I turned away and ran
inside. When I looked out my window I saw Travis standing there. When he saw me
he took a bow, waved and walked away.

During the rest of our college years we grew closer and closer. He took me to a
D&D game and a few weeks after that I joined in as a guest. He immediately
started to court me and we played a very romantic scene together. Just before
the end of the game the villain was able to strike me and I died in the arms of
the noble knight who swore to take revenge. When the game master ended the
session for the week everybody applauded my performance during the game.

"You were so good, Laura," one of the said, "You've got to promise to come again
some day." I just smiled and looked down, I wasn't used to getting praise. But
it was Travis who took the crown by saying "My fair Lady, you were amazing in
this game. If I hadn't fallen for you yet I would have this evening. Thank you
so much for making my night."

"You've fallen for me?" I asked.

"Well yeah, isn't that obvious, I thought it was."

I blushed and said "I like you too."

That night was one of the most amazing nights of my life up until then. We
strolled on campus, kissed a few times and ended up in his bed. That was the
night I lost my virginity. The days after that he introduced me as his girlfriend
for the first time.

Two weeks after we graduated he invited me over to meet his family. I had never
been more nervous in my life. When we arrived at his parents house I was awe
struck, this wasn't an ordinary house: it was a mansion. "Oh yes," he said, "my
parents are filthy rich, but they are still simple folk."

"You never told me this." I replied.

"No, and that was one of the biggest reasons I started to like you. You had no
idea who I was or who my parents are. Other girls just hung out with me because
my parents are rich, you hang out with me because of me. And that's why I love
you Laura Baily." My mouth fell open when he said that. It was the first time he
told me he loved me.

"What did you say?"

"Yes, Laura, I love you. I've loved since the day we met."

"Aw, I", I stared at my lap and whispered, "love you too, Travis."

We kissed and walked up to the front door. A man in his late 40s opened the
door.

"Hey dad," Travis said, "this is Laura."

"Very nice to meet you Mr Willingham."

"Nice to meet you too, Laura and it's just Terry, please. I'm not my father and
hardly an old man." he laughed.

We walked in and to my surprise the whole family was there. Travis had
conveniently forgotten to mention that part.

"Hey everybody, a moment please." he shouted and when everyone was paying attention
to him he continued "I would like you all the meet my fiance Laura."

Again my mouth fell open. Did he just say fiance?

Travis got on one knee and looked me in the eyes "Laura Baily, would you make me
the happiest man in the world and accept my hand in marriage?" He opened a box
with the most beautiful ring I had ever seen.

I was flabbergasted, looked around at everyone. They were all anxiously waiting
for my answer. "Yes," I whispered.

"Um, what now?" Travis replied.

I spoke a little louder "Yes."

"Didn't quite get that. One more time?"

"YES!" I almost shouted and everybody in the room cheered. I jumped into his
arms and kissed him. He put the ring on my finger and all the girls gathered
around me to congratulate me. That was the way I was introduced into his family.
Half a year later we had the best wedding at his parents house, all my family
was there.

Marisha was my brides-maid and Travis had two best men, hist best friend for
years and my little brother who was as proud as he could be. It by far was the
best day of my life. At the end of the day, as per tradition, we left first.
Huge letters spelled 'JUST MARRIED' and there were cans tied to our bumper. I
got in, Travis sat next to me and we drove off: we were now officially Mr and
Mrs Willingham.

## Vibe of the Bahamas
For our honeymoon we went to the Bahamas. And we strolled the white beaches,
staring out over the very blue water. We just were so happy there. We didn't
stay at a hotel or something, Travis had rented a small house near the beach and
it was simply the best. We loved every second of it.

One day he pulled me on his lap and kissed me. When his hand went up my chest I
slapped it away "Not here" I hissed. But he kept on going and I looked around to
see if anyone was there before allowing him to touch them. He slowly unbuttoned
my blouse and started sucking on my nipples. I felt them getting hard almost
instantly. With his free hand he slowly moved up my thigh and rested just short
of my now moist slit.

Almost automatically I spread my legs a little bit and I could clearly feel him
getting hard. Somehow this turned me on, me the reserved girl from high school
and college was turned on by being fondled where everybody could have seen us. I
spread my legs a bit further and softly started moaning.

In one swoop Travis not only slid my panties to the side but he also slid one
finger inside my now wet cunt. I felt my labia spread apart as his finger slid
inside me. I moaned a little louder, although I felt a bit embarrassed by what
he was doing I didn't want him to stop. I placed my hand on his cheek and kissed
him. In the mean time I spread my legs even wider.

"Oh Laura" he moaned.

By this time he had three fingers inside me and a started to gyrate my hips, I
wanted him, right there and then. I got up, got his hard cock out and straddled
him, there I was the shy Laura Baily sitting down on her husbands thick cock
right there in the open for everybody to see. But I didn't care any more, I
wanted my husband to take me.

I rode his dick, grinding my clit against his body. By this time I was moaning
loudly. I didn't protest when he took off my blouse, exposing my triple-D
breasts to anyone who walked by. I had crossed a line and I didn't care any
more. I got up took of my skirt and sat down on him again, this time I was
totally naked.

"Oh yes, yes, fuck me. I want you to fuck me hard." I shouted. Travis had just
unleashed the tigress in me and I wanted him, all day long. I leaned forward,
put my arms around him and kissed him, grinding on his hard cock inside me. I
closed my eyes and just lost myself in the moment. When I opened my eyes I
realized we had gotten an audience. From almost 30 feet a dark man was watching
us, I looked at him and smiled. I got up, turned to him and sat back down
sliding Travis cock inside me. I spread my legs wide, thus giving the man a
clear view of my wet pussy sliding over that big cock.

My movement mad my boobs bounce and the man got a bit closer. He took step by
step until he stood next to us on the other side of the balustrade. He reached
over slowly until he touched my boobs, sending jolts of pleasure through my
body.

'I'm fucking my husband and a strange man is touching my boobs' I thought.
Normal me would have stopped and run away, but I didn't I wanted more. Slowly
the stranger went down until he touched my clit. I though I went crazy with joy,
just a few touches and I orgasmed so hard I thought I fainted.

Travis got excited to by seeing this stranger touching his wife and at the
moment I orgasmed he exploded inside me. He screamed as he came sending wads and
wads of cum inside my now cum hungry pussy. He patted my ass and I stood up, he
crawled from under me and I sat down again. This time turning towards the unknown
man. I spread my pussy lips, exposing the cum covered pink insides of my vagina.
He slit two fingers inside me and made me cum all over again. He just thanked me
and walked away.

I needed a moment or two to regain my wits, gathered my clothes and joined
Travis inside. He kissed me and told me "This was amazing. You were so good and
I just lost it when that guy started touching you."

"I don't know what came over me. I'm so sorry, I won't ever do that again."

"No, no, no, that's not what I meant. I loved it. Makes me feel so proud you are
my wife. If other men desire you like that. Oh man, I can't explain it. It's the
best feeling for me."

"So, you didn't mind when he touched me down there." with my head I nodded down.

"No, I loved it. I almost came instantly when he touched you there. And when you
showed him your, well, vagina it was even better. I loved it how he made you
cum."

I walked over to him and kissed him. "Relish this memory. It won't happen again.
Count on it." I said as I walked towards the shower. Somewhere deep inside me I
knew that was a lie. As I showered my thoughts went back to that moment when
that stranger and I were alone and he had tree fingers inside me. I remembered
wanting him to fuck me too. As I stood there thinking about I started
masturbating giving myself another orgasm. It was at that moment I knew I wanted
it to happen again, but it had to be organic, just like it was today.

The next few days we spent exploring the island, doing some sightseeing and
buying the most hideous presents for our family. On one of those trips we were
hiking a trail and ended up at a beautiful waterfall. Travis wanted to take a
picture of me in front of it. When I stood at the fence I noticed a small sign
stating 'Swimming allowed. Sharp rocks. Feet protection mandatory'. I told
Travis to hold on for a minute and walked down the small path leading to the
water.

The water wasn't that deep and I shouted "Are you ready?"

"For what?"

"To take the picture of your life time."

Travis walked up to the gate as I swam to the middle of the pond. The water was
cold, but it wasn't that bad. When I was near the waterfall I dove made my hair
wet and went under water. There I took off my bikini top and put it under my
bottoms. I tilted my had backwards and pushed as hard as I could with my legs. I
rose up so fast I breached the surface up until my waist, exposing my now naked
breasts to whoever was standing at the fence. Luckily the only one there was
Travis.

I laughed and swam pack to where my clothes were. Once there I noticed I had
lost my top and quickly put on my white shirt. As I didn't have a towel there
was nothing to it but to let myself dry in the hot climate of the Bahamas. When
I joined Travis two wet patches made my nipples clearly visible. He showed me
the pictures he took as I squeezed the water from my hair. The photos were
amazing, I looked like Bo Derek in the Blue Lagoon. Years later he would
surprise me with an enlargement of that photo which now has a prominent place
above our bed.

By the time we got back to our car I had fully dried up, except for my hair
which was still a bit damp. Who would have thought that I, Laura Baily, would
ever do a thing like that? I sure hadn't, but there was something really freeing
about that island. Something struck a cord with me and I loved feeling this
free. And I loved the man who allowed me to be free and to never restrict me to
become who I am.

## Ordinary Life
When we got back we had to adjust to ordinary life again. Travis joined his
fathers company and I got a job at a local veterinary as a site-manager. I loved
my job and spent many an hour with the sick or injured animals we took care off.
I loved the staff and I would like to believe they loved me.

One day a stray dog was brought in who had been struck by a car. The poor boy
was in a very bad shape and somehow this dog had something more than all the
others who had been with us. Although he clearly was in pain he wagged his tail
every time he saw me. I had to admit I fell for the guy who I named 'Sandy'
after the white beaches of the Bahamas. 

When he recovered someone had to foster Sandy and I volunteered without
hesitation. "Somehow I knew you would", the vet laughed. And that evening I took
him home for the first time.

"So we've got a dog now?" Travis asked with a slight tone of sarcasm.

"No," I replied, "we're just fostering him until he's healthy and we find a good
home for him."

"Sure" and he walked off.

I sat down on the couch and Sandy crawled up to me. It was so hard not to feel
attached to this dog and after two days I send Travis a picture of Sandy: "Look
at him, isn't he cute?" followed by "I think I'm failing this foster."

"I'm glad you finally admit it." Travis texted back.

Two days later we signed the adoption papers and Sandy was officially ours. And
although he might never admit it, Travis grew attached to this mutt too. We took
him on our hikes, to the beach and the dog was as a happy as a dog could be.

A few months later Travis had to go on a business trip for a week, leaving Sandy
and me alone in the house. We called each other every day and on the third day I
took a day off, as it was quiet at the veterinary and I had some time coming to
me anyway.

When I woke up that morning Sandy was sitting next to the bed staring at me. As
he always did he waited for me to wake up and then jump on the bed. It was time
for his morning walk. Back home I fed him and took a shower. With only my towel
covering me Sandy jumped up to me as he wanted to play. I laughed and said "No,
Sandy, down boy." But he kept jumping up to me.

In the bedroom I lost my balance for a bit, dropped my towel and just about kept
on my feet. Sandy pushed me once more and this time I couldn't hold on. As soon
as I was on the floor Sandy was on top of me. I pushed him off and got on my
knees to get up. Sandy jumped again and this time I felt his private parts
against my ass cheeks. A jolt went through my body. What was I thinking? This
can't be happening? This is just wrong.

But I couldn't deny it. As Sandy jumped on top of me once more he started
humping and I felt his penis against my slit. I noticed I was getting wet, after
one or two more humps I felt his K9 cock enter my pussy. My dog was fucking me
and I liked it! I arched my back and Sandy entered my wet cunt all the way. His
big knot entered me and I moaned loudly. 'Oh yes, Sandy, fuck me. Fuck your
mommy." He fucked me like only an animal could, I held on to his back paws and
Sandy calmed down. I stayed inside me for a few minutes, I could feel hem
ejaculate inside my cum hungry pussy.

When Sandy pulled out I could feel his K9 cum drip out of me. He lay down next
to me and started to clean his penis. I had to collect my thoughts, still not
believing what just happened. I stood up, put on a skirt and a simple shirt and
sat down on the bed. What had I just done? This couldn't be happening? This is
so wrong.

Sandy came up to me and put his head on my lap. I started petting him and
thought 'Oh you damn dog, why are you so cute?' Sandy nudged his head against my
legs forcing me to spread them, he launched forward and sniffed my still wet
slit. He started to lick me sending all kinds of feelings through my body. I
spread my legs again and leaned back on the bed. Before I knew it Sandy had his
front paws next to me and I felt his penis touch my wide open vagina.

He started humping again and for the second time that day his big dog dick
entered me. I slid a bit forward and clamped my legs around his body. "Oh yes
Sandy, yes, fuck me."

That day I had sex with my dog a couple of times and every time I loved it. I
started to crave it. For me it was the ultimate sign that I loved my dog. But
there was no way I could tell Travis about this.

The next day I went to work again and after a hard day, where we lost one of our
patients, I came home feeling rather sad. It was at moments like this I missed
Travis so much but he wouldn't be home for another two days. As always Sandy was
waiting for me by the door as I came in. I petted him, took him for his walk,
fed him and just crawled into bed. I wanted Travis to be home.

Sandy did something that day he never did on any other day. He jumped onto the
bed and crawled against me. He didn't urge me to play, he didn't whimper, he
just lay there next to me. Comforting me. I started to pet him and said "Yeah,
it was a bad day." Sandy looked at me with his understanding eyes and I kissed
him on the nose. I put my arms around him and just petted his belly.

At one moment I touched his penis and just took it in my hand. I cupped his
balls until he exposed his pink dick. When it was all the way out I got on my
knees and leaned forward. I took his dog cock in my mouth and started sucking
him. With my free hand I pulled down my panties, Sandy jumped up and mounted me.
In one swoop I felt his big dog dick enter me again."Oh yes, that's what I needed.
Fuck your mommy, Sandy, fuck me."

After that day it became some sort of a ritual. I would come home, take Sandy
for a walk, feed him and he would mount me before I took a shower. I had become
a K9 slut, I was addicted.

A few weeks later I was browsing the internet and found several sites with
videos of other women with dogs. A seed was planted although I didn't know it at
the time. A few days after Travis had gotten home he noticed the dog paying
special attention to me. I waved it off by saying "Yeah, he needs to be fixed."

But one day the inevitable happened. It was a Sunday and I woke Travis up by
sucking his cock, I just felt an urge to have sex with him. While I had his cock
deep down my throat, Sandy somehow opened the door and jumped on the bed. We
both pushed him off, but somehow he got back on. Before I knew it Sandy mounted
me and I felt his cock enter me. I moaned as I felt this big K9 cock stretching
my pussy.

I sucked Travis even harder now my dog was inside me. I moaned loudly and looked
Travis in his eyes as Sandy was humping me. "Oh yes, yes, yes, I love it. Oh
Travis it feels so good."

Travis as flabbergasted by what he saw and even more by the fact I didn't fight
it. He started jerking to seeing me fuck my dog. "Oh yes, Sandy, fuck your
mommy. Oh yes, yes, yes." I grabbed his paws again to feel his knot inside my
pussy. I looked at Travis and smiled when I saw him jerking his cock fiercely.
When Sandy pulled out, Travis got behind me and took possession of my cunt filled
with K9 sperm. It didn't take him long to explode inside me.

Afterwards Travis kissed me and said "I knew it. I just knew it." I smiled and
was happy it wasn't a secret anymore. From that day forward I never wore panties
in the house anymore, unless I was on my period. I started to always wear a
dress or a skirt around the house. It almost became normal for Travis to see me
on my hands and knees being mounted by my dog or to see me sucking Sandy's cock.
I had crossed another boundary and my limits kept getting pushed farther and
farther.

Sandy was with us for another year until he got cancer and we had to put him
down. I was inconsolable from the loss of my dearest friend and lover. We
buried him in our garden and gave him a nice head stone: 'To our dearest pet and
friend. Sandy'. That place became my solace, my place where I could cry and talk
to my best friend. I still miss that dog to this day.

## Urges met
It took me a few months to get over the loss of my dog. But I just had to let
him go at a certain point. A went for another stroll and had his leash in my
hand. At our favorite look out point over the ocean I stopped and said "Sandy,
you are free. Run wild, be free." With those words I threw his leash as far as I
could into the ocean. It was a symbolic gesture, I know, but it felt cathartic
to me. I had set my dear pet free. A breeze on my cheek almost felt like he was
licking me and I smiled, for the first time in months I smiled.

When I came home Travis noticed there was something different about me. I told
him what I did and about the breeze on my cheek. He hugged me and said "Good on
you. Let him go and live again." He kissed me and just was happy for me.

A few weeks later I noticed I felt empty somehow, like there was something
missing. It wasn't the lack of the sound of nails on the wooden floor. It was
something different. I just didn't know what it was.

Then one day, I don't know how, I came across this community on the internet of
people who where like minded. 'A place for pet lovers' the subtitle was.
Thinking it was an ordinary site for pet owners I joined and soon was greeted
with tales of men and women who enjoyed sex with animals. I read stories of
women having sex with dogs, pigs, horses even snakes.

I opened a new thread and told the story about Sandy and me. How it started and
what it became. How I missed him since he passed away, everything. And although
I used a nickname and Travis had installed all kinds of measures so nobody could
track us, it felt freeing to share my story.

Within seconds people reacted and felt sorry for my loss. Some of them shared
their story of how they lost their pets and how they finally got over it. As I
spent more time on the site I realized what I was missing, the feeling of that
dog cock inside my pussy. I really wanted to have sex with a dog again, no I
needed to feel a K9 inside me again. I longed for it.

After a few days I was granted access to a hidden part of the site. This section
wasn't just people sharing their story, they shared pictures, videos and crude
ads offering all kinds of animals for sex. Thread after thread I opened, looked
at some pictures and watched few videos. There was one longer one titled 'Nine
dogs in a day'. The video was of a very attractive woman having sex with
multiple dogs, one after the other. I started masturbating watching her get
fucked by all those dogs, wishing it was me.

I didn't tell Travis anything about the site, but in the weeks after joining it
it became somewhat of a obsession to me. I spent hours on that site, sometimes
even the whole day. During the day at work I couldn't stop thinking about the
site and every dog I saw I wanted. But I just couldn't give into it, so as soon
as I got home I joined the site and chatted with the people who were there.

Then I saw a new post. This time it wasn't a story from a pet lover, it was from
someone offering their services to the community: _Feel the urge? Don't have a
pet of your own? Contact me and we can see how we can help you fill that need_.
I was intrigued and thought about it for several days, before I responded via
Private Message. After a few hours I got a response. _If you want to do this,
come to Harrington Plaza at 1PM this Saturday. Wear something pink and a collar
around your neck. That way we will know who you are. We will pick you up in a
white van with markings of a flower shop. Please be on time, we will only wait
for 5 minutes. Don't forget to wear a mask when we pick you up._

The next two days I was elated and very anxious at the same time. Would I do it?
Did I dare? It was all just so exciting. Finally the day arrived and I told
Travis I was going shopping with Marisha. I had put on my somewhat tight pink
dress with a white blazer. I got in the car and put on my large sunglasses and
20 minutes later I parked my car near the Harrington Plaza. I sat there for a
while contemplating if I was going through with this.

As I walked over to the plaza I checked my watch, 12:45. I walked into a pet
store, bought a pink collar to match my dress and in a quiet spot I put it
around my neck. The feeling it gave me I can't describe, it just felt so natural
to me. I walked out the front of the plaza and sat down on a bench near the
street. I checked my watch again: 12:58. I could still walk away, but then a van
stopped in front of me. A woman opened the door and asked "Sandy77?" I nodded
and she said "Very nice to meet you. Come. Put on your mask."

I got into the van next to her and put on my mask. As we were sitting in the
back, I had no clue to where we were going. But almost an hour later we stopped
and two men opened the door. "Hi," one of them said, "come, follow me."

I was so nervous I could hardly walk. Where was I? And what was I getting myself
into? The men and the woman led me into a small house. And the woman introduced
herself as Misty, "Don't worry, we won't hurt you. You're with friends now. This
is Ken and this is Marvin. They are just here for our protection. Now Sandy, do
you want to do this?" I looked at her and nodded slightly, I had gone this far.

"Okay, let's start then shall we. Maybe we'll start with Rover, he's a nice dog.
So please make yourself comfortable, we're going to have some fun." And before I
knew it she took off her dress. I hesitated for a moment and then took off my
blazer. Rover walked in, a nice Golden Retriever. He wagged his tail as he
walked up do me. "Just sit down and let him sniff you" Misty said. I sat down on
the couch and spread my legs a little. Rover sniffed me and I started to relax a
bit.

Rover started to lick my panties and automatically I pulled them to the side.
The feeling of that dogs tongue on my clit sent jolts through my body. Misty sat
down next to me and started caressing my breasts. I looked at her and started to
moan. "Yes," she said, "relax, don't mind the camera's." It was only then I
realized that they were doing. They were making porn videos of women having sex
with animals. But instead of being angry I was turned on by the idea.

I lifted my legs and spread them wide. The camera got really close to the dog
licking my wet cunt. I moaned louder. Misty took out her breasts and offered
them to me. I started sucking on them, I lost myself in the thick of it. Before
I knew it I was on my hands and knees feeling Rovers cock entering my wet cunt.
He humped fiercely and I moaned as loud as I could.

I arched my back and held Rovers back legs. The camera filmed my pussy filled
with that K9 cock. I loved every minute of it. After Rover pulled out with a
soft plop, the camera recorded the K9 cum dripping out of my gaping pussy. I got
up and kissed Misty, who undressed me and started to finger me. I was so turned
on by all of this and before I knew it I was sucking the camera mans cock. I
wanted more of this.

As soon as the next dog, a Rottweiler, entered the room I got on my hands and
knees and offered myself to him. He sniffed me for a while and then mounted me.
This was the biggest cock I had ever felt entering me. I groaned deeply as I
felt this giant cock entering me. The dog started fucking me so hard, this boy
was so strong. I had multiple orgasms on this dogs cock. Misty held the dog in
place and I felt his cock twitch and turn inside me.

The camera man sat in front of me and I took his cock in my mouth. I didn't care
anymore. I wanted to feel this for ever. Right after the dog pulled out, his cum
came urging out of me. I quickly got an my back and offered myself to the camera
man who didn't hesitate and thrust his cock inside my stretched out pussy. This
was what I had missed all this time.

He fucked me hard and I moaned "Oh yes, fuck me, fuck me hard. Come inside me,
please, come inside me." He thrust a few times more and then exploded inside my
cum hungry pussy. The feeling of this stranger who I just met coming inside my
pussy gave me a giant orgasm. I screamed as loud as I could as the orgasm rolled
through my body.

An hour or two later the dropped me of at the Plaza and drove off. They had
handed me 500 dollars for my services and I smiled as I walked back to the car.
The easiest money I had ever made.

When I got home Travis noticed the scratches over my body and I had to come
clean. It took him quite some time to get over it, but finally he accepted me
for who I had become. "It isn't what you did, I don't really care about that,
just as long as you come home to me. It is the fact you kept it a secret. The
fact you kept it from me. What if something had happened to you? I wouldn't have
known where to find you."

"I am so sorry, Travis, I promise I will never ever keep secrets from you
again. I promise. I made a huge mistake, I just don't know why I did it, I just
had to."

He hugged me and we kissed. From that day forward I told him everything.

## 
