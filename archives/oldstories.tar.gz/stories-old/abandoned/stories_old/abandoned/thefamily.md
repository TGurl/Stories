# The Family
_an erotic tale by TransGirl_

## Disclaimer
This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as possible, forgive me any (scientific) mistakes or freedoms taken.

## Chapter 1
"Oh, come on. You can't do that. That's not fair, you know I don't have that
many hit points." I shouted when my brother attacked me out of the blue. We were
playing a role-playing game on the computer and his character was way stronger
than mine.

"I can't help it. The Mage put a spell on me."

"What do I need to do?"

"Attack him. Break his concentration. Got any 5th levels left?"

"Just the one."

"Do it. If you succeed I can do a 6th level one to defeat him."

I pressed the buttons on my controller and on screen a green glow surrounded my
character and a blast of green and purple mana flew towards the evil Mage. It
was just enough to break the spell and my brother cast his. The Mage was
defeated and we had finally cleared the level.

"Wow that was close." I sighed with relieve.

"But we did it Laura, we did it. And the best part is we're going to level up.
Can't wait for the next level."

"Yeah, let's just save it. I'm tired."

"Just one more level? Come on."

"No, Travis, no more levels tonight. I'm beat." I logged off and closed my
laptop. Hung my headset on the hook and walked over to my brothers room. "I just
want to get a drink and go to bed. It's almost 11:30 and we've been playing for
almost four hours. Mom and dad will be home soon and if we're not in bed by then
you'll know we'll be grounded."

"Yeah, you're right." He turned of his computer too and jumped on his bed.

We were typical siblings, we fought a lot but we loved each other and we were
best friends. Travis was just a year older than me and he loved being the older
brother. The fact that we both loved geeky stuff only added to it. I went into
the kitchen, got two diet cokes and walked back. I handed him one and sat on the
chair next to his bed.

We talked a bit about the game and then it was time to go to bed. I wished him
goodnight and closed the door. Just as I switched off my light my parents
arrived home. 'Good' I thought 'at least they've seen my light was still on. It
is good that tomorrow is a Saturday.'

My alarm woke me up to get ready for practice. I sat on my bed rubbing my eyes
for a bit and then made my way over to the bathroom. I looked in the mirror and
the image of my brother naked under the shower nearly gave me a heart attack.
Almost automatically my eyes went down to his crutch and I saw the size of his
penis.

"Laura!" he shouted.

"Why didn't you lock the door? I turned my head away, but couldn't unsee what I
had seen. I ran out and into my room. Leaning against the door I could still see
the giant schlung hanging between his legs. I shook my head to get the image
out of my head, but it didn't work. All I heard was "It's free now, go ahead. I
made sure I used all the hot water, though."

All day I kept having flashbacks to that morning. I caught myself thinking about
how it would feel. '_He's your brother. Stop it._' I thought. When I got home my
brother was in the pool and yelled for me to come in the water. But I just
couldn't. _What if I had those thoughts again? What if I got to see it again?
Maybe he would let me touch it? Lick it? No. Laura. No!_ my thoughts were racing
through my head. I felt my nipples stiffen and my pussy well up. "You need a
cold shower" I said to myself.

"What was that hon?" I heard my mother's voice behind me say. "Oh nothing, it's
just so hot. I need a cold shower." I quickly answered. "Oh no honey, if you
want to cool off join Travis in the pool. Go and get your bikini. I'll join you
two in a bit. Just need to shelve the groceries."

'_Darn it. Now I don't have a choice_' I went to my bedroom, reached for a
bikini and a few minutes later I walked out to the pool. "Hey little sister,
jump on in. How was practice?"

"It was okay. We've got a game next weekend, come to watch?"

"Sure, oh darn, that's when we play State. Sorry."

"But it's at 10 in the morning."

"Sorry, we leave on Friday."

I was very disappointed. I played field hockey now for almost two years and he
never had seen me play. Sure, he couldn't help it and I would go to see him play
the finals, I just wanted him to see me play once. Was that so much to ask?

Slowly I lowered myself in the water and swam a few laps. Then I got out and lay
down on one of the lounge chairs to enjoy the sun. As I was covering myself with
sunscreen I couldn't help but notice Travis was watching me. With both my hands
I smeared the lotion on my legs and took my time with my thighs. When it was
time to do my torso I turned my head to him and said "What are you looking at?
I'm just doing some sunscreen." Internally I giggled as Travis' head turned red.
He quickly got up and ran inside.

When my mother came out I asked her to do my back and a few minutes later I did
hers. She took the other lounge chair and we just enjoyed the sun for a while.
"Travis? Honey, please get us some lemonades. It's in the fridge." my mother
yelled as she turned over. A few minutes later Travis brought the drinks and
jumped in the pool again. He splashed some water on us and laughed.

The next morning I woke up and as the shower was free I took my chance to be the
first. The moment I wanted to lock the door I didn't. The nightgown that I was
wearing disappeared into the hamper and I started the shower. Somewhere deep
inside me I wanted Travis to walk in and see me. I washed my hair, lotioned my
body and had a sense of failure when that didn't happen.

With a towel wrapped around me and my hair I made my way into my bedroom. I blow
dried my hair, brushed it and stood in front of my dresser deciding what to
wear. I decided for my summer dress with sunflowers. I loved the way it flowed
around my body. I added a little bit of make-up to my look and walked out the
door.

My dad was sitting at the kitchen table reading yesterdays newspaper, my mom was
in the kitchen doing something and clearly Travis was still asleep. "Oh morning,
sunflower." my dad said. "Morning, um, yesterdays Herald." My dad snickered and
took a sip of his coffee.

"Hey honey, want some eggs?" my mother asked.

"With toast please."

I sat down at the bar dividing the kitchen from the rest of the house. "Mom?
Could we go to the mall today? I wanna look for a new bikini."

"Oh sorry, dear, I've got to work. Maybe your dad could go?"

"What? Dad taking me shopping? That would be a first."

"Oh please, honey," my dad complained, "don't make me shop with Laura. We'll
just go from shop to shop to shop only to return to the first one and buy stuff
she saw there." My dad winked at me as he said it.

"Ah, shush it. Oh, I know. Travis needs new trousers for the game next week.
Maybe he can take you. See, problem solved."

"What? Travis? Well, at least I could keep him from buying something stupid like
the pair he bought the other day. Those were not his best choice ever." I
replied.

"No, they weren't. Luckily the store took them back." my mom laughed.

Travis entered the room with his hair all in a mess, his shirt just about
covered his boxers and he yawned. "Morning my family."

"You need to take a shower, then eat some breakfast. You're taking your sister
to the mall. You need new pants for next week and Laura needs a new bikini. So,
get ready." my mom said.

"But mom..."

"No but mom, get ready."

Travis sighed and walked away. An hour later we got in the car and drove to the
mall. "Now," he said, "don't go all Laura on me. I just need some pants and you
need, whatever. We go in, see something nice, buy it and then we can go home. No
shopping till we are dropping. Not today. There's a game on later and I want to
see it. Understand?"

"But I can't just buy a bikini. I have to try it on. See if it fits, if I like
it, if it matches my eyes.."

"and then you need new slippers or shoes. Oh and this shirts fits nicely with it
too, see? Almost the mermaid has almost the same colors in her eyes. Yeah,
yeah." he sighed. I laughed at the exaggeration, but he wasn't wrong. That is how
it normally goes.

We arrived at the mall and we found the perfect pair of pants for him almost
immediately. I pushed for him to buy a new shirt too. Then it was my turn and in
the fifth shop I found what I liked, but I said "Nah, let's go look somewhere
else. We can always come back here later." Travis rolled his eyes and checked
his watch. "Hurry up, please."

I decided to not tease him any longer and grabbed one or two of the bikini's I
liked. Travis sat down on the bench across from the stall I used. I went in when
I felt a rush going through my body. I made sure there was a gap in between the
curtain and the divider. Just enough so I could see him and if I could see
him...

I turned my back towards him and took of my shirt, unclasped my bra and took it
off too. In the mirror I could see Travis was trying his hardest not to look. I
picked the first top to try it on. I turned a bit so my breasts were clearly
visible in the mirror. Travis turned his head as soon as he saw them. Inwardly I
giggled. I put the top on and tight the top around my back. Travis was looking
again, so I pushed up my boobs and tugged on the fabric covering my nipples.

He looked away again and I turned around, opened the curtains and asked "Well,
what do you think?" He took a quick glance and said "Nice, very nice. Don't make
this awkward, please." I went back in and closed the curtains again, making sure
he could see me. I took of the top and noticed he was taking a peek again. I
rubbed my breasts as if I was sweaty and silently laughed when I saw his red
face. The other pair I had chosen because the top was really small.

I acted as if I just noticed the gap and closed it. The other pair was just a
red bikini and the top just about covered my nipples. I decided to get them
both. I also added a wrap-around skirt and a nice silky robe to go with them.
And off course I needed a new pair of espadrillas to complete the outfit. These
had a small heel.

Travis rushed me out of the mall and just for the fun of it I said "Oh look at
those..." a couple of times. We were back just in time for him to see the game
and I showed mom what I had bought. Everything but the red bikini. Those were in
my purse, I had put them in there when I went for a quick bathroom break.

That afternoon my mom went to work and my dad was doing some yard work. Travis
mood had swung as his team had lost the game. To release his anger he helped dad
take down the old fence. He threw all his frustration in to it. As I watched him
flex his muscles I felt my nipples harden. I shifted my hips afraid the wet spot
between my legs might be visible.

How much I would have wanted I couldn't stop looking and was happy I was wearing
dark sunglasses. I had raised the lounge chair so I could rest my head against
and still watch the two men work. With his muscular arms he raised the hammer
again and unleashed a mighty blow against the concrete pole he was demolishing.

I got up and to get them some lemonade. As I was pouring the drinks into the
glasses I could hear the smashing of the hammer. I closed my eyes and envisioned
the muscles of my brother lifting that heavy hammer. I started to squeeze my
breasts and with the other hand I reached into my bottoms. Another smash and I
slid one finger inside my now fully wet pussy.

"Oh Travis," I moaned softly, "smash me, slam that hammer of yours against me."
Smash and a shudder went through my body. I started sopping I was so wet. I
lifted my leg on the counter and pushed the fabric of my bottoms aside. Another
smash and I slid two fingers inside my cunt. "Oh brother, fuck me, fuck your
sister, maker her your slut." I whispered. On the next smash I came and after
catching my breath I grabbed a paper towel, cleaned and dried myself, washed my
hands and brought the two men their drinks.

Having no idea I had just make myself come to a fantasy of having sex with my
brother they thanked me and handed me the empty glasses. "Anything for my
hardworking boys," and as our eyes crossed I added "anything." Travis just said
"whatever" and went back to work. A few hours later the new fence was up and it
was quite a bit higher than the old one. Giving us more privacy in the garden.
My dad sat in one of the chairs drinking a beer and Travis had jumped in the
pool to cool off.

From my parents bedroom I was watching Travis, fully naked and masturbating. I
just couldn't help myself anymore. The urges were too strong and I just gave in.
When I heard my dad say "I'm gonna take a shower, Travis. Please order some
Mexican if you come out. I don't want to cook tonight." I quickly put on my
dress, held my bikini in one hand and my slippers in the other. As soon as my
dad saw me I said "Do you know where moms black dress is? I wanted to see if I
wanted to borrow it for prom."

"You know mom doesn't like it when you go through her clothes. Get out." he
said. I shrugged my shoulders and walked into my bedroom. I put the bikini in my
hamper and put on a new shirt together with a mini-skirt. The shirt was like a
second skin, so tight. I walked onto the patio and just as Travis was getting
out of the water I asked "What are we eating tonight?"

"Dad wanted to order Mexican," he said and as soon as he saw my outfit he gasped
a little. The tight shirt clearly showed my curves and clearly followed the
roundness of my triple-D breasts. I hopped a little and cheered. Not because of
the food, I wanted to see him react to my bouncing breasts. He did not
disappoint, he shrugged and quickly made his way inside. From the kitchen he
ordered the food and I thought _if only you knew what I have been doing in
there_. I couldn't resist to giggle and sat down in one of the chairs.

The sound of the TV clearly indicated Travis had no plans of joining me. When he
had settled on a channel I got up to go to the kitchen and made sure he could
see my swaying boobs as I crossed in front of the TV. I then changed my mind and
got a loose blouse from my room. I had teased him enough for today.

The next day started our last week before summer break. Next weekend Travis
would have his finals and I had a week of practice too. Although I was still
disappointed my brother couldn't see me play, I was also excited for him. They
could become State Champions Soccer.

The week went by extremely fast and on Friday we waved the bus goodbye. When we
got back home I prepared my bag for the game and had a somewhat restless night.
I kept thinking about Travis and how it would feel if we were together. I threw
off the sheet that was covering me, took off my gown and started caressing my
body. I squeezed my nipples and panted "Yes, Travis, bite my nipples. Suck on
them my brother." with my other hand I rubbed my clit. Then I got up, rummaged
through my stuff and found a tube of skin lotion that resembled Travis.

I jumped on the bed, spit on my hand and rubbed my slit. I then pushed the tube
against my labia, spreading the lips with two fingers. "Oh yes, brother, slide
that pole inside me. Fuck your sister, make her yours. Yes, yes, yes, fuck me
Travis, fuck this little sister slut." I had to cover my mouth not to make too
loud noises. The sopping of my went cunt being battered by a plastic tube was
clearly audible. I arched my back as I felt myself come, I buried my face in my
pillow as a roared from the orgasm.

I threw the tube of lotion on the floor and my whole body tingled and shivered,
I had to gasp for air. When I regained my senses, I cleaned everything up and
went to bed again.

The buzzer woke me up and I slammed the alarm-clock. My mother knocked on my
door at almost the same time. "Game day" she shouted. I got up, showered, put my
uniform on and 30 minutes later we were on our way. My dad drove and my mom
cheered waving little flags with my teams logo. It was a good game but we lost
by just one goal. Which wasn't that bad, knowing we had just played the best
team in our league.

"That was a good game." my father said. He had no clue about field hockey, but
he knew we always did our best and until 10 minutes before the end we lead by
one goal. "You are getting better," he continued, "just keep on practicing and
one day this score will be the other way around."

"Yeah, I know. We did our best and I'm rather proud of us. We are improving,
just wanted Travis to see me play. Just once."

My mom hugged me. "I know, honey, I know. Maybe next time."

"Maybe next time." I repeated followed by "Now let's get ready to see him win
State." My mom cheered and my dad put his arm around me as we walked back to the
car. "Oh, a text from Travis. He asks about the game, what shall I tell him?"

"The truth." I replied.

"Okay, let's see." She spoke the words as she typed them "It went super. They
almost won against the best of the best. See you later." I smiled as she sent
the message. My mom was the best in seeing the positive things in everything.

After a quick shower and a bite to eat we made our way to where Travis was
playing the finals. It was a four hour drive and we had to hurry. I wore clothes
in the colors of our school and the jacket of our team. On the way over my mom
smeared my cheeks with the colors of the soccer team. Go Tigers.

We arrived at the stadium and were amazed how big it was. Normally the home base
for the _New England Revolution_ but tonight the host for the State Championship
Game. We walked in, bought some food and searched for good seats. The music was
playing over the speakers and mom was talking with one of the other mothers. A
girl from my team sat down next to me and we started chatting.

"Does your brother play tonight?"

"I don't know. He didn't tell us."

"My brother doesn't play. He's on the bench. Tore a muscle earlier today so
they are careful. He might sub though."

"Sorry to hear, hope he will play."

"Yeah, but it's a team effort. They are with 22 players, only 11 on the field
so anything can happen, right?"

"Right" In soccer there are only 3 substitutes, in field hockey we change
players all the time. That was about all I understood. As the start of the game
approached I felt more anxious. Then the speaker said. "Ladies and gentlemen.
Welcome to the 2019 annual high school State Championships." the crowd roared
and cheered. The speaker continued "Please welcome both teams The Inglewood
Tigers and The Mangling Wolverines!" Again the crowd cheered and roared. I
eagerly looked if I could see Travis in the base line-up and sure enough he ran
on the field as one of the last. I felt so proud of him. I could my mom scream
"That's my son! That's my son. Number 10, that's my son!"

"Ladies and Gentlemen, please rise for our national anthem." the speaker
sounded. And with that the referee blew his whistle and the game started. It
went from side to side, neither team was stronger than the other. A few times
Travis got close, but just missed the ball. At half time it there was still no
score. My dad got us something to drink and before we knew the players came on
the field again. No changes. Then out-of-the-blue a long distance shot landed in
our goal. The other team had scored. The game became a thriller our team had to
score and then out of a corner the ball landed on Travis' head, he knocked it
forward towards the goal, one of his team mates just got his foot against it and
the score was 1 all. Just one more goal to prevent overtime.

And again both teams came close, but time was up. The speaker sounded "This is a
game, ladies and gentlemen, we're going into overtime. Two more periods of 15
minutes. But as is the rule in this league, the first who scores wins the game."

The trainer had substituted Travis and I was happy for the girl next to me. It
was her brother who got time to play. Two more substitutions were made, but a
lucky goal meant the other team won.

Disappointed as we were we congratulated the people from the other school. It
had been a fair game and either of us could have won. We waited for Travis to
appear from the locker room and we congratulated him with a good game. "Ah, I
am so mad. We could have won, we were so close." I hugged him and said "Just
beat them next year." The coach asked us if Travis would join the team or if we
would take him home. Travis decided to come with us, he needed to get his mind
of things. The coach said okay and wished us all a good summer.

We took Travis to his favorite restaurant and celebrated being second in State.
That was the best we could do. When the owner of the place saw the logo on
Travis' jacked he said "Sorry man, close game. You played good, number 10
right?"

Travis lit up and said "You saw the game? Sure, our school streamed it. Didn't
you know?"

"No," Travis said, "but thanks man and congratulations. We did our best, but it
wasn't to be, I guess."

He spoke some more with the man and after half an hour we checked into an hotel.
The only rooms they had available were two smaller rooms, one with a single bed,
the other with two beds. My mom handed us the room with two beds and we went up
with the escalator.

When Travis and I walked into ours we noticed this room had just one bed. Travis
turned around to tell our parents but I stopped him. "If mom and dad have two
beds they will come. Otherwise, these were the only rooms available. Let's just
make the best of it. You take the bed and I will sleep on the couch."

"No way, if mom finds out she will scold me. You take the bed and I will sleep
on the couch. And I'm pulling rank as the older brother."

"That's something you always win, you are the only brother in the family. It's
like me saying as the eldest sister in this family."

Travis burst into laughter as he could see the irony in his statement. I started
laughing too and said "Look just sleep next to me. It's okay, the bed is wide
enough. I'll sleep under the blanket and you above. Is that a good compromise?"

"It doesn't feel right, but there's no other way. I need some rest from the
game, everything hurts. I'm going to take a shower, again."

"Sure. I placed my bag on one of the chairs and switched on the TV. I lay on the
very comfortable bed and waited for Travis to be ready. After a few minutes he
came out, wearing boxers and a t-shirt. I grabbed the long shirt I had brought,
showered, brushed my teeth and crawled next to Travis on the bed. We watched
some TV together and I crawled under the blanket and turned my back to Travis.
"Goodnight brother."

"Night sister."

He switched off the TV, turned of the light and laid down. Within minutes I
could hear he was asleep. Me on the other hand was wide awake. Contemplating my
options: we were in a hotel-room and our parents were across the hall, we were
in a bed together and I could take advantage of that fact. On the other hand
what if Travis didn't respond? What if he got angry? I couldn't act on my urges
tonight. But we were in one bed together.

Travis' movement startled me a bit and I turned around to look at him. I had my
hands in front of my mouth and peeked down. Should I dare? I carefully touched
his boxers and shrug back the moment I felt the fabric. I watched Travis as my
hand went down again. This time I not only felt the fabric, but I felt what was
underneath too. I bit my lip and watched for signs of Travis waking up.

I slowly placed my hand on his belly and waited for his reaction. Nothing. I
moved down a bit. Still nothing. I moved further down and had the top of my
fingers underneath the top of his boxers. I almost pulled back as Travis moved,
but his breathing indicated he was still asleep.

Just a little more. I pushed down and the tops of my fingers felt the softness
of his penis. I gasped as I felt it and was afraid it would wake him up, but it
didn't. I took a deep breath and in one last push I had his penis in my hand. As
I put my fingers around it I could feel it getting harder. I slowly started
moving up and down, realizing I was jerking off my brother in a hotel room. I
felt myself getting wet. '_oh my god. I'm actually doing it. I have my brothers
cock in my hand_ I thought.

I grabbed it a little tighter and started to really jerk him off. He started to
moan softly and I enjoyed hearing him getting pleasure from what I, his sister,
was doing. Travis moved a bit more and I crawled against him, placing my leg
over his. I was still jerking him as he opened his eyes and whispered "what are
you doing?" I shushed him and kept on jerking him, I placed my lips close to his
and pressed my upper body against him. Then I got up, pulled his boxers down and
started to suck on his cock. _Oh Laura, you slut, you know this is your brothers
cock, don't you_ I looked up and saw the shock on his face as he watch his
little sister sucking his cock.

I held his cock in my hand and moved up his body, making sure my breasts were
touching him. As I looked into his eyes, I raised his cock with one hand, pulled
my panties out of the way with the other and guided his big fat cock inside my
pussy. As I felt him entering me I sighed and whispered "Oh yes, finally." I
raised myself up and took of my shirt. I threw it across the room and took his
hands up to my boobs. I started moving my hips and felt his cock sliding in and
out. My breathing deepened and I bend over. This time I kissed him, on the
second time we both opened our mouths and let our tongues touch.

"Oh Travis, I wanted this for so long." I whispered.

"Me too" he answered silently.

We kissed again, pressing our wide open mouths against each other. I moved my
hips more quickly and the feeling of my brothers cock inside me almost made me
come. But I suppressed it. I wanted to wait.

"Oh you feel so good inside me." I moaned, "this is what I needed, wanted. You
know I masturbated to you, sometimes multiple times a day."

"You did?"

"Yes, brother. Your sister is a slut. She loves to fuck. I'm careful though, I
don't want a bad name, but deep inside. I'm a whore. I want to fuck every cock I
know. I want them all to take me. But most of all. I want you to take me. To
thrust your cock deep inside that wet cunt of mine." I rose up again and started
to bounce "Watch how your sister bounces on you cock, brother. Watch how she
enjoys having you cock inside her pussy. Oh yes brother, I am your slut now, you
may fuck me anytime you want. I will stop wearing panties around the house, you
can slide it in whenever, where ever you want. I am yours, your slut, your
whore."

Travis started moaning deeper, he then grabbed me, turned me on my back, raised
my legs and thrust his big cock deep inside my wet cunt. "Oh you little whore,
if only you knew how much I've jerked off on this. And now finally your mine."
He started pumping faster and harder. I started panting and bit my lip not to
make to much noise. "Oh yes, brother, fuck your sister. Fuck me as hard and deep
s you can. I want us to come together, I'm nearly there, just keep going, just
keep slamming that dick deep inside me, oh yes, yes, come inside me, come inside
your little sister, give it to me." As I felt his cock twitch and throb the
biggest orgasm I had ever felt rolled over me. My pussy was so sensitive I could
feel my brother explode inside me. I felt wads and wads of cum slam against the
walls of my vagina. I held my hand in front of my mouth not to scream.

Travis rolled off of me and we both needed to catch our breath. I could feel my
brothers cum slowly drip out of me. I turned to him and kissed him. A few
minutes later I was playing with his penis a bit. We kissed and he invited me to
lay in his arms. I crawled up against him with my head on his shoulder. Thus we
fell asleep.

The next morning a knock on the door woke us up. "Hey children, are you awake?
Please get up, we're going to get breakfast and then go home. Laura? Travis? Are
you awake?"

I giggled as we both were still naked and I shouted "Yes, mom, we're awake. Do
not open that door, Travis, I'm getting dressed. No Travis. Mom, don't open that
door I'm not decent. Please mom, we'll be right there."

Quickly I got up, grabbed the dress that was laying on the floor ad put it on.
Travis rushed to the bathroom and I opened the door slightly. My mother stared
at me and said "Everything okay?"

"Yes, mom everything's fine. Travis is just being his annoying self," I turned
my head towards the shower and shouted "Dickhead, wait till I get my hands on
you. You'll learn what a little sister can to to you DICK head."

"Now, now, Laura. That's enough. Just get dressed you two dad and I will be
waiting in the dining room, okay and Travis? Stop teasing your sister!"

"You hear that Travis? Even mom says you should not tease me."

"Just get dressed," Travis shouted, "so I can finally leave this bathroom."

My mom shook her head and said "Sometimes I do not understand the two of you.
Just hurry up, we need to go soon."

I closed the door and took my dress off. We both stepped into the shower, where
he raised on of my legs and shoved his hard cock inside me. I encouraged him to
come inside me once again. Then we got dressed and at the breakfast table I
could feel my brothers cum drip out of me while I smiled at both my parents.

## Chapter 2
In the weeks after that night Travis and I had one or two more times we got to
express the love we felt for each other. Once was when our parents were having
dinner to celebrate their anniversary, the other was on a weekend they had to
visit our grandparents. They had decided we were old enough to stay home alone
during that weekend. "Have fun." my mom said when the took off. Well we did what
she asked: we did have fun. We had fun in the kitchen, in the dining and living
room, on the side of the pool and we had more fun on their bed.

The last few hours we spent on cleaning the house and their bed. My mom did ask
why there were new linens on their bed and just said I had washed the others.
"Oh, you didn't have to do that. They were fresh ones. But thanks honey, I know
you mean well." The fact was the ones that were on their were drenched in my and
Travis' bodily fluids.

And with that summer break was over and we had to go back to school. On the
first day my period started and as always I was a bit cranky because of it.
Travis teased my and I bit him off. "I'm on my period, right. You know how I am
during this."

School was basically the same and we had agreed to play our normal roles at
school. He would be obnoxious and I would be embarrassed to call him my brother.
But secretly the both of us just wanted to jump each other. The mere fact I
couldn't fulfill my needs made me cranky and I needed a way to release. At a
party I almost threw myself at a boy, but got a hold of myself at the last
moment. I grabbed my coat and went home, feeling happy we had just kissed. There
were more girls who had been seen kissing a boy.

The day after a few girls teased me for it, but that basically died down the
following days as there was a new rumor going round. One of the girls at school,
Clare, was supposedly caught having sex in the bathrooms at school. She and the
boy were suspended and both didn't return to school. The policies were clear
about this.

As the months went on I needed to feel the excitement again. Travis and I hadn't
been together in months and masturbation in my bed wasn't enough anymore. As I
stood in front of my dresser I decided to wear a nice, decent skirt to school,
with a nice blouse and a blazer. It was an outfit made for an office environment
and I got quite a few complements, from my classmates as well as from the
teachers. Little did they know, I wasn't wearing any underwear. The movement of
my chest area caught some attention from the boys, but most of them didn't dare
to look.

I repeated to leave out my underwear more often and than just stopped wearing
them at all. Only on the days I had practice did I wear them, just because we
had to change for practice and I could hardly show my teammates I didn't wear
any. On those days my bra started to feel restrictive.

When Travis turned 18 he asked for a camera and we bought him a nice one. He had
gotten into photography after a class in school and he was rather good at it. He
went out in the world and made some really beautiful photos. As I was studying
for mid-terms he walked into my room and said "I've found this beautiful place
and I want to shoot a picture there. But I need someone to model for me. I've
asked a few girls but they didn't want to go. Please, Laura, will you help me?"

"Sure, where is it?"

"It's over by the _Old Crescent Mill_, I've found a way in and there's this
window. I've shot a photo, but it's missing something. And I think if you stand
in front of it, it might just be what I'm looking for."

"Seems exciting, count me in. When?"

"Now. It will be getting dark soon and the light needs to be just right."

"But, do I need to change?"

"No, you will be a silhouette, mostly dark. So that doesn't matter."

"let's go and make a photo."

We got in his car and we drove to the old mill. At the back was an old shed and
he opened the door. He let me in and closed the door after us. He then proceeded
to walk up an old stairway. "Watch out, some of the planks are loose." he warned
me. At the top of the shed was a walkway. "Just walk in the middle, there's a
big beam underneath it." When he reached the other side, he lend me his hand and
helped me across. We went up one more flight and we arrived almost at the top of
the mill.

At the opposite site was a largish window with some broken glass remaining in
it. He showed me were to stand and took a few photos. He re positioned me and
took another few. We waited a few minutes until the sun was half way down the
horizon and the sky turned a beautiful red and purple color. He told me to pose
and took a few more pictures.

"I've got an idea," I said, "hold on." I stepped away from the window, took off
my dress and with only wearing my shoes I posed in front of the window again.
Travis started taking pictures again. In one of them I've placed my hands on
both sides of the window and push my hips back a little bit. The thrill of
posing naked for my brother really excited me and I wished we had consumed our
love right there and then. But we needed to get out before it was too dark to
see anything.

Back home he dove behind his computer and showed me the photo he meant to make,
but then he showed me the ones of me naked. He had darkened the colors, so I was
mainly an outline against the colors of the sky. It was a stunning picture, you
couldn't even see it was me standing there. The photo we showed our parents was
the one where I was in silhouette and clearly showed the collar of my jacket.

"Oh, I want that one enlarged." she said and then scolded us for even entering
the derelict mill, "The photos are really nice, but never ever go in there
again, you hear?" We both nodded, knowing full well we would go back there one
day. An hour later Travis sent me the pictures where I was naked in front of the
window and I stored them in a folder on my private laptop.

The result was that I had fun modeling for my brother and said to him if he ever
needed a model he just had to ask. He would keep it in mind he said, but he was
more into landscapes and buildings at that time. 
