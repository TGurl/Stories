# A new life
_an erotic story by TransGirl_


_All of the below is fictional. The town, the people and everything else. My
stories take place in a different time-line. So if I mention an existing
town/city and what I describe doesn't match reality I can only say: hey, it's my
fantasy world, deal with it._

## Introduction
For the sake of this confession I will call myself Laura but everything I am
about to tell you is the truth. This is how I became the woman I am today, a
woman who I am perfectly happy to be.

It might have been a shock to them at first, but after a while they accepted it
and I can talk freely when I'm around them. My father was the hardest nut to
crack bet even he accepted it eventually and now even feels proud of what I have
accomplished. I own my own company, own a nice house and have three beautiful
children.

As I said we are a close family and when I was in high school I wasn't one of
the popular kids, I wasn't a loner either. Especially when be body started to
grow I got my attention from the boys, but I never allowed myself to go too far.
The mere fact I went to college a virgin should attest to that. But I'm getting
ahead of myself, let me start when my life started to change. In college the day
I met my husband.

## Parade
It was a sunny day in June and it was time for the annual parade of the town
where our college was situated. As per tradition our college took part with a
massive display. This year highlighting the football team who won State a few
weeks before. I was asked to help with the decorations and was busy painting one
of the giant letters in a bright green color when someone approached me.

"Oh hi, I'm sorry," the young man said, "Hi, my name is Travis and, well, one of
our flower girls has fallen sick and can't join us on the parade and since you
are already helping us, well, would you like to take her place?"

'Me? A flower girl? On this thing? No way.' I thought but when I turned and saw
his face full of embarrassment I asked "Did you guys make a bet before asking me?"
His face turned a nice shade of red when I asked him. "You did, didn't you?"

"Um, they did. I didn't take any part in it. It's degrading and, well, to be
honest I would never do such a thing to you."

"Why?"

"Why? What do you mean why?"

"Why wouldn't you do such a thing to me. I'm just a geeky girl and you are a
jock of the football team. Why wouldn't you do such a thing to me? It's what you
guys do, isn't it?"

"Maybe they are, but I don't ever feel comfortable with it. I just like to play
football and having them is like a packaged deal. Look, there's a whole other
side to me and if you would like I could show it to you."

"Are you asking me out on a date?" when I saw his face turn red again I added
"You are. You are asking me out on a date."

"No, well, maybe. But we really do need a new flower girl, the rest came out in
conversation."

I couldn't resist to smile and he surely wasn't like the other jocks. This guy
had something charming about him, he talked to me with respect not the disdain I
was used to by the likes of him. "Just tell them I'll think about it and about
the other question: if you come to me after you've read Moby Dick and tell me
all about the story maybe then I will think about it."

With that Travis walked back towards the group that was eagerly waiting for an
answer. Some of them started to laugh, other padded him on his shoulders. I
shrugged and continued painting.

That evening I was in my room which I shared with another girl who I met in
college, despite our differences we got on really well together and during those
years we bonded a friendship that lasts until current day. Although we often
studied together this night I was alone, when a knock on the door interrupted my
studies.

"Call me Ishmael. Some years ago—never mind how long precisely—having little or
no money in my purse, and nothing particular to interest me on shore, I thought
I would sail about a little and see the watery part of the world." Travis
recited when I opened the door. He looked at me and added "Next time name a book
I haven't read in high school." He winked and I couldn't hold back my laughter.

"Okay, okay, you win. When will you show me that other side of you?"

"Right now. Come."

"But, I need to study. I've got exams in a few days."

"There is something like studying too much, you know. You need to relax too and
what I'm about to show you will blow your mind." he said and grabbed my hand.

"Wait, wait, my jacket and purse!" I shouted, barely had time to grab them as he
pulled me out the door. In the hallway I put on my jacket and my purse on my
shoulder "Where are we going?"

"We're going on an adventure." was all he said.

We ended up in the basement and I was almost sure something bad was going to
happen but the excitement of Travis had made me curious and I really wanted to
know what he was talking about. At the end of a long corridor he opened a door
and when I went in I saw a group of people sitting around a table in a sparsely
lit room. At the head of the table sat another young man who introduced himself
as Matt.

"Welcome, new player?"

"Oh no, I'm just here to see what this is all about." I replied.

"Ah, Travis, nice you could make it. Sit down."

Travis sat down at the table and reached for a notepad in his bag. I grabbed a
chair and sat down in the corner of the room having no idea what was going on.
Matt started speaking "Okay, I guess it's time to start. Last time we left off
when our brave group of adventurers did their utmost to scale the mountain of
Ariratath, the birthplace of dragons. You were able to procure the one thing
that could bind the dragons to this mountain but in a fight with Arithel, the
golden one, you lost it and it fell down the mountain. During this fight you all
got very hurt and managed to find a cave small and deep enough to escape the
wrath of Arithel. So what are you going to do?"

"Who of you needs healing?" One of the girls asked, "I've got three potions left
and I can't heal you all."

"Just heal the ones who are the worst." a rather thin boy on the other side
answered.

"What are we going to do? We can't possibly win this fight without the scepter?"
Travis asked.

The session went on for hours and told about the epic fight between a group of
misfits and an army of dragons. The played scenes where one of them almost died
only to be saved by that girl who offered the potions. Somehow she mustered the
strength and courage to use the one thing she was most afraid of: a goblin of
resurrection. But ultimately they managed to get the scepter back and bind the
dragons to the mountain and made a miraculous escape back to civilisation.

This was my introduction to Dungeons & Dragons, I had never seen a role-playing
game before and I had thoroughly enjoyed it. Like the players at the table I
lost myself in the story they told, burst into laughter at the really funny bits
and shed a tear when the healer finally got the courage to become who she was
meant to be. Although it all took place in a fantasy world, these players made
it so lifelike, they weren't afraid to show how they struggled.

When Matt closed the session all I could do was clap and thank them for this
wonderful experience. "We are starting a new campaign in a few weeks. Maybe you
would like to join us. Anyone here can help you create a character." Matt said.

I nodded and replied "I'll think about it. Thanks."

The girl who played the healer said "It would be nice to have another girl in
the group, I'm Ashley by the way." I looked around and just then noticed she was
the only girl there, besides me.

"I'll think about it, thank you Ashley."

When we walked back Travis asked "And, what did you think?"

"It was wonderful. Such an amazing story. I would never have thought you would
be interested in something geeky like Dungeons and Dragons."

"Neither did I. But Matt asked me along one day and we started playing. Ever
since them I'm hooked. It's nice to play a game that tells a story and Matt is
just so good as the Dungeon Master. He always has his ways to surprise you. And
when you have a group like this, well, let's just say: these are my friends, the
team are just people I know. I know I can go to any of them for help. When my
father died it was Brian, the thin one, that supported me. This group went with
me to the funeral. All I got from my teammates was a pad on the back and a
card."

I could see the sincerity in his eyes and it was the first time I felt
butterflies in my stomach. I was so happy he showed me this other side to him. I
grabbed his arm and said "Okay, here's the deal. I will be one of your flower
girls, but you will help me study. I really need to pass this test. So do we
have a deal."

Travis looked at me and reached out his hand. I shook it and he said "Deal."

The next few days Travis helped me study and I finally understood what some of
the things meant. He was such a good teacher. After the results were posted he
joined me to see the results: A-. I jumped for joy and just kissed him,
immediately regretting that I did. Embarrassed as I was I ran away. Just before
I reached my room he caught up with me, grabbed my arm, turned me around and
kissed me. "You don't know how long I wanted to do that." he said. I smiled and
duck into my room.

A startled Marisha, who was deeply into her book, asked "What? What happened?
Something wrong?"

"No," I smiled, "nothing wrong."

"Oh my god, did you? Yes you did. You kissed him. Oh I'm so happy. You kissed
him, didn't you?"

I nodded and all excited shouted "Yes I did!"

"How was it? Why? How? Tell me everything."

I had already told her about the D&D game and how he helped me study. I also had
told her how I felt about him. She basically knew the whole story already.
"Well, I wanted to know my grade and he saw me walking towards it. He just
followed me and just before I could find out he wished me luck. When I read I
got an A- I was so happy and I just kissed him. I felt so embarrassed I ran. But
he caught up to me and kissed me and then... and then he said I didn't know how
long he wanted to kiss me. ME! Little old me."

Marisha hugged me "Oh, I'm so happy for you. He's such a nice guy. I can't wait
how some of the cheerleaders will react when they learn about this."

"Oh no, don't tell anyone. I.."

"Laura, you kissed him in the hallway. I'm sure people saw."

That was true, I couldn't deny it. "They will be so mad." I giggled. I knew some
of the popular girls were interested in Travis and weeks later I asked him about
it. He said "They're just too shallow. All they care about is their looks and
their reputation. You on the other hand care about lots of things besides those
two. You are way deeper than that and a bit of a mystery to me."

Again I'm getting ahead of myself. I really need to tell you about one of the
most embarrassing moments of my life. The day of the parade.

That morning I woke up all nervous about what was going to happen. We had made a
deal and so I just had to do it. The previous evening I had collected the dress
I was supposed to wear: a hideous cheerleader outfit with a big S in the front.
The skirt was way too short and the body way too tight. Marisha on the other
hand was amazed by how I looked. "Girl, you've got to start wearing some nicer
clothes. You look amazing."

After Marisha did my hair and make-up I felt like a failed version of a
Barby-doll. I put on a long coat to cover what I was wearing. "I don't want to
wear this let alone in a parade, throwing flowers." I protested. Marisha pushed
me out the door saying "A deal is a deal, go. It's good for you to get out of
your comfort zone." 

Anxiously I made my way to the gathering point and desperately looked for Travis
to tell him how sorry I was that I couldn't go through with it. I had made up my
mind and go home. When I finally saw him I pulled him aside to a quiet spot.
"Look Travis, normally I wouldn't back down. But this I just can't do. I feel so
embarrassed by all this."

"Okay," he replied, "but you look wonderful and I don't really understand."

I opened my coat and showed him what I was wearing. His mouth fell open and he
stuttered "Laura! You look amazing. Wow."

"Really? I feel like a Barby doll that's about to be rejected."

"Maybe so, but it wouldn't be because you're a failure. Maybe because you are
too pretty, that might be the case. Laura, you are beautiful."

I blushed when he said that then quickly replied "So, I'm not pretty or
beautiful when I'm not dressed like this?"

Travis turned white and responded "No, no, that's not what I meant. I meant..."

"I know," I interrupted, "I know, was just teasing you."

To make it short. I did end up on that cart, throwing flowers at the people
watching and I must admit after a few minutes I started to enjoy myself. I waved
at the people, threw flowers and chanted "Go Wolverines!". I had a really good
time on the float. When the parade finished at the end-point, Town Hall, I even
posed with some fans to take pictures. As covered as I was that morning, when we
walked back Travis was carrying my coat and I felt comfortable wearing that
outfit.

Marisha joined us on the way back to school and said "Look who's flaunting her
legs." and laughed. I giggled and for one of the first times I felt good about
myself. Before we reached the dorms Marisha said goodbye and Travis walked me to
our room. I opened the door and invited him in.

"Thank you for a great day." I said.

"No," he replied, "thank you for the best day."

We kissed and started to make out. He took me in his arms and I felt him pulling
down the zipper on my back. "Oh, Travis, stop." I whispered. I sat down on my
bed and almost started crying.

Travis sat down next to me "What's the matter? What's wrong?"

"It's just," I stuttered, "I've never done this before. I've never allowed
myself to. What if Marisha walks in?"

"Oh," Travis replied, "yes, I didn't know. I'm sorry. If you aren't ready I'll
wait."

"Oh Travis, you don't know how much I want to, but there's always something
holding me back. It's like a wall I can't get over, no matter how much I want
to. It's just impossible for me to scale it."

"Okay, maybe you just need some help. But only if you are ready, not before. I
will encourage you, but never push you too far."

"Oh Travis, that's something I love about you. You are so patient with me."

"Well," he said, "I can't help it, Laura, I love you."

A jolt went through my body. Did he just say? Yes he did. "What? What did you
say?"

"I love you, Laura, I have since the day I asked you for the float."

"Oh, Travis, I love you too." We kissed again and made out on my bed. This time
I let him pull down the zipper on my back and his hands felt so good on my naked
skin. Slowly he pulled down the straps on my shoulder and just as he was about
the pull them off Marisha walked in.

"Oh, God, sorry. I just needed my books. Sorry, Sorry, Sorry." She held her book
up to cover her sight and quickly walked out again. Both Travis and I burst into
laughter but the spell was broken. I got up, grabbed a few clothes and retreated
into the small bathroom.

Ten minutes later we joined Marisha in the cafeteria and she turned bright red
the moment she saw us. As soon as I burst into laughter when I saw her red head
she started laughing too and we had a wonderful evening. At one moment I caught
her looking at Matt and elbowed Travis. "She's staring at Matt, invite him
over." I whispered.

Travis got up and together with Matt they returned. One of the few times I ever
saw Marisha lost for words, but that soon changed when they started chatting. I
smiled and the four of us ended up in a local bar to have a few drinks at the
end of parade day.

After a weekend when I visited my family who were all delighted when I told them
about Travis I returned to the dorms and found out Marisha wouldn't be coming
back for another week. When she called she told me her granny had suddenly
passed away and she wanted to attend the funeral. I had told her how sorry I was
for her loss and asked her if she needed me to be there.

"No," she said, "I will be busy with the funeral and all. But thanks for the
offer, I will remember it. Just do me a favor. Have some fun over there. Please,
have some fun for me."

"Shall I tell Matt?"

"No, he already knows. He's here with me."

I smiled when I heard that. 'He's so good to her' I thought. When we hung up I
looked around the room and thought 'So I've got the room all to myself for a
whole week.' Sat down at my table, opened some books and started to study. 'What
am I doing? Marisha told me to have some fun.' I called Travis and asked him to
come over. "I can't right now," he said, "we've got practice in ten minutes.
What about 8 o'clock?"

"That's fine, just bring some taco's. I really crave some tacos."

I returned to my books until it was 7PM. Grabbed my bag and a towel and made if
over to the showers. Back in my room I browsed my closet for something to wear
when I remembered the nice black dress Marisha had showed me. I opened her
closet and reached for the dress. 'She has told me I could borrow it.' I
thought. After I had put it on I checked myself in the mirror. It was a tight
dress, showing all my curves. The only thing was my bra, it just didn't feel
right and after taking it off it looked way better.

A few minutes past eight there was a knock on the door and nervously I opened
the door. Travis was blown away by the dress and said "I thought we were just
going to eat tacos..." I smiled and invited him in.

"We are. Isn't a girl allowed to dress up a bit?" I laughed.

Travis walked in and placed the tacos on my desk. We each sat at a side and
talked about everything while we ate our food. He felt sorry for Marisha when I
told him what had happened and he was glad Matt was with her. "He's a good guy.
He will support her." he said.

After dinner we held hands and kissed. I pulled him up and pushed him to my bed.
When he sat down I took a few steps back and slowly pulled down the straps of my
dress. Travis just stared at me not saying a word. I looked him in the eyes as I
slowly pulled my dress down lower. Slowly revealing my breasts and the rest of
my body. I held the dress up with both my hands holding a strap.

"I am ready." was all I said as I dropped the dress and stepped out. The first
hurdle was taken. There I stood, with just my panties and heels. Half naked in
front of the love of my life. I took a few steps forward and thrills went
through my body when I felt his hands touch me. Automatically I started to
breath a bit heavier. His hands went up and he cupped my full triple-D breasts.
I moaned when he did. Travis moved his head closer and kissed my nipples. I
could feel them getting hard.

"Please be gentle with me," I whispered, "it's my first time."

His hands went all over my body and he pulled me closer. I bent over and kissed
him, our tongues met and I pressed my mouth against his. He caressed my thighs,
hips and the back of my body sending shivers all over me. He pulled me on the
bed and started kissing me everywhere. He then lay next to me and slowly moved
his hand in between my legs. I could feel his hand make it's way up and the
closer he got the heavier my breathing got. A jolt went through me the moment he
touched my panties. By now he could feel how wet I had gotten. I started to move
my hips and spreading my legs. With my hands in his cheeks I kissed him and
moaned loudly when I felt his finger touch my labia.

With my tongue in his mouth I felt his finger slide inside me. I couldn't help
but take a deep breath, it was the first time someone besides me had touched me
in that way. I felt my fluids amounting and I pushed my hips up. "Oh Travis" I
moaned. He slid his finger in deeper and I spread my legs wider.

He pushed in another finger and then another. To my surprise it didn't hurt that
much, not as much like other girls had told me. I started moaning deeper. "Oh
yes, Travis, yes. It feels so good." I moaned as he slid his fingers in and out
of me. Travis sat up and took of his shirt and pants. Then he proceeded to take
off my panties. I rose up and pulled of his boxers and stared in amazement at
his large penis. Careful not to hurt him I took it in my hand. We never spoke a
word during all of this.

Both naked he lay back next to me and caressed me all over my body, sucking on
my breasts. I slowly moved my hand up and down his pole. Almost organically he
got on top of me and I felt the top of his penis against my labia. I took a deep
breath and nodded. Ever so slow Travis moved forward. I could feel the lips of
my labia spread apart as the crown of his penis started to penetrate me.

"Oh god" I moaned.

Slowly he pushed on and I felt the walls of my vagina stretch to accommodate his
pole. It looked like it went on for ever until he finally stopped and lay down
on top of me. I put my arms around his neck and my legs around his hips. I was a
virgin no more, I had given him the most precious thing I had. Travis seemed to
realize this special moment and said "Oh Laura, I love you."

Then he slowly started pumping, sliding in and out of me. I started to moan
deeply "Oh, yes, Travis, fuck me. You can fuck me any time you want. I am
yours." He started moving faster and I spread my legs as wide as I could. "Oh
yes, fuck me, fuck me, FUCK ME!" I shouted. Then I felt all my muscles tighten
up, my vagina grabbed on to his cock, I shivered all over and put my nails in
his back. With a loud groan I came all over his big beautiful dick. As I bit his
shoulder I felt the orgasm everywhere. My vagina started cramping making me feel
his pole even better.

After a few more thrusts Travis pulled out and came all over my body. Wads and
wads of cum landed on me, sending met thrills all over. Although I had never
seen a man cum before I knew I loved it. Travis sagged down next to me and
kissed me. "That was the best" he said.

We laughed and did our best to regain our breath. After a while he said "You,
Laura, are no longer a virgin. How do you feel?"

"Wonderful, I'm so happy it was you." I replied.

We lay there for a while enjoying the feel of both our naked bodies against each
other. We both fell asleep feeling satisfied.

A few days later Marisha came back and I hugged her telling her how sorry I was
for her loss. She cried and told me everything. "But, that's all over now. And I
want to honor her by first finishing school and then by doing what she always
wanted to do. I'm going to open a shelter for dogs: Marsha's Shelter"

I told her how proud I was of her and she just smiled. "Okay, and what's the
news here? What about you and Travis? Had any fun?"

"Well, first let me thank you for borrowing that black dress." Marisha looked at
me and then realized what I was talking about. "Did you wear it for anything
special?"

"Oh yes."

"What?"

"Well, Travis and I ..." I winked at her, "You know.."

"Wait? What? In MY dress? Ew"

"No, I took it off before we.."

"Ah, okay. But wait, you and Travis, no. You did?"

I nodded "I'm not a virgin anymore."

Marisha cheered and hugged me with tears in her eyes. "I'm so happy for you. How
was it? Everything you hoped it would be?"

"And more. He was so gentle with me. He even waited for me to be ready for it.
He only went forward when I said okay. It was so good, Marisha, I can't believe
I waited so long for this."

"Wow, that's better than my first time. But hey, I was 14 and he was 15 so we
both didn't know anything. But wow, Laura, that's so nice. Congratulations."

We chatted for a while longer and then decided to fetch both Travis and Matt to
go out for dinner in honor of her granny. We wanted to celebrate her life
although three of us had never met her, that little fact didn't matter we got to
know her through all the stories Marisha told us that night.

## Meeting life
A few weeks after that night I introduced Travis to my family and they really
seemed to like him. My sister even said "If you ever get tired of him..." I
laughed when she said that. It was the ultimate stamp of approval from her.

After graduation we moved to another town near to where Travis had found a job.
We rented a small apartment and I moved in with him. My parents helped us move
and gifted us a nice bed. "I wished living together was a thing when I was
young. Mind you I would still have married that guy, but still it would have
been nice." my mother said with a smile on her face. "Do you hear that Travis?
Married for 24 years and still she's complaining." my father replied jokingly.

We settled in quite nicely and the fact Marisha and Matt didn't live that far
away certainly helped. Marisha started working for a veterinarian to get some
experience and Matt started a job at an advertisement agency. Travis started his
job a few days later and I was still looking for a job. "Don't worry," Travis
said, "you'll find something."

During those days I was bored at home and started exploring the city we lived
in. On one of those explorations I came across a place where they were looking
for waitresses. On a whim I walked in and applied. I just wanted to do
something. A few days later I was invited for an interview and I felt a bit
nervous when I made my way over.

As I opened the door a woman came up to me "Sorry, we're not open yet."

"Oh, I'm Laura. I was asked to come for an interview."

"Ah, Laura, come in, come in. Sorry I didn't recognize you. I'm Gabrielle, Gabby
for short. Please sit down, want a coffee?"

"Oh, that would be nice."

Gabby returned with two steaming hot cups of coffee and sat down across from me.
"Now," she said, "in your application, where is it?. Oh here, yes, in your
application you said you have no experience. So why should we hire you as a
waitress?"

"Well, I'm a quick learner and," I paused for a moment then continued, "what am
I saying? You are right. Why should you hire me? It basically comes down to: I
need a job. My boyfriend works, all my friends work and I'm going crazy at home.
I need something to do, saw the sign and applied. Thank you for giving me your
time, but it's of no use."

Gabby laughed and said "I like honesty. Come sit down again. I asked why I
should hire you as a waitress. I never said I wouldn't hire you. So you studied
management in college. Tell me about that."

I talked about college and what I had learned. How I met Travis there and how
school had prepared me for life. Gabby listened with a warm, welcoming smile on
her face. "Oh, I'm rambling." I said, "what are you looking for?"

"Oh, I'm looking for someone I like, someone who could help me run this place. I
tried to do it all on my own, but it's getting way too much. I need someone help
me with the business side of it. Look, I'm an entertainer. I love talking to
people, to make them feel good. To let them forget the 'problems' in their
lives, even be it for a few hours. That's what I'm good at."

I smiled and said "I haven't got any experience in management either. I just
studied it and did some odd jobs in college. I never was 'the' manager."

"But if nobody gives you a chance, how will you ever get that experience?"

"That's true. I can't deny that."

"Now, looking at your grades you might even be over-qualified, but I like you.
And I want to give you that chance. I didn't invite you to become a waitress, I
wanted to see who you are. So, Laura, when can you start?"

"What? Are you serious?"

"Yes, I am. Come let me show you around. The bar you've already seen, but
there's more." We got up and she took my arm. "Look, you don't have to accept
yet. Not before I've shown you what this place is all about. This place is all
about fantasy and imagination. This is a burlesque bar and we sell fantasy, with
a whole lot of liqueur I might add. But this is strictly no touch. If anyone
goes to far their out of here, patron or worker I don't care." We walked on and
went through a door.

"And this my dear Laura, is the 'speak-easy'. Decorated like it would have been
in the 20's or 30's of last century. There's the stage and our patrons sit here.
Men and women, all just having a good time. The girls bring the drinks, other
girls dance on stage. And some days even I do perform." She pointed to a 30's
style poster on the wall "That's Mindy Grisham (not her real name) she's the
singer and she's good, real good. This is the band. We've got it all. You should
come by when we're open, you'll love it."

It was all beautiful and we walked on stage to reach the back. "And this is
where the girls change." There were trolleys full of western-style dresses and
hats. The dressing rooms looked like they would in a theatre. We went up a set
of stairs and reached some offices. "This is where you would work. Together with
the girls, making sure they are well taken care off." We went down another
flight of stairs, went through another door into a kitchen. "This is where Mario
does his wonders and through here we end up in the bar again. What do you think?
Could you work here? No, don't answer me yet. Just come by tonight and bring
your boyfriend. Drinks are on me."

"You make it very hard to say no" I replied, "but I will think about it. Maybe
even show up tonight, I will have to ask Travis first."

"Sure, sure, just don't let me wait too long."

When I walked home I was excited, but had no clue what 'Burlesque' meant and
when I looked it up I was a bit surprised. Basically it was striptease without
showing too much. When Travis got home I told him about the interview and the
job. When I told him about the invite he said "Let's get ready. I'll order us
some food, you take a shower and get ready. We're going out tonight." I smiled
and jumped up.

When we arrived at the bar Gabby walked up and said "Oh wow, Laura, you could be
one of the dancing girls. You are just stunning. Come, come, and you must be
Travis. So nice to meet you."

She led us to the 'speak-easy' and pointed to a table in front. She grabbed the
'reserved' sign and asked us what we would like to drink. Travis ordered a
whiskey and I a small glass of wine. "No," Gabby said, "Mario is going to
overwhelm you both. I'll be right back." She returned with two cocktails, handed
the darker one to Travis and the yellow one to me. "You'll learn the names
quickly enough, just enjoy the evening and have fun you both."

The band started playing a jazz song and Mindy came on stage wearing a tight
glitter dress like the singers did in the older days. Gabby hadn't lied, she was
good. With her dark voice she sang "Valentine" and it was if the skies opened
up, everybody went silent to listen to this mystical bird singing. Mindy
followed with a few more songs and bowed as the audience cheered. Gracefully she
left the stage. What followed were perfect acts of strip-tease. The girls took
off their clothes, but never showed too much skin. Always covered somehow. It
was all just perfect.

Then a voice said "Ladies and Gentlemen, please welcome to the stage for one of
her rare performances, Lulu!" On walked Gabby in a beautiful dress with two
large feathered fans in her hands. She sat down on a chair in the middle of the
stage. The lights went out and the band started playing. Her dance was graceful
and magical. One after the other she removed her clothes only to cover herself
just in time when she removed her bra. The audience cheered and clapped,
including me.

When it was time to go I looked for Gabby and said "When do you want me to
start? I accept your offer." Gabby smiled and said "Tomorrow, at noon?" I nodded
and I took Travis' arm as we walked back to our apartment.

"Wasn't it magical?" I asked him.

"It sure was. I really enjoyed it, but there's one thing. If I'm working during
the day and you start at noon, when will I ever see you?"

"Oh, we'll make it work somehow." I replied, "I'm really excited about this.
It's not that I'll be performing, I'm just the manager. I can start early in the
morning if I needed too. Gabby told me so. I can schedule my own hours."

"Ah, that's nice. I would love that. Who am I kidding? I am so happy for you
Laura. The way you looked, how happy you were being there. That made me happy."

The next day I was introduced to the staff and they all welcomed me to their
family. Mindy, who actually was named Carol, said "I do have to give you a
warning though. Once you're in you're in. This is a family." Everybody laughed
and said she was right. Gabby showed me everything I had to do in the office and
told me how she handled things. "But feel free to take your own spin on it. Make
this yours, move or change the furniture to your likings. This is your office
now."

"Thanks, is it okay for me to get to know everybody?"

Gabby walked towards the door and replied "You're the manager. Do what you think
is right. Bye now."

Most of that week I spent talking to everybody, from the girls to the
bartenders. I wanted to know everything they did and to learn how they did their
work. Not that I knew better, but I had never worked in a bar before and really
wanted to learn. I even rehearsed with the girls a few times.

"Oh, Laura! You could be a performer one day" Lucy said with a wink.

"Nah, that's not for me. Could imagine me, dancing in front of an audience. No
thank you." But I had to admit rehearsing was fun and those dresses were
beautiful. One day I asked Lucy if she would take a picture of me on stage in
one of those dresses. I sat down on a chair, held a feathered fan and tried to
look as sexy as I could. As I saw the photo I burst into laughter. "What are you
laughing about?" Lucy asked.

"Look at me!" I laughed.

"What? You look great. You should have it enlarged and framed. I bet Travis
would love it."

"Nah, but thanks."

I settled in my role as a manager quite quickly and made a few changes in the
schedule to accommodate the girls. I also changed the way our stock was ordered
and Gabby was happy with the results. I became more than just a manager, I
became a confidante of the girls. They knew they could always come to me with
anything. I would help them in any way I could.

Travis and I found our rhythm in combining our jobs and still be able to see
each other. When he got promoted we moved to a bigger apartment, closer to his
work and almost the same distance for me. We both were happy where we were and
settled.

Then one day I came home to find a note on the table. On the envelope was my
name. My nerves were killing me when I opened the letter.

_Laura,

The last few weeks have been hard on me because there is something I need to
tell you, but I don't know how to.

I've asked Gabby to give you the night off, please meet me at 'Galveston Park'.
I need a neutral space to talk. Please come as quick as you can.

Travis_

This time he didn't add the triple x's or a heart. I felt worried and got really
anxious. I called for a cab and made my way over to the park. There I was
surprised to see Marisha standing there. I walked up to her and asked her what
was going on.

She said "Laura, we met in college and that is one of the best things that has
ever happened to me. Meeting you changed my life. Because of you I am with the
love of my life and all I can say is: Thank you, Laura, for being my best
friend." She handed me a rose and invited me to walk further.

A few yards further there was my brother. "I might have been jealous when you
were born. But you are my first sister and I love you. You've always been a pain
in my ass, but you were hardly ever wrong. You've brightened up my life and I
love you sis." He handed me another rose. Tears welled up in my eyes.

Further up was my sister "Laura," she said crying, "I've made some mistakes in
my life, but you never ever told me you didn't love me. You are the rock in my
life and I know I can always count on you. Laura, my dear sister, I don't say
this often enough but I love you." She handed me a rose.

I lost it when I saw my parents, weeping I took their hands as they said "Laura,
our first daughter, you were so small when you were born. We worried about you
every day in that hospital. We never knew we didn't have to worry ever again.
You have become a strong woman and we're so proud of you. We love you, Laura, we
love you so much." The handed me a bunch of roses and urged me to walk on.

There on the pier I saw Travis in his best suit, crying my eyes out I walked up
to him. "Laura," he said, "for weeks I've kept a secret from you. Because I had
to talk to your parent first. Laura, I love you so much, since the first day we
met and talked at that float. I love you with every fiber in my body." He got a
box out of his pocket and knelt on one knee.

"NO!" I shouted, "No"

"Laura Baily, will you give me the honor to become my wife. Will you marry me?"

Crying my eyes out I nodded and whispered "yes" through my tears. Travis got the
ring out of the box and put it on my finger. He kissed me and then cheered "She
said YES!" All my family came running up to congratulate us. I was worried about
nothing and Travis surprised me in the best way possible. It was all just
perfect.

All the girls ran up to me to admire the ring, when my sister said "Now we've
got a small problem." I stared at her and she continued "Who's going to be the
maid of honor, Marisha or me?" I started laughing and said "Both, it would be my
honor to have the both of you." My mom hugged me and congratulated me.

My dad took me in his arms and told me about when Travis came over to ask for my
hand. He told me how honored he felt when Travis did that. Not that my dad would
ever decide for me, it was more the gesture. "He just asked if we would be okay
with him asking, that's all." I smiled and said "I know, dad, I know."

The next day I couldn't wait to tell the girls and to show off my ring. They
all cheered and congratulated me. Gabby told me Travis had come to her weeks ago
and they all arranged it so I would be home for this. I thanked them all.

Six months later we were married and went on our honeymoon.

## Changes
For our honeymoon we went to the Bahamas where we had rented a nice tiki-hut
near the beach. It had a nice porch looking out over the beach, a nice living
room, a gorgeous bedroom and a small but very nice bathroom with shower. It
wasn't much but it was nice.

We took strolls on the beach, had nice dinners at the local restaurants and just
enjoyed our time in paradise. One of the bartenders in the bar nearby advised to
hike a trail on the other side of the island and so we did. We brought food and
drinks with us and started the hike. All we had to do was to follow the signs
and the man was right, it was so beautiful. We rested at a nice field near a
waterfall and because it was so hot I said "oh, what I would give to jump in the
water."

"What's keeping you? There's nobody around. Hop in."

"No, I didn't bring a bikini." I protested.

"Just wear a shirt, or don't. I wouldn't mind." he winked when he said it.

I elbowed him, but still I was intrigued by the idea. Would I dare? I got up and
barefoot I walked over to the railing. There was a small path leading down to
the water and a sign read _Swimming allowed. Be warned of sharp rocks._ I walked
back a bit disappointed. "You are allowed to swim, but there are sharp rocks and
I didn't bring any other shoes with me."

"Oh, didn't we?" Travis reached for his backpack and got out my pair of diving
boots. I grabbed the backpack and pulled out one of my bikini's. "Just in case
we needed it" he winked. This guy knew me so well. I put on the boots, checked
if nobody was around and hid in the bushes. As quick as I could I put on my
bikini and made my way down the small path.

The water was cold but not too cold and I dove in. Travis watched me from the
railing above and took some pictures. When I found a spot where I could reach
the bottom I was near the waterfall and posed for another picture. I kept posing
and then without thinking I took off my top exposing my breasts. Travis took a
few more pictures of me topless and then I submerged to put on the top as best I
could.

When I joined Travis we both burst into laughter. "I'd never would have thought,
Laura Baily-Willingham would do a thing like that." He said. I had to agree, but
there was something freeing about the Bahamas. People just didn't seem to mind
it that much.

We followed the trail and after another hour or two we were back at the car. As
we drove home we decided to grill some food. We bought two steaks, a nice fish
and some other things like salads. We also bought a few bottles of wine.

Back at the hut Travis started the grill and I checked the photos he took.
Travis loved taking photos and he was good at it too. When I reached the photos
of me in the water I found one special one. He took it as I rose up from the
water with my hair waving through the air. Then I saw the topless ones and
although they were really nice pictures I felt a bit embarrassed by them.
"That's the one I like" he said. It was one of me, with my hips sideways, but my
upper body turned to the camera. My lips were touted a bit. He was right, it was
a nice photo.

"You know, I had fun posing for you. Maybe we should do that again. Maybe even
tomorrow?"

"Sure, let's just find a good spot somewhere. Somewhere nice."

"Okay, that should be fun. Let's bring some nice clothes and such."

"Yeah, like a real photo shoot."

We both were excited and after dinner we sat on the porch enjoying the sunset.
When we kissed I got up on his lap. He placed his hand on my inner thigh and I
spread my legs a little. "Oh," he whispered, "Someone isn't wearing underwear."
I smiled and replied "No, they got wet somehow." We laughed a bit and I moaned
as he slid a finger inside me.

"Let's go inside." he said

"No," I answered and spread a little wider, "this is exciting."

He pushed another finger inside me and I started moaning a little louder. He
undid the strap of my dress and opened it up a bit. I leaned backwards against
him and listened to him breathing heavily in my ears. With both his hands he
opened my dress exposing my breasts. I moaned louder and didn't want him to
stop. He cupped my breasts and pinched my hard nipples. "oh yes, yes" I moaned.
As he pulled down the dress I leaned forward and let it slide of my shoulders
and my arms. I got up a little and my dress slipped down on the floor. I sat
back down again, spreading my legs.

Travis slid three fingers inside my wet pussy and I closed my eyes. The sopping
sound of his fingers sliding in and out, the feeling of him sucking on my
breast, it all just was so exciting. I opened my eyes and noticed a dark shadow
standing a few feet from us. "Looks like we've got an audience." Travis said.
"Yes, we do." I answered.

I spread my legs wider and turned my wet pussy towards the one who was looking.
The idea of a stranger watching us excited me so much. I got up and pulled
Travis towards the bench at the top of the veranda. I pulled down his pants and
boxers and started licking his pole, making sure it would be visible for the one
watching us. As I was on my knees sucking my husbands pole the shadow came a bit
closer to us.

He was a dark man and he had a very nice smile. I pushed Travis on the bench and
placed my legs on either side of him. With my back towards Travis I sat down,
guiding his big dick inside me. It was so exciting to feel my husbands cock
slide inside me as a stranger was watching us. I moaned loudly and kept looking
the man in the eyes. The man fondled with his pants and I watched as he got out
his big black cock and started jerking to us.

With my finger I invited him to come closer and moaned hard when I felt these
strangers hands on my boobs. Instantly I had an orgasm. The man kept on jerking
with his cock close to my face and before I knew it I took it in my mouth. I
almost came again. By now Travis was all excited too. He patted my back and I
got on my hands and knees. Travis thrust his cock inside me and the stranger
pushed his deep inside my throat.

With just a few thrusts Travis came all over my back. He walked off and watched
as I was still sucking this stranger. I wanted more, I needed more. Not caring
any more, I got on my back and offered my hole to this man, this stranger with
the big black cock. I groaned as the stranger entered my love hole. I looked at
Travis and he just sat there with a big smile on his face.

I closed my eyes as I felt my pussy being stretched to the max. This man went in
so deep. "Oh yes, yes, fuck me" I screamed, "fuck me hard." The man started
thrusting hard and deep. I groaned and felt a giant orgasm coming over me. I
pulled this stranger close and pressed my body against him. "Oh yes, yes, I'm
coming, fuck me, fuck me.." I screamed. "Come inside me, give it to me, oh yes,
please come inside me... I want it... I want you to come inside that pussy..."

The man groaned like an animal as he exploded inside me. I could feel his cum
slam against my pussy wall, wad after wad. There was so much it even dripped out
of me. "I'm coming again, o lord, I'm coming again." I dug my nails in his back
and locked my legs around his hips, pulling him deeper with my legs.

We kept like that for a few minutes and then I let go. He pulled out, got
dressed, thanked me by kissing my hand and just walked off. I asked for his
name, but that made it even more exciting. With the strangers cum dripping out
of me, Travis walked over and took possession of me. He thrust a few times and
then added his cum to what already was in my pussy.

The next morning when we got up he said "About last night." I got a bit nervous
and said "Yeah, I don't understand what came over me. I'm so sorry, I didn't
mean to hurt you."

"Oh no, it was just perfect. Seeing you having fun like that. It was just
perfect. Here was this guy wanting to fuck my wife, MY wife. It made me feel so
proud to call you my wife. I loved it."

"Really? Do you mean that?"

"Yes, I do. Especially when you got so into it and let him come inside you."

"Yeah, about that. I'm not on birth-control right now. So I'm a bit anxious."

"Let's cross that bridge when we get there."

"Can we stop at a pharmacy somewhere? I want to get something."

The rest of the day didn't go as we had planned. My head just wasn't into it. We
went back to the hut and I took the plan B I had purchased. The next few days I
couldn't stop thinking about it and a giant load fell off my shoulders when the
first drops of blood announced my period. I jumped into Travis' arms and kissed
him. "My period, I'm on my period." I shouted. Never ever had I been more
excited for my period than at that moment.

When it was time to go home I was fully menstruating and never felt happier
about it. This time I welcomed the pain and nausea that accompanied it. On the
flight home we looked at some photos and when we landed we were picked up by
Matt and Marisha, who invited us for dinner.

At their house the men were in the house somewhere playing a video game. Marisha
and I always told each other everything. "yeah, so there I was in the water and
before I knew it I took off my top. Travis took pictures of me. So exciting."

"What??? You, Laura Baily, topless on photos. I can't believe it."

I grabbed my bag and showed her the photos. "Wow, Laura, they are beautiful. The
photos I mean, your breasts are okay, but the photos." I burst into laughter, I
knew Marisha to be a bit jealous of my chest area. "Yeah, so we decided to grill
some food at the hut. You know, making use of that nice veranda. And it was all
just so romantic. Wine, the sunset, everything." I told her how we kissed and
how we started making love, everything.

"It felt so good. I had one in my mouth and one down there. When Travis was
done, something happened. I turned on my back and let the man take me. I even
let him come inside me. Then he got up and walked away. No idea what his name
is."

Marisha's mouth fell open in amazement: "You had sex with a stranger in front of
Travis? Wow. I never did a thing like that. And he came inside you?"

I nodded "and when the man walked off Travis came inside me too."

"Wow, Laura, you slut you." Marisha smiled.

"Yeah, the next few days weren't that nice. I forgot to bring the pill, you
can't imagine the relieve when I got my period."

"You did get plan B though, right?"

"Sure, but still. You know."

"Yeah, but wow Laura. I would never have thought."

"Neither would I, but it just happened. I don't understand but it did. And
what's more we both liked it. Travis told me he got off on seeing me, you know,
with another man."

"How about you? Did you like it?"

"At that moment, yes. But I don't know if it will ever happen again. I just
don't know. There was something about that night, it all was so, how do I say
this, organic about it. Like it was meant to be."

"I understand, it just has to happen."

"Yes, like that."

"Good on you girl. My girl is growing up. So happy for you." Marisha said,
"Now for some more wine and then we will drop you off, okay?"

"Sure, and thanks for listening. I just had to tell someone I trust."

"Even Travis won't know I know." Marisha winked and walked in the house and
shouted "Oh boys! Not that game! That's the lamest game ever! Whatever, Laura
and I are opening another bottle. Have fun!"

It doesn't have to be a surprise we decided to spent the night over at their
place, the next morning Marisha dropped us off on her way to work. We said
goodbye and suddenly we were back in reality.

I called my parents and told them all about our honeymoon, well almost
everything. After that my sister and my brother. Travis called his family and it
was time to adjust to normal life again.

## Exposure
In the weeks after our honeymoon we settled in to the routine of everyday life
as best we could. But something had changed we both felt a restlessness we
couldn't explain. We always were honest about it to each other, but I caught
myself thinking about that man being inside me even as I was having sex with
Travis. My mind kept going back to that night and how good he felt.

Some days when Travis was off to work I started fantasizing about that night and
masturbated until I had an orgasm. I wanted to feel like that again, I wanted to
be with another man while Travis was watching me. "Oh yes, Travis watch me,
watch me being fucked by someone else." It became an obsession, I needed to feel
something inside me. My fingers just didn't do it anymore.

All nervous I walked in an adult store I found on the internet as I didn't dare
to order one online. To scared it would arrive while Travis was home. I dove
into the section with the dildos and was amazed about the sizes and how
expensive they were. I found two that were on the cheaper side, one resembled
that stranger and one was quite a bit larger. Why I bought two? No idea, but I
did.

On my way home I discarded the packaging in a container on the parking lot and
had to giggle a bit when I saw other packaging in there. I drove home as quick
as I could and locked myself in the bedroom. The whole time I was wet and
excited to try them. I lay down, closed my eyes and pushed the smaller one
inside me. Although it wasn't the same, the feeling brought me back to that
night. "oh, yes, yes, fuck me, fuck me with that big black cock. Oh yes, deeper,
deeper" I moaned as I pushed the dildo deep inside me. Even though I never asked
his name I had given the man one: James. We had met a lot of them over there.

"Oh yes, James, fuck me. Make me yours, yes, yes." As I slid the dildo in and
out of me, I looked to the side at the bigger one. "Come here, Michael" I
moaned. I pulled James out and placed Michael against my wet cunt. As the large
dildo stretched me I moaned loudly "Oh Michael you are so huge. Oh yes, fuck me,
Michael, fuck me hard and deep." I pushed it in as deep as I could, but I wanted
to feel it deeper. I wanted to feel the fake balls against my ass.

I placed the dildo on a chair and slowly sat down on it. It went in easier then
before. My pussy stretched out and I felt it going in deeper then earlier. I
felt the top against my cervix but still I went down. Finally I felt the fake
balls against my add and I raiser my feet. My full weight was now on the dildo
and it went in a bit deeper. Immediately I felt an orgasm roll over me. When it
subsided I started bouncing on that huge dildo. "Oh Michael, fuck me, fuck me.
Are you watching Travis? Watch how your wife is fucking a huge big black cock,
watch how he comes inside your wife. Oh yes, fuck this bitch, fuck this whore,
oh yes, yes, yes. After a second orgasm, my pussy was thumping and pulsating. I
got up and fell on the bed.

After I showered and hid the dildos I got ready to go to work. But all day I
felt my vagina thumping from the beating I had given her. It felt so exciting I
couldn't wait for the next morning. I repeated this ritual every morning and
even went back to the store to buy an even bigger one. This one had a timer so
it could ejaculate fake seamen. This one I called William.

It was a Saturday and Travis was home playing a video game online with Matt. I
told him I was going to take a shower and crossed the living room with only a
towel wrapped around me. In my left hand I had hidden James. Just the mere fact
I was holding the dildo in the same room as Travis was already exciting, but
actually riding that big black cock in the shower while Travis was mere feet
from me was the top.

At one moment he even knocked on the door to ask me what I was doing. "Nothing,
just my hair." I shouted with that big dildo up my cunt. He asked me what I
wanted for dinner as I slid up and down James. "Oh, whatever you like honey" I
answered suppressing my moans. "Okay, just don't make it too long. It's almost 6
and we should go at 7:30 at the latest." I had totally forgotten about that
evening. Travis was receiving an award for his work and we had a special night
planned. "I'll be ready." I shouted as I kept bouncing on James.

I bit my lips not to scream as I felt the orgasm. I gasped for air and fell on
the floor. "Everything okay in there?" "Yes, honey, just dropped the shampoo."

I quickly finished showering. Wrapped a towel around my head and another one
around me. With James in my hand I skipped across the kitchen door and made into
our bedroom. I hid James after I kissed him and acted as normal as I could when
Travis entered. "You forgot, didn't you?" he said, "that's why you're acting so
strange. You forgot." I turned to him and said "I'm so sorry. But I haven't been
myself the past couple of days. I don't know, maybe I'm getting sick or
something."

"Ah, I don't mind. It's a boring venue anyways. If you don't want to go you
don't have to. I can't get out of it. I have to go."

"Oh no, babe, I want to be there. Just give me a few minutes, okay?"

"Sure, dinner is almost ready."

"Thanks hon."

I quickly dried my hair, put on a long shirt and sat down at the table with
Travis. We had dinner and I got dressed for the occasion. Just a few minutes
late we arrived at the venue and I met a few of his co-workers. The first time I
met Johnathan I felt my pussy getting wet, he was a tall black man and just
gorgeous. A shock went through my body as he took my hand and kissed it.

The night was rather boring and I caught myself glancing over to Johnathan. He
was alone there and my heart skipped a beat when our gases crossed. "What are
you doing?" Travis whispered when he noticed me looking at Johnathan. I shook my
head and answered "Nothing."

"You were looking at my boss, weren't you? All the ladies do." Travis whispered.

"I can't help it. Sorry." I whispered back.

It was time for Travis' reward and after a few drinks we went home. In the car
Travis said "Okay, tell me the truth. What were you thinking about when you were
looking at my boss? And the truth."

"I was thinking about that night, at the tiki-hut. How it felt. How I want to
feel it again." I whispered.

"I knew it. I just knew it. You acted so strange the last couple of weeks. I
knew you were up to something. Tell me who were they and do I know them?"

"No, you don't know them." I quietly answered.

"What? You don't even deny it? Wow, Laura, I thought you knew me better than
that, but to go behind my back. I don't mind you being with another guy, but at
least tell me about it!"

He parked the car and stormed inside. We didn't speak in the elevator and he all
but slammed the door in my face. I had never seen him so angry. With tears in my
eyes I walked in the bedroom and started to cry. I had hurt the love of my life
and I had to come clean.

"Travis? Honey? Come in please, I would like you to meet them."

He looked up and was totally confused. When he walked in he saw the dildos lying
on the bed. I grabbed on of them and said "This is Johnathan and I would like
you to meet, William and Michael." Travis just stared at the huge black pieces
of silicone on the bed and burst into laughter. "These are the guys you cheated
with on me?" He took me in his arms and said "Oh, I am so sorry Laura. I jumped
to conclusions. It's just you acted so weird lately. Earlier tonight, in the
shower, where you playing with one of them?"

I nodded and cried "Yes, I was. I don't know Travis. It's just ever since that
night something changed within me. That night it felt so good and when I saw
your smile as that man was inside me, it made me feel so good and happy. I don't
know what's wrong with me. I love you so much and never ever want to loose you.
But there's an emptiness inside me that I just can't seem to fill."

"Oh Laura, I love you too." he looked at me and said "Don't ever hide a thing
from me again, not like this. I just knew something was up, you couldn't wait
for me to get out of the house and other small things. It just didn't add up,
but now they do."

"I love you, Travis."

"I love you too Laura. Now, the next time you want to play with either of these
boys, just do it. Maybe if you want to you can let me watch."

I smiled and answered "We'll see, we'll see."

The next time we had sex we included either of the three into our game. Travis
watched me as I rode either one of them panting "Oh Travis, look how this big
black cock slides in and out of your wife. Watch me fuck this big black cock.
Watch you wife being a BBC slut." Soon after that Travis started taking pictures
of me penetrating myself with the dildos, exposing my stretched out cunt to the
camera.

Soon after that he bought more equipment like lights and stuff. I bought more
and more sexy dresses and high heels. I stood in the window, totally naked for
anyone to see as Travis took pictures.

Then one day I came home after work there was a note on the table. I opened it
and read

_My lovely wife,

I've arranged a small surprise for you. Just come over to the Holiday Inn and
wear something sexy, with high heels. Knock on the door of room 146 and just let
it happen.

Your husband,
Travis_

Wondering what it could be I took a quick shower, did my make-up and put on my
sexiest black dress. I put on a nice pair of heels and made my way over to the
hotel. In the lobby I asked for room 146 and told them my husband was waiting
there. They told me the way and I got in the elevator. As I got closer to room
146 I decided to take of my coat and draped it over my arm. My hands were shaking
as I knocked on the door of room 146.

To my utter amazement Johnathan, Travis' boss, opened the door. I quickly
checked the room number. "No, you are at the right door" Johnathan laughed,
"Come in, come in. Travis is here too." I walked in and saw Travis sitting with
a huge smile on his face.

'What are you doing?' I whispered.

'Just let it happen.' he answered.

Johnathan walked up to me, took my hand and kissed it. "This is not a normal
thing for me, but you are so beautiful I am willing to make an exception." he
said with his deep dark voice. As soon as he took me in his arms I melted. We
danced a bit on non-existing music and I glanced at Travis every time I had the
chance. He just sat there and smiled.

When Johnathan kissed me I lost all control. I put my arms around his neck and
pressed my mouth against his. His tongue went deep inside my mouth. His hands
went all over my body sending thrills I hadn't felt since the Bahamas all over
my body. I put one leg around his and felt his knob press against my belly.

In the distance I could hear shutter sounds of the camera, but I didn't care. I
released myself from his embrace and with one hand I pushed him towards the bed.
He felt down on it and I took a few steps back, slowly sliding the straps of my
dress down my shoulders, revealing the sexy lingerie I had meant for Travis.

As the dress dropped on the floor I slowly bend my knees and with my legs a bit
spread I moved my hips slow from side to side. As I rose up again I unclasped my
bra exposing my full breasts to Travis' boss.

After that I walked up to him and bend over. As my nipples barely touched his
clothes I made my way up to his mouth and kissed him again. His hands touched my
back and I moaned as he started caressing my back. With my mouth on his I
unbuttoned his shirt exposing his muscular body underneath. He rose a little to
take it off and I pressed my breasts against his black muscular body. He rolled
me on my back and sucked on my breasts. I breathed heavily and stared at my
husband taking pictures.

Johnathan started to kiss all of my body and when he reached my legs he pulled
down my string. I raised my hips to accommodate him. When I was fully naked I
moaned "Look at your wife, Travis, she's being pleasured by another man. Watch
how she gives herself to him." Johnathan spread my legs and as soon as his
tongue touched my clit I almost came. But I resisted, I didn't want to. Not yet.
Johnathan licked me, stuck his tongue inside me and I just went crazy. "Oh yes,
Johnathan, lick me. Watch how your wife is being licked by another man, Travis.
And this man is going to fuck your wife. Oh Travis, I'm going to be fucked by a
big man, a big black man. Watch how this whore is going to fuck him."

At that same moment I felt Johnathan place his big cock against my labia. I
grabbed it with my hand and it felt huge. "Oh, watch me Travis, watch me closely
as I guide his big black dick inside my cock hungry pussy. See it, see it enter
me." And with that Johnathan thrust his cock deep inside me. He didn't wait or
stop. In one push it went all the way in.

"Oh, god, you are huge." I shouted, "fuck me, fuck this whore. Fuck me hard,
Johnathan. Make me yours." Johnathan started to pump and the orgasm could hold
back earlier came over me in two-fold. "Oh lord, I'm coming, I'm coming over
your big dick, Johnathan, fuck me. Oh yes, yes, yes, right there, keep going,
don't stop, I'm coming!" Johnathan put all his weight on me and I locked my legs
around his back, pulling him deeper.

"Oh god, Travis, this feels so good. Are you watching? Look how your wife
becomes a whore, a slut, oh yes Johnathan, go deeper, go as deep as you can.
Come inside me, give it to me, I need your cum inside my pussy. Yes, yes, do it.
Come inside me, yes, yes, yeeeeesssss!" Johnathan exploded inside my pussy and
another orgasm took hold of me. When he caught his breath he rolled of off me
and I spread my legs as Travis took pictures of the giant load of cum dripping
out of my pussy.

I then rolled my body against Johnathan's and stated playing with his now flaccid  
penis. I kissed his muscular torso and pressed my upper body against his. Soon
enough his dick got hard again and I got on top of Johnathan, sliding my wet
cunt against his pole. I felt it growing underneath me and pressed my mouth
against his. As we kissed I moved my hips and in one swoop I slid over his
massive cock again. I rose up and started bouncing. "Oh Travis, watch how your
whore wife is bouncing on this big black cock. See how she's going to make him
come inside her again. I want him to fuck me all night long and you can only
watch how you wife is becoming his whore, his slut. Oh Johnathan, you are so big
and you feel so good inside me. Oh yes, I'm coming again. Yes, yes, yes, I
grinded my clit against his body until I had another orgasm.

Travis sat on a chair and was jerking his cock. "Oh yes, that's the only thing
you can do tonight. Tonight I am his and his alone. Tonight I am a whore for
black cock." I panted.

At that moment Johnathan picked me up and threw me on the side of the bed, with
one thrust he place his cock against my ass and pushed it in. The pain was
immense as he shoved his big black pole in my ass. When he was all the way in,
he rested and the pain subsided. He slowly started moving and it started to feel
good, really good. "Oh Travis, watch how your slut wife is being fucked in the
ass. See how she likes it." I started to scream and Johnathan covered my mouth.
He violently slid in and out of my ass. "Oh yes," I panted, "fuck my ass, fuck
me hard, see this Travis? Your wife has given him every hole, even her virgin
ass is now his for the taking. Oh, yes Johnathan, fuck me, fuck me any time you
want. I am yours. I am your slut now."

With a few more thrusts he came deep inside my ass and I had my first orgasm
from anal sex. The jetties had broken, the gates were opened, there was no way
back I had become a hotwife, a slut, a whore. And I loved it.

Johnathan and I did it a few more times that night, even with Travis lying next
to us. He even fucked me on the balcony of the room, I didn't care I just wanted
to feel his big black cock. I sucked him, I fucked him, I kissed him and I even
sat on his face. Everything he wanted me to do I did.

At around 4 in the morning Johnathan left and kissed me goodbye, thanking me for
a wonderful night and as it was a Saturday Travis and I decided to stay for
another night. As soon as he had left I rolled over to Travis and thanked him
for doing this. I slowly went down and sucked his cock. I then proceeded to get
on top of him and slid his cock in my stretched out cum covered ass as my pussy
was hurting too much. I rode him until he came and he came much more then he
usually did. He let go of an animal like growl as he ejaculated deep inside my
add. I kept sitting on him and kissed him. Thrusting my tongue deep inside his
mouth, I kept moving my hips and my sensitive clit sent jolts through my body.

Within seconds I felt Travis getting hard again and I started to bounce on his
cock "Oh Travis, fuck that cum covered ass. A hole covered in your and
Johnathan's cum. Fuck your whore wife, fuck her good. Oh yes, Travis, make me
come one last time tonight."

After just a few minutes we both came and exhausted I sagged down on the bed.
Everything hurt, but in a good way. We kissed and fell asleep.

## Real changes
The days after that night we couldn't stop talking about it. We both had so much
fun, we even watched the photos together. "Next time you should make a video." I
said. The sight of this big black cock inside me turned me on and I started to
suck Travis' cock. After just a few minutes he exploded inside my mouth and I
did my best to swallow all of it.

After a few weeks as we were home watching a movie my phone buzzed. There was a
message from Gabby, one of the girls was sick and she needed one soon. I called
around but nobody was available. As I didn't know what to do I told Travis I had
do go and see how we could solve this. Travis decided to come with me and sat at
the bar while I rushed backstage to try to find a solution. It was difficult but
I managed to find one.

As the show started I was really nervous. I had no idea if it would work. In
stead of the singer, we started with the Cancun and soon enough the audience
cheered and clapped with the girls. The Cancun was followed by Misty who sang
two more songs and then it was time for the Burlesque show to start. First of
was Lucy and she was marvelous then the room went quiet.

_Ladies and Gentlemen, for your pleasure and for one night only we present:
Scarlet!_

Nerves went through my body and I waited for the music to start. This was it.
Make or break time. At the first tones of 'the Stripper' I took my first steps
on stage for an audience. I moved as gracefully as I could and always kept one
fan in front of my face. As gracefully as I could I took off my gloves, my
skirt, my corset, always covering the vital parts. Then it was time for my
panties to come off, I held on fan in font of my crutch the other in front of my
breasts. I turned my back and showed the audience how I unclasped my bra and as
gracefully as I could I dropped it on the floor. When I turned around again I
had both fans in front of me and on the last tones I held my arms up high
showing the tassels on my nipples and crutch. The lights went out and I hurried
of the stage. My heart was beating in my throat. I had just finished my first
strip-tease in front of an audience.

I was totally quiet for a moment and then the audience exploded in cheers and
they whistled and clapped so loud that Gabby handed me a robe and ushered me
back on stage again. With the robe covering me I took a bow and thanked them for
their kindness. The kept on applauding and I had to return two more times.

Backstage I found Travis who just said "Wow, what a performance. You were so
great. I loved it." I hopped from excitement "It was so exhilarating, Travis.
Oh, never thought it was so much fun."

"I could see that, at first you were scared but then you started to have fun
with it. It was just great."

Even Gabby was more than pleased with it "You should do it more often, it's rare
to see a natural." She smiled and walked off. That night I got part of the tips
for the girls. "You've earned it." Lucy said with a smile. As we went home I was
still full of adrenaline from my performance and just couldn't catch my sleep.
Travis was fast asleep next to me as I heard my phone buzz. I grabbed it and
sneaked out the room. It was a message from Jonathan. _Put on something sexy and
come to me. Room 123._ it said. I gasped for air and felt my pussy getting wet
instantly. I sneaked back in the room, grabbed a dress and my heels. With my
purse over my shoulder I left a note for Travis.

_Don't worry. I will be home as soon as I can. I'm just too excited._

It wasn't totally besides the truth. I went out the door as quietly as I could.
Twenty minutes later I knocked on the door of room 123 and walked in. Jonathan
took me in his arms, kissed me, stripped up my dress and just thrust his big
black cock inside my pussy. "Oh yes, boss, fuck me, fuck your whore." I panted,
"fuck this slut which you can call whenever you want." As he was fucking me the
door of the bedroom opened and another man walked in. He took of his pants and
shoved his cock down my throat. Now I had one big black cock in my pussy and
another one down my throat. I went crazy and when the man sat down on the couch
I crawled on top of him and guided his cock inside my pussy. I bounced on him
and moaned "fuck this whore, make her cum, oh yes I'm coming all over your cock.
oh yes, yes, yes, fuck me." At that moment Johnathan came behind me and placed
his hands on my hips. Instinctively I knew what was going to happen and I lifted
my hips. Johnathan put some lubricant on me and him then slid his big black cock
inside my ass.

I bit my hands not to scream, I had a huge cock inside my pussy and an even
bigger one in my ass. Immediately I had a huge orgasm, I started to shake all
over and they showed no mercy. Both men started to fuck me and I had one orgasm
rolling over in the other. It took them quite some time to come, but both of
them exploded inside me. "Oh yes, fill me up, fill this little slut with your
cum. Yes, yes, oh yes, feels sooo good. Yes. I'm coming again!" This time all
went black for a moment, I couldn't stop shaking for almost 20 minutes.

When I finally came to Johnathan looked at me with a smile. Threw me my dress
and shoes, handed me 500 dollars and told me to leave. Totally flabbergasted I
put on the dress again and my shoes. Grabbed my purse and coat and walked out. I
got in the car and drove home to find Travis sitting at the table with my note
in his hand.

I burst out in tears and told him what I had done and how they had treated me.
"I thought it meant something to him too, but it didn't I was just another cheap
whore to him. He even paid me 500 dollars." I sniffed.

"What! No, oh I am so sorry Laura. But I have to say I was so worried when I
noticed the empty spot next to me. And when I found your note I was extra
worried. And this, this is just unacceptable. Now I understand why some of my
co-workers acted so funny. Oh I'm going to tell him tomorrow."

"No, Travis, don't. Don't make it worse than it already is."

"I don't care anymore."

I don't know how but somehow I fell asleep only to wake up to Travis yelling
through the phone. "I thought you were to be trusted. But your just a piece of
shit, Jonathan and after all I did for you and for the company. Well, you know
what, stick it where the sun don't shine. I QUIT!"

Travis came storming in the room and said "oh, you're awake. How much did you
hear?"

"Enough" and I opened my arms. He lay down in my arms and I kissed him. This was
the man I loved, the man who would do anything for me, even quit the job he
loved. I called in sick that day and just wanted to stay home. A few hours later
Gabby called "I heard you called in sick, what's the matter girl?" I just
started to cry and before I knew it I had told her what had happened.

"Men!" was all she said. She never judged me, never spoke a bad word about me,
she just comforted me and said "Okay, stay right there I will be right over."

30 minutes later Travis let her in and she briskly walked in the bedroom. She
sat down on the bed next to me, looked at Travis and asked him to leave us for a
minute. "Okay, I will do the groceries I guess."

When the front door closed, Gabby started to speak. "Laura, listen to me. It's
not the end of the world. It's just a bad experience, we all had them. You made
a mistake, we all made them. I know I did. So wipe those tears and get dressed.
We're going on a small trip."

"But Travis?"

"Dial his number and hand me your phone. I got this. You get dressed."

I put on some yoga pants and a sweat shirt. Grabbed my sneakers and went into
the bathroom to clean my face a little. When I got out Gabby handed me my phone
and said "He understands, you've got a great one in him. He's a keeper."

After an hour we arrived at an old house. "That's where I was born," she said,
"back then it was the biggest brothel in town. I have no idea who my father is
and only found out who my mother was after she had passed away. Don't get me
wrong I had great parents, they adopted me when I was a baby and always treated
me as one of their own. But I never felt it that way until it was almost too
late. I fell into a deep dark hole and without them I would never have gotten
out. I befriended the wrong crowd and got addicted to heroine. Sure, the get you
addicted for free but then you have to pay. They put you on the streets and take
everything you've earned. You don't care, all you want is that shot."

She looked at me with tears in her eyes "Until that day a man approached me. He
didn't offer money, he didn't offer drugs, all he offered was to take me home.
To get me out of that hole. That man was my adoptive father. He had searched for
almost a year and then he finally found me. He got me in the car and we drove
off. My pimps must have thought I was just doing another John."

"My mother took me in her arms, she never judged me, she just said she loved me
and how much she had missed me. The next day we moved and started a new life
over here. My parents are the ones that raised me, who left everything behind
for me, the other ones they just created me, nothing more."

"They helped me of the drugs, got me back in school, they even supported me when
I opened the bar. The felt so proud of me. That's why I am so protective of my
girls, my place is a safe place for them. I've never told anyone but my late
husband this story. And I trust you to keep it."

I nodded and took her in my arms. 'If someone can survive that, this is nothing'
I thought. "Thank you for sharing that with me" I said. Gabby just nodded and
said "My real name is Mathilda, but I hate that name." I burst in to laughter
because of the face she made, Gabby started laughing too.

"Okay, Gabby it is." I smiled

"It's good to see you smile," Gabby said.

"And you were right," I replied, "this is a family. Thank you so much for
accepting me into your family, Gabby."

"You are so welcome, honey."

On our way back we stopped for a cup of coffee and chatted about this and that.
Gabby dropped me off at home and went back to the bar. As I opened the door
Travis came storming to me and asked "Everything okay?"

"It's better now, thanks. Gabby really helped."

"Thank God for that woman." Travis sighed.

We stayed in for the rest of the day and just watched some movies. We crawled
against each other and just enjoyed being together. When my phone buzzed it was
another message from Johnathan instructing me to come. "fuck off" was all I
texted back and crawled back into my husbands arms.

## Struggling
In the months after we struggled to come by on my salary alone as Travis had
some trouble finding a new job. Johnathan had called around and talked bad about
him. Sure he did the odd jobs but it was never anything permanent.

To make some extra money I started dancing a bit more. The girls understood why
I had to and they accepted me fully. I always tried to take a slot that didn't
disturb the others too much and I always kept it short.

But then we received a letter from a lawyer. Johnathan had sued us for
everything we had. In the courtroom we learned his wife had received an
anonymous letter together with a compromising picture. The court was behind
closed doors and we told the judge that that picture didn't come from us.

And then they showed the picture. It was of me with the two men. They had set me
up, I was sure of it. But there was no way to deny it, it was me in that
picture. But this one was taken through the window and Travis had never taken a
shot like that. But it looked like we were going to loose it all. Our house, our
life, everything. And Johnathan, he just sat there with a grin on his face.

That all changed when Johnathan's wife broke the story to the news how he had lied
to her and to the stockholders. How he was now trapping an innocent woman in his
web of lies. He was deep into debt and never had the business he told everybody he
had. The FCC went after him for illegal trading and more of his lies came to the 
surface. He had never studied at Harvard and his diploma was a fake.

On those revelations the judge dismissed the case: "As the revelations in the
news shine a new light on this case. It seems to me entirely possible that the
claimer set this up and that Mrs Baily is telling the truth. It seems to this
court entirely possible the claimer sent this picture to his own wife, just to
have an excuse when his house of cards fell down. Therefore I dismiss this case,
without prejudice and give Mrs Baily my sincere apologies." He banged his gavel
and with that it was over.

A few months later in a very public trial Johnathan was convicted of 32 counts
of fraud, 18 counts of federal mail-fraud and 3 count of conspiracy to commit
fraud. He was sentenced to 43 years in prison. His wife? She got rich of her
book and all the appearances she made on television. But never ever did she say
an ill word about me. She said "that woman is a victim too. And it's a good
thing her identity is hidden and everybody should just leave her alone. And
honey, if you are watching this. You are welcome to visit me at any time, I have
no ill feelings towards you. You opened my eyes to the scumbag he was and I
lived in denial for so many years. So, whoever you are, thank you for showing me
the truth."

Despite winning the court case and all these revelations Travis found it
difficult to find a new job. He decided to open up his own and I fully supported
him in it. We struggled for a almost a year on my income as his bar was
struggling. It wasn't the story, almost nobody knew it was partially about us,
it was just a bad economy to open up a new bar. I helped as best and as often
as I could, but there was no other way around it: we needed some money and we
needed it fast.

Gabby tried to help us the best she could, but I had to find a second job and
she called around but had no success. Then I saw this ad in the paper asking for
girls. I called and the man on the other end gave me bad vibes and I told him to
forget it. He just sounded too sleazy and when I told Gabby she said "Oh good,
he's a real piece of shit. Just ask Lucy, I rescued her from that hell hole."

Then one night Travis came home all worked up and tired. "We have to come up
with something" he said, "or I will have to close the bar." He almost cried, he
had worked so hard and somehow it just didn't want to take off. "What if, now
listen to me, what if we asked some of the girls to help us. Give it a more of
a, let's say, nude bar vibe but classy. No touching, no anything else. And no
burlesque either. Maybe go a bit farther than Gabby does, but as I said with
class."

"I don't know. That's not exactly what I wanted. And I've got to look into
permissions and such."

"That shouldn't be much of a problem, it was a strip-club before you bought it,
maybe the people who came there are looking for it somewhere else. We could
offer it to them, but with class. I will talk to Gabby about it and see what she
thinks."

The next day I talked to Gabby. "Just don't steal my girls and don't do
Burlesque either." she laughed. After a few minutes she came back and said
"Seriously. If some of the girls want to help you, be my guest, and if it works
and they want to start working for you, well, not as good but I could live with
it. The best would be if they worked for the both of us."

I smiled and called Travis. He had called town hall and they were about to hand
him the necessary paperwork. We took a few days to change the bar a bit, made
some advertisements and changed the name to _the Midnight Owl_. Five of the
girls offered to help us and we hired three girls who weren't afraid to show
some skin. A friend of Travis helped him get security in order and it was
finally time to open.

To our amazement the bar was almost full and security had their hands full for a
while telling the patrons the girls were just for looking not for touching. The
message got through loud and clear when one of the guests was dragged out of the
bar and thrown on the streets never to come back.

The crowd went silent when the music started and a spotlight was turned on. Lucy
was on stage, wearing a cowgirl outfit. She danced her ass off and loved the
pole. She ended her act when she pulled of her bra and revealed her boobs. The
audience applauded, but I got the sense they wanted more. I walked backstage and
told them they were doing great, but it needed to be a bit more.

The next girl, Haley, did her best to be more explicit but she too didn't quite
touch what the audience was looking for. I ran into a dressing room, changed
into the first outfit I could get and rushed back. "Let me show you," I
whispered, "I think this is what they want." As the music started I walked on
stage. My heart was beating fast and I started to dance sensually around the
pole. At the beat I did my moves and bend backwards spinning the pole, only a
small piece of fabric covered my vagina. At another beat I sat down on a chair
and spread my legs wide. At another beat I pulled off my top and exposed my
breasts. I started to loose myself in the beat of the music. Again a beat and
looked into the audience my hands on my hips. As I stood up I pulled the strings
and pulled it up. Then I went down on my knees, my legs a bit wide and bent
backwards, giving the audience a first glimpse. The music welled up and I walked
to the edge of the stage and on the last beats a laid down on my back, spreading
my legs wide and with two fingers I spread the lips of my pussy. Lights out.

As I walked off the stage the audience started clapping and cheering. The
whistled loudly and even the girls backstage clapped. The next girl, Audrey
followed my example and ended her act by spreading wide on a sofa. We had found
what they were looking for.

At the end of the night we counted how much we had made and we both were so
happy. I kissed Travis and told him "Wow, what a night." Travis looked at me and
said "You made it possible. You found what they wanted."

For the next few weeks we looked for new girls as only Lucy and Haley opted to
join us. We found a good group of waitresses who didn't care to wear something
sexy. When they asked if they could choose their own outfit I gave them a chance
to surprise me. An boy they did. They game back with very small skirts, glittery
g-strings and tassels for their boobs. They told me they would glitter their
bodies and wear classy make-up.

The bar started to run. Every Friday and Saturday people came for the show, the
other nights just for the ambience and the girls who served them. Some of the
girls even let patrons touch them for an extra tip. I scolded them at first but
then I saw how much they made and as long as it didn't go to far we allowed it.
One night a girl was sick and I helped the waitresses. With my nipples covered
and wearing a very short skirt I walked amongst our guests. I felt the thrill
the girls felt as they served our guests.

"I'll give you a hundred dollars to touch your boobs." one of them told me and I
wanted to slap him, but I leaned forward and said "The tassels stay where they
are." The feeling of this mans hands on me send thrills down my spine and felt
my pussy swell. Quickly I stood up and said "That's enough" and held up my hand.
Begrudgingly he handed me the money and I put it in the tip jar.

As a new show night approached I needed to think of something special to do, my
act started to get stale and I needed something new. A twist. I looked for a new
song and found exactly what I needed. I practiced my act at home until it was
perfect. It was Saturday night and it was time to reveal my new act.

In a schoolgirl uniform I walked on stage. A spotlight on me and I looked at the
audience as innocently as I could. The music started and slowly I started
moving, then there was a loud thunder strike, the lights went out and as they
turned on again I was wearing I tight outfit and high-heels.

I turned my head to the audience and looked as mean as I could. I danced to the
beat circling around the pole and as I spun I pulled off my top revealing my
breasts, another spin and gone was my skirt. I stood up again, my legs wide as a
Wonder woman I crossed my arms. With one leg on the couch I pulled a strap of my
panties, stared at the audience again and pulled the other one, dropping it on
the floor. I bend over forward and spread my ass, giving them a good look at my
cunt. Then I turned on my back with my feet in the air and spread my legs again.
Another thunder strike and a black out. When the lights turned on I sat on my
knees at the front of the stage. My legs wide and in between them stood William,
one of my black dildos. The music slowed down and slowly I sat down showing them
how the dildo slid inside my pussy.

As the music went faster again, working up to a climax I slid up and down the
fake penis at the moment supreme I wanted to fake an orgasm but I had one for
real. As another thunder strike sounded, the lights went out again. This time
for a little bit longer and as the lights went on I stood at the same place I
started, in my school-girl uniform with a lollipop in my hand. The lights went
out again and I rushed off the stage.

The audience roared and clapped, the clapped for 10 minutes or more. I walked on
stage and totally naked I bowed and threw kissed to them. It was a good thing it
was the final act of the night. As none of the girls said they could have
followed me that night.

The next few months we applied for a more permissive permit and the regulations
became bit tighter. We closed the bar for two weeks and started remodeling to
what I had first envisioned. After the inspections we received the new license
which gave us basically a free hand to do anything we wanted. There were some
protests against our bar, but they were far and few between as people basically
said "If you don't want to see it, then just don't come."

The bar did really good and the acts got more and more explicit. The girls
started to do real sex-acts on stage and two of them even did a lesbian act.
Some of the waitresses started giving lap-dances for tips. But still there was
no touching the girls. I walked through the bar on a Saturday night and watched
some girls doing lap-dances and others were just happily talking to the
customers shaking their boobs. I smiled and it was almost time for me to
perform.

This time I walked on stage wearing 12 inch stiletto's, a tight short skirt and
a crop top. When the music started water fell down on top of me, showing my
nipples through the white fabric. I danced, throwing my head around, splashing
water on the patrons. I sat down on a small bed and spread my legs as I took off
my top. I pulled my skirt to my waist and spread my legs. I slid two fingers in
my pussy and started to masturbate on stage. Then I walked around the audience
and grabbed a young man by his throat and licked him. Then I moved on and
repeated it with another guest.

Finally I grabbed the hand of a nice young man and pulled him on stage. I placed
him on the couch and gave him a lap-dance. On the beat I grabbed is pants and
tore them off. At this moment the audience understood he was part of the act. I
sat down again rubbing my as against his stiff pole. I placed my feet on the
bed, he lay down and on the beat I sat down, guiding his hard dick deep inside
my pussy. I spread my legs to show the audience he truly was inside me and I
started to bounce on the beat. My boobs were flapping and I started to moan for
real. Within minutes we forgot we were on stage and just had sex. He fucked me
long and hard, I lifted my leg so everybody could see it. I lay there, my boobs
bouncing as this young man slid in and out of me. I looked all men straight into
their eyes as if to say: wouldn't you like to be him right now?

The volume lowered and a shouted "Oh yes, yes, fuck me. Fuck me hard" and when
the music stopped I yelled "oh please come inside me. Fill me up, Give me all
your cum, oh yes, yes, yes give it to me." With a loud moan he exploded inside
me, pulled out and ran of stage. At the last tones I turned my body to the
audience and showed them the cum dripping out of me. Lights out.

The guests were quiet for a long time. Had I gone too far? The answer came when
they all burst into cheers, screams and the clapped as loud as they had never
clapped before. It was the best act I had ever done. I walked on stage with my
stage-lover and we took a bow. With a wink to the audience I got on my knees and
licked his still hard cock clean.

A few weeks later I was helping the girls serve drinks, it was a Friday night
and I wasn't performing that night. A man offered me 500 for a lap-dance and I
put down my tray and started to dance for him, when I straddled him I could feel
his throbbing cock against my vulva. It totally excited me when the 15 minutes
were over I got off him and walked backstage. I just had to cum. I dove into the
ladies room and closed the stall. I took off my panties and started to rub my
clit, but it just wasn't enough I needed a cock. I pulled my skirt down, flushed
the toilet and walked out again only to realize when I was in the bar I had
forgotten my string. Another man asked me how much it was far a dance and he
handed me the money.

He was flabbergasted when he noticed I didn't wear panties. "Shh, don't tell
anyone." I whispered. I leaned forward and pressed my breasts in his face. With
one hand I grabbed his cock and guided it inside me. I leaned backwards again
and acted like I was giving him an ordinary lap-dance. Luckily he sat way from
the other patrons and the only thing they could see was me from the back. I
moved my hips and felt him slide in and out of me. I kept moving to the music
and not for long he exploded inside me. As the minutes weren't up yet I kept
moving, raising my hips a bit so he could slide out of me. The man quickly put
his cock away and when the 15 minutes were up I stood up. Kissed him as I always
did and walked off.

The money from the lap-dance I put in the tip-jar and went to the other ladies
room to clean myself up a bit. At the end of the night one of the girls asked
who lost her panties and I answered "That would have been me. But I grabbed
another pair lifted my skirt and showed them the pair I was wearing."

At home I told Travis what I had done and he got real excited and wanted to see.
I spread my legs and he started to lick and suck my pussy. "You know" I said to
him "People pay lots of money to see me having sex. And you like to film, why
don't we just start filming me having sex?" Travis looked up from licking me and
said "But what?"

"Well, I said, there's this new site where people pay for content like this. You
could upload your photos of me and when they want to they can subscribe for
more. We could then start filming me having sex with people from Craigslist or
something.
