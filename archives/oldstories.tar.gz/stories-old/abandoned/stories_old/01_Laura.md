# Laura's Story
_an erotic tale by TransGirl_

## Disclaimer
_This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as possible, forgive me any (scientific) mistakes or freedoms taken._

## Chapter one
The sky was dark, the wind bend the trees sideways and the rain smashed against
the windows as the storm, that already lasted for two days, did not show any
sign of laying down. In the distance I saw a tree snap like a match-stick and
diverted my eyes to the one standing next to our house. Although this one moved
heavily due to the wind it didn't show any signs of breaking, yet.

My mom laid her hand on my shoulder "Wow, did that tree just break?" I nodded,
turned my head and noticed my mom had lit candles all over the livingroom. Power
had been out for at least 8 hours, my father had been gone to get a generator
for at least half that time. I was starting to get worried. "When will dad be
home?"

"Soon honey" my mom tried to reassure me, but her voice let me know she was
worried too. Then the sound of the front door slamming shut made an end to our
worries. In the doorway appeared the soaking wet figure of my father. He just
stood there for a moment dripping water on the floor. "I am so cold," was all he
said as he walked towards the bathroom, leaving a trail of puddles behind him.
My mom quickly got a towel to dry the spots he had left behind.

"Did you get a generator?" she asked loudly.

"Yes," my father replied from the bathroom, "it's in the back of my truck. Man,
I had to get out and move several trees from the road. I'm soaking wet, cold and
I need to warm up. Then I will connect the generator, okay?" He sounded a bit
miffed and we both just let him be for a moment. I changed my position on the
couch and looked outside again. There was nothing else to do as we didn't have
any power at that moment.

The light of the candles gave our livingroom an eerie feeling as darkness set
in. My dad fresh out of the shower did his best to light the fireplace for some
warmth and soon the crackling of the burning wood completed the eeriness. My dad
got up to get a portable radio from his office. He sat down on his chair while
he tried to find the local radio station.

Within seconds the last notes of 'Let it rain' from Amanda Marshall sounded
through the small speaker of the radio, a dark voice started speaking 'As this
storm shows has no end in sight, we are playing songs to keep you warm. After
the next song we will give you updates about the weather and the news from
around our county. But first a song about purple rain." My father turned down
the volume as Prince started to sing. The music so fitted what I was seeing
outside and I was almost heart broken as the song ended and another voice
started telling us about the weather and how long this storm could last.

My father sighed when he heard it could be another couple of days before power
would be restored. He got up, put on his raincoat and wandered outside to attach
the generator. After about 20 minutes I could hear the purring of the generator
through the walls of our house. "Okay," my father said a he shook of the water,
"we should have enough power for the fridge and maybe even a light or two. But
nothing more than that. The only thing I could get was this small generator and
with any luck Brad will bring a larger one tomorrow." Brad Uhrlig was one of the
men who worked for my dad, he was a very handsome man and he was 19 already. A
very interesting age for the 17 year old me. My heart skipped a beat when my
father mentioned his name.

That evening we dined with candlelight, my mom made us a bed near the fireplace
as it was the warmest place in the house; I slept in between my parents. Halfway
through the night I woke up feeling my fathers arm around me. At first I wanted
him to move but decided against it as it gave me a warm feeling inside. I
couldn't place it, but I knew it felt nice. I scooted a bit closer to my dad to
feel the warmth of his body against my back. My lower back touched his and I
could clearly feel his crutch. I checked if my mother was awake and held my
breath as she moved a little.

With my left hand I lifted his and placed it against my bosom. A thrill went
through my body as my dad just moaned a little and got even closer to me. For
sure he thought I was my mother at that moment. His hand softly squeezed my
breast, I just had to bite my lip. "What are you doing?" my father's whisper
startled me, but I just rested my hand on his. "Go back to sleep, dad" I
whispered.

With a groan my father turned on his back and went to sleep again. I moved
forward and crawled against my mother who was laying on her back. She moaned "Go
to sleep Laura." "I'm scared mom" I whispered. She opened her arm, I rested my
head on her shoulder and pressed my body against her. "Go back to sleep", she
moaned once more. I placed on of my legs over her body, pressing my crutch
against her hip. With my right hand I touched her belly and slowly moved upwards
under her loose shirt. When I cupped her breast she opened her eyes and just
looked at me. I stared in her eyes and pinched her nipple, she bit her lip and
diverted her eyes towards my father. My hand slowly went downwards, my nails
just about touching her skin. I slid underneath her panties and I started to rub
her clit. My mother automatically spread her legs a little and started to breath
heavily.
