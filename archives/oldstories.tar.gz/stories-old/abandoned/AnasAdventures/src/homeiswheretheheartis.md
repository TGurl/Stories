# Home Is Where The Heart Is
The wind was blowing the snow against the window. Through the falling flakes I
could barely see my father who did his best to get the generator going. We
lived in a small house just outside of town and the power had just gone down.
My mother was anxious about all the food in the fridge and the generator hadn't
kicked in automatically, so my father had to brave the storm to get it going.

My mother cheered when the lights turned back on and hurried to turn a lot of
them off, just to save on power and make the petrol last as long as possible.
The roads had already been close to be shutdown and now they most likely were.
We had no idea whether we could go back to town any time soon.

By the time my father appeared in the pantry he looked like a snowman and I
giggled the moment I saw him. "Don't you laugh," my father chuckled, "Don't you
dare laugh."

"You look like a snowman," I giggled.

My mother turned around and started laughing too. "You really do," she agreed
with me, "The abominable snowman." We giggled for a while as my father took of
his coat. His beard was all white and slightly frozen. Just a few minutes later
he sat down next to the fireplace where some logs gave us some necessary
warmth. I sat down close to him and asked "Dad? How long are we closed off?"

"I don't know honey," he replied as he accepted a mug of hot chocolate from my
mother. "It's snowing pretty hard out there. It might take some time, but when
the snow stops falling we can go out with the snow scooter. Wouldn't that be
fun?"

I cheered as my mother handed me my mug and I blew in it to cool it down a
little. "It's isn't Christmas, but here you go sweetie," she said as she
dropped some marsh mellows in my mug. I looked up and smiled. Even though we
might be locked in our house I did like the cosines of it all. My mother sat
down with us and the three of us enjoyed our hot chocolate.

To keep warm during the night we all slept in the same bed that night, me in
between my parents. Ever since I was little I had loved sleeping with my
parents, but this night would prove to be a little different.

At some point during the night I felt my fathers arm around me woke me up. I
crawled a little backwards so my back was pressed against him. I placed his arm
against my chest and bit my lip as I placed his hand on my emerging boobs.
After a few minutes of laying there like that I felt his hand squeeze my boob a
little, then some more and some more. Then I felt his hand going down and up
again, this time underneath my nightgown.

I bit my lip even harder when I felt his hand cup one of my breasts and I
leaned a little backwards. I felt a bump against my bum and with my right hand
I tried to feel what it was. Softy gasping when I realized what it was, my
father moaned softly and whispered "You can touch it, if you want to." I looked
at my mother who's back was turned towards me. Her regular breathing indicated
she was still fast asleep.

Ever so careful I placed my right hand on his boxers and felt something hard.
Through the fabric I grabbed it and my father moaned again. He took my hand and
pushed it underneath the cloth of his boxers and pushed it down. My fingers
touched his penis and I gasped softly before I closed my fingers around it. I
turned my head towards him and he placed his mouth near my ear. "Now just move
your hand up and down," he whispered.

As I did what he told me I felt his right hand move down my body and slipping
underneath my panties. I spread my legs a little and he started to rub my
little clit. We kept pleasuring each other for some time until he pulled down
my panties and threw them on the floor next to the bed. I felt him take off his
after and pushed his lower body against mine. Feeling his penis against my ass
cheeks send a rush of lust through my little body.

He lifted my right leg and placed the tip of his cock against my little slit,
ever so slowly he pushed his big dick inside my little wet pussy. It hurt a
little as he stretched me out, but soon enough he was all inside me and I felt
his balls against my ass. "Oh daddy," I moaned softly, "What are you doing?"

He breathed heavily and started pumping slowly. I felt him slide in and out of
me. At first it hurt a lot, but after a while it started to feel really good
and I didn't want him to stop. "Wow," he whispered, "you are so tight." He kept
on pumping when all of a sudden the lights snapped on and my mother was staring
right at us.

But instead of getting angry she smiled and threw the blankets of. She looked
down and watched as my fathers cock slid in and out of me. She took of my
nightgown and kissed my little titties. My father slid out of me, got totally
undressed and pushed my on my back. He spread my legs and slid inside me again,
I looked at my mother and watched as she undressed too. She got up and placed
her pussy over my head. "Lick me," she demanded and I did as I was told.

"Finally!," I heard my mother say, "Finally we can introduce her to our world.
Come on, fuck her. Fuck her hard, fill her up. Oh yes honey, put your load deep
inside that fertile 12-year old pussy."


