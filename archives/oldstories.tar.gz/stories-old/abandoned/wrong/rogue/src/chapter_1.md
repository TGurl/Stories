# Chapter 1
See that girl walking over there? Tight red dress, high heels, hair and makeup
perfectly done? Do you see her as she's walking towards the elevators? Watch
how her hand trembles as she presses the button. That's me. I'm the girl
anxiously waiting for the elevator doors to open, on my way to the biggest
mistake of my life. How I got here? That's a long story.

It all started in college. Until then I had been the good girl, always
following the rules, did my best to please everybody. I was the girl who stayed
at home reading a book, romance novels most of the time. Never would I have
though I would be who I am today, a woman on her way to sell her body. But
there I am, getting into the elevator to get to room 317. The room where I
officially became a whore.

But let me start at the beginning, to understand how I got here you need to
hear where I came from. How my life changed ever so slowly, how my boundaries
were crossed time and time again. For this, for my story I need to start in
high school. Back to the moment my world fell apart.

"Honey can we talk?" I remember those words as if it was yesterday. My mother
had been crying, my heart froze and I knew what she was about to tell me was
going to be bad. "I need you to listen," she said, "I don't know how to tell
you, so I will just say it. Your father and I are getting a divorce. He has met
someone else and he will be moving out. I am so sorry." She started crying
again and I didn't know what to do, how to act or what to say. I was
dumbfounded, I thought their marriage was one for the ages.

"Why?" I whispered, "How?" I had to fight the tears, but I knew I had to be
strong for my mother. At that moment she needed me. My mother looked at me and
said "He met someone else. Apparently they have been seeing each other for
almost a year now. I found out yesterday and confronted him when he got home."

My father had been cheating on my mother for a year? I couldn't believe it. Not
my father. My mothers eyes told me she was serious. "A year?" I whispered, "He
has been --" My mother put a finger on my mouth and said "Yes, he didn't even
deny it. He said he didn't love me anymore, but I know he still loves you. He
loves you so much and I don't want you to hate him. He still is your father."

"I don't care," I replied, "I really don't care. I don't want to see him ever
again." I was 17 and really didn't know what I was saying. I simply didn't
oversee the consequences. My mother got up asking "Do you want to say goodbye?
He's waiting downstairs." 

"No," I replied, "I do not want to see him right now."

A few minutes later I heard his car start and drive off. I didn't even look out
of the window. The window to tell him I loved him had closed and I would never
get that chance again. A few hours later we heard he had gotten into an
accident. A drunk driver hit him head on and he had no chance. He died on
impact, they said. And I hoped it was true.

At the funeral my mother had the strength to allow *her* to come. If it had
been me I would never had done such a thing. She just attended the service and
didn't stay afterwards. All she did was nod to us, her makeup ruined by her
tears. I had a hard time coming to terms with it all, my grades slipped and I
got obnoxious. For the first time in my life I got suspended from school for
three days. My mother was livid, but all I could see was that I had lost my
father. Never did it occur to me that my mother was hurting too.

One day I skipped classes, just to wander the streets. No clue what I wanted to
do or where I wanted to go, all I wanted was not to be at school. As I sat down
near the fountain downtown, a boy sat down next to me. He was nice to me and
offered to get me a coffee. We sat down at a table and I forgot all about my
misery for a while. He told me he was 19, just short of 2 years older than me.

We ended up in his apartment and I lost my virginity to him. At first it had
hurt a lot, but he was so gentle and the second time we did *it* it had felt so
good. That evening when I got home I felt like a *real* woman, not a girl
anymore. "Where have you been?" my mothers voice sounded cold. I knew there was
no use to lie and I told her the truth, everything but the losing my virginity
thing.

I was grounded for two weeks, my mother checked everyday if I had been in
school that day. I had broken her trust and had to win it all over again. One
evening she had to work late and I texted that boy. Within the hour he knocked
on the door, seconds later he took me on the kitchen table. When I was about to
come I knelt down and he covered my face. Right after I told him he had to go
as my mother could come home any minute. I said goodbye with his come dripping
from my chin. I was in the bathroom cleaning myself when my mother got home.

When I wasn't grounded anymore I told her I was invited to a party and she
dropped me off. I went inside only to leave ten minutes later. I told the
birthday girl something had come up at home and that I had to leave. She said
"Okay, see you at school." and went back to partying. Outside I got into his
car and we ended up in a motel.

He rented a room and once inside he got out his phone. Ten minutes later there
were six boys in the room. I had sex with all of them, it was the first time I
was double penetrated and I loved it. They had a camera and filmed everything,
I even smiled into the camera. "What are you?" one of them asked and I replied
with "I am a slut! And I love it."

My mother had put me on the pill early on, so I agreed to them coming inside
me. They all did, my ass and pussy were filled with their cum when I came home
again. I felt it dripping down my leg as I kissed my mother with the mouth that
had just sucked six cocks. A few days later I told my mother I was going to the
mall, only to end up in another motel room with seven different boys. This time
they had brought drugs and I allowed them to inject me. I didn't go home for
almost three days, in which I had sex with more boys than I can remember.
