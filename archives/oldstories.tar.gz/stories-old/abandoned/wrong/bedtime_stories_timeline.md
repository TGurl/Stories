# Timeline

## Bio
Name: Christine (Christy) Bodine - Richards
Age: 42
Husband: Todd Bodine
Son: Josh Bodine

Majored in Communications
Working for PR of a major company

Graduated college at the age of 22, got married a year later.
Gave birth to son a year later.

## Story line
Story starts when she gets home after work and she can't find Josh. When she
goes upstairs to look for him she sees him on the bed masturbating. She watches
him and hurries away when he has come.

She starts to dress more sexy around her son until they have sex for the first
time. The story describes the process of how they got there.

Not long after they start recording their encounters and even have quickies
when her husband is home. Little does she know her son had already told his
father and ultimately they have sex together and she is double penetrated by
the two most important men in her life.

Slowly but surely she has become the house whore.
