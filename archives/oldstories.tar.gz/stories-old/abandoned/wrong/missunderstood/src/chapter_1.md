# Chapter 1
The store was packed with people and I just walked around like a deer being
hunted. I did my utmost not to look suspicious, at the same time I didn't want
anyone to see what I was about to buy. My heard was beating in my throat as I
slowly approached the item I was there go get: a pregnancy test. I was only 16
and this was the first time I had to get one of those.

Multiple times I had passed the isle where the tests were stored and by this
time I knew exactly where in the racks they sat. I walked by as if I was
looking for something else. Luckily enough some hygiene products were close
enough so I could act like I was inspecting those.

Just as I wanted to grab one of the boxes a woman turned the corner and I had
to abort. The woman got closer and closer to me until she stood right there
next to me. "Do you need some help?" she whispered. My face turned red but I
kept quiet. "Not to worry," she continued and grabbed one of the tests from the
shelves, "Meet me outside in five minutes." I had never met her before in my
life, but she was an angel sent by heaven to me.

I paid for the items in my basked, anxiously looking around if I could see her.
She waved the moment she saw me and I walked over to her. "Now," she said as
she handed me the test, "Promise me you will tell your parents about this. I
hope it will give you the news you want."

"Why?" was all I could utter.

"Because I was in your shoes once," she replied, "There was nobody to help me,
I had to do it all on my own. My parents weren't there for me, my friends
dropped me. I don't want any of that to happen to you. So, here's my
phone number if you ever need to talk, but please tell your parents about this.
Do not think you can do it on your own, everybody needs help sometimes."

She wished me the best and walked away. I stood there for a few minutes,
flabbergasted by her generosity before I finally was able to walk to my car. I
had gotten my license just weeks before and my parents had surprised me with my
mothers old car. I loved it so much and it was a sign of trust and independence
to me. And now I was at a point I was going to break that trust.

We had always been so careful and I never was this late. In my mind I knew I
was pregnant and I had no clue on how I was going to tell my parents. My mother
knew I was sexually active, my father was still in denial. To him I was still
his little girl, to him I was still the same innocent girl I used to be. Not
that I did drugs or anything, I hardly ever went to parties, he just couldn't
accept I was growing up let alone having sex.

On top of that I only had sex with my boyfriend of two years and it took us
almost 18 months before we actually did *it*. Every time we did we used
protection, mostly because his parents were strict Christians and he was
supposed to *save himself for marriage*. Troy just didn't agree to that and
rebelled openly against his parents. That was one of the things that made me
fall for him, he had an opinion and wasn't afraid to share it. He always said
he couldn't wait until he was 18 and could move out of the house. He had plans
to go to a college far away from his parents.

And now there was this. At first I didn't realize something could be wrong, my
period had always been irregular, but now I was really late and I just couldn't
not know. That's why I went to the store right after school to get the test,
which I put all the way down in my backpack. I would go to my room, put down
the pack before I would join my mother for tea. My mother who was British by
birth had met my father when she was in an exchange program, I inherited her
love for tea and we always made sure we had some right when I got home from
school.

Their story was one of true love. They met in high school, continued to
correspond when my mother had to go back to England and as time went by their
love only grew stronger. They met as often as possible until both of them
graduated and my father flew over to England to be at her graduation. Not only
did he surprise her by being there for her, he proposed to her right there and
then. The moved to the US a few weeks later, got married and my mother became a
US citizen the same year. Almost two years into their marriage I was born.
Months later my mother was diagnosed with cancer and they had to remove her
ovaries. I was *doomed* to be an only child.

Luckily enough they got to her in time and after a rigorous treatment she was
pronounced clean a year later. She has been ever since. The only bad thing that
came from it was her over protectiveness of me. Not the she was a *helicopter
mom* or anything, she just always was worried about me. She did her best to
give me the space I needed just as long as I talked to her, I just wasn't sure
I could tell her about this. I needed to know first.

I parked the car in my usual spot and walked inside as normal as possible. I
greeted my mother, walked to my room and acted like it was just another day.
After having tea with my mom and tell her about school, I said I was going to
do my homework before dinner was ready. Nothing out of the ordinary so far.
Finished my homework, had dinner with my parents and sat down to watch some TV
until the moment of action arrived.

"Mom?" I said, "I'm going to take a shower and go to bed. I'm tired and want to
read before I go to sleep. I need to finish that book for English class next
week and I haven't read a word yet."

"Sure honey," she replied, "I will come by later to kiss you goodnight."

I grabbed a large towel from the pantry and made my way over to my bedroom, got
the test out of the box, read the instructions and walked to the bathroom with
the test covered within the towel. After turning on the shower I did the test
as instructed. My heart was throbbing as I waited for the result. It was one of
the longest minutes of my life and the result was as happy as it was
devastating, a plus: I was pregnant! How was I ever going to tell my parents?

Tears started to roll down my cheeks as I took my shower. The water washed away
my tears and a slight panic took hold of me. What was I going to do? I wasn't
ready to be a mother! Not by a long shot. I did my best not to do anything
different from what I would normally do and tried to keep everything the same.

Back in my room I dropped on my bed. All kinds of thoughts went through my
head. How was I going to tell them? What was I going to tell Troy? Did I want
an abortion? Or maybe adoption? Or did I want to keep it? I just couldn't
decide, my brain was way to young to oversee all the problems that could
arise. I laid on my bed for almost two hours contemplating all kinds of results
in my head. The worst one was my parents kicking me out of the house, what was
going to happen to me then? All this time I was crying so hard and I got myself
in an utter panic.

A sudden knock on my door startled me and I did my best to hide the tears.
Right before I could say 'yes' my mother opened the door. The world stopped
spinning, the earth swallowed me whole when I saw what she held in her hand.
The pregnancy test! I had forgotten to take it with me from the bathroom. I
will never forget the look on her face.

"Did you need to tell me something?" she said with a cold voice.

"I wanted to mom," I said, "but I just didn't know how." I started crying again
and my mothers face softened.

"Oh honey," she said as she took me in her arms, "When?"

"Just now," I replied, "just before I showered."

"Oh sugar," she whispered, "You know you can talk to me about anything. You
should have told me right away. But I understand. I love you. When dad gets
home we will talk, okay? Just relax and it will all be okay. I promise we will
figure this out. Come, lets have a tea together and calm your emotions." We
went down to the kitchen and with tea in our hands we talked.

"So tell me," she said, "was it Troy?"

I just nodded.

"And did you use protection?"

"Yes," I whispered.

"Then how?"

"I don't know," I whispered, "I really don't know."

"How often?"

"Three times," I replied.

"Okay, I am grateful you are being honest with me. Does Troy know?"

I shook my head and said "No, I just found out remember? And I really do not
know how to tell him."

"We will figure that out too," my mother said in a calm voice, "how are you
feeling?"

"I don't know," I replied, "That's what I tried to figure out. On one hand I
want to keep it, on the other hand -- I don't know." I started crying again.

"Here, here," my mother said, "don't cry. I understand, you're still so young.
And to be honest I don't know how to feel either. On one hand I am delighted to
be a grandma, on the other hand *me* a grandma?"

I chuckled. My mother always returned to her British accent when she was trying
to make me laugh. Although you could still hear she was British, her accent had
changed over the years. She had become more American as the years went by.

"That's what I wanted to see, that beautiful smile of my little girl." she said
and took my hand into hers. She went down to look at me, her way of saying
*look at me*. The moment I did she smiled and said "It will all be okay. We
will figure this out."

A few minutes later my father walked in and he could see something was up. The
moment he saw the test on the table he looked at my mother, then at me. He knew
my mother couldn't be the one, leaving me. He didn't say a word for half an
hour, then sat down. I had gotten more anxious by the minute and just stared at
him.

He scraped his throat before he said "Troy?"

I nodded.

"Okay," he said with a breaking voice, "we will make an appointment tomorrow
and we will get a decent test. Until then this is just preliminary." Him being
a lawyer really showed at that moment. "Until then we will not talk about
this." he said, got up and walked away.

I stormed off to my room, this was the reaction I had been so afraid off. I
buried my head into my pillow and cried. Deep in my heart I knew I would react
like this and I detested his job more then ever. I felt like in my need for
help he had abandoned me. If it was up to me I didn't need to see a doctor to
tell me I was pregnant, the test I had done was more than enough for me.

I can't recall how long it took for my father to knock on my door. I told him
to go away, but he ignored me and walked into my room. I turned my back to him,
didn't want to hear what he had to say. Despite all my signals he spoke "Blake?
Please listen. I am sorry for how I reacted, it's a lawyer thing and your
mother has told me off. I shouldn't have said what I said and I am really
sorry. I just didn't know what to say and went with something that felt
comfortable to me. I should have done that, I should have done something that
felt comfortable for you."

I just huffed and ignored him.

"Blake? Please look at me. I am really sorry. I am trying to tell you that I am
here for you. Your mother was right. You aren't a bad kid, you just made a
mistake or had an accident. Your mother told me you two used protection and I
am so grateful for that. I know those aren't 100% reliable and I should have
realized that earlier. Please forgive me, but I've never had a 16 year old
daughter before and I can make mistakes too."

I turned to him and he held out his arms to me. I hugged him and started crying
again. "I am so sorry, daddy", I cried, "We used condoms and we were sure we
were doing it safely. I don't understand how this could have happened."

"I know darling," he replied, "I know. We will figure this out. Does Troy
know?"

I just shook my head "No, I am too afraid to tell him."

"We have to, pumpkin," he replied, "we have no choice."

"I know," I whispered.

I hardly slept that night and my mother called me in sick. We had an
appointment to see the doctor for that morning and although I tried to tell
them I didn't need one, they had insisted. It took them a few hours to get back
to us with the same result: I was pregnant. In my head it became cleared I
wanted to keep the baby, there was no more doubt in my head. As soon as I had
made it clear to my parents we talked about how we would accommodate me being a
new mother with school and everything else.

We were in the lucky circumstance my mother was working from home and could
take care of the baby while I was in school. My school had special programs for
teenage mothers and I could attend classes via the internet as much as I
needed. So far so good.

Telling Troy and his family was a whole different ballgame. Right after we told
them the ostracized me and forbid Troy to ever see me again. According to them
I had seduced their son into sin and said I had gotten pregnant so he had to
marry me. No matter what I said or did convinced them otherwise. They even
started to spread rumors about me, which only stopped as soon as my father
threatened to sue them. They knew how good a lawyer he was and he made them
write apology letters to everyone they had spread their lies to. Those actions
had severely impacted their status in the community and soon after they moved
away. I still don't know to where. All I know is a few years later Troy was
involved in a serious accident and had passed away.

For me a whole new chapter was beginning, one of me being a mother.
