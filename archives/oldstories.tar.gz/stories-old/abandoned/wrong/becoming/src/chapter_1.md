# Becoming
*an erotic tale by Transgirl*

## Chapter One
Never in my life I would have thought I would become who I am today. There had
always been these feelings and urges but I always knew not to act upon them.
Not in a million years would I have thought I would ever give in and explore
that side of me. And I have to say I never regretted that I did, I am so more
me now, so more in touch with myself and I really feel like I am who I was
meant to be.

This didn't happen overnight though, not by a long shot. This life opened
itself to me very gradually, boundaries were crossed with just a few steps at a
time. Never did I not agree to testing where my limits where, never did I do
anything I didn't want to do. I knew what I was getting myself into and I chose
to do it of my own free will. To explain what I'm writing here I need to start
at the beginning and tell you how it all came to be. This is the story of how I
became me.

---

We got married right out of college and were high school sweethearts. Even
though we had our break ups and went to different colleges, we always got back
together. It didn't take long for either of us to realize what we were missing
and to make contact again. At some point he said "Why do we always end up
together? Let's just stop doing this and let's get married." It wasn't the
romantic proposal I had dreamed of as a girl, but it was emotional nonetheless.
His eyes told me he was serious and I said yes.

Just weeks after graduating we got married and moved in together. We both
started our new jobs and our careers took off. We both worked long hours and
thought this was what life was all about. Two people working hard, living in a
house together. He brought up the topic of children several times, but I wanted
to concentrate on my own career. This was the first small crack in our marriage
and many others would follow soon.

After just three years we divorced and I moved into a small new apartment. At
first I was devastated, but I also knew it was for the best. We were friends
who tried to be something more. Dating just hadn't been enough to prove that to
us, we had to be married to understand we had gone to far.

Just a few months after we got divorced I learned he had passed away in a car
accident. A drunk driver had missed a red light and plowed into his car.
According to police he died on impact, so hard was the collision. The news of
his demise send me in a spiral of depressions and although we weren't married
anymore I felt like I had lost my husband. I felt like a widow. On his funeral
his parents comforted me like I still was part of their family, a gesture that
still makes me cry after all these years.

It took me a few months to pull myself out of it and to start living again. I
wasn't even thirty yet, there was still a whole life ahead of me. Slowly I
started dating again, it was just so difficult not to feel some sort of guilt
thus most of them lead to nothing. No second dates let alone thirds. My friends
urged me to keep trying but I just didn't care anymore. I had had it with
dating and I just wanted to be left alone.

I underwent therapy and she told me I showed signs of being *demisexual* or in
layman terms only felt sexual attraction when I had a deep connection to
someone. For a long time I thought she had been right. I hadn't crawled into
bed with anyone on a whim, couldn't understand the concept of a *one night
stand*. That all changed when I discovered a site for people with *sexual
problems*, that's my description of the site not theirs. The said it more like:

> Our site offers support to anyone experiencing a different type of sexuality.
> On our site you can talk anonymously and share your thoughts and feelings.
> We do not judge, we do not lecture. We only offer a place where you can share
> freely and be who you are.

I registered an account and started to read what others had posted. As I was
diagnosed as being *asexual* I started looking for other people with the same
diagnoses. There were just a few of them, most of the people on the site were
talking about how they were cheating on their spouses and just couldn't help
themselves. How guilty they felt afterwards and how they promised themselves to
never do it again, but they always did. There was one part of the site with a
big *Not Suitable For Work* warning. At first I avoided it like the plague, but
my curiosity won in the end and I read some of the posts with literal red
ears. I couldn't believe what people posted there, not only text but photos and
even videos of how they were cheating on their spouses, men and women.

Being on that site I learned so many new terms like *hotwife* or *cuckold*, to
name just two of them. I couldn't believe how many women were into this, I
always thought it was more a male thing. But clearly I was wrong. I kept on
reading the stories they had posted, some of them even excited me. Not to the
point of arousal, but just the thought of them going to a hotel room to meet
with a man who they had just met through the internet. Just the risk they took
by going there, who knew what could have happened to them and then to go there
without telling their spouse where they were? It all seemed so dangerous and I
couldn't imagine myself doing such a thing.

And still reading their adventures excited me. My heart started beating faster
as they described their feelings just before they knocked on the door. And then
there was the part where they described how they felt when they got home and
had to keep up the lie about where they had been. One woman described how she
kissed her husband as the fluids of her prior encounter still dripped out of
her and how she nearly had an orgasm when she did so. It all seemed so strange
to me, but also so very exciting.

The site became a regular thing to me and I visited it almost every night, I
didn't post anything nor did I react to any of the posts. I just needed to see
whether there were any new stories posted, any new adventures. The explicit
section became the first thing on the site I visited and the last one as I was
about to logoff for the night. In the mean time I lurked the other sections as
I got more comfortable reading the posts.

One evening as I spent some time in the *Females for Females* thread, I felt
the urge to place my first post. I had been lurking the site for a few weeks
now and I felt like it was time to announce my presence. With my heart beating
in my throat I typed the following.

> Hi, I've been lurking the site for a few weeks now. Finally got the courage
> to post. It's not easy for me, I wasn't raised to talk about these things so
> openly, but somehow reading the posts made it more comfortable for me to do
> the same. Maybe it's time for me to open up and to talk about stuff like
> this.
> I was married for a few years and just after our divorce my ex died in a car
> accident. I don't know how or why, but I still felt like I lost the love of
> my life. And in some way he was, we just couldn't live together. I haven't
> *been* with anyone besides him and somehow I just do not feel that kind of
> attraction. According to my therapist I'm what they call *asexual*, what
> basically means I need a deeper connection before I want to sleep with that
> person. Maybe they're right, I don't know.
> Reading these stories in the *NSFW* section I felt excited and scared at the
> same time. I can't imagine myself being in their shoes. Not just because it
> might be dangerous, I meant just in general like you just met the guy. I
> don't know, I've never been like that. As I said, after we started dating I
> never been with anyone but him and even before or after our marriage I really
> haven't slept with anyone. Is this strange? Am I crazy or something?
> Wow, I've revealed more than I thought I would. But the words just came out,
> it feels like I'm a balloon deflating. I can't stop now, I have to post more
> but I want to know how you'll react first. I'm so scared to read your
> reactions. As I said, I'm not used to talk about subjects like this.
> Love, CrazyCatLady27.

I had chosen that nickname because I was afraid to become one. All I did was go
to work, come home and watch TV or read a book. I didn't go out, had hardly any
friends and those I had lived far away and had families of their own by now. I
was the strange single friend in their circle and I got tired of the questions
"is there someone new?" or "When are you going to see someone again?" or
anything like that. So I stopped talking to them as often as I did before I got
divorced. Being on the site became sort of a substitute. There I could hide
behind a nickname, there I could show my true self. I could walk down the
street and nobody would know it was me behind that name. It gave me a sense of
security, a sense of comfort.

The dings on my phone where from e-mails I had received telling me there had
been responses to my post. I was so nervous when I opened the site a few hours
later, I had tried to do it several times but I was just to scared to see what
they had said. It was almost midnight when I forced myself to go and see. An
enormous sigh of relieve left my body when I saw they were all so positive. All
of them were supportive and not a single one told me I was strange or crazy.

There was one that stood out for me. It came from *MissMandy777*, she told me
she had felt the same way when she got divorced. Not that her ex had passed
away, but she felt the same guilt when she was with someone new.

> I felt like I was cheating for quite some time. Maybe even years. It was when
> I joined this site it started to change. I realized I wasn't his partner
> anymore and why should he get to have fun with someone new and not me? Why is
> it he doesn't feel this guilt. Because it's not reasonable to feel it, that's
> why. I'm so sorry for your loss, I truly am. But you got divorced before he
> passed away. He wasn't your husband anymore. That doesn't mean you can't
> grieve the loss of a good friend, or maybe even your best friend. It just
> means you weren't his wife anymore. Maybe it's time to forgive yourself, to
> let it go. Maybe it's time for you to explore your sexuality. Something you
> never did before you got married. Maybe it's time to start searching who you
> really are. And I know for a fact there are people here that can and will
> support you. All it takes is a little trust. We're not here to hurt you, we
> are all here because we, just like you, need some (moral) support.

Reading that post felt like something clicked inside me. Like someone lit up a
room inside me that had been dark for all my life. I read her reaction over and
over again and realized she was right. I hadn't explored my sexuality at all, I
was always told women that did were basically whores and that it was wrong to
*sleep around*. My mother even had a hard time explaining my period to me, she
never used the real words she basically told me it was normal and that there
were bandages in the bathroom I could use. She called them *female hygienic
products* not tampons. I had to learn how to use them on my own by reading the
package and felt ashamed when I went to school feeling it inside me.

Sure I knew other girls my age had the same *problem*, but still I didn't even
acknowledge when they asked if I had my first period yet. I just blushed and
didn't answer the question. When my body started to develop I wore shaggy
clothes to cover them up, I hated wearing tight clothes especially during
sports activities. I couldn't believe the other girls didn't feel that way. It
was so strange to see them walking around proud of their bodies.

So when my ex showed interest in me in college I was immediately struck and it
took a long time before we ended up in a bed together. The first time we did it
was in complete darkness. During our break ups I couldn't sleep with anybody
else, it just didn't feel right. Not that I didn't try, but I always chickened
out when that stage was reached. To avoid feeling like that I just stopped
dating anyone else.

In the weeks after that first post I posted more and more. I really opened up
to the people on that site. I told things about myself I hadn't told anyone
before. About how I felt, what I longed for and finally how jealous I had felt
of all the other girls in college dating anyone they wanted. I felt like
everybody in college had sex with everybody and I was the odd one out. One
woman replied she had felt the same way. She also said there were a lot more
like us in college.

But although I felt I could really share on that site there was something about
*MissMandy777* that struck a cord with me. We started sending direct messages
through the site and it felt like I could really open up to her personally. It
took me almost half a year before I realized I had made a true friend. She
didn't judge me, she was just there for me. So it felt safe when she asked to
talk via Skype, not that I wasn't nervous when we finally did but still if felt
safe enough for me to agree.

It was almost 9 pm when I sat down with my laptop waiting for her to call me. I
had never used Skype before and she had given me instructions on how to create
an account. The ringtone startled me and I took a deep breath before I clicked
on the answer button. The screen changed and I could see myself on the right
side of the screen. The other side blinked a few times before a gorgeous blonde
woman appeared on the screen.

"Hi," she said.

"Oh hi," I stumbled.

"How are you? You look nervous."

"I am nervous, really nervous. I've never done anything like this before."

"Don't be. It's just me. Think of it like posting on the site. You just don't
have to type and we can see each other. You are very beautiful, by the way. Not
at all what I expected."

"What did you expect?"

"Not this. You are gorgeous. I can't believe you're the insecure woman I talked
to on the site."

"Thank you, but I am. I just don't feel like the girl you described."

"Well, you should. Trust me, I've been there. I discovered myself through the
site and now look at me. I'm more secure about myself than I've ever been. I
know my limitations and boundaries because I tried almost everything. I know
what I like and don't like. I also know what my partners like."

"Partners you said?"

"Oh yes, I've got multiple. My husband knows about it now and he gave me the
space to explore. He even watches sometimes, but usually I just record it for
him. He loves watching those videos. He loves to see me having fun and getting
satisfied."

"Wow, he does?"

"Oh yes. And you know what? It made us closer than we've ever been. I know he
trusts me when I say *it's just sex*. I only make love to him, there's a
difference."

"There is?"

"Yes. Sex releases endorphins and the human body needs them. He knows he can
never fully satisfy me. Sure I feel good when I have sex with him, it's just
different when I'm with one or more different guys. It's more -- how can I best
describe this -- it's more *raw* then. We're just there for the sex and nothing
else. I love being used as a sex object, I love being humiliated."

It was quiet for a while before she continued "Look, I'm the boss of a small
company and I get to decide what needs to be done on a daily basis. It's nice
to feel have that power taken away. To be reduced to nothing but a thing for a
few hours a week or maybe even a whole weekend once or twice a year."

"I guess I can relate to that. I don't know."

"Okay," she said, "maybe it's time to open up a little more. We've seen each
others faces so why don't we tell each other our real names. Mine is Marisha
and yours?"

"Oh Laura, pleased to meet you Marisha."

She chuckled "Pleased to meet you too, Laura. But let's just keep it at that
for now. Maybe we can take another step in the future."

"That sounds good to me."

We talked for a while longer and after we disconnected I felt rather good about
myself. We hadn't talked about sex all the time, we talked about other things
too like movies we liked and stuff like that. We were like two girls in college
who got to know each other, but it felt like I had found a soul mate. I felt
like I could really trust her.

In the weeks and months after that first contact she proved it to me. I told
her things in confidence and she didn't share any of it on the site. We called
each other almost every night and the both of us felt we were getting really
close friends. We talked about anything but the things we shared on the site,
we just talked about our day and things like that. We laughed and just were
happy to talk to each other. It took us months before we told each other where
we lived and we were thousands of miles apart.

"It's so strange," she said one time, "I feel like you're one of my best
friends and we've never ever met in person. Maybe we should. I'm in the Hyatt
Hotel in St. Louis next weekend. Maybe we could meet there?"

"Oh, I couldn't afford it if I wanted to." I replied, "Flights are so expensive
these days. And the Hyatt? Way to expensive for me."

"Ah, well don't worry about that. If you can get on a flight I will pay for the
rest. I need to be there for business anyway and I can invite a guest to my
room. I'm a member of the Hyatt and there are discounts. I would really like to
meet you there, I think it's time."

"I would agree, but I'm not a CEO of a company like you. I'm just a simple
para-legal for a law firm trying to get her law degree. I simply can't afford a
plane ticket. I'm not trying to get out of it or anything, it's just things are
really tight for me right now."

"I know and really I don't care. I like you Laura and I like to think we've
become more than just good friends. I wouldn't have cared if you worked in a
supermarket, I really wouldn't. I learned to respect people no matter what they
do for a living. I try to talk to my employees as a normal person every day, I
ask about their lives and show interest in who they are. Because of that they
love working for me. I don't have an office tucked away on the 3rd floor or
something. My office is a few doors down from the cafeteria and my door is
always open. Come to think of it, I don't even have a door."

I chuckled and thought it was so typical for her to say that. She was really
down to earth and didn't act like a CEO at all, at least not like the bosses at
the firm I worked for. Sometimes I would sit near the entrance and it was like
they never really saw me. I wasn't allowed to speak up during meetings,
everything went through the lawyer I worked for. I had to tell her what they
got wrong and she would relay it to them. I worked hard for the praise she
received and sometimes she would compliment me on my work too.

Marisha was the total opposite from that. She acted like a normal person even
though she ran a multi-million dollar company. It was one of the things I liked
about her, that still didn't mean I wanted to take advantage of her. I wouldn't
want her to pay for anything.

"No," I said, "I'm sorry. But if we are going to meet I want to pay for my own
trip. I can't accept you paying for it. I simply can't. Don't think I'm not
grateful for the offer, I am. It's just I wasn't raised that way."

"Nonsense," she replied, "First of all the room is already paid for and as I
said I can invite a guest. It doesn't change the price at all. So basically I'm
giving you something I got for free. And I just checked, a return flight is 153
dollars for you. What if we slit that. I paid more for dinner tonight. Please
Laura, it would mean the world to me if you would come. Please."

"Oh, you make it so difficult. Are you like this at work too? No wonder nobody
can resist you." I chuckled.

"Well, I don't resort to begging but I would if I needed too." She laughed,
"Does this mean you're saying yes?"

"Yes, it means I'm saying yes. But I will pay for my flight. All of it. I'll
just make it work somehow." I replied.

"Nope," Marisha said, "Already booked your flight and paid for it. You're too
late, can't go back anymore. You're ticket will be waiting for you." She
laughed when she said the last words and I almost felt angry.

"Did anybody tell you ever how difficult you can be?" I said with a smirk.

"Oh yes, daily. But I don't care." Marisha chuckled.

"Thank you Marisha," I replied, "I mean it. Thank you. I don't deserve it."

"Oh yes you do," she replied, "and as I said I paid more for dinner tonight. So
please, let me do this for you. I can afford it and as I said I would love to
meet you for real. I'm so looking forward to what would have been a very boring
weekend otherwise."

The weekend had finally arrived and as it got closer my anxiety to go got
bigger too. In the end I really didn't know whether I would go, but I pushed
myself to go anyways. It was time to cross some boundaries and get a little
more adventurous. My co-workers couldn't believe it when I told them I was
going to St.Louis and were happy for me. That was a major part that pushed me
over the edge to go. I had packed my suitcase and arrived at the airport early.

After checking in I had to wait for two hours before my flight and I got more
and more nervous every second. During the flight one of the attendants even
asked whether I was afraid of flying. "No," I replied, "I'm just anxious about
what I'm doing. I'm meeting a friend I've met online for the first time. We've
been talking for almost a year now and we're finally going to meet each other."

"Oh," she replied, "that's really nice. I wish you all the best and have some
fun. I'm sure it all will be fine."

"Oh I hope so," I thought as she walked away. After almost 4 hours we landed in
St.Louis and a cab took me to the Hyatt Hotel near the arch downtown. The hotel
was really high class and I had never been in such an expensive resort in my
entire life. It had conference rooms larger than all of the office space at the
firm I worked for, there were more than 900 rooms in there and the lobby was
just so beautiful. I felt really underdressed as I walked in. Not that I was
wearing a simple dress or anything, I had really dressed up but still it felt
like I didn't belong there.

The girl behind the desk looked up and said "Hello, welcome to the Hyatt. How
can I help you?"

I gave her Marisha's full name and she said "One moment, I will call up to her
room and see if she's there." She reached for a phone and looked at me as she
waited for the answer. It felt like she was judging me and didn't believe I was
there for one of their guests.

"Hello," she said, "yes, this is Paisley from the front desk. Yes, good evening
to you too. There's a woman here saying she's here for you? She's your guest?
Well, I don't see it in our systems and according to our policy we can't accept
it now. -- I'm sorry you feel that way, but guests need to be registered at
least 10 days before arrival. What? Sure, that will be more than okay. Yes,
I'll ask her to wait. Yes, I'll be here." The girl turned to me and I could see
she had turned white a little "She will be right down and we will continue from
there. If you would you could wait over there. And again, welcome to the Hyatt,
our apologies for this mix up. But there are polices I need to follow."

I just nodded and sat down on one of the many chairs in the lobby. I looked
around and saw all kinds of business men and women sitting all across the
lobby, some with coffee's others just chatting. After a few minutes a blonde
woman walked out of the elevators, my heart skipped a beat when I recognized
her. She didn't even look around as she made her way to the same desk I was
standing just a few minutes before.

I got up and made my way over too and when I arrived I heard Marisha say "How
can this be? I registered a guest almost three weeks ago. How can it be it
isn't in your system? This simply is unacceptable and I demand you fix it right
now or I will take my business elsewhere next time. You see those people here
in the lobby? Well, most off them are *my* employees and I've paid enough to
get some cooperation. So what are we going to do about it?"

"I'm sorry miss, but our policies --"

"Yes, yes, your policies. So --" Marisha opened a folder she had under her arm
and took out a piece of paper, "this confirmation of the registration means
nothing, does it? See, there the third line? Confirmation for a guest. That
e-mail came from you. So as far as I'm concerned I did register a guest."

"Oh," the girl replied with a white face, "this changes things."

"Yes, they sure do," Marisha said with a stern voice. During the whole
conversation she hadn't raised her voice, she just sounded stern and direct. At
that moment I understood why she was the CEO, she stood up for her people just
like she had told me a few times. As the paper work was checked Marisha looked
at me and winked. I chuckled and behind me I heard someone whisper "They don't
know who they're dealing with. Marisha on her best."

After a few minutes one of the managers walked up to Marisha and said "I'm so
sorry this happened. I can't explain it, but the registration never was
processed it seems. But you got the confirmation and we will correct it in our
systems. Your guest is more than welcome to stay. To make up for our mistake
let us offer you dinner for tonight."

Marisha's demeanor totally changed and with a soft voice she said "That would
be lovely thank you. As long as everything is in order now I won't be taking
further actions and I hope mistakes like these won't happen again in the
future."

The man apologized once more and Marisha turned away from him. She walked up to
me and said "So sorry it had to be like this, but I can't stand when someone
hides behind policies. There are always ways to bend the rules a little." She
winked once more and then turned to the man who had commented before. "And
Marcus? Please don't say when I'm on my best, I'm always on my best. Don't ever
forget that." She chuckled and the man burst into laughter "How could I ever
have forgotten." he laughed.

As we got in the elevator she told me they had a conference with three other
companies the next day and they were there to represent her company. "It's all
very boring stuff," she said and as he bumped my elbow with hers she added "And
because I'm here with the rest of my company I can't indulge in some fun
either." She winked as she spoke the last words and I immediately understood
what she meant to say.

The room was just beautiful with a full view of the arch and it had two double
beds, a beautiful bathroom and a small balcony. I had never stayed in such a
nice room before in my life. The room was almost as big as my apartment.

"Sorry for the small room," Marisha said, "it was all they had available.
Normally I would book one of the suits, you know for me being a CEO and all. I
mean I deserve the best, don't I?" It took me a while to realize she was being
sarcastic and I burst into laughter. The ice was broken and every inch of my
anxiety was gone. She was as straight to earth as she had said during our Skype
calls.

We sat down and chatted for a while. "Yeah," she said, "I was just another girl
from a working class family. My parents worked hard to put me and my sister 
through college. She's a doctor now and I did business school. I got a job at
this company when one of the managers saw I could do more than what I did. He
offered a position to me and it all went up from there. Never would I have
believed I would become the boss one day, but hey, here I am. Just rest assured
my family makes sure I'm still grounded. We don't live in a gated community,
just a simple house in a normal street. Our children go to public school and
have to work for their stuff, just like we had to do."

"I always wanted to go to law school," I said, "but I didn't get in. So I opted
to do *Social sciences* instead, Political Sciences to be exact. I wanted to go
into law enforcement, or something like that when I got offered this job and I
thought at least it's something to do with law. One of the lawyers who used to
work there encouraged me to go to night school and get my degree. So after
thinking about it for quite some time I finally did."

"Good for you, you will be a fine lawyer one day. What do you want to do when
you get your degree?"

"Maybe public defender at first, you know to get your feet wet. And we'll see
after that."

"Noble of you, I like that."

"Thanks."

Marisha was just a few years older than me and she always said she was lucky to
be at the right place at the right time. "Yes," she said as she stared out the
window, "I was totally flabbergasted when Winston, the previous CEO, announced
me as his replacement. I couldn't believe he said my name. I was so sure it
would be someone else. So did he, he resigned just ten minutes after the
announcement. Which was fine by me, I would have fired him if he hadn't. Such a
sleazeball, I had heard multiple complaints about him from female employees.
But, I didn't have the power to do anything about it at that time. All I could
do was tell Winston and he said he needed more than just rumors. Well, I
didn't. I thought the rumors were enough and when I told staff he was leaving
there was a sigh of relieve with a lot of the women. That was more proof than I
needed."

Before diner that evening I took a short shower and Marisha handed me one of
her dresses. "Not that I don't trust you," she said, "but I never wear this and
I think it would look beautiful on you." It was a very nice dress, more
expensive than I could ever afford.

"Thanks," I replied, "I will return it later." After getting dressed I looked
at myself in the mirror and it did look nice on me.

"Oh wow," Marisha said as she came into the room, her hair still wet from the
shower, "it looks so much nicer on you than it does on me. Keep it. As I said I
never wear it anyways."

"Oh I can't --"

"Will you for once just say thanks," she interrupted me, "it's getting
annoying." She winked once more and smiled.

I chuckled "Thanks Marisha, I love it."

Marisha stood next to me and through the mirror she said "That's better. Now,
come let's do some makeup and stuff. I want us to look at our best at our free
dinner." We laughed and almost an hour later we walked into the restaurant of
the hotel. During a lovely dinner Marisha told me she would be busy all day the
next day and I said "No problem, I will explore St.Louis. I brought my camera
and I'm sure I can take some nice photos."

"Oh, you're into photography?"

"Yes, ever since I was little and got my first camera. It's just a hobby, but I
like it."

"You should show me them one time. I would love to see them."

"Sure, I can't right now. I didn't bring my laptop, but sure."

We spent the rest of the evening having some drinks at the bar and Marisha
introduced me to some of her employees. They all were so friendly and
welcoming, I felt right at home with most of them. They were so different from
the people I worked with, not that they weren't nice or something, it just felt
different. These weren't lawyers, they were just ordinary people with ordinary
jobs and it was so nice to see them laugh and talk to Marisha like she wasn't
the boss. They were just having fun.

"You should have been there before Marisha became boss," one of the girls said,
"The whole mentality at the company was so different. Marisha fought hard to
change it, she hates being called *boss*, she is but she insists on calling her
by her name. Don't get me wrong if decisions have to be made she's to one who
makes them. And she will tell you if you did something wrong, but never in
front of anyone but who needs to be there. She's such a good leader and I would
walk through fire if she asked me to."

"Damn right," a man standing next to her said, "she's the boss anybody should
have. One night we had to work late to get it all done in time, she came up to
me and told me to go home. My little girl was sick and she told me it was more
important for me to be with her than to be at work. She didn't listen to my
protests and basically threatened to fire me if I didn't go. I'm still so
grateful for that. She not only says family is the most important there is, she
lives it. But how did you get to know her?"

"Oh," I replied, "it sounds stupid but we met online. I was looking for
information about something legal and she replied with an answer. Not a legal
document, but a practical example. We got to talking and one thing led to
another. We've been chatting online for almost a year now and this is the first
time we actually met."

"Typical Marisha," the man replied, "she's so open and welcoming to everybody."
He bent forward a little and whispered "Trust me if I say this. If she says
you're her friend, you are. Just you being here proves it." I smiled and
thanked him. I wandered off a little and sat down in a chair. Marisha was
talking to everybody as I enjoyed my wine.

Just a few minutes later Marisha joined me and said "So nice to see them having
a good time. It costs me a fortune, but hey, we all need a break don't we? But
it's late already. I'll be right back."

Marisha stood up and asked for their attention. She told them how happy she was
they were there and how they would have a good conference the next day. She
told them to get some sleep and to be up bright and early. "Thank you all for
coming here tonight. It's time to get some sleep." she ended her speech.

Her employees applauded and finished their drinks. We were one of the last to
leave and back in our room she fell on her bed. "This is all so exhausting,"
she said, "I wanted to leave earlier, but I have to do my job and be the good
boss. All I really wanted was to find a good, strong man to fuck my brains
out."

I blushed when I heard her say that. "Sorry?" I said, "What did you say?"

"Oh you heard me," Marisha smiled, "I really wanted to grab one of the men
sitting at that bar earlier. Oh, he was so fine. I wanted to throw myself at
him and I wanted him to take me right there and then. But I couldn't, I had to
keep it in because of all my employees being there. But god, it was so hard to
hold it inside. I couldn't stop staring at him. All night I peeked if he was
still there. From one moment to the other he was gone. Darn it."

"Would you really have brought him here? Where would I have gone?" I asked.

"Well," she turned to her side and said, "You could have watched. Or maybe even
joined in."

"What?"

"Yes, why not? You already know my darkest secret. I don't have to hide that
side of me from you and it feels so good to be here with someone who knows that
part of me."

"But --"

"No buts. I've told you before, it's time for you to explore a little. To push
some boundaries. I'm so grateful you came, I know how hard it was for you. But
you can't tell me you didn't have fun tonight. I saw you talking to Rachel and
John. I saw how you blossomed talking to them. I am so proud you did."

"Oh, yes but that's not the same as doing what you said I could do."

"Why? It's just biology." She said as she got up from her bed. Without blinking
she unzipped her dress and dropped it on the floor. "This is me," she said as
she stood there totally naked. I gasped realizing she had been totally naked
under her dress all this time.

"Oh yes," she said, "I never wear underwear underneath my dresses. I hate the
stripes they make. Now, it's time for you to show yourself to me. Come on, it's
not that I've never seen a female body before. I mean I have one of my own."

I blushed again and Marisha kept on pushing me to get up. I finally did and
with a giant red head I took off my dress. After some more encouragement I took
off my bra and panties. I felt a little embarrassed as I stood there naked in
front of her.

"See," she said, "there's nothing strange about it. Just two naked women. Enjoy
yourself, feel free and I have to say you have a beautiful body. I wish I head
your breasts, mine are a little small to my taste."

I just stared at her and it felt good hearing those compliments. I felt a
tension growing between us and we just looked at each other. She took a few
steps forward and then another few. She was standing really close to me and
stared into each others eyes.

I shivered when I felt her hand on my waist. She turned her head slightly and
we kissed. Shy at first, with every kiss it became more passionate. In the end
we had our mouths wide open, our tongues deep inside the other mouth. She put
her arms around me and pulled me closer. Our breasts were pressed against each
other and I carefully placed my hands on her back. Marisha pushed me down on
the bed and got on top of me. Looked at me and kissed me again. Before I fully
realized what was happening I felt her hand between my legs. I felt a little
scared but I didn't want her to stop.

Automatically I opened my legs a little and she smiled when she touched my now
somewhat wet lips. Her soft skin felt so good against mine and I leaned over to
kiss her breasts. Her soft nipples felt so nice and she moaned softly. When she
pushed one finger inside me I groaned. It had been a while since I had anything
inside me. "Bite me," she whispered, "Bite my nipples." I softly placed my
teeth on her nipples and bit. "Oh yes, harder." she moaned, "bite me harder. I
love the pain."

I bit a little harder and each time she encouraged me to go harder. In the end
I tasted a little of her blood in my mouth, she groaned so hard and then just
launched at me. She pushed her tongue deep inside my mouth. She took total
control and placed one leg underneath me, without warning she pressed her wet
slit against mine. "I'm going to ride you so hard," she huffed, "I want us
both to come at the same time." My pussy had gotten so wet by now I just nodded
and she started to grind on my slit. Our clits touched and I thought I had to
come almost immediately. "No," she said, "don't come yet. Wait for me so we can
come together." I held it in and the moment she said "Oh yes, I'm coming almost
there. Yes, yes, oh yes..." I released and a huge orgasm rolled through my
body. Marisha sagged down on me and we kissed and caressed each other until we
fell asleep.

The next morning I woke up feeling something between my legs. I looked down
into Marisha's eyes. "Good morning," she said and started to lick my pussy. She
pushed her tongue in between my lips and I moaned. Placed my hands on her had
as she licked my slit and my clit. She kept on licking until I had another
orgasm. Then she sat up and over my head. Slowly she went down on me and for
the first time I licked a pussy. It tasted sweet and sour and I loved it. She
started to move her hips while she encouraged me. "Oh, yes, right there," she
huffed, "oh yes, keep going. I'm coming, I'm coming all over your face."

As she came she squirted all over my face. I was startled when she did and was
in total awe she could do such a thing. Before I could say anything she sat
down on my face again ordering to push my tongue as deep as it would go. "Eat
my pussy," she demanded, "eat it. Oh yes, eat it." I did as I was told and if
I'm being honest I loved it.

After another orgasm Marisha laid down next to me and we kissed some more. I
held her breast in my hand and pressed my crutch against her leg. I started to
grind and she just said "Oh yes, do it. Come for me, Laura, come for me. Show
me how you come." She pressed her thigh against my pussy and I moved my hips up
and down her leg. "Oh my god," I moaned, "I'm coming again. Oh yes, it feels so
good. Oh yes, yes, I'm COMING!" I pulled her close as my whole body started to
shake. Marisha held me as the orgasm took hold and everything went black for
me. It took me a few minutes to come to my senses and Marisha kissed me.

"I was hoping we would do this," she said, "maybe we can continue tonight. I
need to get ready for the conference." I just nodded and watched her as she got
out of bed and into the shower. On an urge I joined her as soon as I heard the
water falling. We kissed some more and washed each other. I took initiative
when I grabbed her pussy and slid two fingers inside her. I kept sliding in and
out of her until she came. She kissed me, stepped out and got ready for her
day. I followed a few minutes later and watched her dress and get out the door.

The rest of the day was all to myself. I wandered the streets of St.Louis, did
some window shopping, took a few photos and had a wonderful day. All this time
I thought about what had happened and how much I had enjoyed it. For the first
time I had just given in to my feelings and hadn't run away. It was such a good
feeling and I felt good about myself.
