# My Life
_an erotic tale by Transgirl_

## Preface
This is not a tragic story, I'm not a victim nor was I ever brutalized, raped
or did anything I didn't want to do or happen to me. Ever since I was young I
knew there was something special about me. People always were attracted to me,
I just didn't know why.

So if you read the story of my life hold that in mind and just enjoy what I
have to tell you.

## A special girl
Saying I didn't have a good childhood would be lying, I had the best one
possible. We lived just outside of town on a small farm, which seemed gigantic
to me and it felt like every day I could go on a new adventure. Some days I
would just walk through the stables and look at the cows, the horses or just
pet the dogs in their pen. Other days I would run through the fields, the corn
swaying as I ran through them, my dress fluttering behind me. I felt so free at
those times. When I looked over my shoulder I could see my father watching me
with a big smile on his face.

When I was eleven years old the world changed when my mother passed away, she
had been my fathers rock and he was devastated. I can still see his face when
he walked out of her room to tell me mom had gone to heaven. I had no clue on
how to react and just hugged him as he cried on my shoulder. The last words my
mom said to me were "I love you sugar, take care of daddy when I'm not there.
Please sugar, promise me you will take care of daddy when I'm gone." At that
moment I didn't know what she meant. With hindsight it was clear she told me
she was dying.

My father locked himself up in their bedroom for a couple of days, just coming
out to make us dinner and to see how I was doing. Then he made the decision he
had to be strong for me and pulled himself out of the hole he had been digging
for himself. In those weeks my father and I grew closer than we already were
and I started to fulfill my promise. I learned how to cook, to clean the house
and to take care of my father and me.

The first time my father saw me cleaning he told me how proud he was of me and
hugged me. As he held me I felt something I had never felt before, I felt a
little aroused.

One evening, it had been a few months since the funeral, we sat in the living
room watching a movie. To me the movie was a little scary and I crawled on my
fathers lap. He held me in his arms for the scary parts. As he held me I felt
something in his pants getting bigger the longer he held me. I was just old
enough to know what it was and it made me feel good knowing I had that effect
on him. Every movie night I crawled on his lap, whether it was a scary movie or
not, I just wanted to feel it grow again.

It was on a Saturday night when I woke up in the middle of the night. I had
heard something strange and listened carefully to try to determine what it
was, but I couldn't place it. I quietly crawled out of my bed, opened my door
and listened again. The sound was coming from my father's bedroom. In the dim
light I could see his door was ajar and I snuck over to see what he was doing.

The closer I got I heard a female voice say "Oh yes daddy. Fuck me." I peeked
inside and saw my father laying on his bed with his laptop next to him. With my
hand over my mouth I watched him holding his penis in his hand. He was moving
his hand up and down as he stared at the screen. "Oh daddy, it's so big" I
heard the voice say. I couldn't stop watching him and wished I could see what
he was watching. After a few minutes my father groaned and he ejaculated
something from his penis. It was the first time I had seen a boy come.

My father laid his head down and I quietly snuck back into my room. For the
rest of the night I couldn't stop thinking about what I had seen and I wanted
to see it again someday. A few nights later I heard that noise again and as I
looked out my room I saw this time his door was closed. Disappointed I went
back to bed waiting for the sounds to die before I fell asleep again.

A few days later I was alone when I came home from school. My father was
working the fields and I saw his laptop on the dining table. With my heart
pounding I opened it and started looking for what he had been watching. After
almost half an hour I opened the browser and checked the history as I had
learned at school. It didn't take me long to find what I was looking for.

I turned the sound down and started the video. I saw how a girl was talking to
her father about how she really wanted to get that purse. He said he didn't
want to give her the money when she said "But I can repay you." She placed her
hand on his crutch and I put my hand over my mouth when I saw her take out the
penis. "Oh dad, you have a nice cock," I hear her say and she licked it with
her tongue. I fell from one surprise into the next as she undressed and finally
sat down guiding his cock inside her weewee. "Oh daddy, fuck me" I heard her
say and he lifted her up. I watched the whole video and then watched another
one.

After a couple of videos I saw a thumbnail of a girl alone in bed and I watched
how she was playing with herself. I spread my legs and copied what she was
doing and soon enough I felt myself getting wet. I followed her lead and pushed
a finger inside me. I started to moan softly until I heard a sound nearby, I
closed the browser and shutoff the computer. I ran to the living room, switched
on the TV and fully expected my father to walk in. But he didn't and I sighed a
breath from relief.

The seed had been planted and I started masturbating every night. I used my
brush on myself for a couple of weeks until I wanted something bigger. I
rummaged through my room and tried anything I thought would be nice, until I
just used the posts of my bed. At first they hurt a little but the more I
played with them the better they felt. I started to fantasize about laying in
my father's bed and to do to him what I had seen in that video.

One night I knocked on his door and when he said "come in", I crawled into his
bed next to him and said "I had a nightmare, can I sleep here with you?" He
opened his arms and I laid my head on his shoulder, crawling close to him.
After a few minutes I placed my hand on his chest and pressed my body against
his. My hand slowly went down and he said "What are you doing?" I told him to
be quiet and finally I placed my hand on his crutch.

I looked at him as I lifted his boxers and took his cock in my hand. "It's okay
daddy, I know what you want. I've watched you as I looked at those videos. I
kissed his chest and went down until I felt his cock against my cheeks. Softly
I licked it like the girl in the video had done. It tasted a bit salty, but I
liked it. I opened my mouth and took the tip in. I went as deep as I could go.

"Oh Laura," I heard my father say, "we shouldn't be doing this." And he tried
to pull me away.

"It's okay daddy," I said, "I promised mom I would take care of you. I'm just
fulfilling my promise to her. I rose up and took off my gown before I pulled
down his boxers. I went back to sucking his cock until I crawled on top of him
placing his cock against my vagina. I pulled my panties aside and slowly went
down. His dick was a little bigger than the posts of my bed so it didn't really
hurt me. He went in a lot deeper though. "Oh Laura," my father panted, "this is
just wrong."

"Be quiet daddy," I said, "it's okay. I want this."

I slowly started to move up and down saying "Oh yes daddy, fuck me!" like the
girl did in the video. My father placed his hands on my hips and soon we found
a rhythm. Before I knew it I came on his cock for the first time, after my
father laid me on my back and came on top of me. I spread my legs and he pushed
his cock inside me again. He started pumping and slammed his cock deep inside
me. "Oh god daddy, this feels so good. Fuck me daddy, fuck me like you fucked
mommy. Oh yes, fuck me hard."

After a few minutes he pulled out, jerked a little and came all over me.
Feeling his cum touch my skin felt even better than I had thought it would. He
laid on his back next to me and I licked his cock clean. The taste of his and m
fluids tasted so good I wanted more.

In the morning I woke up next to him and with a slight smile I started to suck
him again. It didn't take long for him to get hard again and just as he woke up
I sat down on his cock. This time he lifted me up and laid me on the bed. He
stood next to it, pulled me close and pushed his cock inside me once more.

During the day I walked up to him as he was working the fields in his tractor,
I took off my dress, climbed up and crawled on his lap after he had taken out
his dick. Right there in the fields he fucked me and for the first time he came
inside me. "Oh yes daddy," I screamed, "come inside me. Make me a mommy."
