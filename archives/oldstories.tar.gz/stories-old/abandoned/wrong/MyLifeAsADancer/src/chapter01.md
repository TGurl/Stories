# Chapter One
Growing up in a small town in the north of The Netherlands I had a very nice
childhood. To the north was a large lake where you could go swimming or sailing
in summer and ice-skating in winter. To the south were large fields where
farmers grew their crops in one field and cows were grazing in the next. Being
a medium sized town all the necessary institutions were there like a hospital,
multiple schools and a shopping center downtown. It was a very nice place to
grow up in and to a small child it felt like growing up in a city.

I was only four when we moved there when my parents were able to buy a new
house there, my father even filmed the house being built. When it was ready we
moved into a neighborhood with lots of children and my school was just around
the corner. For the first view years my mother would bring me and later on I
could go on my own as there always was an adult checking nothing bad was
happening.

Now I feel the need to stipulate I'm talking about the world before the
internet existed. News you read in the newspaper or you could watch it on
national TV. If you needed to look up facts for a paper or something, you
needed to go to the local library and make photocopies of some books. We didn't
even have a computer until I was maybe 12 or 13, a typewriter was what I had to
use for school. Not that I'm complaining, I'm just setting a scene so you
understand it were different times.

At home we never talked about sex, I can't even say whether I have ever seen
either my father or mother naked in my life. You might therefore understand my
embarrassment when we learned about the human anatomy at school. I couldn't
stop staring at the picture of male genitalia in my Biology book. It was a
cross section of a penis so you could see all the blood vessels and other parts
that made a penis do what it does. I was around 10 or 11 when it was discussed
at school, right around the time I started to understand boys and girls really
were different. Until that age I had been a tomboy and loved playing soldier,
hide-and-seek with the boys. I was one of the fastest climbing a tree.

At the age of 10 I started to like more girly things, my mother was stumped
when I held up a skirt I wanted in the store. I had always resisted wearing
skirts or dresses. Not long after I wore my first pink outfit to school, got my
ears pierced and posters of boy bands appeared on the walls of my room.

My parents had always been progressive in some things. I was 13 when I got a
monthly allowance for clothes. "You need to learn how to handle money," my
mother had said, "If you spend it all in one go you will have to wait for your
next allowance." Of course they jumped in when it was needed, but basically it
taught me you had to manage your money.

In my country you can start a paper route at 13 and I added another 100 to 150
guilders a month to my allowance. That money was my own money and as my father
told me "You can do with it whatever you want. You earned it, it's your money."
The day I received my first paycheck I couldn't have been prouder. And yes I
hated getting up at 6 in the morning, especially when the weather was bad but
when I saw the money appear in my bank-account I always was happy.

I kept that paper-route until I was 16 and started working for a few hours a
week in the supermarket in our neighborhood. Starting out filling the shelves I
quickly was promoted to the register and later on to the customer service desk.
Working there for almost 2 years I became a group-leader, then one of the store
managers, only leaving when I went to college and moved to a town 45 kilometers
from home.

I was 18 and a whole new adventure started for me. I moved into a house with 11
other people my age or a little older. It is custom in The Netherlands to just
rent a room in a house with other students and I was one of the lucky ones as
the room was on the bigger side and even had a small balcony. Behind the house
we had a shared space mostly filled with grass and there was a central kitchen
where we all could cook our meals, do the dishes and so on. Every floor had a
central bathroom with a shower and you simply had to wait your turn in the
mornings. Not that it was a huge problem, everybody had to get up at different
times but for me being an only child it took some getting used to.

One morning while I was getting ready for school I forgot to lock the door and
Danny walked in on me. Luckily enough I had just put my underwear back on, but
still it was rather embarrassing. "Get out!" I shouted. He profoundly
apologized and disappeared into his room. For the next few days it was a little
uncomfortable between us. Little did I know that whole incident had sparked
something inside me.

A few weeks later I was in the shower and the glass walls were a little steamed
up. I was soaping up when Peter (his actual name was William, but he didn't 
like that name) opened the door. "Oh my word," he shouted, "You really need to
learn to lock the door!" But in stead of leaving he stepped in to brush his
teeth. When he was done he said "This is all your fault, just so you
understand. If you wanted privacy you shouldn't have left the door unlocked.
I'm just saying. Now I will take as much time as I need in here."

While he was there I pressed myself against the cold wall, not knowing how to
react. I fully expected him to step into the shower with me, when that didn't
happen I got a little more comfortable and stepped into the hot stream of water
again. When he started to shave I reached down for the soap once more and
soaped in my full breasts. All this time Peter was rambling about things I
can't even remember as I didn't really listen. My heart was pounding so loud
and it all was just so exciting to me. Just the mere situation of me being
naked underneath the shower and just feet away a guy was doing his thing.

Now to clarify something of the 12 people living there we were with 3 girls.
Somehow there was one girl living on each floor of the house. So on my floor I
shared a bathroom with 3 boys: Peter, Danny and Dillon. The girl who lived a
floor down tried to get us to share one floor, but it would have meant I had to
move into a much smaller room and I wasn't about to do so. I loved my room and
she didn't want to move up because the rooms were more expensive, so that idea
never went anywhere. Mary-Anne who lived one floor up said she wasn't going to
be there for long as she was preparing to go to the US as an Au pair.

In the first year I lived there the girl who had suggested the move moved into
an all girls house and the room was rented to another boy. Mary-Anne and I got
along nicely until she went to babysit a rich couples children. As rooms were
on high demand it didn't take long for a new girl to move in. That's how I met
Melissa. We clicked immediately and became friends. We spent many evenings on
my small balcony when the weather allowed.

During the summer we were sitting there when she turned to me and said "You
know what we should do? Put on our bikinis and catch some sun." She was looking
at the backyard, turned to me and said "Sod the boys, if they aren't
comfortable with us laying there they can look the other way." She smiled and I
knew there was no way I could talk her out of it. She got up and about 10
minutes later she came back wearing a bikini. "Why didn't you change? Come on,
let's go."

"I don't know," I replied, "It all feels so -- strange."

"Why? Don't you wear a bikini when you go swimming or at the beach?"

"Yes, but --"

"But what? What's the difference? It's a nice day and I want to catch some sun.
Get some vitamin D. Come on. I will go to the bathroom and you get changed."

As she left the room I opened the drawer of my wardrobe with my swim- and
underwear. The bikini I had was rather old and the triangles didn't quite cover
my breasts anymore. But still I put it on and when Melissa walked into my room
she said "Wow, now I understand why you were a little reluctant. We need to get
you a new bikini soon, flowers? That's so three years ago." She didn't even
mention the part where my top was barely covering my breasts.

She grabbed my hand and carefully I followed her downstairs, minding every step
as I was sure my top would slip and one of my breasts would pop out. It all
went fine and ten minutes later we laid down in the backyard underneath the
blazing sun. We smeared ourselves with sunblock and enjoyed the warmth of the
sun on our skin. "This is it," Melissa sighed, "This is so nice."

A few yards from us I could hear someone in the kitchen and for certain he
could see us laying there. "Catching some sun?" I heard Patrick say. He lived
on the first floor and was the one who lived in the house the longest. I looked
up and watched him sit down in one of the chairs in the shade. "I don't
understand girls and their obsession to get tanned. My sister is the same way.
At the first rays of the sun she has to go outside and just lay there *all*
day. Don't you ever get bored?"

"No," I replied as I laid down again, "this is just so relaxing. If you shut
your mouth that is." Melissa giggled and said "That's what I like about you.
You never beat around the bush." I turned my head and replied "Why should I?"
and giggled too.

"What are we doing?" I heard Peter say as he stepped outside, "Hey Patrick,
mind if I join you? What is it with girls and the sun?" "I really don't know
Peter," Patrick replied, "but I must say I don't mind the view." The boys
laughed and Peter said "You can say that again my man, you can say that again."

Knowing the boys were sitting there looking at the two girls laying in the sun
somehow excited me and deep inside me I was hoping more of them would come
outside. My wish was granted and twenty or so minutes later six of them were
sitting there talking and looking at us. I turned my head and my eyes met
Melissa's, she smiled and whispered "Let's give them something to look at."

Before I understood what she meant by that she rose up, pulled the string on
her back and took off her bikini top. Topless she laid down again and the boys
gasped when they saw what she was doing. A rush of excitement and dread went
through me, I just laid still for a moment or two then thought "Sod it" and
followed Melissa's example. Now there were two topless girls laying in the sun
in front of six boys who suddenly went totally silent.

Melissa started to giggle and whispered "Well, that shut them up." I burst into
laughter and totally agreed. Laying there topless felt better than I thought it
would, exposing my breasts to the boys felt so -- I can't really explain. I was
raised not to show to much to the other sex and now here I was laying topless
in front of six boys. I don't know but it just felt so -- right. Like this was
what I was meant to do somehow.

We laid there until the shadows replaced the direct sunlight, we got up and I
said I was going to take a shower. When I got down wearing a summer dress I was
amazed Melissa was sitting in one of the chairs drinking a beer still topless.
I grabbed a beer from the *community* fridge and sat down next to her. Melissa
finished her beer and said "I will take a shower too. We just decided to go to
the store and have a barbecue, you want to join?"

I nodded "But we don't have one."

Patrick replied "Oh, I can borrow the one from next door. They agreed and we
can get it while others are going to the store. I believe Peter is making a
grocery list, you know how it is with those business people everything needs to
be documented. That's why I love art school." Patrick was studying graphical
design and one of his works was on the wall of our shared living room.

This might be a good moment to explain the layout of the house. It was built
especially to house students about 5 years before I moved in. To be able to
move in you had to pass the ballot committee, basically you were invited for a
meeting and if the majority voted in favor you could move in. If there were
more applicants who passed it basically was a lottery.

On the first floor all the shared space was located. There was a large bathroom
with two showers, a bath and three sinks. Every other floor had a smaller
bathroom with just one sink, a toilet and a shower. Next to the bathroom the
first floor also had a shared living space with three large couches, a dining
table that could seat 12 people, a large TV and a solo chair where you could
sit and read a book or something.

On the second floor David, Lucas, Henry and Steven had their rooms. The third
floor I shared with Peter, Danny and Dillon. The fourth was shared by Melissa,
Patrick, James and Owen. Now I've used English names in stead of their real
names but I'm sure that whenever one of them reads this, if ever, they will
know exactly who I'm talking about.

We all got alone quite well and I saw my fellow inhabitants more like brothers
and sisters than just people who I shared a house with. Maybe it's because I
was an only child, maybe it was something else, I don't know. Fact is they were
more than just friends to me, they became family. Maybe that's why I was able
to be topless in front of them that day.

About 15 minutes later Melissa stepped out of the kitchen and said "Who's going
to the store with me. Peter handed me this list of stuff to get and I really
don't want to go alone." I raised my hand and Owen offered to go with us.

"Maybe we should ask the others to join too," he said, "we could make it a
house thing." We always tried to include as much people as possible when we did
something together. Like when our national soccer team played we always got
together to watch the game. Not that I particularly liked soccer, but it was so
much fun watching it with a group of people.

The three of us went to the store and when we came back everybody was outside,
all twelve of us. Davis had started the grill and somehow they had borrowed a
table from the neighbors too. The backyard where Melissa and I had enjoyed the
sun earlier was now filled with chairs. Owen filled the shared fridge with the
beer we had purchased and shouted "The beer needs to get cold, so just grab the
ones from the top shelve."

We had a good time that evening and decided to try to make this happen at least
once a week. "In winter we could have dinner together," Melisa suggested. We
all agreed to it and that's how we started doing more activities together in
stead of just staying in your own room. Even James who was the quiet one of the
group agreed and I was glad to see a smile on his face.

"Do you like it?" I asked him and he replied "Yes, more than I would have
thought." Although James was a little bit of a loner, he wasn't awkward when
you were alone with him. He just didn't like larger groups and 12 was a bit
much for him sometimes. I punched his shoulder and said "See, I told you it
would be fine, didn't I?" He just nodded and chuckled "Yes you did."

Just a few days later Peter showed us the grill he had gotten from his parents
and we all put money together to buy some plastic furniture for the garden. The
shed at the far end of the backyard was filled to the brim whenever we stored
them in there.

That year we had a barbecue together every Thursday as most of us would go home
for the weekend. When it became clear we all would be staying at the house for
the summer break we had a large party planned on the last Friday of that school
year. Most of us would be off around three that afternoon to prepare for a
night of fun. We had warned our neighbors beforehand and nobody seemed to mind
just as long as we lowered the volume of the music around midnight.

As it was one of the hottest days of the year so far we decided to give the
party a beach theme. When I got home the backyard was already dressed up with
garlands, umbrellas and there even was a children's pool filled with water. The
table was placed to the side and the chairs were scattered around the backyard.

Slowly everybody arrived home and we got ready to start the party to celebrate
the year behind us. Danny who loved to DJ had placed his equipment on a wooden
table just outside the kitchen and two large speakers next to it. He was
playing with the settings and the beats soon started to blast. He loved dance
music and I watched him play with the sliders for a while. Although I could see
him change songs I could hear the transitions, the beats were perfectly aligned
and when he noticed I was watching him he smiled and raised his left arm up in
the air. I chuckled and mirrored him which only encouraged him more.

Around 6pm everybody had arrived and David was grilling the first burgers,
Danny had pumped up the volume even more and all of us were moving to the
beats. Melissa and I were dancing on the patio and having a good time. We lost
ourselves to the beats and just went for it. At some point Steven and Dillon
took of their pants and shirts before they jumped into the pool. "What's a
beach party if we don't swim?" he shouted.

After a couple of hours the grill was abandoned and we were chatting, laughing
and having fun. I was wearing a white shirt and was moving to the music when
suddenly a bucket of water was emptied over my head. My t-shirt immediately got
opaque and my nipples were clearly visible. "Now do me!" Melissa shouted and so
it was done. Both Melissa and I were dripping wet and I wanted to go inside to
change. But Melissa had other ideas, she pulled me towards the patio and
started to dance. She turned towards the boys who were watching us and slowly
she lifted up her wet shirt. With my hands I removed the wet hair from my face
and without thinking I followed her example.

We started to dance topless, her hands on my ass. The dance got more sensual
as we put our faces close together our lips nearly touching. We both had
consumed some glasses of wine and a little tipsy. Danny changed the music to
something with a faster beat and we bounced to the music, our breasts touching
at some moments. I noticed my nipples getting hard and so were Melissa's. After
dancing for a while like that we took a small bow and went inside to get
dressed again.

When we got back the boys applauded once more and we all laughed. This was the
second time I had exposed myself to the boys and knew that I liked it a bit too
much. We partied until the early hours and as agreed Danny turned down the
music at midnight. He had started a playlist so he could join the rest of us.

The next morning I woke up with a little bit of a headache and I hit the shower
to wake up some more. When I looked outside I could see Lucas and Henry
clearing the backyard. I quickly put on a summer dress and joined them clearing
everything. "What should we do with the pool?" I asked them. "Leave it," Lucas
said, "Maybe someone wants to use it later today." The morning was full of
promises for another hot day.

One of the other woke up and soon the backyard was filled once more. "Let's go
to the lake," James suggested, "I haven't been there for a long time." It was
so unlike him to suggest anything and we all were a little stunned. "Wow,"
Peter replied, "He's opening up to us. But that's not a bad idea. We could go
swimming."

And so it was decided. The lake wasn't that far away and we all got on our
bikes an hour later. We brought as much as we could carry and a short ride
later we arrived at the lake. As it was a beautiful day already it was rather
busy and it took us a while to find a good spot for us to bunker down. "Who
wants an ice-cream?" Dillon asked and walked off towards the vendor.

Melissa and I laid down next to each other and applied sunblock to our skins. I
asked Lucas if he wanted to do my back and feeling his hands touch my skin send
thrills through my body. "It's a good thing I'm laying down," I thought as I
felt my nipples harden. He applied sunblock to my back and legs, as he went up
to my ass I spread my legs a little. I could hear him take a deep breath before
he reached for my inner thighs. He got close to my crutch but not just quite.

As soon as he got too close I said "What are you thinking?" He couldn't pull
back quick enough and his face got really red. As I laid down again, my face
turned away from him I giggled softly. Melissa noticed and burst into laughter.
When Lucas asked what the funny thing was Melissa replied "Oh, it's a girl
thing." and left it at that.

We had a lovely day at the lake, we went swimming, played some volleyball and
just had a good time being young. Later that afternoon we went home again and
after a shower I returned to the living room downstairs. Danny was laying on
the couch complaining about the heat. The others were sitting outside, all of
them in the shade. Melissa walked in and said "Come, there's a sale and stores
are open until 10. I want to go shopping." I ran upstairs go get my purse.

Half an hour later we were going from store to store, trying on clothes, shoes
and looking at makeup. This was by far the girliest thing I had ever done and I
loved it. The most fun I had trying on clothes we thought were very ugly and
laughed at each other when we got out of the changing room.

"Girl, that really accentuates your curves." Melissa said when I came out
wearing what we had dubbed a "grandma" dress. We walked from street to street
until we came across a shop which we both were a little hesitant to enter. It
was called the *Golden Rose* and tailored towards an adult clientele. Basically
it was a sex shop selling everything from toys to sexy outfits. Not that it was
a shady store or something like that, it was quite the opposite. The windows
had lots of pink and in general it was very inviting. Just the thought of going
inside was a lot to handle for the both of us.

But we did and gawked at all the sex toys they had on display. "Imagine
inserting that!" Melissa gasped pointing at a very large dildo. I couldn't
imagine any woman would even try to fit such a thing. "I bet it's just for
display," I whispered. Melissa nodded "It has to be." We looked at vibrators
and all kinds of other toys for women.

In a different part of the store they offered all kinds of clothes, from nurses
outfits to baby dolls. Melissa took a very tight latex suit from one of the
racks and asked "How ever would you fit into that? Oh, it stretches." The suit
had holes in it on all the convenient places and according to the label it
would show your breasts and crutch. She put it back and we walked to another
rack with a sign stating *Last chance. Going out of stock.*

We checked everything when Melissa held up a very short shirt. "It's and
underboob crop top!" she giggled, "let's get these. You like pink, don't you?"
She handed me the pink one. I checked the label and it said *one size fits
all*. Melissa held on to a light blue one. Both of them had prints on it and
mine said *Got Milk?*, hers said *Slut in training*. She giggled and said "This
is just too funny."

On the rack were also some very, very short skirts which included belts that
were almost as wide as the skirt itself. In the back we found a changing room
and we tried them on and I was amazed by how comfortable the shirt was and not
as all as tight as I had thought it had to be. The skirt just about covered my
crutch. "Let's step out on the count of three," Melissa said from the other
booth, "1.. 2.. 3!" We stepped out and burst into laughter when we saw each
other, we checked our looks in one of the mirrors and ten minutes later we
walked out carrying a bag with our new outfits.

We purchased a new bikini for me, together with some new skirts, shirts and
blouses that were on sale. One of the last stores we visited was a shoe store
as I needed a new pair of sneakers. They didn't have any that I liked when
Melissa pulled me towards the high heels. "These would be perfect for our sexy
outfits." she said.

"I've never had heels," I told her and Melissa waved it away with "You will
learn to walk in them soon enough." She handed me a pair of 6 inch stiletto's
with a little buckle to go around my ankles. "Try them on," she said and I sat
down on one of the seats. I took off my sandals and put the heels on. As I
stood up I leaned on Melissa and carefully took a few steps. I could feel the
difference in height and I tensed up all my leg muscles.

"Relax," Melissa said, "try to walk normally like you would do in those sandals
of yours. Just take a few steps." I did as she said and withing a few steps I
got the hang of it. "You're a natural," Melissa said with a chuckle. Within the
first few minutes my feet started to hurt and I told Melissa as much. "Oh
they've got pads for that. You just put them underneath your forefoot, they are
like little pillows. It will make walking in them way more comfortable and
after wearing them for a while you will get used to them."

As I took some more steps I could feel I was walking differently, my hips
swayed way more than they would normally do. "They look so nice on you,"
Melissa said, "You should get them. They are on sale now." Melissa tried on a
different pair and we both paraded up and down the isle for a while. At the
register I asked the girl for those pads Melissa had mentioned and she handed
me a small satchel with them.

When we got home around 9 in the evening six of the boys sat in the living room
and were playing some kind of game. The others were in their rooms or had gone
out for the night. Melissa and I decided to go dancing and we got ourselves
ready to leave. I put on one of the new mini skirts I had purchased, together
with a nice shirt. As to not show any strange stripes I decided not to wear a
bra, it was still to warm anyway. I read the instructions that came with the
pads and placed them in my new heels as was instructed. When I was ready
putting my new heels on it felt more comfortable standing in them. With a knock
on the door Melissa entered my room. "Wow, look at you!" she said as she
entered. I finished my hair and makeup, grabbed my purse and we got out the
door.

As we walked towards our favorite bar our heels clacked on the streets and we
giggled as we made our way over. The guard at the door greeted and opened the
door for us. As we stepped inside the mumbled beats were audible in the small
hallway. We stepped into the bar and made our way towards the dance floor.
There weren't that many people yet and that was the way I liked it. Normally I
would leave as soon as the bar got too crowded. The DJ was playing some popular
songs from the radio and we checked if we knew anybody who was there.

When we saw nobody we knew we made our way over to the bar and ordered a white
wine each. We sat down on the bar stools and talked a little. Melissa pointed
out a guy she liked and said "I would love to have breakfast with him some
day," she winked after she said it and I chuckled. When the DJ started to play
some dance music we got on the dance floor. I was a little hesitant at first
dancing in those heels, but got more confident the more I moved.

I danced to the music and could feel my breasts sway. Melissa leaned over and
said "You aren't wearing a bra, are you. You cheeky devil." She laughed and
started dancing again. After a few songs we sat down at a booth near the dance
floor. Two boys approached and offered us a drink, when they got back they sat
down opposite of us.

"Hi, I'm Micheal and this is Kenneth. Come her often?" one of them said.

I replied with a "Wow, could you have chosen a more boring opener?"

Melissa burst into laughter then said "I'm Melissa and her name is Ana. Don't
mind her she's always that direct." I chuckled and took a sip of the white wine
he had handed me.

I stared at Michael and loved his rugged face, he had a little of a stubble
going on on his square jaws. He looked like he could be a model and any of the
magazines Melissa loved to read. When the music changed he reached for me and
said "Want to dance?" I placed my hand into his and he guided me to the dance
floor. It was a bit of a slow song and he placed his hand on my waist, with the
other he held it higher. We started to dance, at first I looked at him then got
a little shy and looked down. The more we danced the closer he pulled my to
him, in the end my upper body was pressed tightly against his.

I looked up into his eyes and we kissed. When we returned to the booth Melissa
and Kenneth were talking and I sat down to take another sip of my wine. Michael
sat down next to me, placing his hand on my knee. I didn't protest and watched
how Melissa and Kenneth slid to to other side of the table in the middle.

Michael and I talked a little before we kissed again and again. Before I knew
it we were making out and his hand slipped underneath my shirt. From the corner
of my eye I could see Melissa almost on top of Kenneth, his hands were clearly
on her breasts and I let Michael do the same to me. Before I realized what was
happening he had pulled my shirt up and my breasts were exposed for anybody to
see who was looking our way. Knowing that somehow excited me more than the fact
Michael was touching them.

But I also knew exposing yourself wasn't allowed there so I pushed him away
quickly and pulled down my shirt. "How dare you!" I shouted and slapped his
face. "Go away you pervert!" Michael chuckled and said "You girls are all the
same, just little whores!" He reached for my glass of wine and threw the
contents at me. I screamed as the wine landed on me, I was totally
flabbergasted and luckily enough one of the bouncers had seen it and grabbed
them to throw them out.

When he got back he apologized and offered a place for us to clean up. He
handed us some shirts the bartenders would normally wear "Here have these
shirts so you can wear something clean."

"You are so nice," I said, "What's your name?"

"Derek," he replied, "pleased to meet you. And I am so sorry this happened to
you. Well, I will give you girls some space. Take all the time you need."

He closed the door behind him and Melissa started to giggle "At least we got
some free shirts out of it." I burst into laughter but my evening was ruined
and I wanted to go home. "Just one more wine," Melissa said and she bent her
knees "Please? One more drink?" I caved and a few minutes later we sat down at
the bar.

The bartender said "Oh, no alcohol during work." when we ordered wine. "Oh no,"
I replied, "some jerk threw wine at me when I refused his advances, Derek
handed us these so we didn't have to wear our wet shirts." "Typical Derek," the
bartender replied, "Always a soft spot for the girls. He may look like a
gorilla but he has a very big heart. He's just a big softy."

I stared at the bartender and said "You really like him, don't you?"

His face turned a little white and said "How could you tell?"

"Besides that rainbow wristband? Everything about you screams gay." I laughed.

He bent is head and said "Guilty as charged. My name is Travis and you are?"

"Ana, this is Melissa. She got splashed too." Melissa shook his hand and said
"You are not just a bartender are you? You own this place. I know you."

"Another truth has been told. Yes I am the owner but don't tell anybody, it's
a bit of a secret." Travis said. He got us our wines and leaned over the bar.
"I also own *The Dormitory*, that's where I usual am. One of the bartenders got
sick and I couldn't find anyone to fill in."

"Oh Ana is looking for work," Melissa said, "she's got experience."

I stared at her with a what-are-you-doing face as I had never worked in a bar
in my life. "Oh, is that so?" Travis replied, "Well, show me what you can do."

"Oh no," I replied with a blush on my face, "She's lying. I've never worked in
a bar before. I wouldn't know what to do."

"Just be friendly, smile and get their orders. It's not that difficult and I
could show you how to draft a beer. Come on, it would be fun." Travis said and
ushered me to get behind the bar.

As soon as I stepped behind it a woman raised her hand and ordered two beers.
Travis told her I was new and it took a couple of tries before I had a decent
order prepared. Travis took them and said "Now be proud of those. They are her
very first beers ever and because you were so patient they are on the house."
The woman gave me thumbs up and I smiled.

Travis looked at me and I said "This is fun." I walked over to another patron
who wanted to order. "Two white wine and three beers, please." he said. I
drafted the beers and Travis cheered "Not bad! Not bad at all." I handed the
man his order and calculated the total in my head "That will be 13.50 please."
He handed me twenty and returned the change.

"You can even do that," Travis cheered and leaned over the bar to Melissa. He
said something to her and Melissa laughed. There were three more orders before
I noticed Travis sitting next to Melissa on the other side of the bar. I was on
my own and it was getting rather busy. I handled order after order and gained
more speed as I went along. Sometimes I had to check the prices, memorizing
them as I went along.

The DJ started playing dance music again and I even started to move to the
beats as I handled the orders. When it got more busy Travis stepped in to help
me and we quickly found a groove behind the bar. Dancing as we prepared the
orders, just missing each other as we went from one side of the bar to the
other. "Whoohoo", I shouted, "Who wants to order?" I was having so much fun and
Melissa sat there enjoying me having fun.

Even the patrons enjoyed what Travis and I were doing behind the bar. People
started laughing as we high-fived every time we passed each other. I moved my
upper body to the music, which the male patrons really seemed to enjoy. Melissa
and I stayed until the bar closed and when I sat down on a stool, rather tired,
my feet hurting from walking in those heels all night Travis said "Well Ana,
the job is yours if you want it. I've checked the register and I think it's one
of the highest we have done in a while."

"But you won't be here every night, are you?" I replied.

"No, normally I would be at the Dormitory. But I know someone who would be a
great match. His name is Paul and he's just as gay as I am, so he should be a
lot of fun to work with."

"Let me think about it. When do you need to know the answer?"

"Tomorrow afternoon? We will be open tomorrow night as it's summer."

"Okay, I will let you know." Melissa and I gathered our still wet shirts from
that back room and just as we were about to walk out I turned and said "At what
time do I need to be here?"

Travis didn't look up and said "Be here around 9:30. I will tell Derek to let
you in."

"See you tomorrow then," I said.

"Yes, I might even be here."

On our way back home I told Melissa "That was so much fun!" Melissa chuckled
and said "I knew you were taking that job. You were totally in your element
behind that bar. You glowed the whole time. I loved watching you so much, I
didn't even dance a minute more."

The next day I arrived at the bar and Derek was standing outside. He smiled
when he saw me and said "Well, you're wearing decent shoes this time." I
laughed and said "You should have felt the pain I was in when I got home."
Derek chuckled and said "No thank you, heels wouldn't look on me."

"Don't sell yourself short, Derek. With those thighs? Hmm" I winked.

He opened the door and I saw Travis preparing the bar for the night. At the bar
sat a nice looking man, he was just a few years older than me. As I approached
Travis looked up "Ah, Ana! So good to see you're on time. That's a big change
from the other girl. Ana, this is Paul and he will be working with you. Paul
this is Ana, the girl I told you about." Paul and I shook hands and I sat down
next to him.

Travis stopped doing what he was doing and said "Now, Paul isn't just the
bartender, he will be the manager too. I can't split my attention to both
places anymore, I need some help. Paul has run all kinds of bars in the past
and I trust him. So he will be your boss too, is that a problem?"

I shook my head "Not at all. Pleased to meet you Paul and I'm looking forward
to working with you."

Paul nodded and said "Travis had told me all about last night and how quickly
you found your spot behind the bar. I will join you when it gets too busy,
until then I will attend to anything that is needed. All the same rules still
apply. You can get a fresh shirt from the back room and no alcohol while you
are working. Not even a sip when it's offered. It's okay to give regular
patrons a free drink every now and then, just don't overdo it."

"I understand. But we haven't discussed the wages."

Travis chuckled "Her friend, Melissa, told me this one was direct and she
wasn't wrong. You will get payed an hourly wage of 18 an hour, before taxes
that is. If you come by the Dormitory on Thursday we can do the paperwork and
make it all official. At the end of the night all the tips are split evenly
between everybody who has been working that night. Is that okay?"

I nodded and said "Let's do this. Let's have some fun tonight."

A few minutes later the DJ entered and we shook hands. He got behind his booth
and turned everything on. Within minutes we could hear some music coming from
the speakers as he tried all the lights. Paul finished preparing the bar for
the night and Travis handed me a shirt to wear for the night. It had the bar's
logo in the front and a large CREW on the back. "I got these today, do you like
them?"

I nodded and put it on when Travis had turned his back to me. In front is was
rather low cut and showed a lot of cleavage. "You can look now," I said with a
slight chuckle, "Not that it would interest you, but thanks for turning
around."

Travis chuckled "Well, I won't do it in the future then. I just wanted to be a
gentleman." I chuckled and looked at myself in the mirror. I pulled the front a
little more down and raised my breasts a little higher. I jumped a couple of
times to check if they would fall out and then said "I'm ready."

Paul had finished setting up the bar and said "Next time I will show you what
to do. But it's time to open up." I took my place behind the bar and sat down
on the small stool. I felt a little nervous but that feeling disappeared the
moment the first guests arrived.

"Hey, you were here yesterday," one of the women said, "I'm Rosie." I
introduced myself and said "It's my first real night, yesterday was a spur of
the moment thing." "Well, I wouldn't have known." she replied and ordered two
wine. I got her her drinks and she walked over to a booth where another woman
was waiting on her.

As more and more people arrived the DJ turned up the volume and before I knew
it the bar was filled with men. I leaned over to get there orders, fully well
knowing they were looking down my shirt. As the music got louder I started to
dance to the music again, fulfilling order after order. On the request of one
of the male patrons I shook my upper body for a 20 euro tip and laughed. All
this time I was fully aware of my triple-D breasts and that they were the main
reason mostly men were ordering drinks.

At the busiest part of the night Paul jumped in to help me and we found our
groove behind the bar. It was different but just as much fun to work with him,
especially during the quieter moments when we talked about some of the boys at
the bar. While I was getting the change for a customer he whispered "The one on
the corner, just look at him. Isn't he adorable?" As I walked over to the woman
next to the guy Paul had talked about I turned around and winked at Paul. He
just nodded and mouthed "Wow." I chuckled. I loved talking about boys with a
gay man. At the end of the night we cleaned up and Paul showed me how to clean
the bar, where I could find the refills. Derek was cleaning the dance floor and
the toilets and when everything was done I retreaded into the back room to
change my shirt. I put the one I had worn on the to-be-washed pile and returned
to the bar.

We sat down to have a nightcap and Paul divided the tips we had received that
evening. When he was done I said "Hold on a minute. This isn't right. Paul has
worked hard too. He deserves a cut of the tips too." We all agreed and divided
the tips into four equal shares. Paul had a little tear in his eyes and said
"Not needed, but much appreciated."

"No," I replied, "You told me the tips would be divided between all of us
working here and that includes you. Plain and simple." Martin, the DJ, just
said "Hear, hear" and I burst into laughter. "Wow, he can speak." I winked at
him and he laughed too. "Oh by the way, my fridge up there is almost empty. Can
I fill it tomorrow?" Paul agreed and said "Well, this was a good night
everybody. Please be here on Thursday to do it all over again for four nights
in a row."

Derek offered to drop me off in his car "It's not safe for a girl to walk home
alone. No matter how close it is." As we drove through the almost empty streets
I asked him if he had a girlfriend. "Yes," he said, "she became my wife almost
10 years ago. We have a little girl, Amelia. She's the love of my life, besides
my wife that is."

"How long have you two been together?" I asked.

"Oh, that would be 15 years or so."

"And how old is Amelia?"

"She will turn 7 next month."

"I would love to meet her one day."

Derek stopped the car right in front of the house and turned to me "That would
be lovely. I'm sure Andrea would love to meet you too."

With a goodnight I got out and stepped into the door. As soon as I entered
Melissa came rushing out the living room. "How was it?" she grabbed my hand and
pulled me into the living room. "Tell me all about it? I couldn't sleep until
you were home and I had nine cups of coffee to keep me awake. If I'm a little
on edge you know why. Well, start talking. I need to know. How was Paul? Is he
as gay as Travis or is he even gayer. Come now, talk to me. I've been up all
night --"

"Melissa!" I raised my voice, "Stop talking and give me a chance to answer." I
looked at the table and saw another cup of coffee steaming. I reached for it
and walked towards the kitchen to throw it away. "You've had more than enough
of this."

We sat down on the couch and I told her all about the night and how much fun it
had been. "In the end Paul divided the tips between the three of us and that's
when I said it wasn't fair. So we put all the tips in one pile and divided it
between the four of us. I told them Paul had worked hard too and he deserved a
cut of the tips. Luckily everybody agreed."

"Wow," Melissa said, "I am so happy for you. But you had to wear a low cut
shirt? Didn't that feel uncomfortable?"

"No, it was fine. It's just work, not that I'm selling my body or anything. The
men didn't mind it, if you know what I mean."

Melissa giggled and leaned back against the couch. Before I knew it she fell
asleep. I covered her with one of the blankets and chuckled. I went up to my
room and got into bed too.

The next Thursday I went over to the Dormitory, the high end club on the other
side of town. It was a very exclusive club for the rich and famous. The front
was nothing more than a blank wall with a large graffiti spelling the name of
the place. To the side was the entrance and I rang the bell, stood there
waiting anxiously for someone to answer.

A few minutes later someone answered the door and I said I was there to meet
Travis. The girl opened the door to let me in. "He is in his office upstairs,"
she said. The girl was wearing a shirt skirt and a crop top. As she guided me
to the stairs I noticed she was wearing extremely high heels.

On my way over to the stairs I saw a few guests sitting at the bar looking at
another girl that was dancing on top of it. In the rims of her stockings I saw
some euro bills, as she went over to a man holding up 10 euros she bent down a
little and the man stuffed it with the other bills.

When I looked to my right I saw a man sitting in a booth, to either side two
girls were leaned against him. Two other girls were dancing on a raised
platform, one hand on a pole in front of them. It clearly wasn't the busiest
moment of the day. "Just walk up, it's the first door on your right. He's
waiting for you."

I knocked before I opened the door and Travis got up from behind the desk.
"Ana! So good to see you. I've talked to Paul and he was very pleased with you.
He even told me about the tips." We sat down at a table and he opened up a
folder that was laying there. "This is the contract, read it and take your time
before you sign it. I will need your social security number, an ID and of
course your bank account number." I handed him everything he had asked for and
started to read the contract.

It was just a standard contract and I didn't see anything strange about it. So
I signed it and we had a small conversation afterwards. "Well, what do you
think of the Dormitory?"

"I've heard about it before, but it isn't anything like I imagined it would
be." I said.

"Oh you should see it when it's busy," Travis replied, "You should come here
someday. One of the perks if you work for me. Bring Melissa too, if you want
to. We are a bit more *relaxed*, so to say."

"I've noticed," I chuckled, "Maybe we will one day."

I had worked for Travis for a couple of months before I had the nerve to go to
the Dormitory one evening. I had a rough period behind me with lots of tests I
had to study hard for. Melissa was visiting her parents and none of the boys
wanted to come with me.

It was a Friday night and I was off work that week as I just couldn't combine 
it with working at the bar. It wasn't that late when I walked towards the bar
and just before I arrived I changed my mind and continued on to the Dormitory.
Anxiously I waited for the slot in the door to open and I told the man I worked
for Travis. He opened the door and let me in.

"Ana right?" he said and I was amazed he knew my name. "I'm John. Overall
manager and I see to the Lighthouse as well." "Pleased to meet you John," I
replied, "still very amazed you know my name."

"Ah," he said, "nothing special. I saw your photo in the files and I remember
faces. The rest I forget but faces, never." I chuckled and handed my coat to
the girl behind the wardrobe. She handed me a number and I put it in my purse.
She handed me a card and said "Everything you order will be registered on this
car. Keep it with you at all times, when you forget to pay do it when you
return." I nodded and told her I wouldn't forget.

I walked into the bar and it was way more busy. To my left was a seating area
filled with people dressed very sexy, on both sides of the bar girls were
dancing on top of the bar. I sat down on an empty stool and ordered a white
wine. I turned to the dancing area. All the raised platforms were filled with
dancing girls, some even hung from the poles. I was amazed by their agility to
do what they did. 

As I was looking around I felt and arm around my waist. I turned around and
stared into the smiling face of Travis. "You made it!" he shouted to raise his
voice above the volume of the music. I wanted to reply but he interrupted and
said "Let's go somewhere more quiet!" I nodded and followed him to the area in
front. The volume of the music was a lot lower here and we sat down at one of
the tables.

"So nice to see you here," he said as we sat down, "How's things? Did your
tests go well?"

"Yes, I think so.  Can't say it was easy, but I did the best I could. How are
you? Any new romances?" I winked at him and he waved it away with a "You know
how it is with a very busy business man." We chatted for some more, sometimes
interrupted by personal asking him something.

"Well, what do you think about the Dormitory?" he finally asked me.

"I am a bit overdressed I think," and nodded to a couple of girls walking by.

"Nah, we don't judge here. You come here the way you want to. But something
I've noticed is the following. People come here dressed rather conservatively
and the more often they come the less dressed they allow themselves to be." He
laughed and said "So, maybe you might be one of those people."

"I doubt it," I replied, "but it sure is very relaxed here. I needed a break."

"So where's Melissa?"

"She's visiting her parents. She will be back soon, I hope."

"You hope?"

"Yes," I turned my eyes to the half empty glass of wine in front of me, "Her
father isn't doing so well. The last I heard was he's in the hospital. I'm sure
she will call me tomorrow with an update or may be the day after. She needs a
little space."

"So, you have a house full of boys to your own?" He laughed cheekily at me and
winked.

"What? Oh no, it's nothing like that. They are more like my brothers, nothing
more. Yes, I like them but not in that way."

"Who cares? You could have some fun with them. It's not love, just sex."

I raised my gaze at him, totally stunned by what he had just said. "What? No!
No way! I can't believe you just said that. I should be insulted and throw the
rest of this wine at you, but that would be blasphemy so I will just drink it."

Travis chuckled and I caved, started to giggle too. Travis had a way over him
which was disarming and he knew it. He played with it because he knew he could
get away with it. He looked up, waved and said "Oh great, Paul is here. Now he
can take my place and comfort the sad little girl." He touted his lower lip and
I giggled once more.

Paul sat down at our table and we chatted for a while before Travis had to
leave and attend to something. "Why aren't you working?" I asked him.

"What? A boy can't take a night off? Derek is running the place and Tracy is
doing a good job, but she isn't you behind that bar. When are you coming back?"

"Next week. I just finished exams, had the last one today and I am so fucking
tired. But I needed to get away for a while. I thought about going to the
Lighthouse, but I know I would just end up behind the bar and I needed a drink.
So I came here."

"In that case we can't have you sit here with an empty glass, can we?" Paul got
up and returned a few minutes later with two white wine. He handed me one and
said "But tell me, what's really on your mind. It isn't just the exams, is it?"

"No," I replied and stared at my wine once more, "It's -- I don't know, one day
I was perfectly happy and the next I wasn't. I was cramming for my exams,
sitting at the library with all those books in front of me. Then Melissa called
to tell me she had to go home for a while. Her father is in the hospital and
suddenly I felt so alone. I don't know, it might be the stress or something."

"Girl, you have nothing to be depressed about. I mean, look at you. You are so
pretty and you have an amazing body, for a woman that is and you know I am in
no way biased about such a thing. You've come here, you are studying and you've
made a lot of friends along the way and at least someone really special:
Melissa. You might not feel it but there are a lot of people who like and even
love you. I consider myself part of the latter one."

"Thanks," I smiled and blushed a little, "that's nice to hear. But I just don't
feel it, you know. I feel there's something missing in my life and I don't mean
a boyfriend or something. I mean something more basic, something raw."

"Something raw? Let me think," Paul said, "Something raw? Oh I know --" he got
up took my hand and guided me to the back of the bar. There was a door with a
sign *Personnel only* and we just walked in. We walked through hallway until we
reached a door, he knocked and shouted "Anyone in there and are you decent?"

"Yes," a voice replied from the other side. We stepped in the room and a girl
was finishing her makeup. "Ah, this is Irene," Paul said, "Irene this is Ana.
She works for us at the Lighthouse. Maybe you could show her around a little
and tell her what we do over here."

Irene nodded and smiled. "Hi, nice to meet you. But I have to get on stage in a
few. Sit down while I finish." She was dressed in a outlandish costume, with
lots of feathers and glitter.

"What do you do here?" I asked her.

"Oh, I am a dancer. The main attraction tonight. I will perform on the center
stage in a few minutes. You're welcome to watch." She was doing her eyes while
she talked to me. "And you, what do you do?"

"I'm a bartender at the Lighthouse. That's how I met Travis and Paul."

"Those two really need to get together in a room one day. There's so much
sexual tension between those two, they just don't seem to know it yet."

I chuckled and said "Yeah, I noticed too."

"Girl, you are the best. How do I look?" She was just beautiful, the glitter on
her ebony skin just popped and she stood up and twirled around. "Everything
still in the right place?" she asked. I just nodded as I didn't have a clue
whether it was or not.

"Okay, three more minutes. Relax Irene, relax. You've done this a thousand
times, no need to be so nervous." she then looked at me and continued
"Stage fright every time. It never goes away." She gestured for me to follow
her and we walked down that hallway again, turned left at some point and
reached a small space behind the central stage. Through the curtain the music
was clearly audible.

Irene started to move to the music and stopped when the volume lowered, a voice
said "Ladies and gentlemen, for your viewing pleasure the incredible moves of
Irene!" And with that Irene walked through the curtains and stepped onto the
stage. I peeked through a slit to the side and quickly stepped into the bar,
next to the stage. The DJ played a new song and Irene started to dance. She
just looked straight at you as she moved and she pulled everybody in who was
watching her.

After a few minutes she took off the cape she was wearing and it drifted slowly
onto the stage. She jumped high onto the pole and held on with her thighs, it
was incredible what she did. She spun around as she took off the gloves she was
wearing. The longer the act lasted the more clothes she took off and I realized
she was a stripper, but a class A one. This wasn't just stripping, this was a
high end performance done my a class A performer.

After about ten minutes so stood at the edge of the stage, stared straight into
the crowd and with one sensual swoop she took off her top. She danced some more
topless and laid on the floor spreading her legs up in the sky, then before I
realized it she had taken off her panties too. A moaning female voice appeared
in the music and Irene laid down on the edge of the stage.

With her finger she invited a man to come close and she spread her legs. He
moved in and she placed her hands on his head. From my standpoint I could
clearly see he was licking her pussy, she raised her hips and then pushed him
away, inviting someone else to come to her. This time it was a woman who licked
her for a while. Then Irene got up and two girls brought a chair onto the
stage. Irene sat down on it, spread her legs once more and the one of the girls
guided a man onto the stage.

They danced around him and slowly undressed him, then they guided him to Irene
who sensually put a condom around his hard cock, then she nodded and he got in
between her legs, she guided him and as he entered her she looked at me and
winked. After a few minutes she pushed him off her and told him to lay down,
she got on top of him, her face towards the crowd. She sat down and him clearly
showing everyone there how he entered her ass this time. She leaned backwards
and moved her hips up and down on this mans cock.

Then seemingly out of nowhere, the other girl guided another man towards the
fucking couple. Irene guided his condom covered cock inside her pussy, now two
men were fucking her. I felt myself getting wet as I watched her on stage, I
felt a longing to be her at that moment those dicks entered her. The men fucked
her until they came and were guided to the back of the stage by the girls.
Irene got up and held two cum filled condoms high up in the air. The crowd
roared as she emptied them over her naked breasts.

The DJ started speaking again "Ladies and gentlemen, the incredible moves of
Irene! Give her a giant applause, Irene!" Irene walked along the stage and
bowed a few times. Then she walked off stage and disappeared behind the
curtain. I popped in too and saw the two men who were cleaning themselves with
some tissues that were handed to them.

I followed Irene back to the dressing room and sat down in a chair, still
totally amazed by what I had just seen. Irene was in the little bathroom to the
side and asked "Well, what did you think?"

"Wow," I couldn't find the words, "just wow. I can't believe you just did
that."

Irene popped her head out and said "Did what?"

"You had sex on stage! Do you even know those men?"

"No," Irene said, "those are randomly chosen by the girls. And it's just sex,
Travis pays me a lot off money and I can take care of my kids."

"You have kids?"

Irene appeared from the bathroom dressed in a robe. "Yeah, why? Is that so
strange? A stripper can't have kids?"

"No, that's not what I meant. It's just your body doesn't show it, your still
so -- tight."

Irene laughed and said "A lot of exercise, girl. A lot." She sat down and
started taking off her makeup. "My husband complains sometimes, when I'm not
working I'm in the gym. And when I'm not in the gym I'm taking care of my
kids." Then she looked at me and said "But he get's his share of attention, you
know what I mean?" She winked and chuckled.

"You're married? And your husband knows what you do?"

"Yes, we actually met during a performance. He actually made me come for real
on stage. I couldn't believe it. When we got backstage I invited him in here
and we talked. Everything after that is history, we got married a year later.
He was a lawyer, but now he runs our company. We offer acts on the *sensual*
side of the spectrum."

"Wow" was the only thing I could utter, "How did you get started? I'm sorry if
that's too personal, I've just got so many questions."

"It's okay," Irene replied. She turned to me and I chuckled as she had one
clean eye and one still in full makeup. "I was working a lousy job, had a kid
from a lousy father who split the moment he heard I was pregnant. I had to take
my kid to childcare, work all day and by the time I got home I was too tired to
play with her. When I saw an add asking for dancers I thought why not. One
thing lead to another and I ended up stripping. I made more dancing then I ever
did in that job so I quit."

She went back to taking off her makeup and continued. "I started my own little
company and got asked to dance all over Europe. The more I performed the more
*explicit* the act became. Then I met Oliver during an act and well, you know
that story. Now I perform whenever I feel like it and run the company with my
husband the rest of the time."

"So, if a girl joins your company how much would she make?"

Again Irene turned to me and said "Why? Are you interested?"

"No, just curious."

"It depends. It depends on the act, her looks and how much revenue she
generates. Lets just say my best performer can live very comfortably and she
only has to work for a few hours a week."

I was quiet for a while and let Irene get dressed into her normal clothes. By
then she was almost unrecognizable. She didn't look at all the way she looked
on stage, she was more a business woman than a performer.

"Well," she said, "Time to go home, it was a pleasure meeting you. Let me give
you my card, if you want to know more just call me."

She got up, checked her watch and said "My husband will be waiting. Bye."

I sat there for a few minutes, processing all I had just heard and seen. Then
got up, returned to the bar, ordered another white wine. Still processing it
all I went home.

The next day I still was stunned by the whole experience and couldn't wait to
tell Melissa all about it. It was late in the afternoon when she finally did.

"Hey, how's your father?" I said as soon as I answered the phone.

"Hey, he's doing okay now. The doctors said he's going to be fine. We just need
to change his diet a little and he needs to get more exercise. My mother will
see to it that he does. I will be home tomorrow."

"Nice, I can't wait to see you. I've got so much to tell you."

"What? Spill it girl. But first how did your exams go?"

"Good, I think. I don't know, they weren't easy."

"They aren't supposed to be. So what do you have to tell me?"

"Well, last night I needed a break and none of the boys wanted to come, so I
went alone and went to the Dormitory."

"No, you didn't. I don't believe you."

"I did and I talked to Travis for a while until Paul walked in. He took be to
the back and introduced me to one of the dancers, Irene."

As I told her what I had seen Melissa went from being amazed to totally
flabbergasted. "She did what now?"

"Yeah, two of them at the same time. Let's just say, both her holes were
filled."

"No way! On stage?"

"Yes! It was unbelievable. Afterwards I went with her backstage and we talked.
She's married, has two kids and owns a company specialized in erotic acts. She
even gave me her card, *Erotic Arts* it's called. They perform all over the
world."

"Wow, will she perform again and are we going? I need to see this."

"Oh, she only performs when she feels like it. But we could call her and ask."

"Maybe. Let's talk about it when I get home. I still can't quite believe it."

"Get home soon, I miss you."

"Aw, I miss you too Ana."

We hung up and I felt a little more happy. I went down into the living room and
watched some TV with the guys sitting there. Lucas turned to me and said "Not
going out tonight?" I just shook my head and said "No, I'm tired and want to
get some sleep." With that I got up and went to bed early.

The next day I woke up at 6 in the morning, the rest of the house was still
quiet. I opened the curtains and saw it promised to be a beautiful day. I
stretched after I had opened up the doors to the balcony. I stretched as I took
in a deep breath of the fresh morning air. Still dressed in my night gown I
collected the dishes strewn all over my room and took them downstairs.

I did the dishes and made a pot of coffee. When it was ready I poured myself a
cup and went outside to the backyard. I sat down in the early morning sun
enjoying the smell of fresh coffee in my hands. As I sat there Henry joined me
holding a mug of coffee. "You always make the best," he said as he sat down.

"Good morning," I said with a little raised voice.

"Oh yes, good morning," he replied.

"Why are you up so early," I asked him.

"Ah, need to go see my folks. I got to catch the train at 8."

"That explains it."

Henry just nodded. "Yeah, my father wants to talk to me. I expect him to push
me to start working for him again. He just can't seem to get it. I don't want
to be a lawyer, I want to do what I do. It's always the same, I guess."

"Oh no, my parents accepted my choices and fully supported me." I said, "When I
told them I wanted to be a vet they never said I couldn't."

"Yeah, but a vet is something *acceptable*, being an artist isn't. 'Why don't
you become a lawyer first and when you still want to be a photographer you can 
do it as a hobby and see where it goes. At least you have something to fall 
back on.' I know the drill by heart."

Henry wasn't the typical art school student, he wasn't eccentric or anything
like that. If you saw him you didn't think he was an art student, but he
created beautiful photos. He had rented a small studio on the other side of
town, where he spent most of his time. I couldn't remember the last time I had
seen him without his camera.

"Well, I hope it all goes well for you. You shouldn't give up on your dream."

"I won't, I refuse." He said as he got up and went back inside.

After sitting in the backyard for a while I went inside too, got into the
bathroom and took a shower. I was washing my hair when Henry walked in. "Oh
sorry, I didn't realize. The door was open..."

"Well, as long as you don't need to shower..." I replied.

Henry laughed and said "No, just brushing my teeth and shave. I can go
downstairs if you want me to."

"Nah, just don't peek." I replied.

I continued showering and soaped my body. Through the steamed up glass I could
see Henry stealing glances at me. I softly giggled and didn't say a word. When
I was done I wrapped a towel around my body and stepped out of the shower.
Henry almost swallowed his tooth brush.

"I did wrap a towel around me," I said acting a little displeased, "and it's
not that you haven't seen the girls before."

Henry chuckled and said "No, I can't say that I haven't."

I wrapped another towel around my hair and walked towards my room. I blow dried
my hair, applied a little makeup and got dressed. It was such a beautiful
morning I wanted to go outside and got on my bike. After cycling for about 30
minutes I found myself at the lake once more. As it was still early there
weren't that many people there and I walked around the lake until I sat down on
one of the benches overlooking the water.

In the distance I could see the sails of two or three boats, for the rest it
was so quiet and peaceful. "I should have brought a towel," I thought to
myself, "I could have gone swimming." I just didn't want to go all the way back
to get one. Enjoying the calm and the ever rising sun I stared over the water,
the longer I sat there the warmer it got. I opened up my jacket and just sat
there doing nothing.

A man walked by with his dog and waved to me. I nodded and watched as the dog
jumped into the water going after his ball. "You have it easy," I thought as I
watched the dog fetching his ball. The dog shook his body when it got out of
the water and ran to the man who took the ball and threw it again. With a
splash the dog jumped into the water again.

I sat there for a while longer then got up and went back to my bike. I cycled
to the part of the lake that was a nature reserve. You were allowed to got
there and have a stroll. I hadn't been there before and saw on the sign they
had three routes you could walk. I chose the blue one as it was the shortest
one. All I had to do was follow the wooden poles marked with a blue strip of
paint.

Twenty or so minutes into the trail I found myself at the waters edge once
more. It felt like I was totally alone on the world. From here I couldn't even
see the sails anymore. It was totally secluded and a crossing point with the
other trails. I sat down on one of the benches to rest and enjoyed being in
nature, listening to the birds singing, the water splashing. I took off my
jacket as walking had made me sweat a little.

Suddenly I felt the urge to take off all my clothes. I checked if there was
anybody who could see me, then dismissed the thought. "You can't" I told
myself, then proceeded to take off my yoga pants. Within seconds I was totally
naked, just wearing my sneakers. I got up and walked around for a moment or
two, before I gathered my clothes and started to follow the blue path again.

Nerves ran through my body and with every sound I checked if it was a person
behind or in front of me. When the bushes got a little thicker I relaxed a bit
more and just started walking. At some point I dropped my clothes and made sure
they were hidden. I walked a few hundred meters before I turned back to my
clothes and got dressed as quick as possible.

I was giggling all the way back to my bike and couldn't believe what I had just
done. I got on my bike and went home as quick as I could. By the time I got
back the other boys were awake and sitting in the backyard. I got myself
another coffee and joined them. "Where have you been?" one of them asked and I
replied with a "Oh, at the lake. It was beautiful."

Later that day Melissa returned home and we had a chat in her room. We talked
like we hadn't seen each other in a year, it just felt so good having her back
in the house. We spent the rest of the day together in her room and went out
for dinner.

The summer changed into fall and then winter. It was cold outside and I had to
study for another round of exams. I had passed the previous ones, but these
were even harder than the previous ones and me going to take a residency
totally depended on them. When the exams were over there were just a few weeks
until Christmas and I had to go home. The day before I left I learned I had
passed all of them and I could start my residency after the holiday break.

I was totally elated and couldn't wait to tell my parents the food news. We had
a lovely Christmas with the rest of the family and I spent new years at my
grandparents. My grandfather loved fireworks and every year he made it
something special. On New Years day I walked into the kitchen where my
grandfather was sitting. "Good morning Ana," he said, "please sit down with me.
I need to tell you something."

I sat down wondering what it could be. "Now," he said, "you know I'm getting a
little older and can't do the things anymore I used to do. No, don't interrupt
me, this is important. Tomorrow you will join me and we will go to the DMV. I
am giving you the Volkswagen, we don't need two cars anymore. We are both
retired now and the VW is just rusting away and I know how much you like that
little beetle."

"What?" was all I could say, "Are you serious?"

"Dead serious," he replied, "and there's more. As long as you are studying we
will pay for the insurance and taxes. You only have to pay for the gasoline."

I jumped up and hugged him. "Thank you so much," I cried, "This is too much."

"No," he said, "You're my only grandchild and I want to do this for you."

"Thank you gramps. Thank you so much."

At that moment my grandmother walked in and said "Why is she hugging you?"

I turned around and hugged her too. "I love you grandma. Gramps just gave me
the beetle."

"Ah yes, that. It makes me happy to see you happy, dear. He's still a grumpy
old man, but he has his moments." I chuckled, they had been together for over
45 years and I knew they loved each other. "Don't think for a minute this was
his idea."

I chuckled again and when my mother walked in I blurted it out. "What?" she
said, "Are you sure dad?" My grandfather nodded and said "Yes, I am sure. I
haven't driven that car in quite some time and I want to see it go to someone
who will take care of it the way I did."

My mother blurted out "Well, get the keys and take it for am spin shall we?"

Ten minutes later I was driving the car and my mother sat next to me. "It's
nice to see that smile on your face. You really love this old car, don't you?"

I nodded and my mother continued "I still remember sitting in that backseat on
top of loads of blankets. Your uncle next to me on our way to our holiday,
somewhere in Germany or France. Can't believe we actually did that, it seems so
dangerous now."

The VW beetle was an old car and my grandfather had always taken very good care
of it. Because it was such an old car it was tax exempt and still a beauty to
drive. After about half an hour we returned to my grandparents place and I was
even more elated than I was before. My father had gotten up by now and was
fully aware of the news. He hugged me and congratulated me. "I had hoped to
take it of his hands, but you beat me to it. I love to see you this happy."

The next day we registered the car in my name and my grandfather made sure the
insurance knew I was driving the car and he was paying them. When he hung up he
walked over to me, keys in his hand. "Now promise me you will take care of
her," he said. I nodded and he said "She is yours." He dropped the keys in my
hands and I jumped for joy.

A few days later I drove home in my *new* car. Melissa was so happy for me and
the boys marveled at the old beetle. "How fast does it go?" Owen asked me and I
said "Well, with the wind in my back it can reach a 150 Kmh, but it does 120
comfortably. She's such a nice car isn't she?"

"She?" Peter interrupted.

"Yes, my grandfather named her Rosie, after my grandmother. He got this car
when they got married. She's been in the family ever since."

"Isn't that confusing?" Peter asked.

"No, for some reason he always calls my grandmother *Poppy*. I don't really
know why, he has done that for as long as I can remember."

"Well, Poppies are roses too." James replied. And somehow that clicked with me,
my grandmother always said she loved Poppies and now it just made sense. "They
are the most delicate of all the roses," she had told me once.

As winter turned to spring I had joined a vet for my residency and loved taking
care of the animals, but also the every day grind of getting up to go to work,
study when I got home got to me. At first it had been exciting, but the long
hours I had to make some days were exhausting. The other vets had told me it
would get better once I graduated, but never really change. You always had to
keep up with the latest procedures, medicines and there would always be an
animal that got to you a bit more.

I studied hard and passed another round of exams. And as spring turned into
summer I passed another round of exams and got appointed a new residency. This
time I had to do research and write a paper. I had no clue what I would take up
as a subject, but I still had some time to decide. I said my goodbyes to all
the people I had been working with and felt sorry I had to leave.

A few weeks later most of the boys left to go on a holiday and in the end it
was just me and Henry left in the house. He had numerous jobs coming his way
ever since that talk with his father. In stead of pushing him towards law 
school his father had told him about a company which had hired him. And he had
talked to them about Henry and showed them some photos. That company had hired
him to do some work for them.

It was a warm summers night and the both of us sat in the backyard enjoying a
wine. "Ana," Henry asked with a break in his voice, "can I ask you a huge
favor?"

"What?"

"Well, this isn't easy but I need to do an assignment for school and I was
wondering if you would like to help me with it."

"What do I need to do?"

"That's the hard part. I would like you to model for me."

"Me? Model?" I started laughing, "Why me?"

"Well, I am a little shy and I would feel a little more comfortable if I knew
the model. I could hire one, but that just would feel weird to me."

"Why?"

He stared at his feet and said "It's a series of nudes I have to make."

"What?!"

"Yeah," he quickly turned to me and said "It's not porn or anything like that.
They are nudes, artistic photos of the female body."

"Wow, and when did you want to do this?"

"Soon, I want this getting over with."

"Wow, I really need to think about this."

"I understand. Forget it, I didn't even ask you. I will just hire someone."

It felt a little uncomfortable for a while and then I said "Let's just do it.
I'm in. When are we doing this?"

Henry looked elated and a little relieved. "Right now? We can go to my studio
and shoot some photos. It doesn't have to be long. I've got some ideas. I want
them to be black and white, not fully nudes. Are you sure?"

"Yes, I am. Let's just do this before I change my mind."

A few minutes later we got into my car and drove over to his studio. It was
located in an old industrial complex that had been made into all kinds of art
studios. His studio was located all the way in the back and when he unlocked
the door he let me in. It was filled with all kinds of lights, equipment and a
large space for a model to stand.

Henry walked up to the wall and pulled down a huge white canvas, which he
carefully laid down so it didn't show any wrinkles. He than walked out to
return with a large chair on a cart. We placed it on the white canvas and Henry
did his thing with a camera, adjusting the lighting and finally asked me to sit
down. He took some measurements with some kind of device and made some more
adjustments to the lights, the camera and finally stood up and said "I think
it's time."

Suddenly the nerves really hit me and I walked to a table, slowly taking of my
clothes. Henry didn't look at me while I undressed. Anxiously I returned to the
scene and sat down on the chair. Covering my breasts with one arm and my crutch
with the other. Henry gave me instructions how to sit and how to place my arms.
"Now turn away your face, like you are looking at something behind you."

A flash indicated he had taken a photo, he gave me some more instructions and
then said "No, this isn't it. Wait!" He disappeared and later returned with a
table. After he removed the chair, he pulled down a dark canvas carefully
placing it over the white one. He placed the table in the spot where the chair
had been and asked me to lay down on it, my back turned towards the camera.

The position I was in wasn't the most comfortable and I just waited for the
flashes of the lights. "Now turn around and place your arm on your side, the
other underneath your head. Yes, just like that. Hold it." I was fully aware my
breasts were now exposed to the camera and again the lights flashed as he took
a series of photos. "Now look straight into the camera, don't smile just look."
Another series of flashes.

After those he removed the table and just asked me to stand in all kinds of
poses, never anything sexual or something. The longer we worked together the
more fun I got and in the end I didn't mind being naked anymore. Henry didn't
look at me that way, he just looked at how the light hit my body and how he
could photograph me.

After about two hours he said "I think I've got it. Thank you so much, I really
appreciated it." I just stood there for a while and said "Well, maybe I will
ask for something in return one day." I walked over to my clothes and got
dressed while Henry was checking the photos on his computer. I just sat there
for a while before I said "Want to go home?"

Henry looked up from the screen and said "Oh yes, you drove me here. Let's go."
A few days later he showed me the series he wanted to turn in and they were
just beautiful. I loved them all especially the one where I stared straight
into the lens of the camera. "Can I have a copy of that one?" I asked him and
he said I could. Sure it was a photo of me naked, but he had placed my arm as
such that it covered my breasts and it wasn't sexual at all, it just was a
beautiful photo of me.

The next morning I got up very early, I wanted to go somewhere nice and quiet.
I had heard about this nature reserve an hours drive away. As I was getting
ready an idea popped into my head, I dismissed it with a giggle. Just as I
was about to leave I changed my mind and got everything I needed. When I
arrived at the parking lot near the reserve I was relieved to see there
weren't any cars there.

I got out of the car grabbing my bag from the seat next to me. I walked for
about ten or twenty minutes before I sat down in a somewhat secluded spot. I
checked if I could see anyone then took a deep breath, undressed and locked all
my clothes with the chained lock by putting the chain through the legs of my
pants and the arms of my shirt. When the padlock clicked there was just one
thing I could do to get them out, I had to walk back to my car totally naked. I
placed my clothes behind some bushes and checked if they were visible.

Then I took a deep breath and started walking back to the car. My nerves were
racing through my body and I felt my nipples getting hard. It was so exciting
and with every step I checked if I could see anybody. After a brisk walk I
reached the parking lot, this was all in the open and I took a deep breath
before I finished the final yards to my car. I bent down and got the keys from
behind the front wheel and quickly opened the door.

I reached for the keys that were laying on the chair and closed the car once
more. This time I took all the keys with me and made my way back to my clothes
and just as I felt a little more secure a man appeared in front of me. He was
walking his dog and I had nowhere to go but walk straight passed him. He smiled
and nodded when I was next to him and I acted like I didn't care. My heart was
throbbing and I felt like I could pass out at any moment.

I rushed forward and when I reached the spot where I had left my clothes my
hands were shaking so much I had a hard time unlocking them. I pulled the chain
out and got dressed as quickly as I could. I put the chain and lock back in the
bag, together with the keys. I walked on a little more and when I reached a
nice secluded spot I sat down to take a deep breath and calm my nerves.

At that moment I started to giggle uncontrollably and thought back to that
moment the man saw me. I tried to imagine his thoughts seeing a naked girl
walking up to him and I started laughing even more. I stayed there for quite
some time just to make sure that guy was gone. When I walked back I looked
everywhere if I could see him and sighed a breath of relieve when I sat down in
my car and drove off.

It was at that moment I felt the adrenaline wear off and I felt a little weak,
but I had loved the rush it had given me. I wanted to do it again and after a
short drive I found a new spot. Again I got out and walked for a while, got
undressed, locked my clothes and walked naked back to my car. This time I was
seen by a few people and I loved the rush it gave me. On my way back to my
clothes a man approached me and asked if he could take a photo with me and I
said yes. He took a selfie of me standing naked next to him, feeling his arm
around my waste made my nipples harden and then I continued to were my clothes
were. But this time I just grabbed the chain and walked back to the car, still
totally naked. Back in the car I got dressed and drove off.

Being seen naked had given me such a rush and I knew I would do it again
someday, but not that day. I had taken more than enough risk for one day and I
drove around for a while before I decided to go home again. By this time
Melissa had woken up and was sitting in the backyard.

I sat down next to her and said "Let's go to the Dormitory tonight. I want to
show it to you." Melissa agreed and that evening we got ready to party. When
Melissa walked into my room she was stunned to see me in the sexy outfit we had
purchased some time ago. "Wow," she said and turned around only to return
minute later wearing hers. We did our makeup and giggled in anticipation. We
put on our long coats and went out the door when the taxi arrived.

We were dropped off at the entrance and John greeted me by saying "So nice to
see you once again and who's this?" "She's with me," I replied, "this is
Melissa, my best friend." "Welcome to the Dormitory, Melissa" he said as he
opened the door. We walked in and saw there were quite a few people there. The
moment Travis saw me he walked up to us and I asked him if it was okay for us
to put our coats into the back. He nodded and said "Just knock before you
enter."

Just moments later we returned to the bar and sat down. We ordered wine and
Melissa was taking it all in. There was just one girl dancing on the bar at
that time and after a few more wine Melissa challenged me to get up on the bar.
I chuckled and I asked if I could. The girl opened the door and showed me the
steps where I could get up there. I took a few careful steps and started to
dance. Fully aware the men could look up my shirt and see my breasts.

One man waved with a 20 euro bull and I made my way over to him, he put the
bill underneath my belt and I got up again. Another man offered me money and
again I offered my belt to him. I kept on dancing for a while and in the end I
got down and showed Melissa the 80 euros I had collected. Not letting me get
the best of her Melissa got up on the bar and collected 10 euro more than me.
"Ha," she said with a smile, "10 more than you." I laughed and we got onto the
dance floor.


