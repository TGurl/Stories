# Starting Over
_an erotic tale by TransGirl_

_DISCLAIMER_

_Although I checked online for the correct names of streets and buildings I
took some 'artistic' freedoms in my story. Everything I write is pure fantasy
and any resemblance to anyone living or dead is purely coincidental._

## Introduction
It was devastating losing my husband the way I did. A drunk driver ignored a
red light and ended his life. We had only been married for five years when two
officers told me the worst news I would ever hear in my life. It was like the
earth swallowed me right there and then. One of the officers stayed with me
until my parents arrived and everything after that is a blur to me. I can't
remember the service, not even who were there. There were a lot of people and
it had been a lovely service as far as I am told.

All this was almost 8 months ago as I slowly crawled my way out of the cobwebs
in my head. I needed to breath again, to live again. Waking up from that mist
made me realize I was alone again, I had to push through it, I just had to
confront the pain.

The room was dark as I sat there on the couch. I didn't want to turn on the
lights as everything around me reminded me of him. In nearly total darkness I
stumbled my way to the bedroom to try to get some sleep. In my dreams I always
saw him, but somehow this time it was different. This time it was like he was
saying goodbye, he was letting me go. I can't explain it, it just really felt
like he was telling me to move on with my life and do the things I always
wanted to do.

The next morning I woke up feeling refreshed, you could even say free. It was
one of those times I could remember my dream and I whispered "Josh, it you can
hear me. Thank you for being in my life. I love you and I always will, but you
are right. I need to move on and I can't do that in this -- in our house. I
need to go. So again, thank you and I love you."

As soon as the real estate agent opened I was on the phone telling them I
wanted to sell the house. The made an appointment for that afternoon for an
appraisal, the next call was to my parents to tell them what I was doing.

"Yes mom, I'm sure. There is just to much of him in this house. I need to move
in order to live my life again. I'm not even thirty mom, I can't go on like
this." I said.

It didn't take long for the house to sell and I proceeded with selling anything
I could the furniture, his car and what I couldn't sell or wanted to keep I
gave to goodwill. What wanted to keep I stored at my parents place until I was
left with just my clothes and my car. After staying with them for a couple of
days until I had rented an apartment, I was ready to go. My car was packed with
the stuff I wanted to bring and was hugging my mother. She didn't want me to
go, but she understood why I had to. My father kept a brave face but I knew he
just hated it too. I got in my car, waved and drove off. Ahead was a 38 hour
drive to my new hometown, Portland, Oregon.

## Road trip
As I drove towards the rest if my life I was looking forward to it. I had flown
over there just a few days before and had bought an apartment. It was listed
for so long the previous owners almost immediately accepted my offer. The had
left the bed, the couch, the washer and dryer and some stools at the bar. I
loved the colors on the walls and all I needed to do was clean it, for the rest
it was ready to move in.

That was all good and well, first I had to get there. I had been driving for
almost four hours and parked at a diner for some food and rest. I was going to
enjoy this road trip and just make the best of it. I had stopped a few times to
take some photos of the ever changing landscape, but that was about it. I had
another four hours to go until I reached the hotel were I would spend the
night.

After lunch I got back in the car and put the water I had just bought in my bag
next to me. I looked at the road ahead of me, took a deep breath and started
the car. With every mile of road that I traveled it felt like whatever was
restricting me let go and I started to breath more easily. At a sightseeing
spot I parked the car and took a photo of the breathtaking landscape around me.
'Oh Josh, I wish you were here with me. I'm taking the road trip we've been
talking about for so long,' I thought and just moments later a butterfly landed
on my camera. It was like Josh was telling me he was with me and I felt a
blanket of love come over me, total and unconditional love. But this time it
didn't feel restricting, it felt more like he supported my decision and wanted
me to go and live the rest of my life.

I moved my finger and watched the butterfly fly off and whispered "Goodbye my
love. Thanks for being in my life." I whispered, got in my car and with renewed
energy I drove on until I reached the hotel. It wasn't much, but at least there
was a shower, a bed and a TV in the room. I had ordered room service and laid
on the bed watching some stupid series while I ate. I placed the cart in the
hallway afterwards and made my way down to the bar for a drink.

There were a few people sitting at the bar and I sat down on one of the
available stools. While I sat there enjoying my wine a man came up to me with
some stupid opening line. "Does that line usually work?" I asked him.

"Well, I don't know. It's the first time I used it, so you tell me." he
answered.

I giggled, at least he had a sense of humor. We talked for a while and I had
another glass or two. Before I knew it we were walking up to my room where we
started to kiss. I hadn't been with a man for so long and it was like my body
just had a mind of it's own. We undressed each other and he pushed me down on
the bed. I spread my legs and guided him inside my wet pussy. He fucked me hard
and I came multiple times. "Lay down," I whispered and got on top of him. I
rode him hard and when he said he was coming I whispered "Come inside me, come
inside my pussy. I want you to come inside. Oh yes, give it to me." He groaned
loudly as he exploded, sending his cum deep inside my willing cunt.

I rolled off him and giggled. "What?" he asked. "Nothing, I just realized that
the stupid opening really worked." I said. He started to laugh too and I took
his cock in my hand and looked him in the eyes. It didn't take him long to get
hard again and he got on top of me. "Oh yes, fuck me again," I whispered, "I
want to come all over that cock of yours." This time he came in my mouth and I
swallowed every drop of his cum. He took a quick shower, got dressed, thanked
me and left. I giggled, turned over and fell asleep.

The next morning I woke up feeling really guilty about what had happened the
night before. I had never picked someone up at a bar, not even when I was in
college. I always thought it to dangerous, there were these stories of it going
horribly wrong. But it wasn't that, I felt guilty towards Josh. I hadn't been
with anyone else since I had met him and we started dating. And even before
that the men I had been with I could count on one hand, three fingers actually.

Quickly I got up, took a shower, got dressed, checked out and drove off. I
wanted to leave that hotel behind me as quickly as possible. Luckily enough I
didn't see him in the lobby or the bar, no awkward moment there. But it had
felt good to feel loved again, even though it just had been sex. As I drove
towards my new home I vowed to never ever do something like that again.

On one of my moments of rest I stopped at another diner to have some lunch, as
I sat there waiting I could still feel his cock inside of me and I smiled
slightly, it did feel good to sit there amongst the locals having some
strangers cum drip out of me. I got up to go to the restroom, as I sat there I
took of my panties and put them in my purse. When I was done I straightened my
skirt and walked out to my table. 'What are you doing?' I thought, but it was
just too much fun. A few tables from me an elderly man sat down and he tipped
his hat as he sat down. On a whim I did a Sharon Stone and crossed my legs the
other way. I knew he was watching me as I did it, but I still don't know if he
saw anything.

At some point I got off the highway as I wanted to drive through the towns on
the last stretch. I wanted to see the surroundings of where I was going to live
and it was just to nice to not drive through the mountains. I knew it would
make my trip take a little longer but I didn't care, it was just more relaxing
than the endless straight roads of the highway. After another few hours it
became dark again and I stopped to look for a hotel nearby on my phone.

There was one only a few miles ahead. The hotel was in the middle of the
mountains and it was just so beautiful there. I had breathed a sigh of relief
when the girl said she still had a room available. The room had a nice view
over the mountains and I sat on the small balcony for a while, before I went
down to the restaurant for dinner. Across from me a man who clearly was a
businessman looked at me and smiled. We both were about to eat alone and he got
up and asked if he could join me.

After dinner we ended up in my room where he sat down on the couch and I was on
my knees sucking his cock. I took off my shirt and straddled him, guiding his
big black cock inside me. I could feel myself stretch as I sat down and moaned
loudly. Once I felt his balls against my ass I rested for a moment so I could
adjust. Then I started riding him making myself come multiple times. He grabbed
my breasts and squeezed them. "Oh yes," I moaned, "fuck that white whore pussy.
Oh yes, I'm coming. Oh my God, this feels so good." I came hard and for the
first time in my life I squirted. His chest was all wet from my fluids and he
laughed.

He then got up and pulled me to the balcony. He bent me over and plunged his
cock deep inside me. Just realizing I was with another stranger and on a
balcony where anyone could see me, made me come even harder. He just kept on
plowing me until I could feel him twitch and throb inside me. "I'm coming," he
moaned and I said "Come inside me, fill me up. I want you to give me that cum,
oh yes, come inside me. He screamed as he unloaded his cum, sending it deep
inside my cum hungry pussy.

As he pulled out of me I could feel it gush out and I started to giggle. We
went inside quickly and we sat down on the couch. As we sat there I played with
my pussy a little and without warning he got on top of me again. "Oh yes," I
giggled, "Oh yes fuck me again. Fuck me hard this time, I want my pussy to hurt
tomorrow." He slammed his dick as deep as it would go and just a few minutes
later he send another load as deep as it would go.

This time he stayed inside me for a few minutes while we kissed. This time he
got dressed after he pulled out, threw me a couple of ten dollar bills and said
"If you really are a white whore then I need to pay for your services," with
that slight insult he left my room. I collected the money, it was 40 dollars,
and giggled. Fully well knowing I hadn't kept my promise to myself I took a
shower, cleaned up my crutch a little and went to sleep. The next morning I
would drive the last stretch to my new apartment.

## The rest of my life
As soon as I arrived I called my parents. They were relieved to hear it and
said they would come over soon. They hadn't seen my apartment besides the
photos taken by the real estate agent. I made the bed with the linens I had
brought with me and walked through the almost empty apartment. For the next few
days I had to shop for furniture, pots and pans and everything else I needed.

I spent some time reading the manual for the washing machine and did my first
laundry. Putting my stuff away didn't take me that long and I just laid down on
the couch, when a serious attack of guilt came over me. I felt like I had
cheated on Josh and started to cry. It was almost to hard to stop but somehow
deep inside me I knew I had needed it to happen, to mark where my previous life
had stopped and the new one began. When my tears dried I looked at my finger
and took off my wedding ring. "I don't need that anymore," I said to myself,
"You've clearly shown you're moving on." I held the ring in my hand and looked
up. "I will keep it," I whispered, "but I just can't wear it anymore Josh." I
went into my bedroom and placed the ring in my beauty case, closing it felt
like I was starting a new chapter for real.

Over the next few days the guilt subsided slowly and I spent most of my days
looking for furniture and everything else I needed. I found some nice things
and a few weeks later everything was the way I wanted it to be. On the walls I
had strung a string of led lights that could change color, there were small
tables with plants on them and I had a nice photo I took of the mountains
enlarged to hang above the fire place. It started to feel like home.

Every morning I stepped on my balcony to look at the view over the harbor to
enjoy my morning latte. I was lucky the company I worked for had an office in
Portland so I was able to transfer easily. He had said he didn't want to let me
go, but he understood why I wanted to. The new office was on the other side of
town and I had visited it once years ago. During that visit I fell in love with
Portland and I had told Josh multiple times I wanted to live there. Now I
finally did, albeit without him.

There were still a couple of days before I had to start working again so I
decided to make the most of it. I drove over to the office a couple of times
just to get to know the route. On one of those test drives I stopped at a strip
mall nearby and had my nails done in a salon there. On the advice of the girl
who helped me I wanted to go to 5th avenue to explore town. "Just park your car
nearby and take public transport," she said, "It's easier and cheaper."

Walking those streets was just so nice, we had lived in the suburbs for so long
it felt good to be among people again. I did some window shopping and ended up
strolling through Pioneer Place, a very nice mall there. Unintended I ended up
with some bags of new clothes and a pair of nice high heels I stumbled upon.
'Darn sales,' I thought. On the second floor I found a Soma which reminded me I
had to get a new bra. Once inside I also checked the lingerie they had and at
the checkout I had two new bra's, three sets of lingerie and I nice soft
slightly translucent negligee. As I waited for the total amount my eyes fell on
a box with round things. I got one of them and read they were nipple stickers.
As they were just a dollar for ten I got five bags of them. The woman looked at
me and I said "Well, a girl needs some fun now and again." and I winked. She
laughed and said "You can say that again. That'll be 167 dollars and 29 cents."
I handed her my credit card and a few minutes later I left the store with
another two bags in my hands.

'Okay,' I thought to myself, 'just a latte and then home or you will buy
everything here.' I sat down at a coffee place and ordered a latte when one of
the waitresses asked me what I wanted to have. I felt good about myself and
enjoyed sitting there drinking my coffee. Having finished my latte I got up,
stepped into a tram that took me back to my car and drove home.

A neighbor in the lobby said "So you've found 5th avenue, now did you?" She was
an older woman and we talked for a while. "So where you're from?" she asked at
some point and I explained where I was from and why I had moved. "Oh I'm sorry
to hear that," she said, "If you want to talk sometime my door is open. I don't
get many visitors anymore, they all passed away and my children moved too far
away." I promised her I would come by some day as she lived only a few
apartments from me.

Once back in my apartment I washed my new clothes and put the other things in
my underwear drawer. "Why did I buy these?" I thought while I folded them to
put them away. I checked the time, made some dinner and spent the evening
watching a movie. The next day I had to start work and I wanted to go to bed
early.

## The new boss
I arrived at the new office early and walked inside. To my left was the front
desk receptionist busy answering calls, to my right were some sofas where you
could wait and in the back was a security guard. I waited for the woman to be
ready for me and she smiled a couple of times saying "So sorry, I don't know
what is happening." I said it was okay and waited patiently. Another woman
walked in and got behind the desk. She put on her name tag and asked me how she
could help me.

"Yes, thank you. I'm Laura Davis and I'm transferring from the home office. I
was told to go here first."

"Ah yes, Laura Davis. It's here somewhere, Diana where are the new employee
papers? Oh there they are, now let me see Davis, Laura. Ah here they are. Just
sign these and hand them over to Brian over there. He will make your pass and
then you can go up to the third floor. Mr Andrews is expecting you."

I thanked her, sat down at a table to go over the papers she had given me and
walked over to Brian. "Good morning Brian, I'm Laura and I had to give you
this?"

"Good morning, um Miss Davis. Yes, just come and sit here for the photo."

"Please, call me Laura. Miss Davis makes me feel old."

Brian laughed and said "No can do, Miss Davis. I was brought up right by my
mother. She always told me to be respectful. Yes, now smile." he took the photo
and sat down at his desk again. Just a few minutes later a card was printed
with my credentials and photo. "Now," he said, "just scan the code at the gates
and they will open. Have a nice day, Miss Davis."

"Laura, please." I smiled and wished him the same. During the time I worked
there it became a bit of a meme between us and he told me one time during
coffee break I was the only executive who ever talked to him.

Feeling a little anxious I knocked on the open door and peeked inside. Behind
his desk was my new boss, Ben Davenport, the CEO of the Portland office. "Ah,
Laura!" he said, "Nice to see you again? Getting settled?"

"Yes, thank you. Portland is just so beautiful, totally different to where I'm
from."

"You can say that again," he replied, "I'm always glad I can go back here when
I'm in the home office. Oh yes, Glenn says hi and some woman in the restaurant
made sure I tell you you still owe her 36 dollars."

I chuckled and said "Oh yes Barbara, she's a hoot."

Ben got a bit more serious and said "Now, I've spoken to Glenn about what you
were going to do here and there is something we need your help with." We talked
about it for almost an hour after which I said "Well, I need to get up to speed
with local and state laws first, but this looks like a good job to dive into.
It's a bit bigger than I expected but it shouldn't be a problem."

"I didn't expect otherwise," Ben replied, "and Charlie or Britt can always
assist you. Just ask them if you need anything. If you really don't know what
to do, my door is always open. Now let me show you your office."

We walked out and just a few doors down was my new office. It had a somewhat
nice view over the area and it was almost empty besides a small couch and my
desk. "You can call 1311 for a new chair and they will bring one up. You can
get your laptop one floor down, it should be ready by now. And please dress
this up a little, I can't stand empty offices." Just as he was about to leave
he said "Oh yes, Charlie and Britt are across the hall to the right, you can't
miss them."

I dialed 1311 and asked if they could bring me a chair. Just a few minutes
later they rolled one in, still in plastic. The adjusted the chair so I could
sit well and I thanked them as they left. One floor down at the IT department I
got my laptop and on my way back I stopped to meet Charlie and Britt. I was a
bit surprised to see Charlie was a girl and she said she had that effect on
people.

We talked for a while before I went back to my office. As I entered I thought
'I really need to dress this up' and sat down. After reading the instructions I
got my mail working and one of the first I received was from Ben welcoming me
to the office. The rest of the day I spent getting to know everybody and
although I tried to act normal to them I was the new head honcho and the top
lawyer from the home office. A feeling I vowed to change real soon. Sure I was
one of the executives, but I was also just another human being.

I met with some of the other lawyers and got a crash course of local and state
laws to know where they were different from what I was used to. I knew it would
take some time before I would see the inside of a court again, but I knew that
before I accepted the new position. At then end of the day I got my schedule
for evening classes at the University of Oregon. They offered crash coursed for
active bar members of other states totally designed to help you pass the bar as
quickly as possible.

For the next few months my schedule existed of going to work, class, going home
and doing it all over the next day. It was something I just had to do and when
I finally passed the bar having all that free time in the evenings felt
strange. I was used to working hard and making long hours. The past few months
had made me feel wanted again.

One morning when I arrived at work Ben rushed up to me and asked "Do you have a
travel bag?" I asked him why and he explained to me what had happened. One of
our projects was shut down suddenly and we had to go to Seattle for a few days.

"Just get some stuff and follow he there." He gave me the address of the hotel
where he had booked rooms and went on his way. A few hours later I arrived at
the hotel and checked in. Ben had booked two rooms with a shared door. As soon
as he knew I was in my room he knocked on it before he entered. "I just thought
it might be easier this way. We sat down to talk about the case which he would
be first chair on.

"Then why am I here?" I asked.

"Because I need you. We need to show we mean business." he replied.

We spent a few hours on the case and ordered room service so we could keep
working on the case. It was almost midnight when Ben said "I think we're
ready." He leaned back, yawned and said "It's nice being a lawyer again."

"Yes," I said, "that's why I am one. You still haven't told me why you are
taking this case. I really want to know."

"I think you're entitled to an explanation. This project is my child, I started
it and when Glenn asked me to be CEO I just couldn't drop it. But I had to and
now I just can't stand by to see it go to hell, I have to do something."

"Sure, but you could have done the same assisting me."

"I know, but see it as my last stance. One last case before I stop being a
lawyer. In just a few weeks my bar card expires and I can't practice law
anymore."

"Ah, now it proverbial cat comes out of the bag. I understand and I will be
happy to assist you."

Ben laughed and leaned forward. "I know the case would be in good hands, I just
couldn't give it up." As he leaned forward I felt a tension between us and
shrugged away. He was married and my boss.

"It's late," I said, "Court is early tomorrow."

Ben got up, collected the papers and said "Yes, you're right. Good night,
Laura. I'll see you tomorrow."

He closed the door and I got ready to go to bed. As I laid there I just
couldn't catch my sleep and an hour later I heard the door open. Ben got into
bed with me and as he laid there staring at me I took off my gown, got on top
of him and guided him inside me. "Oh yes Ben," I moaned, "I wanted this all
night, I wanted you to just take me." Ben's hands went all over my body as I
rode him and shortly after he rolled me on my back and plowed his dick deep
inside my wet pussy. "Oh Laura," he panted, "I wanted to fuck you ever since
you walked into my office. That's why I asked you to come."

He fucked me so hard and good I came multiple times and when he was ready he
came all over my body. His cum went everywhere and I giggled as I felt his warm
fluids land on my sensitive skin. He rolled off me and a few minuted later he
got me a towel from the bathroom. When I was clean I crawled into his arms and
said "This was nice, but what will your wife say?"

"Nothing," he said, "we've got an open marriage. She sees other men too. We've
become closer than we've ever been since we started swinging. All we want is
for us to be open and honest about it. I told her about you weeks ago and she
told me to take my chances."

"Oh," I said, "is that the truth?" And I rolled on top of him, guiding his cock
inside me again. "Then show me how much you want me. And this time I want you
to come inside me. Fill that pussy up with your cum, counselor. Make me
scream."

I started moving my hips and felt him getting harder inside me. It didn't take
long for me to come again and when he rolled my on my back again he started
pounding me so hard and when it was time I screamed "Oh yes Ben, come inside
me. Fill me up!" I could feel his penis twitch as he exploded inside my pussy,
feeling him come made me come once more. Totally exhausted we laid down and
fell asleep.

The next morning I woke up to him sliding his cock inside my pussy and I smiled
as I opened my eyes. "Oh, that's a nice way to wake up," I said and put my
hands on his ass to pull him in. "Oh yes, fuck me." I whispered, "fill me up
again, I want you to come inside me every time you fuck me. And you can fuck me
any time, any place." Ben pounded hard until he came after which we got up and
showered together.

In court we acted professionally and he was just brilliant. After the judge
dismissed the case and we had won we celebrated in a bar. As we were sitting in
a booth he placed his hand on my pussy and slid a finger inside me. I started
moaning softy and whispered "Let's go back to the hotel." And so we did,
undressing as we entered the room. We had sex multiple times that evening and
all during the night. As promised he came inside me every single time.

Once we were back in the office we acted like nothing had changed, but some
late nights weren't just filled with working on cases so to say. But as long as
we weren't alone we acted like was expected of us.

One day he invited me over for dinner at his house and I was really anxious of
going there to meet his wife. She was just so friendly and open I immediately
liked her. Before we even had dinner I was laying on the table, with my legs
spread and Ben deep inside me. His wife was sucking my breasts and when Ben had
unloaded inside me, she got on the table and pressed her wet pussy against
mine. Grinding against her mixing the mix of Ben's and my fluids with hers made
me come so hard I almost fainted.

During dinner I got up, rolled up my skirt and straddled Ben once more, while
his wife was watching I fucked her husband until he came once more. I leaned
back on the table and showed her how her husbands cum was dripping out of me
and I started rubbing my clit until I came. Totally satisfied I went home again
only to hear the following morning Ben had passed away from a heart attack.

I went over to their house and comforted his wife. His death meant I had to
step up as temporary CEO and to keep things rolling. The service was really
nice and not long after his widow moved in with one of her lovers. Just a few
months later they moved away and I never saw her again. Ben's death meant I ha
to step up as temporary CEO to keep things rolling. It took Glenn a couple of
weeks to find someone new. When she arrived she made so many changes I just
couldn't work there anymore and I quit. Without Ben there it just wasn't the
same anymore and I decided to start my own little law firm.

Another chapter was about to start.

## Laura's Law
Starting my own company wasn't that easy. I had spoken with someone at the
Portland Business Alliance and in the end he told me what I should do and
pointed me to the website of the state of Oregon. "They have an excellent
checklist there and some references for further help." I thanked him for his
time and information.

One of the first things I had to do was my research, did Portland really need
another lawyer setting up her own shop? On top of that I wasn't a criminal
lawyer I did civil law and there were enough of those around I discovered. Did
I really want to fish in diluted waters? I wasn't sure I was up for that and
tried to find something else to do.

Even though my bank account gave me enough time and space it wasn't unlimited
so I had to find something and started working as a consultant for different
firms and companies. That's when I noticed they were really looking for
consultants with knowledge and experience. So my law firm became a consultancy
of one, me. Sure this meant I never had my own office anymore, but it also
meant I could walk away whenever I thought it was necessary.

_Laura's Law Consultancy, LLC_ was born and I thought it was a nice pun. I
didn't expect the state to allow it, but they did. The woman who did my
paperwork even called to say she liked it. My little consultancy was a limited
liability company therefore my personal assets were protected from any
litigation against the company that might arise. Luckily for me it never did.

Being my own boss also meant I could regulate my own hours and work when I
wanted to, not because it was expected of me. Of course when I did work for
someone I gave it my all, but I also had the freedom to just say no. Soon I
learned which companies I did want to work for and which I needed to avoid at
all costs. There was one where I walked away in the first hour I was contracted
by them, I didn't even bill that hour. When they sued me the judge just threw
it out and said "Miss Davis, I applaud your stance to keep to your principals.
Case dismissed." Not soon after the exposure bankrupted them.

It didn't take long for my former employer to contact me for a job. It felt
strange at first returning to the company I had worked for for so long, but it
was nice seeing my former co-workers again. The extra bonus was they had to
pay me more than the ever did when I worked for them. Cynthia the new CEO had
increased their business by 15%, which was quite the accomplishment, still
there was something about her that irritated me. But I did the job and won
their case, which was all she wanted from me.

As I sat in the lounge waiting for her to sign my declaration Charlie sat down
next to me. "Do you need an assistant? I really need to get out of here." she
said. I apologized and she looked a little disappointed. "Look," she whispered,
"I know about you and Ben. Everybody knows. We just respect you too much as a
lawyer so nobody really cares. You just have to know, Cynthia knows too and if
you hadn't left she would have fired you. Just so you know."

Although I was startled by that revelation I said "Thanks Charlie, he was a
good guy and I loved him. We all did. Thanks for letting me know."

Charlie got up and whispered "I would have done him in a heartbeat, all he had
to do was ask.". With that said she walked away.

Cynthia had signed the papers and her assistant handed them to me. "We will not
require your services in the future," she said as she handed me the papers. I
thanked her and on my way out I stopped at Cynthia's office. She sat at her
desk and I said "You might think you don't need me anymore, but I know I'm a
better lawyer than anyone here. So I think I will be seeing you again. Have a
nice day, Cynthia. Oh, by the way, Glenn says hi. He just called me and I will
be working for them for the next couple of weeks. Looks like something isn't
quite right with the books since you took over."

With a smile on my face I walked out the office, only to return to tell
Cynthia she could pack her bags. "It's like this," I said, "according to
accounting you gave them permission to do this. And someone kept the evidence.
You should be happy we're not filing charges. You can even say you are stepping
down on your own. Glenn doesn't care and neither do I."

Within weeks the Portland office was closed and I felt sorry for the people
like Charlie and Britt. They didn't deserve to lose their jobs over this. Glenn
just had to take measures as business had declined. A week or so later I bumped
into Charlie and asked her how she was doing. "Oh, I'm alright," she said, "my
husband has a good job and I'm doing odds and ends." I told her how sorry I
felt for what had happened and she said "It wasn't your fault. You just
uncovered a fraud. She had embezzled thousands of dollars, you did your job.
What I don't understand is why you didn't sue her."

"That was Glenn's idea. If it were up to me we would have sued her for
everything she owned." I said.

Charlie chuckled saying "That's the Laura I know." I laughed and we went our
separate ways.

For the next year I worked from time to time and at one job I met Noah. We got
along really well and after the job we started dating. We didn't jump into bed
right away, he wanted to take it slow. We went on hikes through the mountains,
sat on my balcony watching the boats sail by and it was just so special to
really get to know him. He liked photography and he took some really nice
pictures of me. I thought I was falling for him big time.

During the time we dated we both came to the realization it wasn't meant to be,
we weren't more than just friends. The best of friends, but nothing more than
that. Not long after he sat on my couch crying. "I think I know why I can't
have a steady relationship with a woman." he turned to me and said "Laura, I
think I'm gay."

"Are you?" I asked not really knowing how to respond.

"Yes," he said, "I met someone last night and -- well -- we ended up in bed."

"Wow," I replied, "how was it?"

"It was the best Laura. Feeling him, kissing him, it all just felt so right."

"Noah, you are gay. And I don't care. I like you Noah, just the way you are."

He looked at me and said "I was so worried you would be angry. I know you felt
something for me that I couldn't answer. I just couldn't lie to you like I did
with the other girls."

"I'm flattered to hear you say that and thank you for not leading me on. I
respect that and my door is always open. Now tell me about him. What's he like?
What color eyes does he have? And -- um -- is he well shaped down there?"

Noah blushed and asked "Is that girl talk? Do girls really talk about that?"

"Hey," I said, "you're on my side now. I love talking about boys and now I can
do that with you too."

Noah laughed and told me all about his date from the previous night, every
filthy detail. "Oh he felt so good when he entered me. The moment he pushed his
dick inside me, it just felt so right." he said. I hugged him and told him how
happy I was for him.

Over the next few months Noah and I became closer then we'd ever been and
supported him when he quit his job to become a freelance photographer. During
one of our hikes he suddenly stopped saying "Oh my Lord, this is just
beautiful. Laura, please stand over there and lift your hair with your hands.
Like that yes, an smile like you just had the best lay ever." I did as he told
and he took a lot of photos of me.

"Remember our hike the other day," he said a few days later, "Well --" He
handed me a magazine and said "Turn to page 32." I did and saw the photo he had
taken of me in an ad for a local wellness company.

"What?" I uttered.

"Yeah, they bought the rights and this is for you." He handed me an envelope
with 3000 dollars. "That's your cut, 30%." he said. I did a quick calculation
in my head and stuttered "10,000 dollars? You sold it for 10,000 dollars?"

He nodded and said "Yes, I had some offers for it and the bid the most." He
opened my laptop and opened a site where photographers offered their work.
After two clicks he showed me his profile. He had offered loads of his photos
and just the one of me, which was the only one he had sold until then.

"I think I've found my muse and I think we should see were this goes." he said.

"Do you really think so?"

"Yes, they even asked me who the model was and which agency the could contact
for more information. I told them who you were and they said to tell you to
find an agency as soon as possible."

"What? Me a model? No way."

"Laura," he said in a serious voice, "Didn't you tell me you were getting a
little tired of the law. Of just sitting at your desk reading paper after
paper. Didn't you say you wanted to do something a little more exciting?"

"Yes, but modeling?"

"Oh like they don't have brains. I worked with a girl the other day and she's
putting herself through college by modeling. And she's going to be a rocket
scientist one day or at least that's what I understood. Aeronautics is
rockets, right?"

"No airplanes, but it's almost the same." I laughed and he did have a point.
Not all models were brainless puppets who just were pretty, or at least some of
them weren't.

"Well, I talked to Neil the other day --"

"Neil?" I interrupted him, "Are you two getting serious?" I clapped in my hands
and hopped on my chair.

"Um, we might be. Back to what I was saying. He told me he knows someone who
wants to start her own agency, she works at one now and she just wants to be
her own boss. She's really good at it and I could call her to come over it you
want me too. I think it would be nice to have a group or startups together."

I thought about it and said "Sure, call her. Let's see where this goes."

Noah jumped up from excitement, got his phone and walked into my bedroom. I
thought it a little odd, but Noah was Noah and this was what you could expect
from him. After about ten minutes he came back and said "She'll be here in
about half an hour. This is so exciting."

"It sure is," I replied, "But about Neil and you. Tell me, is it getting
serious? I really want to know." Noah told me all about them and how good it
felt. "Yeah, I might even introduce him to my mother."

"Oh, you _are_ getting serious." I cheered. It didn't take long before my
doorbell rang and I pressed the button of the intercom. A girl said "Yes, hi.
Noah called me? Am I at the right address?"

"Charlie? Is that you? Come on in." I pressed the buzzer to open the door and a
few minutes later Charlie walked in.

"You two know each other?" Noah asked surprised.

"Yes, we used to work together. I never knew you were into this, Charlie. What
a nice surprise."

Charlie sat down and told how she did management as a hobby and how she got a
job at an agency. But they treated their models so she had decided she wanted
to try and start one of her own. Her husband full supported her in her
endeavors. She then told how she knew a lot of people in the business and how
she was helping her niece model her way through college.

"Wait a minute," I said, "Is that the same girl you were talking about Noah?"

Noah blushed and nodded "I had to reel you in with a good story. And you have
to admit it _is_ a really good story."

Charlie laid out her plans for me and I offered her my services as a lawyer to
take a look at the legal stuff. And thus _Silvia's List_ was born. Charlie
explained the name to me "I really want to honor my mom, she always wanted to
be an actress but she never had the chance. When she passed I promised her I
would always follow my dreams. And this was my dream, so I would love to honor
her this way."

Both Noah and I agreed as it would be her agency, not ours. We started working
on the business plan, registered the company name and did everything necessary
to start business for real. A friend of Charlie had designed a beautiful
website and one of the features of the company was they had on in-house
photographer.

Charlie did a press release stating her company had just signed a major
account: the girl from the wellness ad. She had done her research and had
learned the 10,000 dollar investment had a six figure return for the spa. I was
amazed to see a small article in the entertainment section of the newspaper
talking about how a small startup agency had signed their first major model. I
couldn't believe they were talking about me.

Within days the spa contacted us for another photo shoot. This time at the spa
itself and the three of us went over there to talk about the details. Charlie
did her magic and I sat down with a smile, although we were just a small agency
Charlie played hardball and I saw a side of her I didn't expect from such a
small woman. But she got the deal and I was so happy when I saw my bank
account.

I send my parents a picture of my face on the local buses and benches. It was a
large campaign and I was recognized as the spa-girl for a while. We had some
other assignments after and Charlie signed some new models. Her list grew
steadily and she always treated her models like she said she would, fairly.

But soon my face was replaced with a younger one and my modeling days were all
but over. I started to return to my law background when Charlie called she had
another gig for me. "But," she said, "I don't really know if it's something you
want to do." She explained the gig was for a magazine aimed at men and it would
be a sensual thing. "No nudity, just really really sensual. Like you in a bed
with just a silk sheet covering you."

"Oh my," I ousted, "wow, I will have to think about that. When do you need an
answer?"

"Today?" Charlie said, "the shoot is this weekend and they offered us a very
good deal. But I said I would have to ask you first."

"I don't know Charlie," I replied, "Me laying in a bed with just a sheet
covering me? I don't know."

"Would it help if I said Noah will take the photos? And it will be just him?"

"That would make it a little easier, maybe. But do they really want me?"

"Yes, they specifically asked for you."

"I'm flattered, but I couldn't be a lawyer anymore if I do this. No judge would
take me seriously after this. You're asking quite a lot."

"I know, but how many cases have you done lately. Almost none, you hardly talk
about it anymore. You've already said goodbye, you just don't know it yet."

Hearing her speak the words out loud made me realize she was right. I hadn't
taken any jobs for almost two months now and I didn't even miss it. I had
filled my days with the odd job for charlie and had played the mother in a
shoot for a diner, the laughing aunt at a birthday party and things like that.
This was on a whole different level though.

"Let me call you back," I said, "I need to talk to my mom about this."

I called my mother and told her about the offer. "Well," she said, "at least
you're not naked. And who knows the photos might be very classy. Plus it's a
national magazine, it might give you more jobs in the future."

"Don't you mind it's me in that photo?" I asked her.

"No, if they are nice photos I would be proud to show them to anybody who wants
to see it. My daughter in a national magazine? I couldn't be more proud, except
for the days you were born, graduated college and got married." With that vote
of confidence I called Charlie and said I would do it.

When the day arrived I was anxious all morning and really nervous when I drove
to where the shoot would be. I was happy it would only be Noah and me, but
still I had to get naked in front of him. 'At least he's gay,' I thought.

My hands were shaking when I pressed the doorbell and Noah opened the door. I
made it up to the third floor and entered his studio. It was filled to the rim
with equipment and to my left I saw a fully lit bed. Noah noticed me looking
at it and he said "Don't worry. I won't look." I chuckled and asked what he
wanted me to do.

"They've explained to me what they want and we're just shooting some tests
today. When they are happy with the results we will do this one more time for
real." he said, "We're just going to have some fun today."

He showed me were I could undress and with just a robe I returned a few minutes
later. I was surprised to see a girl there and he said "This is Nala, she will
do your makeup and then she will leave."

Nala said "Hi, pleased to meet you. I understand this is your first time and I
fully respect you not wanting me to be here."

"Oh that's alright," I replied, "you can stay. It's not like you haven't seen
it all before. And Noah is gay so that's a comfort too."

Noah stared at me and said "Hey, that was almost insulting. If I didn't like
you so much --"

"You would what?" I replied

"Nothing, you're still a lawyer and I've seen what you can do. So I will not
finish that sentence. I plead the 5th."

"I'm in civil law, there is no 5th."

Nala laughed and asked "Are you two always like this?"

I nodded and said "Yes, he's always a pain in the ass. Oh, did that hurt you?"

Noah chuckled and said "No, it felt rather nice. Thank you."

The ice was broken and I laid down on the bed, took off my robe under the sheet
and Noah draped it around me as he saw fit. He took a lot of photos asking me
to place my arm like this or my hands like that. "Now stare sensually into the
camera, like that yes. Beautiful, now look at me like you want to seduce me. Oh
yes, wonderful. They will like this a lot."

As I moved under the sheet it slit down a bit, just about covering my nipples
and as it went down it was over my left leg just covering my crutch. I wanted
to adjust it when Noah said "No leave it, put our right arm over our head, like
that yes. Look into the camera. This is the money shot, Laura. Turn your
shoulders a little more towards me --"

My right nipple peeped from under the sheet and a flash indicated Noah had made
his shot. I knew my nipple had been visible and somehow it excited me, it felt
good to be photographed like this. But I wasn't going to tell Noah that, in
stead I pulled the sheet back and said "Oh no, you can't use that one. Noah
promise me."

Noah looked at me and said "You can hardly see. Come, let's check them on the
computer." Nala handed me my robe and under the sheet I put it on. When Noah
opened the last one I shouted "See, you can clearly see it. No Noah, I want you
to delete that one. Right now."

Nala hadn't said a word until then "Um, might I say something? I think the last
one is very beautiful. And I agree with Noah, it's hardly visible and it's a
really sensual photo. I think it's the best one. I'm getting aroused by looking
at it and I'm totally not into girls."

I stared at her and if looks could kill, but I softened up and said "Do you
really think so?" Nala nodded and said "Yes, I really do."

A few weeks later I opened the magazine and there it was accompanying a story
about sensual women. It was spread out over two pages and if you looked closely
you could see my nipple. My mother called the moment she saw the photo. "Laura,
did it have to be like that?"

"What?"

"Did it have to be such a beautiful photo? My Lord Laura, you are so beautiful
in it. You're like Cinderella awakening after being kissed by her true love."

"Didn't you see the nipple?" I asked her.

"What nipple? Oh my, now you told me." She burst into laughter and said "Okay,
an explicit Cinderella."

Right after that photo appeared nationwide I got more offers for shoots like
that. I posed in bikinis, very revealing dresses or just a towel. I got used to
being naked in front of people as they all were there to do a job. And I do
have to say, the money made up for a whole lot of it.

As the shoots got more frequent I started to have fun with it and loved I only
had to work for a few hours a week to make the same as I did as a lawyer
working full time. I just didn't know where it would end, yet.

## Going for it
My photos appeared in several men's magazines and there even was a fan club of
some sorts. I couldn't believe what I read when I visited their site, I was
flattered and a bit disturbed by some of the fantasies I read.

Noah became more than just my photographer, he became my personal assistant too
as we traveled the world to go to photo shoots. There was a particularly sexy
one of me underneath a waterfall, where I covered my breasts with my arms
looking sensually into the camera. All the photographers I worked with said it
was my eyes that made the photos work. The fact I was naked was just a bonus,
they said. My mother had gotten used to seeing me like that in photos and was
just happy I was doing something I really liked.

I send her photos of everywhere I went and she was just jealous I got to see
all those beautiful countries. When I got an offer I couldn't refuse I called
her to ask if she wanted to come with me. Noah couldn't come this time and I
really didn't want to fly alone.

"Where are we going?" she asked without wasting a second.

"New Zealand, mom. The country you always wanted to visit."

"New Zealand? You mean that? Can we --"

"Yes mom, we can visit Aunt Ruby."

Ruby was my mothers sister who had moved there almost 20 years ago. They hadn't
seen each other in over 15 years. "But don't tell her," I said, "Let us
surprise her."

A few days later we made the 20 hour flight to Auckland, New Zealand with just
one stop at LAX. Completely worn out we went to our hotel and crashed. I woke
up the next morning to find my mother happily down in the restaurant enjoying a
cup of coffee. "Oh good, you're awake. It's so beautiful here, Laura. I've
asked and we could rent a car to drive to Ruby. That way we can see the country
a little. I would love that." She looked so happy and I melted.

"Sure, I said. But you know they drive on the left side, don't you?"

"That's why I won't be driving, dear."

We had breakfast and could spend the rest of the day sightseeing the city. I
was so totally different from what we were used to and we loved every second.

The next day I had to work and my mother insisted to come. When we arrived I
introduced her and sat down at makeup. "Are you sure you want to see this?" I
said as I got out of the dressing room. My mother nodded and I could see she
was a little nervous. We walked to the area where the shoot was and Phil, the
photographer told me what he wanted me to do.

I took my place and revealed the micro bikini I was wearing and posed for the
camera. The triangles of my top just covered my areolae and I stared sensually
in the camera. One of the assistants sprayed water over me with a hose and the
fabric got a bit more translucent. "Oh beautiful," Phil shouted, "more water,
yes, play with the water Laura. Have some fun with it. Yes, nice."

After that series I dried myself and asked my mother what she thought. "If I
were a little younger," she said, "I might have like it too." She hugged me and
said "It's all okay, honey. I love you no matter what."

I got ready for the next series which would have a little surprise for my
mother. After another round of make up, I walked over to the pool and jumped
in. I leaned on the edge as I looked into the camera I bounced up and down a
few times, went under water and got back up with my head tilted backwards. Phil
kept taking photos and just let me have some fun. "Good one, Laura. Very nice,
now go to the middle of the pool and do the same a few times more."

I swam to the middle, went deep underwater and pushed myself up with everything
I had. I raised up until my waist from the water and I could hear my mother
gasp. This time I was topless and Phil took a series of photos. I got out of
the water and laid on the edge, looking sensually into the camera. Then I sat
up, my legs crossed, holding my breasts as I stared straight into the camera.

It was my first naked shoot and I was so happy my mother was there to witness
it. I would have hated if I had kept it a secret from her. After I laid down on
a chair in the burning sun, I held a string of my bottom in between my fingers,
with every shot I pulled it a little further. After almost 20 shots I had the
bottoms in my hand while I looked into the camera. My legs were still crossed
by I was fully naked.

I looked at my mother and saw her smile at me. She gave a little nod and I
opened my legs, exposing my pussy to the camera. Phil bent down to take a good
shot and with my fingers I spread my lips a little. Phil took a few close up
shots and I sat down on my hands and knees for a few more shots. When all was
done I had completed my first shoot for Scoreland.

After I got dressed again, the production manager handed me my check and when I
showed it to my mom she as astounded. "25,000 dollars for just 5 hours of
work?" she gasped, "Ask them if they like women my age?"

"Yes mom," I said, "that's almost twice I made in a week being a lawyer."

I cashed the check at the American bank near our hotel because I didn't want to
carry it around with me all this time. The woman behind the counter called the
manager and we sat down in his office while he did the checks he needed to do.
In the end it was all cleared and he accepted the check.

The next day we rented a car and nearly gave Aunt Ruby a heart attack when she
opened the door to see her sister standing there. I had tears in my eyes seeing
them so happy. Both sisters had lost their husbands years before and all they
wanted was to hold each other again, maybe for the last time ever.

It didn't take long or the house was filled with my New Zealand family and we
had a big barbecue in the backyard. We stayed for a couple of nights before we
had to fly back.

I few days after the Scoreland shoot I had another one, this time for FreeOnes
and I posed like I was washing a car. I got more wet as the photo shoot lasted
and ended up on top of the bonnet, spreading my legs and exposing myself to the
camera. This time I even slipped one finger inside me and acted like I was
really aroused and about to come.

The more shoots I did the more explicit they became. From pushing my fingers
inside myself to dildos I started to do everything. As I did more of them I
didn't bother to get undressed in a dressing room anymore. I just took of my
clothes and asked where they wanted me.

At one shoot I was held by a male model and opened my mouth a little as he held
my breasts. I bent over forward as he stood behind me, his cock inches away
from my gaping pussy. I laid on my back and he placed his dick on my clit,
automatically I moaned a little and without warning he slid it inside me. The
photographer kept shooting as the model started to fuck me. I stared intensely
at him and whispered "oh yes, fuck me." Hearing the shutter sounds coming from
the camera and knowing I was being watched by all those people there excited me
in a way I hadn't expected and I started to moan harder. With just a few pushes
I came hard and as he pulled out I squirted, a lot.

I turned on my hands and knees to let him take me from behind. The photographer
took close ups of that dick inside my wet pussy. "Oh yes," I shouted, "fuck me.
Fuck me hard." I laid on my said, the male model behind me and I lifted my leg
as he entered me again. The camera kept on making noises and with every thrust
a shot was taken. When he was about to come I got on my knees and he came on my
face. The last shot was of me looking into the camera with a cum covered face,
smiling.

Not long after I made my first video and I had so much fun with it. I played a
whore, a doctor, a patient, a mother seducing her son and my star rose in the
adult industry.


