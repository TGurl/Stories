# Port Holwin
Port Holwin exists since the late 1700s, ever since the first
settlers went further north and needed a port to recieve the
goods they needed. It started as a small settlement and soon grew
larger and larger. Now the old city center still consists of
buildings from the late 1800s, including the old town hall which
was built in 1883.

In front of the town hall is the large town square, Holwin Square.
During the summer months the citizens and tourists can enjoy a
spectacle of street artists, ranging from singers to living
statues. The square is surrounded by trees lending shade to people
who sit there reading or just enjoying the weather.

There are apartments for rent as well as for sale, but it is the
most expensive ones in town. On the south side of the square you
will get on Main Street, a two way street devided by a row of
trees giving it a Parisian look. On each side are more buildings
from the 1800s combined with new buildings.

