# Chapter Three
It were the last weeks before summer break and I was cramming for my finals. I
had to pass them not to be stuck in Summer School, a program that Kingston
College had implemented to help students pass the first year. I really didn't
want to have to go to school during those weeks off. I had planned to visit my
parents and go to see Marisha, I wanted it to be a surprise for her as her
birthday was in that same period.

Matt had contacted me a few times, he was organizing a surprise party for
Marisha a week before her actual birthday. "I want everybody who is important
to her to be there and you will be the last person she sees after her parents,
you are that important to her. Her parents know this and they told me you had
to be after them, the even insisted on it. Marisha sees you as her sister and I
really need you to be there for her. And there is one other thing I want to ask
you?"

"What?"

"Can I have you blessing?"

"My blessing?"

"Yes, I want to ask her hand in marriage that evening and I really want to have
your blessing."

"MATT! You don't even need to ask! Yes you have my blessing! Of course!"

"Thank you and will you carry the ring that evening? I want you to hand it to
her. Please?"

"Oh wow, you really want me to do that? Don't you want to give it to her? I can
hand it to you, because I really think you should give it to her."

"You think so?"

"Yes, trust me on this one."

"Okay, I will. Will you be there?"

"I will do my best, I need to pass these finals first though."

"I'm sure you'll make it."

And with that I had a goal, I needed to pass. I needed to be there for my best
friend, my sister. I studied ever single second I had available to me, I even
studied during the breaks at work and all of my co-workers respected it.
Latisha even helped me from time to time and I was glad she did.

The finals had been hard and I really didn't know how what to expect as I
anxiously waited my turn to see the results they had posted on the boars.
Finally it was my time and with a shaking finger I checked to see my name, but
they weren't on any of the lists. Totally confused I turned around, not knowing
what to thing. Did I have to go to Summer School? Did I have to miss one of the
most important nights of Marisha's life?

Then the dean walked up with another list: The Honorable Mentions. These were
the students who had gotten the highest marks. I couldn't be on that list,
could I? After a short wait I looked at that list and on top was my name! I was
the best student of the year! I had gotten an A+ in almost all the finals! I
couldn't believe what I saw. I had beaten other top students and I let go of a
cheer.

The dean walked up to me and said "Congratulations Laura! You aced them all."

"Thank you, thank you so much."

"For what? I didn't do anything, this was all you! Keep this up next year."

The Honorary Student was more of gesture then a real price, all that counted
was the honor of being on the board for all time. At the beginning of the next
school year my name would be engraved on the board near the entrance. My name
would be there, I couldn't believe it.

I grabbed my phone and called my parents. "Mom! You wont believe it. I'm the
Honorary Student mom. I got the highest marks of everybody here, of all the
classes!"

My mom screamed and I knew she was jumping around, "Jack! Laura is the best of
the best at school! She made it! Oh Laura, I am so proud of you! This is such
good news."

"Laura? Congratulations! Take a picture will you? I want to boast to my friends
about you. Oh I am so happy and proud, little girl. You made an old man proud
today." my father always told everybody he was on old man, but he really
wasn't.

Right after that I called Marisha who didn't even hear what I had to say, all
she heard was that I passed and when she realized what I had said she became
all quiet.

"Wait? What? Wait a second, did you say --"

"Yes, I'm the Honorary Student for this year."

"No way, you're kidding me! You are?" It was quiet for a few moments then she
screamed "MATT! MATT! Come here! You gotta hear this. Laura you're on speaker,
please repeat what you just told me. Matt needs to heart this from you."

"I'm the Honorary Student for this year. My name will be on the board near the
entrance next year and it will be there as long as the school exists."

They went nuts on the other end and I couldn't quite hear what they were saying
or screaming all I got from it was how happy they were for me. I was so excited
I almost blew the surprise by saying I would see her soon, but I just about
managed to keep it in.

"So, will you come home for summer break?" Marisha asked after a while.

"Ah, I don't know. I really need to work all summer, next year will be
expensive and I need to have some savings." I said, "I'm so sorry."

"Okay, well I will come out there then. I have to see my best friend."

"We'll talk about it," I said, "I've gotta go now. The dean wants to see me."
That was a bit of a lie but I had to disconnect otherwise I surely would have
ruined the surprise and everybody kept on congratulating me.

A few days later I found out being the Honorary Student did entail some
benefits for me the next year. My new student card would reflect it and it came
with loads of discounts at the stores on campus. Besides that it was just a
title and nothing more.

Anxiously I boarded the plane, not only because I really didn't like to fly but
also I was going home for the first time in over a year. My parents would pick
me up at the airport and we had made arrangements so nobody in Whitestone would
know I was there. I would stay in my room for a day or two as we wanted it to
be a surprise for everybody when I showed up.

Right before we entered Whitestone I duck behind the front seats and my mother
covered me with a blanket. She acted like she was talking to my dad as she
spoke to me. "Now Jack, you keep quiet now. Luke's over there and if someone is
a gossip it's Luke. So if you can keep you breath until I tell you we're safe."

My dad chuckled and said "Yes dear." My dad and I both knew it didn't make
sense to talk like that but we didn't want to ruin her fun. "Okay dear, it's
safe now. Could you not drive this fast? Please?"

Once my father had closed the garage doors it was safe for me to get out and
make my way to my room. But my mom had other plans. "No," she said, "You go
into the cellar. We've turned it into a guest room and there are no windows so
you can turn on a light. It would be strange if all of a sudden the lights went
on in your room, wouldn't it?"

"Wow, that's a great plan mom," I replied and went down into the cellar. It
used to be the place where my parents kept all the junk, but not it was another
beautiful room in the house. "I saw this on TV once," my mother said, "and I
wanted to have one. What do you think?"

"It's beautiful mom," I replied, "there's even a TV in here?"

"Yes," she said with a chuckle, "your father watches his sports down here. I
can still hear him curse at the players. We should sound proof the walls, I
guess." She had a twinkle in her eyes as she said it. "Oh, I am so happy you're
home." She took me in her arms and squeezed me, "My little girl getting all
grown-up. I am so proud of you."

"Thanks mom"

"Are you hungry? Need something to drink? Wait, I will make you something. Just
stay here and I'll be right back."

I laid down on the couch in the cellar, switched on the TV and thought 'I
wished they had made this when I was still living here. This is the best.' Just
a few seconds later my father joined me, lifted up my legs and sat down on the
couch.

"Channel 13 please, the cowboys are on."

I switched the channel and watched the football game together with my dad, just
like we did when I still lived there. It was so nice to do this again. When my
mother returned with my dinner she said "Oh no, sports..." handed me my plate
and left. I chuckled, sat up straight and started eating.

The two days went by a little slow, the only visitor I had was Matt who came by
with instructions for the special night. He handed me a little box containing
the ring he had bought for Marisha. "If you want to look, be my guest." he
said.

"Oh no, I couldn't. Marisha needs to see it before I do." but I really was
tempted to take a peek.

Finally the night arrived. People were told I couldn't make it and everybody
felt sorry for Marisha. Matt lined everybody up the way he wanted to. Marisha
had to walk through the park and around every corner there were people who were
important to her holding little heart shaped signs telling her what she meant
to them. 

Ten minutes before Marisha would arrive I arrived and cheers arose when people
saw me. I walked the same path Marisha would and everybody was so happy to see
me there. "I thought you couldn't make it?" they said "Surprise!" I replied. At
the end I saw Marisha's parents and her mother almost cried when she saw me.

"Oh, my gosh you made it! I am so happy to see you dear. Now please take your
spot, right over there. You are the most important to her besides Matt, you
belong there. Now have fun, you hear? And don't cry! I will do the crying for
you." Her mother was such a kind heart and I simply loved her.

Matt showed me where to stand and asked me if I had the ring. I patted my purse
and asked "Where's my sign?"

"Oh, you don't need one," he replied, "You being here for her is all she needs
to see."

Suddenly there was a "silent, she's coming..." going from group to group. My
anxiety grew and my heart started racing. It seemed to take forever for Marisha
to come closer. I could hear the cheers coming from station to station, ever
closer to me. I could hear Marisha scream and cry "What are you doing here? Oh
thank you." Then right behind me on the other side of the bushes I heard "Mom?
Dad? What are you guys doing?"

"Marisha," I heard her father say, "There are two days in my life that are most
important to me. The first is when I married your mother and the second was the
day I got to hold you in my arms. I never knew what love really was until I
looked into your eyes. Honey, I am so proud of you. Of the woman you've become
and you make me the proudest father on this planet."

Her mother continued "I've carried you for nine months, but the moment they
laid you in my arms I will never forget. There you were my little girl, my
love, my life. Thank you for coming into my life and I love you. You are the
best thing that ever happened to me, besides your father that is."

Marisha chuckled and I could hear her tears. "Now," her father said, "continue
on your path. The people who are most important to you are waiting."

Marisha slowly appeared around the bushes and when she saw me she screamed
"LAURA!!!!! LAURA!!! YOU'RE HERE! YOU'RE REALLY HERE!" She dropped everything
and jumped into my arms. I started laughing and crying.

"Did you really think I wouldn't?" I said to her, "Did you really think I
wouldn't drop everything to be here?"

Marisha wouldn't let go and just said "I'm so glad you're here. This is the
best gift for today!"

Finally she let go and I said "Marisha we've known each other all our lives.
And if our parents are right we shared cots together. You are my best friend,
my sister and I will always be there for you, no matter what. I love you."

"I love you too," she cried, "this is the best."

"Now," I said, "there one more you have to see. Continue this path and see who
it is. Don't mind that stuff, I will pick it up for you."

Marisha kept on walking and I followed her on a distance after I had picked
up the flowers she had dropped. She looked left and right not knowing what was
to come, then she stopped, clasped her hand in front of her mouth.

In the middle of the pond Matt had placed a pontoon, with all white flowers and
garnishes. In the middle of it all he stood wearing a bright white suit. He
held out his hand to her and Marisha slowly walked towards him, for once in her
life she didn't know what to say.

As she stepped onto the pontoon everybody arrived to witness what was about to
happen. Matt scraped his throat and said "Marisha, you are the love of my life
and I couldn't imagine my world without you. The day you told me you were going
to life in Fort Dix was one of the hardest I had to endure, but I knew in order
to keep you I had to let you go. So I did. The day you told me you were coming
back was one of the happiest days of my life. You are the most important person
to me and I never want to see you hurt."

I stepped forward and stood behind them just as Matt had instructed me to do.
Marisha was totally confused what was about to happen and shrieked when Matt
went down on one knee.

"Marisha," he said, "I've already procured the blessing of all these people, of
all the people who are important to you. Now I need to ask you one simple
question: Will you marry me?"

Marisha shrieked once more and then just nodded.

"What? I didn't catch that?" Matt said.

"YES!" Marisha shouted out, "YES I WILL MARRY YOU!"

The crowd cheered and I handed Matt the box. He opened it to Marisha and it was
just beautiful. He had made an excellent choice! It wasn't an opulent diamond
ring, it was a simple and beautiful white golden ring, exactly the ring Marisha
loved. He took it out and placed it on her finger. She jumped into his arms and
kissed him. Another cheer went through the crowd.

Then she turned to me and shouted "You! You knew about this! And you didn't
tell me? Ooh, and you always said you couldn't keep a secret!" I duck away a
little and then we hugged. "Congratulations," I said, "now do you understand
why I had to come?"

Marisha couldn't wait to show off the ring and everybody congratulated the
newly engaged couple. We partied all night long and it felt good being home
again. During that party I talked to Travis once more.

"So I heard you are going to Kingston next year," I said to him teasingly.

"Yes, that was the plan," he said, "but plans change. I got accepted into BIT
and I've accepted their offer to come and play for them."

"Wow, BIT. That's quite the college. I am proud of you." I said, somewhat
relieved but also a little disappointed. Bradford Institute of Technology was a
well renowned college and it wasn't easy to get in. "And a football
scholarship? Wow." I continued.

"Yeah," he said, "they came with an offer I simply couldn't refuse. Hope you
don't mind."

"No, I am happy for you," I replied hiding my disappointment.

We kept talking for a while before we found ourselves hiding behind some
bushes, kissing. "Travis, I really am happy for you," I said the moment we
stopped kissing, "but I have to admit it was a little flattering when Marisha
told me about you wanting to come to Kingston."

"Yes, and I really wanted to. But BIT offered me a full scholarship AND I get
to play football. Maybe even have a chance to go pro."

"I sure hope you will. I mean it, you always said you wanted to go pro."

"And with this I've got a chance. So I just had to accept."

"I fully understand," I said, "and hey send me an autograph the moment you go
pro! I want to sell it on the internet for a lot of money!" I chuckled and
Travis laughed too. We rejoined the party and with that our relationship was
officially over.

After staying in Whitestone for a week or two I returned home. It had been good
to be there for a while but I noticed it wasn't home anymore, Fort Dix was my
home now and I really wanted to be home again. Marisha and Matt dropped me off
at the airport and Marisha asked me there to be her brides maid. I totally
accepted and hugged her.

Once I came home the first thing I did was decorate Marisha's old room and turn
it into some sort of a guest bedroom. I didn't want to see that empty space
anymore. I also made a few changed to myself, I chose to be more confident in
myself and to be more _me_.

The first time I stepped outside wearing something tight was really exciting to
me. I was sure everybody was watching me as I walked through the park or
anywhere else. It felt so good to see that nobody really paid any attention to
me and it made me feel more confident.

The next day I wore an even tighter shirt and a tight skirt, showing all my
curves. This time some heads turned but not out of disgust and I started to
like the people staring at me, especially the men. I started to wear heels and
more exuberant makeup. Bright red lipstick, darker eye shadow and things like
that. Some men even started to dog-whistle as I passed by, I had never had that
before and it flattered me. Some women dislike it a lot, but I sure didn't I
loved it.

Day after day I dressed more sexy as I went to do anything I needed to do. With
every day my confidence grew and I spent days in the mall looking at clothes I
couldn't afford, but it was nice to dream.

I followed instructional videos on YouTube on how to do my makeup and how to do
my hair. The more I practiced the better I got and it was nice to do those
girly things. I had never done that before and it felt good to treat myself
like this. During those weeks I also changed jobs and got a job at a travel
agency who were more than happy to have me. It wasn't like I could travel the
world or anything, but me being the Honorary Student had sure opened those
doors for me.

One of the girls working there was Emma, she was about my age and we got along
great. The first day I worked there she asked me to join her for lunch and we
had a very good time. We left as co-workers and came back as friends. The best
thing about the job was I could earn quite the bonuses if I did my job right,
15 percent of every sale. And with the most expensive offers we had that could
add up quickly.

Emma was the best sales-person in the agency and she had been for several years
now. "Well," I said to her during that lunch, "your reign may come to an end,
my Queen." All she said was "Bring it! Take your best shot!" We chuckled and
came back to the office arm in arm.

Carina, the owner of the agency, smiled and said "Wow, you've become friends
that easily?" We just nodded and sat down at our desks. "I told her I am going
to beat her ass," I said to Carina. And Emma said "And I told her to bring it."
Carina burst into laughter and said "Just as long as it's a friendly
competition, I'm fine with it." We all laughed and when the first customer came
in that afternoon I couldn't help but gloat a little when she sat down at by
desk.

"What's going on?" she asked me and I replied "Don't worry about it, just a
little friendly competition amongst friends." The woman laughed a little and
than told me what she was looking for. I told her all our options and she
booked a nice cruise to celebrate her 30 year anniversary. "Congratulations!" I
said and added "Please accept our gift of a free Captains Dinner."

The woman said "Oh, thank you. Thank you so much."

"Don't mention it, I will book it right away. Just tell all your friends to
come here for their bookings. And they can ask for me, Laura. I will be more
than happy to help them."

"I sure will, thank you so much."

The moment the woman left the office Carina clapped. "I knew you had it in you,
and nice move with that Captains Dinner, you know it's free right?"

"Yes, but clearly she didn't and it's the gesture that counts." I laughed.

Even Emma applauded "Nice move, I got to remember that one. Nice move."

A few months later I was doing well at school and combining school with my new
job at the agency was easier than it was combining it with my old job. Latisha
and I kept in contact and I had dinner over there quite a few times. Loraine
did ask me everything about college and when she got accepted into her first
choice, Kingston, I was so happy for her.

Latisha said "Yeah, she adamant about moving into the dorms. But hey, at least
she's close."

The competition between Emma and I was real close and either of us could win
the ultimate price: The Cup of Honor! A Styrofoam cup we had marked with a
marker and that stood proudly on top of the water cooler. One week I was on top
the next week she was, but we both had underestimated Carina. We thought her
being the boss disqualified her from the competition, but we forgot one thing.
Carina was the one who made the rules.

Just one more week to go and I was just a little ahead of Emma when Carina
swooped in and did the biggest sale of the year! She had gained a lead that was
all but impossible for us to pass. A week later Carina proudly was photographed
holding up the Cup of Honor! Emma and I sheepishly applauded and then just
ravaged the cake Carina had ordered.

"Wow," I said as I enjoyed the sugary treat, "I never thought Carina would be
this competitive."

"Yeah, about that," Emma said, "You are the boss, so how can you be the best
employee?"

"Who ever said it had to be an employee? It clearly states the best
sales-person, doesn't it?" Carina laughed.

"Okay, you got us there. But it still isn't fair, that sale was done on a day I
was in school. Darn it." I replied. Carina just shrugged her shoulders and
laughed.

When I came in a week later there was a huge photo of Emma and me smiling.
Underneath it said "Employees of the year and best persons in the world!"
Carina had replaced the best sales-person photo with that one. I almost cried
when I saw it. Carina said "It's more than appropriate, isn't it?" I thanked
her and sat down at my desk. The rest of the day people coming in congratulated
us and we had one of the best days ever.

Working there not only was way more fun, it also gave me some breathing room
money wise. For the first time I had money left over at the end of the month
and I could spend it how ever I wanted. The bonuses I got were more than enough
for me to pay for all the rent and still have something left. But my parents
insisted on paying half of it and who was I to argue with them.

The second year in school was more practical than theoretical and because I
already worked for an agency I didn't have to find a place where I could get an
internship, Carina was more than happy to provide it to me. As one of my tasks
for school I had to make an inventory of what could be changed and how we could
improve. Not only did I get an A for my report, Carina told me she really
thought I had made some good points and made some changes that were necessary.
We got a new computer system for example, with the latest software. We also
created an information stand with a point-of-sale computer, which became quite
popular with the youth who just wanted to book a hotel for their next trip.

And although those sales didn't count for anyone of us, it did count for the
agency and earned us a rather steady income. Plus we could always inform them
some more or help them make the right choices for them. Carina was very pleased
when she saw the results of the changes we had made. I felt overjoyed when she
told me that.

I had been so busy with school and work I hadn't thought about Ashley in a
long, long time. Then one evening as I sat in my living room watching TV it hit
me. I was watching a documentary about women addicted to plastic surgery and
one of them had a very huge bosom, 3000 mils or more. She had lip fillers, 
botox and her nose done. She always wanted to look like Barbie, she said. The
moment I saw her I knew. I wanted to be like her!

Right after that documentary I started searching for information about all of
it, from nose jobs to breast enlargements. From liposuction to hair-extensions.
I made a list of all that could be done and how much it would cost. The best
thing I came across was something called _a butt lift_, where they would remove
fat from on part of your body to fill up your butt cheeks. The results I saw
were just mesmerizing and I needed to find a place where I could talk about it,
I needed to share my feelings with like minded people.

At first I started a free blog under the title _The Unlikely Slut_ and my first
post went like this:

> Hi and welcome to my blog. I am not going to pretend I will update this
> daily, because I'm sure I wont, but at least this gives me a space to open up
> about who I really am or who I want to become. I am not at all who people
> think I am, I am not that respectable girl from next door, I am not that girl
> who doesn't want to be taken by a strong man, to be overpowered by him and be
> used in any way he wants to. Because I do. Deep in my heart I am a slut, a
> whore and I want to be who I really am deep inside.
> But there's always that nagging voice in my head saying 'what will people
> think?' or 'you can't do that, it's not normal'. I want to be able to say
> 'who gives a fuck?' I want to be open about my sexuality and what excites me.
> I want to be open about anything and I want to show the world who I really
> am. I want to be that girl in the porno's you watch. I want to be fucked by
> multiple men, a cock in every opening of my body. That's what I'm dreaming
> about, that's what's on my mind almost every second of the day.
> For the purpose of this blog you can call me Ashley, that's the alter ego I
> created to live out my dreams. I change into her whenever I feel the need to
> do so. I record myself masturbating, take explicit pictures of myself
> whenever I am her. But I don't want to be her anymore when I do those things,
> I want to be me!
> Today I saw a documentary about women addicted to plastic surgery. One of
> them said she always wanted to be like Barbie and it struck a cord with me.
> That's what I want too! I want those big ass boobs, that nice ass, those big
> lips and fine nose. I want to parade around in my heels and pleasure men
> where ever I go. I want to sell what I have to offer them and for the right
> price they can do whatever they want with me. I am not above pain, I am not
> above humiliation, I am not above being filled with their cum. I want it, I
> need it.
> But for now I am still the old me and I'm starting this journey into finding
> out what I dare to become. And I hope you will join me!

That post was on the internet for almost a day before I chose to delete it, but
when I opened it I saw there had been some responses. Mostly from other women
who said they felt the same way and how nice it was to finally read a post from
someone who said exactly how they felt. I replied to all of them and it felt so
good to have some people who understood exactly where I was coming from, even
if it was through the internet.

A few days later there was another response, this time the woman said "Hi, I'm
_SexySlut21_ and I am one of the moderators on _Only4Women_, a community for
and by women who want to explore the sexuality. Maybe it could be interesting
for you to join us. We not only provide a blog, you could even progress to a
vlog and post videos. We are an adult site and you can show as much as you
would want to. Besides that we also have a forum, a chat service and even a
place where you could arrange to meet people. I really think you will like what
you see when you join us at only4women.com."

I clicked on the link and was greeted by a nice logo and a form where I could
either login or register. There was a huge disclaimer it was an adult site and
I had to check that I was over 18. The registration page talked about all the
advantages of the site and I was intrigued. A few minutes later I received a
confirmation e-mail from the site, explaining the next steps in the
registration process.

First I would get another mail with a temporary link for a video chat with one
of the moderators. This was done to verify whether you were a woman. "Trans or
Natural, we do not differentiate." the mail stated. After that step I would
have to agree to an non-disclosure agreement, this way they could guarantee the
privacy of all participants.

Within seconds I got the second e-mail and with my hear pounding I clicked on
the link. A new page opened and in seconds I saw my own face to the right, to
the left it said "waiting on..." Soon enough some woman appeared saying "hello?
Are you _the Unlikely Slut_?"

I nodded sheepishly and said "I don't really feel comfortable about this."

"Don't worry," she said, "this isn't recorded and the link went invalid the
moment you clicked on it. Hi, I'm _SharedWife36_ and my husband likes to watch
me having sex with other men. He loves it when I record myself while he's at
work. The site made my dreams come true and helped me open up to my husband.
We've never been closer than this. I'm telling you this so you can understand
that this is a safe space, nobody knows who I really am. Except for the men I
am having sex with, that is. But that's a select group of people. I am a mod on
the site, but I don't post pictures or videos of myself. You will be one of the
few who actually will have seen my face."

"Thanks for clarifying," I said, "That makes me feel a little more
comfortable. So, what will happen now. You've seen that I am female, is there
anything else?"

"No, not really. Got any questions for me?"

"Yes, about that NDA, is that really necessary?"

"Yes, it is. Maybe you will want to meet up with people from the site. Some of
them are people in important positions, some of them just want to be sure you
will keep their secret. This NDA will make sure of that. But, as you will know
whenever you read it, we will not hesitate to report anything illegal to law
enforcement. We do not condone rape for example. Not if you, as the victim,
didn't call the shots. If you have a fantasy about being raped and you made
sure that's really what you wanted, you made all the arrangement for it to
happen, then we will respect it. But if you, let's say during a meet, got raped
and you explicitly said it was against your wishes then we will take the
appropriate actions. We've done it before and we will do it again. This site
has to be a safe place for everybody, we talk about our deepest and sometimes
darkest fantasies."

"I understand and will read it closely before I sign it." I replied.

"That's a good thing, well I guess that's it for now. I full expect you to keep
my secret, whether you sign the NDA or not."

"I will and thank you."

With that the conversation was over and I leaned back taking a deep breath. I
still wasn't sure I wanted to do this. And when the NDA came a few minutes
later I took my time reading it. In short it stated that signing it would allow
them to go after my private information whenever I did anything against the
NDA, it also said they were allowed to refer anything to the proper authorities
whenever it was necessary to do so. As I read it I thought of it more like a
gesture than a particularly lawful document as nowhere did I have to disclose
my private information and how would they know it was me? All the people living
in the Harbor shared the internet connection.

There was just one who saw my face and I could always claim my account had
been hacked, I thought. There was just something about the whole document that
made it feel a little over the top, but I signed it and send it back. It didn't
take long for my account to be approved and I was able to log in for the first
time.

There were so many options available I can hardly mention them all, but as a
newcomer I could only was allowed to do one thing, post a message introducing
myself. I read a few older ones first and then posted:

> Hi, I'm the _unlikely slut_ and I am new to this. I don't know what I should
> tell you right now. The only thing I can say is that people see me as this
> nice girl, this girl who is respectful and kind. But that's not how I feel, I
> want to be a slut, a whore. I dream of being taken by multiple men, I dream
> of being one of those girls working the streets. I fantasize about it, how it
> would feel selling my body like that. That's about it for now. I wouldn't
> know what to tell you more.

Within seconds reactions came flooding in, all of them welcoming me to the site
and telling me this was a safe space to really open up. It felt good reading
all those reactions and a new direct message told me all the options were now
available to me. I spent some time exploring the forums and reading some of
the threads, I also read some of the blogs and clicked the follow button on
some of them. I took a quick peek at what the called _the Marketplace_. There
were dresses, high heels and all kinds of other things for sale there. Then
there was the _Parking Lot_, a spot where you could arrange to meet other
people or place an ad offering yourself for a meet. There was just too much to
take in and I kept on clicking on different links.

When I looked up I noticed four hours had gone by and I really needed to go to
bed. I logged off and the next day, as I ate my breakfast, I went back to the
site. There were a few more responses to my post and a few direct messages.
Most of them I ignored as they were asking for meet ups. Then suddenly it
dawned on me, this was a site for women only. Yet on the _Parking Lot_ women
could arrange meetings with _men_. How was that possible?

I sent _SharedWife36_ a direct message with that question and logged off again
because I had to get to school. For the whole day I kept thinking about the
site and about the question I had raised. When classes were over I rushed home,
opened my laptop and logged in. I was glad to see _SharedWife36_ had responded
and her answer read:

> _The Parking Lot_ is the only part for which men can register. They are
> connected through another site of the company running the site, which is
> _SecretLove_, a dating site for married and unmarried men. It is impossible
> for any of them to enter any part of our site through that connection. As you
> will see whenever you enter _the Parking Lot_, you are redirected to another
> site, the address changes. Whenever you click on the back button, you are 
> redirected back to Only4Women.

That was a good explanation and I tried it. I entered _the Parking Lot_ and
checked the address of the page and sure enough there was a different URL
there. But that's about as far as my technical knowledge went. It did make me
feel a little more comfortable though.

I started reading some posts on the forum and even responded to some of them,
then a came across a post on the blogs by _WannaBeBarbie_, she posted exactly
what I felt. She not only talked about it, she even posted pictures of her 
changes. She talked frankly about what she was going through. One of her first
posts was about her nose job, she posted a picture of her swollen face right
after the surgery and a photo from a few weeks later, her nose was way smaller
now and it had become so cute.

The she talked about her boob job and how she got her saline implants. She also
talked about how the doctor had told her how she could inflate them. Until the
time of that post she had added around 200 mils to her breasts. She gave
detailed instructions on what to do and what not to do. She talked about the
type of implants she had gotten and every time she said such things she added
"but always talk to your doctor, what's right for me could be totally wrong for
you."

I admired her openness and immediately clicked that follow button. On one of
her posts I told her how much I admired her courage and how much I wanted just
a little bit of it. "I wish I was as brave as you are. I wish I could be as
open about it as you are. The moment I learned about this I knew that that was
what I wanted too. But I am so scared about what people might say about it,
especially the people close to me. If you have any advice on that I would be
grateful."

It didn't take long for her to respond. She send me a private message and said
"Hi, first of all welcome to the site. It helped me get to where I am now. I
would love to talk to you some more. Maybe we could connect through chat
someday. But let me give you one good advice, one that helped me a lot, be
honest to the people close to you. Tell them this is what you want, tell them
the truth. It won't be easy, but if they truly love you they will amaze you.
I'm sure of it. Don't hesitate to PM me, I've sent you a friends request too."

Tell the people close to me? Oh no, I wouldn't dare. On the other hand she was
right, if I really wanted this I couldn't hide if forever. They would notice it
no matter what. I took a deep breath and thought about it for a long, long
time. In the mean time I chatted with Barbie and she made some good points.
"It's not cheap," she said, "my breasts were almost 8000 dollars. And you will
have to endure the pain that comes with it. But I love the results, every time
I look in the mirror now I see me, the real me."

It was a Saturday and Marisha was about to arrive. We had planned a whole
weekend during which we would make plans for her shower and her wedding, we
would go looking for dresses and make it a girls weekend. I had also prepared
to tell Marisha about what I was going through, but I wanted to wait for the
right moment to tell her.

I was at the airport at 9:30 to pick her up and she was so happy to step into
my car. We chatted about all kinds of things on our way back to the apartment,
when she walked in the first thing she said "Oh, I like what you did to my
old room. I really like it a lot." She stepped into it and placed her suitcase
on the bed. "Now," she said, "I'm dying for a latte from that coffee shop
around the corner." I smiled and we left to get a latte.

We made plans for the rest of the weekend, chatted some more until it was time
to go to the bridal shop where Marisha had made an appointment. She had seen a
dress on the internet and she really wanted to try it on. It was a beautiful
dress, but it didn't fit Marisha. It just wasn't her. She tried on several
different ones and there just wasn't a dress that either of us really liked. A
bit disappointed we left the store and went to the next one. No luck there
either and we had just one more stop. There we found the perfect dress for her,
it looked beautiful on her and it made me cry a little. But to both our
disappointment they didn't ship dresses all the way to Whitestone.

"Oh," I said, "but if you decide to get this one. I could pick it up, couldn't
I?"

"Yes," the woman who helped us said, "but what about the measurements? The
dress has to be taken in a little and we don't do that until we are sure you
are going to buy it."

"That's fair," Marisha said, "But now I know what to look for back home. Thank
you so much for this, you helped me a lot." The woman nodded and clearly was a
little annoyed she didn't make a sale. We spent some time looking at shoes for
her to wear and just got a general idea what she wanted to wear on her big day.

On our way over to the restaurant I showed her the agency and introduced her to
Carina and Emma. "So nice to finally meet the girl Laura's been talking about,"
Carina said, "and congratulations are in order, I hear." Marisha smiled and
showed them her ring. "Oh wow, that's beautiful," Emma responded, "I hate those
big diamond rings, this is just perfect." 

"I thought so too," Marisha responded, "It's either Matt really knows me or he
had some help from a friend. I'm just saying."

"I didn't help him. He did that all on his own," I responded, veining
indignity. Marisha chuckled and said "Sure."

We had a lovely dinner at my favorite restaurant and walked back home. On our
way over Marisha purchased two bottles of wine and some snacks. "We're going to
make a fun night of it." she said holding up the bottles.

Once home we both changed into something comfortable and chatted the night
away, we listened to music as we each sat on one side of the couch, a blanket
over our legs. It was on my third glass of wine when I said "Marisha? Can I
talk to you for a minute. I mean, really talk."

"What's up? You seem serious all of a sudden."

"Yeah," I said as I moved my finger across the top of the glass, trying to make
it sing. "There's something I need to tell you and I don't really know how. I
am so scared of what you are going to say, but I really need to tell you this.
I can't keep it a secret anymore."

"What? Are you gay? You know I don't care about those things."

"No, I'm not gay. Not even a little."

"So what is it then? You are making me a little nervous."

"Okay, here it goes. I've been thinking about it a lot the past few months,
maybe even a year. It all started when you still lived here to be honest, but I
just never dared to tell you."

"Tell me what?"

I took a deep breath, thought for a minute or two and then said "Maybe it's
better if I show you. Just promise me to not peek, it might take a while before
I can show you."

"Okay? Show me what?"

I got up and said again "Don't peek. I will be back as soon as I am ready."

I walked into my room, locked the door to be sure and changed into Ashley. I
wore my highest heels, the shortest skirt I had, my very short shirt showing
the lowest parts of my breasts. Added a pink collar with the word "Slut" in
shiny letters, did my makeup. Just before I opened the door I took a deep
breath, adjusted my stockings and opened the door.

"Marisha? It's time for you to meet Ashley. This is who I am, this is the real
me, the girl I want to be."

Marisha looked at me and burst into laughter. I felt totally embarrassed and
retreated into my room, crying. This was the reaction I had been so afraid off,
her laughing at me as I showed her who I really was. I sat down at my desk and
started to remove my makeup. With every stroke of the pad I started crying
harder. I didn't even hear her knock and her touching my shoulder startled me.

"I am so sorry," she said, "I thought you were joking. I really did. I am so
sorry. But what are you telling me?"

I slowly turned to her and said "I've been dreaming of this for so long, ever
since I learned about it. Way back in high school. Remember? When they talked
about that girl from Dearborn? That girl who appeared in on of those nude
magazines? Ever since then I've been dreaming of being on of those girls. But I
was so afraid of what people would think knowing how they crucified her."

"Yes and?"

"Well, one day I was in the mall here and I saw this skirt and this tight shirt
and a pair of heels. It was a weekend you went home. The moment I put them on I
felt like myself, the real me. It felt comfortable and I kept on wearing it all
day. It felt so freeing, so -- me. The next day I got some more sexy clothes
and I wore those all day. Every time you were not home I wore clothes like
these. I longed to go outside in them, but I just don't have the guts."

"So what did you do?"

"I took photos, videos. I even got a real camera. There are loads of them on
this laptop. Just a few weeks ago I joined this site for women and I met a few
like minded girls. That was after I saw this documentary about a woman who had
changed herself to look like Barbie. Watching that I knew what I wanted, I
wanted to be her. I want to change everything about myself. I want bigger
boobs, just like hers. I want my nose adjusted, my ass, simply everything. I
want to be a Barbie, Marisha. That's who I am! I am a slut, a whore. I am all
of that I just haven't acted upon it yet."

"Yet? You really want to? Be a whore I mean?"

"Oh yes," I looked into her eyes, "yes, I want to earn money by selling my
body. I want men to take advantage of me, ravage me and do whatever it is they
want to me. I want to feel them in every single hole, I want them to fill me
with their cocks. My pussy and my ass at the same time. I can't stop thinking
about how that would feel."

Marisha was quiet for a long time. Then she sat down on my bed and said "First
of all let me tell you how happy I am that you told me this. I always knew you
were hiding something and I just thought she will come out to me one day. One
day she will tell me she's a lesbian. Not that there's anything wrong with
being a lesbian, I'm just happy you aren't one. Oh, that sounded all wrong when
it came out. Not what I was thinking. But anyways, second of all I need to say
this. I've been waiting, longing for us to have a talk like this. How long do
we know each other? 21 years? We never ever talked about sex, not ever. And I
really wanted to, but I respected you so I didn't. Now it's time for me to
tell you a little secret."

I turned to her all the way and waited for her to continue.

"Matt and I have, what you would call an open relationship. We both have our
buddies who we turn to if we need some -- satisfaction. That's the secret of
our relationship. I get to have my little adventures and he has his, just as
long as we are both honest about it. Never hide it from each other."

"You mean --"

"Yes, I mean I have sex with other men and he's got other women. We even had a
foursome one day. We didn't really like it. But, can I be honest? I can? Okay,
I have my fuck-buddies and sometimes I have two of them at the same time. There
are evenings, especially on Friday, when I go out to meet them. Matt helps me
get ready for them and I get into a cab and have some fun."

"Wow, I didn't know."

"No, how could you? See, that's why I said I am so happy we finally have this
talk. I wanted to tell you for so long, but I always thought you didn't like
talking about it so I didn't."

"Wow," was all I could say.

"Yeah, so tell me about this fantasy of yours, about becoming Barbie. What do
you mean?" I immediately got enthusiastic and showed her all kinds of photos I
had collected of women who went there before me. "Look," I said, "she has
saline implants which can be inflated every three months. She's at 2600 mills
now and she wants to end at 3200, which is the max. I so want those, I dream of
having those. And look at her, how beautiful she is. Whenever I look in the
mirror that's the person I expect to look back at me, that's the girl I really
am."

Marisha did her best to understand but she finally said she couldn't. "But,"
she said with emphasis on the but, "that doesn't mean I wouldn't support you.
If that's what you really want, go for it. Let's just start at the beginning.
Tomorrow you are wearing that, or maybe a slightly longer shirt, when we go to
the mall. You are wearing that makeup, those shoes and --" she got up went
through my closet and held up a brightly pink shirt with the word "Girl" on it.
"This shirt," she said, "we're going to show the world the real you. Who cares
what the other people think, they will think whatever they want to. You aren't
hurting anyone."

We talked some more during the night and I even showed her some of the photos
I had taken of myself, even some explicit ones. "Here," I said, "I was so
nervous when I took this. It's right here on the balcony, anyone could have
seen me. But I did it, I sat there for about 3 minutes with my legs spread wide
open and spreading my lips with my fingers."

Marisha whistled and said "wow, that's a nice -- vagina."

"You really think so?"

"Oh yes, it's beautiful. I might want to see it for real one day."

I blushed and whispered "Well, it's right here." and I spread my legs a little.

"You really are a slut!" Marisha replied.

I spread my legs a little wider and she could see I wasn't wearing any
underwear. "You naughty girl," Marisha smiled and placed her hands on my knees
spreading them wider. Before I knew it she dove in and licked my slit, I moaned
deeply as she did so and she said "Wow, you really are a little nasty whore
aren't you?"

I nodded and said "Yes I am a whore, a slut, a cumbucket."

"Next time you come over I will tell Matt to fuck you, would you like that
little slut? Feel that cock of his entering your tight little hole?" with that
she licked me again and I screamed "Oh yes! I want him to fuck me!"

"You want him to fill you up? To send all his cum inside that fertile womb?"

"Yes, yes, yes!" I screamed, "I want his cum deep inside me. I want him to make
me pregnant! I want him to ravage me, rape me, I want to be his cumslut! His
little whore!"

Marisha slipped two fingers inside my very wet pussy and said "Oh wow, you are
so wet." She rose up, keeping her fingers inside me and pulled up my shirt with
her other hand. She dove on to one of my breasts and started to suck it hard. I
almost came instantly. "Wow," Marisha said, "I love this little whore, this sex
toy. I wished you told me sooner, we could have had so much fun!"

With that she took off my shirt and pulled down my skirt. Then she proceeded to
undress too and we kissed for the first time. We kissed passionately and had
sex with each other for the first time. We fingered each other, licked each
other and I saw her squirt for the first time. The moment Marisha pressed her
wet pussy against mine, made me come once more and as she rubbed her clit
against mine she had a huge orgasm too.

We laid down in each others arms, stared into each others eyes, kissed until we
both fell asleep.
