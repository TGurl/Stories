# Chapter Two
The first few months were rather boring and my mother had been right all along,
most of the time I spent studying I was in the library at school. Marisha and I
had gotten closer friends and we studied together most of the time. We both
were studying hard to pass the first round of exams, which we both did. Marisha
did a little better than me.

During those weeks we had started our new campaign and I played a blue tiefling
cleric. She was rather young when she left home to go adventuring. An half orc,
who she met by chance, took her under his wings and as they roamed the lands
they met a monk who was searching for her purpose in life (Marisha). The three
of us sat in a tavern where we met the rest of the party. We had just helped
defeat a pack of wolves who attacked the village we were in and had earned our
first gold.

Marisha was totally different than me, where I was shy and reserved she was
open and outgoing. I admired her for not caring about what people thought of
her. One night when she was sitting in my apartment she confessed she cared
more than she led on to believe. "I just got hurt too much, let's leave it at
that," she said.

"But that's just a defense mechanism," I replied, "at some point you will need
to trust someone. Otherwise you will get lonely, trust me I've been there. I'm
not saying it's easy, it still is hard for me. But at least I'm trying."

"Yeah," Marisha said, "But you're a Tulsa though."

I threw a pillow at her and said "Dumb Lincoln" She threw the pillow back and
we wrestled for a moment, stared into each others eyes and kissed. Marisha
immediately withdrew to another chair and said "I am so sorry. I am so sorry. I
don't know what happened." She got up grabbed her coat and ran out the door.

I got out my phone and called her. After a few tries she finally answered. "Why
did you run?" I asked her, "please come back. I think we need to talk about
this."

"Maybe tomorrow," she answered, "I need to think."

The next day Marisha didn't call and for the whole week she avoided me, she
didn't even come to our game. Then all of a sudden, without any warning, she
rang the doorbell. "Hey," she said, "it's me. Please let me in."

A few minutes later she sat in my living area and I handed her a cup of coffee.
It was awkward between us, the both of us searching for the words to break the
silence. "Um," she said with a cracking voice, "I don't know what to say, but
it shouldn't have happened. I just don't know where that came from and I feel
so ashamed. I didn't want to see you, but I also feel that you needed an
explanation. That's why I'm here, nothing more, nothing less."

I was quiet as I wanted to give her all the time and space she needed. Marisha
just stared at her cup with the steaming black liquid. "Aren't you going to say
anything?" she asked.

"Oh, I thought you were thinking and I wanted to wait until you were ready. I'm
so sorry. Just let me say this. I don't want to loose you over this. It was
just a stupid kiss, it didn't mean anything. Did it?"

"I don't know. I am so confused. I am straight, I am not a lesbian. I wanted
you to know that. I like boys."

"So do I, so why why did you kiss me?"

"I don't know. Spur of the moment thing. Ever since that happened I've been
thinking about it. I can't shake it and trust my I tried."

"So, what made you come here?"

"That thing you said. About me pushing people away, about giving trust another
chance."

"Thank you," I replied, "I'm really glad you're here."

"Well, all of me is saying that this is the last time. But I also think I owe
you an explanation, a chance to talk about it."

"I understand," I replied, "Look, it happened and we both were -- startled. You
said you like boys, but could it be that you like girls too?"

"I really don't know, it's all so confusing. I've never been with another girl,
if you know what I mean. But this past week I realized that maybe, somewhere
deep inside me I really want to."

"Okay, so now we've established that you like boys and girls. Well, as far as I
know I like boys. But that could be because I've never been kissed by a girl
before. I had never thought about it until it happened."

"So how do you know? That you like boys I mean?"

"I just assume that. I do not have that much experience, I only ever been
_with_ one of them. And that happened only after we dated for almost two years,
then he moved away and I never saw him again."

"What? Only one boyfriend? But you're so beautiful."

"Me? No. I mean look at me. Thick glasses, fat body, this isn't what boys want.
They want the sexy girl, the ones with big boobs and wide hips. Not a fat, book
loving _librarian_. Not someone like me."

"Then they really are stupid," Marisha replied."

"Thanks, and you? You had many boyfriends? Be honest now, take that next step
in trusting me."

"When my dad left I went through phase. Let's just leave it at that. He left my
mom for a younger woman and then got himself killed in a car accident. He had
been drinking all day and drove himself into a tree. I lost myself for a short
while, let's just say it is the reason I don't drink."

"Ah, enough said. You can tell me when you are ready to tell."

Marisha looked at me, took a deep breath and said "I ran away from home, got
involved with the wrong people and -- slept with men for money. If it hadn't
been for my mother to find me, the police would have. She literally dragged me
home by my arm and locked me into my room. That's the best thing that ever
happened to me, she didn't lock me up because she was angry, she did it because
she loved me and didn't want me to sneak out again. During those three days she
showed me how much she loved me and told me over and over again she wasn't mad
at me. She treated me like an adult and talked to me."

"Wow, I am so sorry that happened to you. I truly am."

"Please don't tell anyone," tears rolling down her cheeks, "I've never told
anyone. If it gets out it will ruin me."

"I won't tell anyone," I said, "I'm just glad you trust me enough that you felt
like you could share it with me. And to tell you the truth, I don't care.
People do stupid things, things they regret and those things shouldn't be held
against them if they showed remorse and bettered themselves. That's what I
believe, that's something my parents always told me."

Marisha looked at me and said "And you? Did you do anything stupid? Something
you rather not tell anyone?"

"Well, I did borrow this book from the library without them knowing about it.
Does that count?"

For the first time Marisha chuckled "No, something really stupid."

"Okay, then no. I never did. Little old miss boring over here, I mostly spent
my time in my room reading. I never was invited to parties or something. I
never had the chance to to anything even remotely stupid."

"Lucky you," Marisha said, "this haunts me every single day. It wasn't even
that long, just three weeks or so. And it's not that I did it every single day,
just twice. Because I needed the money to buy alcohol. Most of that time
I laid on a filthy couch, to drunk to even walk let alone _entertain_ some
guy."

"I understand," I said, "Can I ask you a question? Something I've been
wondering for a long time and I never had the chance to ask someone."

"What?"

"How does it feel? I mean, you met those men in a hotel room, right?"

"Yeah, they'd call and I went over there."

"So, how did that feel? Knowing what you were about to do? With a stranger,
you'd never met before."

"I was nervous as hell. But they paid me upfront, until that moment I could
always walk away. When they handed me the cash, that's when it got real to me.
And most of the time a was a functioning drunk, the world was mostly a blur to
me. Why do you ask?"

"Well," I said, "and now I'm trusting you. I might look like that respectable,
nerdy girl but that's not who I am inside. Ever since I saw that video on the
internet I -- let's just say I didn't just read books in my room. I watched
videos where women _played_ with men who were not their husbands."

"You watched porn?"

I looked down and nodded slightly. "Still do. I just can't stop. Every time I
say to myself I will stop watching, but after a while I feel that itch. It
could be days, weeks, sometimes it's just hours. It all depends on what is
happening to me. Like the past few months I haven't watched any because of all
the changes like me moving here, going to a new school, meeting you and all the
others. I just didn't think about it because I simply didn't have the time to
think about it."

"Wow," Marisha said, "I never would have thought --"

"That's my point," I said, "We all have our little secrets. True, yours is a
little bigger than mine, but that doesn't negate my point."

"I think I understand what you are getting at," Marisha said, "you are trying
to say to me that you would like to watch a porn movie with me."

I giggled and said "No, I meant to say everybody has their secrets and sharing
it with someone, trusting someone helps lighten the load."

"True, but you _do_ want to watch a porn movie with me, don't you?"

Again I giggled and said "Well, the don't call them _nature_ films for
nothing."

Marisha started laughing and said "Man, I love this. I really didn't know how
you would react. This is so good. You watch porn? Man I love it."

I started to laugh "Shout a little harder, I don't think they heard you on the
other side of town."

Marisha burst into laughter and said "I never thought I would like a Tulsa
girl, but here we are." I just stared at my mug, smiled and asked "You want
another cup? I need another coffee." We spent some more time talking about
anything and when Marisha left she said "I am so happy we met." I responded
with a "So am I" and closed the door behind her.

It wasn't until after the holidays it all escalated. My porn addiction had
returned with a vengeance and one evening as I was _entertaining_ myself
Marisha facetimed me. I had jumped out of bed, thrown on a dress and rushed to
the living area before I answered the phone. She knew something was up and
asked "Have you been watching your cartoons again?"

"No," I replied automatically.

"You have, haven't you," she said with a cheeky smile on her face, "come on, be
honest."

"Okay, okay, yes I have." I replied reluctantly.

"I am so sorry then," she replied, "but you should really turn off your phone
then. What were you watching?"

"Just this movie about a woman who -- had a few friends over."

"And did she have a good time?"

"Better than a good time, she really was have the best time. She was quite
busy, sometimes even _entertained_ two at the same time."

"Wow, she was having a good time then. I just wanted to ask if it was okay for
me to come over. I'm bored and really need to get way from all the dorm."

"Oh yes, sure. Just give me an hour so I can freshen up a little." I replied.

"Okay, I'll be there in twenty."

"Marisha, no I --" but she disconnected and I really needed to hurry then. I
put away my laptop, took a quick shower and as I stood there in front of my
dresser I had a hard time deciding on what to wear. When the buzzer sounded I
was very nervous when I pressed the button to let her in.

I closed the door and when she saw me her jaw dropped. I wore a tight mini
skirt, high heels, a very revealing tank top and on my chest I had written
the word slut in all capital letters. "I wanted you to finally see the real
me," I said. She just looked at me and the word on my chest. She pinned me
against the door and we kissed again. This time we didn't stop, the kisses were
passionate and I put my arms around her.

We made our way to the couch, where she pulled up my shirt and started sucking
my breasts. It made me moan loudly, at some point I said "Wait!" I switched on
the TV, connected my laptop to it and started the video I was watching when she
called me. Marisha looked at it and watched the woman preparing herself in a
bathroom of some hotel.

"Are you ready?" a male voice asked her. The woman nodded and the man asked
"What are you about to do?" "I'm going to get gangbanged by seven delicious
men," she replied smiling into the camera. The shot changed to the bed, she sat
down and a black man started kissing her.

"She is my favorite," I said, "she's married and her husband let's her do this,
that's how much he loves her." On the screen a man started to lick her and
another man offered his cock to her which she began to suck. After a short
while the man who was licking her placed his cock against her little hole and
pushed it inside her.

"You see," I said with more enthusiasm than I intended, "No condom, not
protection at all. She loves the risk, she isn't even on the pill or something.
She has five kids now and they don't even know who the fathers are." I felt her
hand on my crutch and automatically I spread my legs.

"Oh," Marisha said, "you really like watching this." She slipped her hand
underneath my panties and when I felt her fingers enter me I couldn't resist a
moan. I looked into her eyes and she whispered "You really are a slut. I love
it." and she slipped another finger inside me.

Having fingers inside me and seeing that woman on my big screen TV excited me
so much. "Oh my god," I panted, "I'm coming, I'm coming."

Marisha placed her mouth near my ear and said "Oh, yes come for me you slut.
Come for me you little whore." She put so much emphasis on that last word I
came instantly, I had the biggest orgasm I had ever felt in my life. When the
video was over I started a new one and slowly we undressed each other. For the
first time I tasted a vagina and couldn't get enough of it. We spent the whole
night together, exploring each others bodies. By the time we fell asleep we
both were exhausted.

The next morning when I woke up the feeling of someone next to me startled me
at first. Then I saw her face and watched her sleep for a while. It was a
Saturday morning and quietly I got out of bed, put on my robe and walked into
the kitchen where I made myself a cup of coffee. I was leaning on the counter
staring outside and saw it was raining hard. Out of nowhere I felt two hands on
my breasts and leaned backwards. Marisha undid the knot of my robe and it fell
open. She began to squeeze my breasts and kissed my neck.

I placed my cup on the counter and she lifted me up, spread my legs and began
licking my pussy. I started panting and spread my legs wide for her, placed my
hands on her head and pulled her in closer. I wanted her tongue to go as deep
as it would go. "Oh yes," I moaned, "yes, fuck me with that tongue. Oh my Lord,
this feels so good."

Marisha rose up and when she kissed me I could taste myself which excited me so
much. Marisha opened a drawer, rummaged for a while until she found what she
was looking for. Her eyes got hard and I felt the cold steel of a kitchen knife
against my throat. "Now," she said, "You are my little slut now, my little
whore. You are going to make me some money and if you don't if you do not earn
me enough." She took a step back and punched me in the face so hard it made me
dizzy. Then another blow and another.

Then she kissed me and I could feel the sharp point of the knife against my
belly. She slowly pushed harder and a sharp pain went through my body. "Oh
yes," I moaned, "yes, push it in deep. I want you to. Push it as deep as it can
go." The pain made me come, the blood that was dripping down my leg filled me
with extacy as Marisha drove the knife deeper and deeper inside me. She had her 
tongue deep inside my mouth as she slowly slit my throat.

"Laura? Laura? Wake up!" I heard a voice shout from far away. I stared into the
frightened face of Marisha, I had been dreaming. "What were you dreaming? I
heard you say 'drive it in deep', what were you dreaming?" I felt flustered and
confused.
