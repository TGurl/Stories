# Chapter Three
The first few months at school weren't that special, besides from the weekly
D&D game nothing really special happened. I started working at the _Vagrant_
and loved working there. I got used to our skimpy uniform rather quickly and
got decent tips, in total I earned more working there than I would have at that
store. Carina was a good boss and we got along fine, as I did with the other
girls working there.

I didn't return to Lincoln Drive during that period, the narrow escape from the
police had scared me enough to stay away from there for a while. I didn't even
go there during the day time.

What didn't change however, maybe even got a little worse, was me changing into
my sexy outfit the moment I got home. That notebook got filled with even more
notes and I even kept some sort of a diary in there. I simply needed a way to
sort my thoughts. One day I decided writing them down in that notebook just
wasn't enough and I started one of those free blogs you could find on the
internet. _It's just me_ I called it and I started writing an entry almost
every day, mostly about my thoughts and how I felt. The more I wrote the easier
it got for me to really open up and talk about the fantasies I had.

I wrote about that morning I walked among the working girls, how I narrowly
escaped the police but mostly about how it made me feel. "The moment that car
stopped next to me, the moment I knew that man was looking at me as a sex
object was so satisfying. It was at that moment I knew I wanted more of this,
but I do not dare to go back there. What if I can't escape next time? Or even
worse, what if a man agrees to my prices? What do I do then? No, I am not ready
for that step. It's all just too scary."

Other posts were about the plastic surgery I longed for. "According to several
sites saline implants are the safest option and they give the possibility to
add more fluids. Silicone on the other hand will give a more natural look. I
just don't know yet, but I am leaning towards saline. Yes, if I do do this than
saline will be my choice. Just one thing I have to do before I take any action:
I will have to tell my parents and I do not know how they will respond."

The first semester had flown by and I had passed all the exams with mostly
great marks, some were okay and I could improve on them. The second semester I
mostly studied, worked and played the weekly D&D game. I had settled into a
routine and having the friends I had made playing the game sure made it easier.

Marisha and I had become much closer and we spent more and more time together.
I even grew closer to Ashley and the three of us went out on a regular basis.
Marisha finally admitted she really liked Matt a lot and Ashley and I made it
our task to get them together.

I also got to meet Liam, who had just been in Japan for a couple of weeks
recording for a upcoming cartoon or video game. He was quite mysterious about
it. We all got together at my place when the cartoon premiered on TV and we all
were so proud of him and cheered when his name rolled over the screen in the
credits.

All I am trying to say is that the group of misfits I met the first day? They
all became my friends and I was so happy that I had met them. There was just
one thing that bothered me, all the time I was with them I felt like I was not
being honest with them. I was hiding a part of me that needed to come out, I
needed their approval or at least their support and one Sunday I had invited
Marisha over. It was time for me to tell her who I really was and how I felt. I
just needed to confide in someone and Marisha was the best friend I had.

Marisha told me she would come by around 2 in the afternoon and the closer it
got the more nervous I became and when she finally knocked on the door it
startled me. I took a deep breath and opened the door.

Marisha could see something was up and said "Hey, what's wrong?" I asked her to
come in and we sat down on my couch. Again she repeated the question "What's up
Laura? I can see something's wrong."

"Marisha, can I trust you? I need to know."

"Sure you can. I can keep a secret."

"I've not told this to anyone and I am so scared of what you're going to think
of me or how you're going to react. But I need to tell someone, I can't hold it
in no more. Whenever I'm around you guys I feel like I'm lying to you and I do
not want to do that anymore."

"Yes, so what's up? You can tell me."

"It's not that easy. Maybe I should just let you read it instead." And I pushed
my laptop towards her. She opened it up and my blog appeared on the screen.

"I should read this?" Marisha said.

I nodded and retreated to the kitchen, watching her as she read all my posts. I
couldn't see any reaction on her face as she read every single sentence I had
written there. When she was done, a torturing ten minutes later, she got up and
walked towards me.

"Is that true?" she asked, "is that how you really feel?"

I nodded, still scared for what she was about to say.

"Well, it's a lot," she said, "it's really a lot. And I don't know how to
respond to all of it."

I almost started crying, I was so sure she was going to walk out and tell me
she didn't want to be friends anymore. I was so sure I had just lost her.

"So," she said, "you want bigger boobs."

I nodded again.

"And you want a smaller nose."

Once again I nodded.

"A bigger ass too. Well, welcome to being female I guess."

I was a little confused by what she meant to say and it clearly showed. "Girl,"
she said, "I want all of those things too. Look at my tiny ass."

I started to giggle and then she said "Laura, there's nothing wrong with you.
But if you want it, go get it I say. It clearly showed you did all the
research. But stop telling yourself that you're ugly, because you aren't.
You're beautiful, but I also understand that it's like talking to a brick wall.
So, you do you boo. Make yourself happy! That's the most important thing in
life. If you are happy the people around you will be happy too."

"Do you really mean that?"

"Yes I do. But how far do you want to go? I'm just curious."

"Well, there is this girl Anastasia. She's a Russian girl, she has this blog
about how she dreams of being just like Barbie one day. She's beautiful and
she's almost there. Just another few surgeries and she's a real life Barbie!"

I walked over to my laptop and showed Marisha some pictures of her. "Isn't she
beautiful. I want to be just like her, it's just perfection."

"Whoa, you like that? I would have never guessed. Since when do you feel this
way?"

"I've always felt it I guess. It's just when I moved here, on my own, I had the
freedom to explore that side of me. My parents would have never allowed it. But
I always was envious of the girls who looked like that. Whenever there was
something on TV about plastic surgery I was glued to the set. I told my mother
it was the surgery itself that intrigued me, but now I know it was the result
of those surgeries that wanted to see. How happy those women were afterwards."

"So now you are discovering that side of you?"

"Yes, I even bought clothes my parents would never allow, a pair of high heels
and it felt so liberating wearing those outside. I was finally allowing people
to see who I am inside. These clothes? These I wear because it was expected of
me. But I'm not that respectable girl in the inside. On the inside I am totally
different. On the inside I want to flaunt my femininity, I want to explore my
sexuality. That girl is dying to come out."

"So why don't you?"

"Because I'm afraid of what people might say, what my parents might say."

"I understand, but you need to be you Laura. You need to tell them that and if
they love you, and I'm sure they do, then they will accept it."

"I don't know about that."

"Sure they will. Do you trust them?"

"With my life."

"Then trust them in this too."

I knew she was right, but it still didn't make it any easier. We sat there
quietly for a moment then she said "I need a latte, do you need one too? Let's
go, it's nice outside and why are we sitting here?"

I got up, grabbed my purse and then Marisha said "You're going outside wearing
that? Oh no young lady, you go back in that room and change. I want to see the
real you when you come out, you hear?"

I was a little stunned, then giggled and rushed into my room. A few moments
later I came out wearing a rather revealing crop-top, a mini skirt and my high
heels. I had even done my makeup and Marisha said "Yes, that's better. Way
better, come on lets go." I smiled and followed her out the door.

As we sat at the coffee shop we chatted and it felt so nice she fully accepted
me for me, we even went out to get some more makeup for me. As a gift Marisha
bought me the biggest earrings she could find which still were very beautiful.
She even bought me a pink collar and bright, sparkly letters for it spelling
_SLUT_. Just outside the store we giggled as she put the collar all together
and put it around my neck. I wore it with pride and Marisha said how much fun
she had.

Back home as we sat outside on the balcony with a cold drink she suddenly said
"So, what would you have done if that guy had asked you how much?"

I was blown away a bit and just stared at her. Marisha looked at me and said
"Oh, you thought I had missed that part did you? Oh no, so what would you have
done? Would you have gotten into that car? And then? What would have happened
then?"

"I really can't answer that." I replied, "I don't know. I think I would have
panicked and run back to my car."

"But you said you were dreaming about it. You said that next time you might be
ready to take the next step. Are you?"

"I really don't know. But I am dreaming about it. I think I want to know how it
would feel like, giving that part of you for money. Somehow that intrigues me."

"Well, there are safer ways to explore that. You know that, right?"

"What do you mean?"

"Well, there are these sights girls can -- flaunt their body to men who are
willing to pay for it. All you need is a laptop with a webcam and you got one
of those. It's much safer than getting into a car with some stranger, isn't
it?"

"I guess," I said thinking about what she had just said to me. "Are you telling
me I should do that?"

"Oh no, I wouldn't dare. I'm just giving you an alternative. Something saver,
something you do from the safety of your own home."

"Thanks," I replied and really thought about her words and she was right. Being
on that street was way to risky and I needed an alternative way to explore that
side of me.

Just before she left I said "Please don't tell anyone about this, not just yet.
It was hard enough for me to tell you." Marisha nodded and said "It's safe with
me, just promise me to add some hints the next time we're together. Like those
earrings. Give them some subtle hints and I think it will be easier."

Right after she left I searched online for those sites she mentioned and saw
there were so many of them. Which one should I choose? I opened a few of them
but really didn't know what I should be looking for, they all had their
advantages. For now I decided not to act upon that impulse and really take my
time to explore this further. At least it had given me some ideas on which
steps I could take next.

Although my work at the restaurant was great and I got along with everybody
there I couldn't help but notice the girls with a little _more_ got higher tips
than I did. Even when we did exactly the same thing with the same group of
people, the only thing that was changed was the spot where they sat down. There
was one great example that happened within the same week. A group of young men
sat down in my section and we had a great time, I made some jokes and they were
very pleased with my service. They said so on the bill and left me a nice 50
dollar tip.

A few nights later that same group came in a bit later and they happened to sit
down in Daisy's section and she has, let's just say, a nice rack in front of
her. She was even a little slower than I had been and even mixed up on of their
orders, she still got a 75 dollar tip from them. It had to be her bosom that
pleased them, it couldn't be anything else. But I didn't complain to anyone
about it because at the end of the night I still had more in tips than she did.

Working at _the Vagrant_ had given me a some pocket money and I was very
pleased with it. Carina was so pleased with me she scheduled me more often than
some of the other girls, but at some nights I managed to do two sections while
they struggled to keep up with one. I did such a good job I became head
waitress within six months, which basically made me the boss over a few girls
almost 10 years older than me. There was just one who had a serious problem
with me in that position and she quit, most of us were glad to see her go.

What my extra bonus was I got five percent of all the tips, as I was not only
responsible for my own section I was also responsible for all the others and
when needed I would step in. At first the girls weren't happy with it, but when
they saw how hard I had to work for it they were willing to comply. One night
Daisy even said that I saved her butt that night and she handed me 20 dollars,
which was way more than the 5 percent we had agreed on.

Because of my new position I had to stop playing D&D and they were all sad to
see me go, the last game was a tearjerker. I had found my father just in time
for him to die in my arms from the wounds he had after a fight with a black
dragon. In the middle of the night I slipped out and confronted the dragon,
after an epic battle I failed in my mission and the rest of the party came just
in time to see how the dragon slayed me. His tail penetrated my heart, there
was no spell powerful enough to restore my life.

The party stood around me as the dragon flew off laughing. "It's okay," Jester
said with her last breaths, "the Traveler is with me and my father is calling
me. I will have to go now. Please revenge me and do me honor. It was my
pleasure meeting all of you. Dad? Is that you? Mom! I'm coming -- thank you all
for everything!"

"And with that Jester took her last breath of air, her body went limb. Her head
slumped to the side. Is there anything anybody wants to say?" Matt continued.

"Yes," Travis responded, "I stand besides her and do the military greeting I've
seen so many times. I summon my sword and hold it up to my nose and say: It was
hour honor fighting besides your side. Go with honor! We will take over your
fight from here."

"I walk up to her," Ashley said, "I kneel down and my whole body starts to
shiver. What begins with a low rumble in my stomach grows into an harrowing
growl filled with all the pain and anger I feel as I kneel next to her."

"You all hear that howl of anger and pain. In the distance you see flashes of
lightning and you hear the thunder. That howl goes for miles and miles and
everybody who hears it knows I great fighter, a mighty warrior has be slain."

Marisha has real tears in her eyes and says. "I just hold her hand and say. You
were and still are my best friend. I never knew what friendship was until I met
you. You confided in me and you showed me what a real friend is. I will miss
you so much, but I am so happy for you you are with your mother once more. Tell
them good things about me as I will about you to anyone who wants to hear. Rest
well, Jester and I hope you will be there for me when it's my time to come."

One after the other said nice words about Jester and they all made me cry. But
the words from Marisha hit me the hardest because when she spoke those words
she looked straight into my eyes and I knew she wasn't just talking to Jester,
she was talking to me too.

After that game we all were quiet and really didn't know what to say. It was
Sam who broke the silence in his typical way by saying "Come on it isn't like
Laura is dead, she's still here. Let's go somewhere and celebrate Jesters life!
I know for sure she would like that." I had to agree with Sam, it would be
totally according to her character and we did our best to be a little more
cheerful.

That evening was almost two months ago when I saw them walk in _the Vagrant_
and I watched them sit down at one of the tables in my section. I walked up to
them and said "Hey guys. What are you doing here?"

"We wanted something to eat and Marisha said she knew a nice restaurant so here
we are." Sam said. I looked at Marisha and gave her the oh-you look. She just
shrugged her shoulders and said "Well I heard good things about this place and
wanted to check it out." I chuckled and said "Okay then. Well let's start with
the menus and can I get anyone something to drink?" The all placed their orders
and I handed them all a menu. As I still had to attend to the other tables
there wasn't much time to talk to them, but it felt nice that they made the
effort.

I was standing at the bar, checking the orders I had put through when Carina
came up to me. "Aren't the people at table 3 your friends?" she asked and I
nodded. "Well, sit down with them for a moment. Take a short break, Emma can
cover your tables. It's just drinks for all of them anyway. Go and talk to
them, be with your friends. Looks like they came her for you."

I looked at her for a moment, got myself a glass of water and sat down next to
Marisha as that was the only free chair left. I slapped her shoulder and said
"You could have chosen to go somewhere else." Marisha chuckled and said "Why?
This is good food and it's a nice restaurant. Plus we get to see you again,
what's not to like here?"

All the others agreed and even Talliesin, who was mostly the quieter one, said
"Yeah, we all missed you. So we decided to come her to see you, even if you are
working." I smiled and said "Thanks you guys. I missed you too but I really
like this job and it's good money."

We talked for a while and after a few minutes I went back to work, when they
got up they left me a hundred dollar tip. On the receipt they wrote "Come back
to us, we miss you." and it made me cry a little. But I couldn't stop working
there, Carina made it so easy for me to combine my school with it and I
couldn't deny I needed the money.

The last two weeks before Christmas break I had to study hard and could only
work for a few hours. I had some of the most important exams coming up and I
really needed to concentrate on school if I wanted to go home for the
holidays. I spent all the time I had in the books and did some test exams on
the school website to see where I needed to improve. I passed the tests with
flying colors and was so happy I could go home.

My father picked me up from the airport and I was so happy to see him again.
"You look more mature," he said as he hugged me. "That's a good thing." he
added after it. I thanked him and got into the car. It was quite a bit colder
and I noticed I wasn't quite used to it anymore. When we got home my mother
welcomed me with open arms and said "Your old room is ready and waiting," she
said, "I've made the bed and you can just bring everything up there and come
right back. I've made your favorite."

"Thanks mom," I said, "but can I take a shower? Please?"

"Sure," she replied, "Just don't take too long. Dinner is almost ready."

After a short shower I stood in my old bedroom, the posters I had put up there
before I left were still there. "It's a real girls room," I though to myself
and wanted to change everything about it. I opened my suitcase and decided on
what I wanted to wear. I decided on a rather modest crop-top, a mini-skirt and
my heels. I sat down at my old mirror and did my hair and makeup. This was the
moment I was going to show them who I really was and what I liked to wear these
days. I pulled down the shoulders of my top a little more and went down the
stairs.

I took a breath right before I stepped into the living room. My mother didn't
say a word when she saw me and my father barely looked up from his paper. Then
my mother got up and I fully expected to tell me to change, but she didn't. She
had a huge smile on her face and said "Laura! You are beautiful! Wow, that
looks so nice on you. And those heels, I would never have thought you would
want to wear heels. Oh I love it! You made me so happy!" She turned to my
father and said "Look Andy! She's a proper woman now! I knew the Spanish in you
would come out one day. _Este es uno de los mejores días de mi vida._"

It was one of the few times I heard hear speak Spanish and I knew it was okay.
I smiled and felt so relieved. Maybe the rest I needed to tell them wouldn't be
as bad as I thought it would be. We sat down for dinner and I told them all
about school, my friends and my work at _the Vagrant_. When I told them wait I
was wearing as a waitress I could see my mother wasn't really happy with it,
but she said "Oh, how times have changed. But if you are happy then I am too."

This was as good a time as any, I thought and said "Yes, about that. There's
something I need to discuss with you." My mother stopped eating and said "Right
now? While we are eating?"

"It doesn't really matter when," I replied, "this is as good a time as any.
Living in Fort Dix made me realize things about myself, things I've always kept
hidden. Things I pushed away and now I had all this time on my own they all
came to the surface. Every thing."

"What do you mean?"

"Remember those surgery programs on TV I always watched?"

"Yes, I always thought you wanted to become a doctor." my mother said.

"No, it was never about that. I always watched them because I wanted to see
what it would be like to have them. I -- I want to have surgery. I want my nose
done, my boobs, my ass. Everything. When I look in the mirror all I see are the
things that are wrong with me. I don't know how to explain it really other than
the girl looking back at me isn't me. She's not who I am on the inside."

"Did you talk to anyone about this?" my father said, "You know there is no
shame with talking to a professional." He always said that ever since he
himself had gone to therapy to deal with the death of his parents.

"Well, I've done some research and because the thing that I want is so evasive
talking to a psychiatrist is mandatory, they won't do anything until I've
passed it. So I will, eventually."

"But you're such a beautiful girl," my mother said, "And what if something goes
wrong?"

"That's a risk I am willing to take," I replied, "I really need this mom. I'm
just not happy with who I am now. This body isn't mine. I want to be more
feminine, more elegant. I always have."

"Why didn't say anything when you still lived with us? I would have loved to
teach you how to use makeup." my mother replied.

"Because I always felt this was who you expected me to be. You always told me
to be independent, have my own ideas and thoughts. To be that respectable girl
next door. And I always dressed accordingly, not to sexy, always modest. But
that's not the girl I am, I want to be sexy. I want to be --"

"You want to be what?"

"I want to be the girls boys dream off. I want to be the girl they want to be
with."

"So you want to be a slut, a whore," my mothers voice sounded harsh and her
face was full of anger. I knew how she thought of women like that. "You want to
be a sex object, is that it?"

"Basically," I replied.

"Ay dios mío, I thought I had raised you better than that. Why would you want
to lower yourself like that?"

"It doesn't feel like that to me. And changing my appearance doesn't mean I hve
to act on it. I found this girl online who made herself look like Barbie, you
know the doll. She was happily married when she started her change and she's
still with the same man. They have three beautiful children." I left out the
part about her being a centerfold and posing topless for all the major
magazines. "All I am trying to say is if I am going to do this, I am not going
to change on the inside. I am just making the outside reflect who I am on the
inside. I am so insecure mom. I know I cover it with jokes and my sarcasm, but
it's all a front."

We were quiet for a while before I said "Let me ask you a question mom. When
was the last time you saw me with a boyfriend? I mean a real one, not the ones
I had when I was 11 or 12. I mean the ones after I turned 16, the ones that
really matter. Who was it that invited me to prom?"

She didn't answer and I continued "Exactly! No one. I had to go to prom with
Eduardo, my two year younger nephew. It felt so embarrassing, but I did it
because it made you happy. I went to prom with him, because you wanted to see
me in that dress. Did you know we didn't even dance once! We just sat there at
a table, him drinking one glass of soda after the other. I was so happy when it
was time to go and I was even happier when I could finally leave that school.
That was the reason I wanted to go to Fort Dix, I wanted a new life. Make new
friends, people who would accept me for who I really am and I found them mom.
Friends who love me and support me. Isn't that what's really important?"

"Yes," my mother softly replied, "that's important. But I still do not
understand. Why bring it up now? During dinner, right before Christmas?"

"What would be a better time, mom? After Christmas? After New-Years maybe? Or
what about after your birthday? Or mine? When mom?"

"I don't know," she said, got up and walked away. I sighed and almost started
to cry. My father patted me on the shoulder and said "Just give her some time,
she'll come around. You have to understand you're her baby and she doesn't want
to see you get hurt."

"That it dad, I am hurting. Every single day when I look in the mirror. Every
single second I think about it dad. Why don't I have a boyfriend? Why don't men
look at me? I am always in the friends-zone dad! I am always that respectable
girl you ask to come babysit. And now I've found the thing that could help me,
that could make me feel more like _me_."

"I am not going to say I understand, because I don't and maybe I never will. I
think you are beautiful just the way you are. But, if you really want this and
I mean _really_ want this, I will support you. You are my baby too and I hate
to see you like this. Come here pumpkin," he took me in his arms and said "I
wish you told us this sooner. Maybe we could have helped somehow."

"Maybe," I said, "but these past few months I've been thinking about it a lot
and it made me realize a lot. Like why I watched those shows on TV, why I
always felt unhappy on the inside. It's not that I just thought of it dad, I
really took my time and even talked to Marisha about it."

"Marisha? Is that one of your friends?" I nodded and he said "She's a good
friend then and if she's your friend, she's mine too." This was the longest
conversation I had ever had with my dad and after clearing the table and doing
the dishes I looked upstairs to see what my mother was doing. From the living
room my father said "Just a little bit longer pumpkin, she will come to you. I
promise."

It was around eleven when I went upstairs and got ready for bed. And just as I
was about to turn off the lights there was a soft knock on the door. My mother
peeked in and she clearly had been crying. "Can I come in?" she asked. All I
did was open the blankets and pat the spot next to me.

She laid down next to me and took me in her arms, like we had done hundreds of
times before. Finally she said "Look, it was hard to hear you say what you
said. You're my little girl and I think you are perfect. I also know that's
what all mothers say about their children. I just -- it just -- it feels like
I'm loosing you. I mean, if you change the way you look I will feel like I'm
getting a new daughter and that's hard for me."

"But --"

"Please let me finish. I've been thinking about what you said and it became
clear to me. Everything you said about prom, about everything. I should have
seen you were doing those things for me, I looked at the pictures from that day
and finally I saw how unhappy you were in those pictures. Sure, you had a big
smile, but your eyes told a different story. A story I hadn't seen before.
There many other things I remembered and all of them told me how unhappy you
were and that was what made me cry."

"I was happy too mom, a lot. Just not about things that were important to me."

"I understand." she said and looked at me with tears in her eyes, "I don't want
to see you unhappy anymore. If this is what it takes to make you happy -- then
I will be happy too. I just want to look at you as you are now, the girl I gave
birth too."

"But that's not who I am, mom. That's not the girl I feel I am."

"I know, but to me you are."

"I love you mom and thank you for being you."

"Now let's get some sleep, it's been a long day."

I woke up the next morning and smiled to see that my mother somehow had been
able to leave while I was sleeping. I still don't know how she does it. I took
a shower, got dressed and went downstairs. My mother was making breakfast and
cheerfully said "Good morning honey. Oh no, you're not wearing that. Take that
off and wear the clothes you want to wear." I smiled and said "Maybe later mom,
all I want now is some breakfast."

The day after Christmas I went back to Fort Dix, not only because I had to work
but also we had planned to spent New Years at Sam's place. I had never really
spent New Years with friends and I was looking forward to it. It was still a
few days until then and work started around three in the afternoon, so I had
plenty of time for other things I could do.

One of them was finding a nice dress to wear to that party, Sam had said he
wanted all of us to come formal and I really didn't have a gown or anything. I
spent two days looking for something I liked when I came across the perfect
dress for me. It was elegant and sexy and best of all it was not that
expensive. I tried it on and loved how it made me feel. I also got myself a
pair of matching heels and thought it was the perfect introduction of the real
me to the group.

The days flew by and it was time to get ready for the party, we were expected
to be at Sam's around 8, but I told Sam I couldn't make it until nine. I wanted
everybody to be there when I arrived. I did my hair, my makeup, put on some
very nice perfume I had gotten for Christmas. When I had put on my dress and my
heels I checked myself in the mirror. If only I had bigger boobs, I thought.

I had called an cab to bring me as it was almost impossible for me to drive in
that dress and I wanted to drink some champagne as well. The driver was so
friendly to help me into the back seat and complimented me on my looks. I
smiled and thanked him. When I arrived at Sam's place my heart was pounding in
my chest and I was eager to see their reactions.

I rang the bell and waited for the door to open. It was Marisha who did and her
eyes lit up when she saw me. "Wow," was all she said. Once inside she whispered
"Is this the moment?" I just nodded and she said "Wait here." She walked to
where everybody else as and shouted "Could I have your attention please? It's
my honor and pleasure to introduce to all of you. The fabulous Laura, lady of
the night, the dream of all men." It went quiet for a moment and I stepped into
Sam's living room. They were all dressed so nice, but I had clearly overdone it
a little.

Travis was the first to respond. "Wow!" was all he could utter. Ashley filled
in with a "That's a dress." and Talliesin was the one who broke the tension
with a "Where did you get that and do they have one in my size?" They all burst
into laughter and then one compliment came after the other. "You look so nice"
and "I would have never thought, look at those heels!" I loved it all.

We sat down and Sam handed me a glass of champagne. "Wow," he said, "this is
totally different from what I thought you'd be wearing. Not that that wouldn't
be nice, this is just way more --"

"Sexy?" I filled him in.

"Yeah, it's very nice though and you should wear this more often. You are just
so beautiful."

"Thank you, but there is just one thing I have to tell you guys and I know this
isn't the right time, but if I don't do it now I am afraid I never will. I want
to have plastic surgery, a lot of them. I want bigger boobs, I want a bigger
ass, a smaller nose. Everything."

"Why? Ashley asked.

"Because every time I look in the mirror I feel that a different girl is
looking back. That's not the girl I feel I am."

Ashley tilted her head a little and said "Seems fair. Okay then, can I come
with you? I've always wanted to do something about this big chin of mine. What
about you Sam? Is there anything you would want to have done?"

"My eyelids maybe, I hate the way they fold."

"If I were doing it," Marisha said, "I would let them fix my ass. Just a little
bit bigger and rounder. What about you Matt?"

"My nose, definitely my nose and my eyes. No more glasses or contacts? Pfew.."

"I would change my head," Talliesin said, "Just take it off and replace it with
a new one." Again he hit the nail on the head an everybody started to laugh.
But, above all what was most important to me, the had accepted me and shown
their support just by saying what they would get done. It felt liberating and
Marisha winked when she saw how happy I felt.

Half an hour before midnight Ashley came standing next to me. "Laura," she
said, "can I ask you a question?" I nodded and she continued. "There's been
this little thing that keeps bothering me. A few weeks ago, or maybe it's more
than a few months ago, I drove back home and had to go through Lincoln Drive
--" My heart froze and I kept my breath "and I saw these girls there," she
continued, "you know those _working girls_? Well, when Marisha introduced you
as the _lady of the night_ it hit me. Did I see you among those girls that
night? I always thought I had it wrong, but now I'm not so sure."

My mouth went dry and I didn't know what to say. "Not that I'm accusing you or
anything," she kept on saying, "I was just wondering." I took a drink from my
glass and softly said "You might be right." Ashley smiled and asked "What were
you doing there? Are you one of them?"

I shook my head and said "I just wanted to feel what it would be like."

"Oh, and how far did you go?"

"Not that far," I said, "the police came and I had to flee. I was lucky to get
away and I never went back."

"Would you have done it? I mean, all the way?"

"I really don't know."

"Ah," Ashley looked at me, smiled and said "Glad we got that cleared up." Then
she leaned forward and said "If you were one of them I wouldn't care, just so
you know. I think it should be a regular job, so those girls are protected.
Just to let you know." I sighed a breath of relieve and thanked her for what
she had said. At midnight we cheered, wished each other a happy new year and we
toasted. I took a spoon from the table and struck my glass with it. Everybody
turned their attention to me.

"With the birth of this New Year I wanted to thank you all for being my friend,
you have no idea what it means to me. But I need to tell you all about who I am
and more important _what_ I am. I've been soul searching for a long time now
and I've discovered things about myself that I'm longing for, things I want to
do and who I want to become."

"One of the things I found out is that I want to become a living, breathing
Barbie doll. I want to look as much like her as possible. That entails heavy
and sometimes dangerous surgeries. I want the biggest boobs possible and I want
to be a centerfold, maybe even be in some _adult entertainment_ videos. I want
to explore my sexuality and be the girl of dreams. I think what I am saying is,
I am a slut, a whore, a cumbucket and it's time for everybody to know it."

It was quiet for a moment and then Talliesin said "Okay, what else is new?"

I just stared at him and he said "Yes, I could see it in your face whenever one
of those fashion girls walked by. And I respect you for telling us, it tells me
that you trust us."

Matt chimed in with "Yes, that's for sure. If that is what you want to do, go
for it. I will support you along the way."

The rest chimed in and their expressing their love and support made me cry.
"You do not know how I have dreaded this moment," I said, "I am so happy I do
not have to hide it for you anymore."


