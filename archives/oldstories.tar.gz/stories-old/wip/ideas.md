- I start to work at the vagrant and get to know all about _the lifestyle_

- I learn that my parents are in it too and I confront them.

- I start the process of plastic surgery and get my nose fixed.

- I confide in Marisha and get her support

- after I have my new breasts I start to stream online to earn more money

- the streams lead to porn videos

- parents die in car accident, which gives me the funds

- parents come home and I have to tell them what I want to do, they either:
    - support me fully
    - disown me and throw me out
    - support me, but I have to pay for it all

