# Stories
I love writing stories, not that they are any good but still.
