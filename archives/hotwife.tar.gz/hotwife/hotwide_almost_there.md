# How I became a hot wife
by Transgirl, 2022

#### preamble
_This story is totally fictional. Any resemblance to a person, living or dead,
is purely coincidental._


## Chapter One
The music was loud, I could feel the beats in my stomach. It had been years
since I had been in a club like this and I felt a little out of place. Not that
I was the oldest one there, far from it, the last time I was in a club like
this I was still single and trying my best to look attractive to the other sex.
But I had been married to a man who I loved for almost five years now. Like
with all marriages ours had become stale, a rut. We had been together for
almost four years, living together for almost two before he asked me to marry
him.

At first it was exciting, exhilarating, then he got a very demanding job,
hardly was home and when he was he simply was too tired to do anything else but
sit on that couch, watching TV. Whenever I saw him laying there I felt sorry
for him and angry at him at the same time. He loved his job, it was everything
he always wanted, but to what cost? It was ruining our marriage.

Then he got promoted, told me everything would be better as he would have more
time to spend at home. Nothing was further from the truth. It was expected off
him to spend time at the golf club, _networking_ they called it. At some point
he only came home to eat and sleep, it was like I was running a hotel with just
one guest. Sure he was happy and all, but I wasn't. I wanted him to spend some
time with me, to be that boy again I fell for all those years ago.

One day it just got too much for me, I couldn't take it anymore. I was done
being his maid and I just cooked dinner for myself. By the time he got home he
didn't even check the fridge if there was any dinner, he just said "Hey, no
dinner?" I exploded, told him how I felt. Everything came out and I mean
everything. When I was done I shouted "No, don't say a word. Not a word. I do
not want to hear it. No more excuses. This is about me this time. I am lonely
in what should be a loving marriage. You can sleep anywhere you want, but not
in my bed!" I ran upstairs, fell on the bed crying.

The next morning the house was empty, I looked everywhere only to find out he
had been sleeping in the guest bedroom. He didn't even make the bed before he
left. It was a long, hard day for me. All I could think about was confronting
him when he got home, we needed to sit down and talk. About our future, about
everything. The later it got the more anxious I became and by the time I heard
him park the car outside I was shaking.

He didn't say a word when he came in, he just saw me sitting at the kitchen
table, got himself something to drink and sat down across from me. We sat there
in silence for a few minutes, the tension between us was so tight you could
almost cut it with a knife. It was up to me to start talking.

"We need to talk," I whispered with a broken voice as I was holding back the
tears the best I could.

"We sure do," he replied, "I thought we both were happy. I really did."

"Well, one of us is," I replied, "and it isn't me."

We were silent for another minute or two. "Aren't you going to say anything?"
he asked me, "I've been thinking about this all day, even my boss asked me what
was wrong. When I told him I had some issues at home, he sent me home. Go talk
to her, he said. But I don't know what the problem is."

"That's exactly it," I almost shouted, "You're so blind that you don't even see
that. When was the last time you took me to dinner? Or a movie? When was the
last time we did anything together? Huh? Tell me. When?"

"We went out two weeks ago," he replied.

"And where did we go?" I got more and more angry by the minute, was he really
this blind? "We went to a dinner party organized by your boss. You had a
wonderful time talking to your colleagues, your bosses and clients. I didn't
know anyone there. I sat on a chair in the corner all night, you didn't even
bring me a drink. I had one wine, ONE WINE that evening. The only time you
talked to me was to tell me we were going home. You talked about how nice it
had been, all the way home. You never asked me how it had been, not even once."

"Is that true? I thought I saw you talking to Madeline. Weren't you talking to
her?"

"Oh you mean that moment when she came up to me to ask me if I wanted something
to eat? Or that time when she offered me another wine? She was hosting the
party, that's what a hostess does. She mingles, talks to everybody, makes sure
they all have something to eat or drink. For the rest I was on my own. Those
women were talking about going to the spa or having their nails done. You know
I'm not like that, you know that I'm not that kind of girl. You always said
that's what attracted you to me."

"It still is," he replied.

I lowered my voice and said "Then show it. Not just tell me you love me, show
it to me. I feel like I mean nothing to you anymore, that I'm just _arm candy_,
someone who makes you dinner and cleans the house. I need to know you still
love me."

He leaned forward and I saw tears in his eyes. "Oh Laura, I am so sorry I hurt
you. I never meant to hurt you, I really thought you were happy too. What can I
do to fix this? Please tell me, I am at a loss here."

"I think we need some counseling," I said, "I really think we need some help.
Because I am so scared that if we don't we will be back here any time soon.
Will you go to therapy for us? You told me once you would do anything to have
me by your side, then you asked me to marry you." I felt the tears rolling down
my cheeks as I remembered that night when he proposed to me, it was one of the
best nights of my life.

"If that's what you want, that's what we'll do," he said with determination in
his voice. That was just another thing he had to prove to me, he had broken to
many promises by now.

"Just one more thing," I whispered, "and please be honest with me. I need to
know you're telling me the truth. Is there someone else?"

"What!" he blasted, "I cannot believe you would ask me something like that! No,
there isn't anybody else. I've never even thought about something like that.
Not once, not since the moment we first met. You are the one for me, Laura, the
only one for me."

I started crying "That's what I wanted to hear. Sorry for asking but I just had
to know, to see your reaction. I am so sorry!"

We hugged and he told me he understood why I asked. "I guess all kinds of
scenarios went through your head all the time you were alone. I accept your
apology and thank you for still trusting me." I trusted Travis with my life,
never ever did I not trust him. That trust just had taken some blows and it was
near breaking, but it never did.

The first time we had a session with Julie, our marriage counselor, I was sure
he wasn't going to show up. He had told me he was coming straight out of work
and it was almost time. Mere seconds before she called us in he ran into her
office. "So sorry, there was a huge accident on Lincoln. I was stuck there for
almost twenty minutes. I tried to reach you." I looked on my phone and saw all
the messages he had left. "Oh, I am so sorry. I turned off the sound as not to
disturb anyone here. I am so sorry."

The sessions with Julie did miracles for us. The first few sessions were just
telling each other how we felt and what we wanted from our marriage, we learned
to be open and honest to each other, not to hold anything back anymore. We
implemented a safe zone in our house, the kitchen table. Whenever either one of
us needed to talk we sat down there, told each other that it was a safe spot to
talk and opened up.

Julie gave us practical guides on how to implement a lot of things to make our
marriage better, the best one she gave us was _date night_. "Just pick a day,
any day. That day will be just for the two of you. Travis, you block that day
in your agenda at work. No more calls after let's say two in the afternoon.
When the clock strikes two, you are out of there. It's time to spend with your
wife. Go shopping with her, do the things she likes to do and share with you."

"Can it be three?" Travis asked with a slight smile.

"You can pick any time you want, but you have to abide by it. No more staying
late that day, no more excuses. Anything that has to be done after that time
can either wait or be done by someone else. The company will not go bust
because you took some time off to spend with your wife."

Travis turned to me and said "How about Thursdays? That way I can still finish
anything before the weekend on Friday." I just nodded okay. He turned to Julie
and said "I will block everything on Thursdays after three o'clock. That would
mean I could be home at half past three at the latest."

"Just make sure you keep that promise," Julie said sternly, "I've done this
with many couples and all of them said it was the best thing they ever did. The
people at their jobs now know not the bother them at those times. And another
thing, you will notice that it will relax you too. You two can do anything you
want during that time, just make sure you spend it together."

The first Thursday I couldn't wait for him to come home at half past three and
when he didn't show up in time I was sure he was breaking another promise. I
checked my phone to see he hadn't even called to say he was late. I felt myself
getting angry at him. That all melted like snow for the sun when he finally
walked in the door. He was wearing a tuxedo and had a clothes bag in his hand.

"Sorry I'm late, but I had to wait for the cleaners to finish this. Please take
it, prepare yourself. We're going out."

"Where?" I asked him but he wouldn't tell me. I took a quick shower, did my
hair and makeup, opened up the bag and gasped. It was a beautiful dress, just
like the one I wore when we got married. When I finally walked in the living
room, he knelt and handed me a corsage. "Laura Davis. I've neglected you for
far too long and I take all the blame. I am so happy you were willing to fight
for us and I have one little question for you. Will you marry me again?"

I started crying and nodded yes. I hugged him, kissed him and shouted "Yes,
yes, I will marry you again." We got into our car and drove to a small church
nearby. To my utter surprise he had invited my family over and we renewed our
vows together in front of them all. It was one of the best things he had ever
done for me. It was so magical and wonderful I fell in love all over again.
This was the man I loved, the caring, loving man.

Another thing Julie told us was to really be open and honest with each other,
which included our deepest, darkest fantasies. "Only when you share everything
with each other you will know how much you can trust each other." she said.
"That way," she said, "you can try and find ways to satisfy those fantasies.
You could role play for instance or maybe even try them for real. This isn't
easy, I know, just take it slow at first. Baby steps."

That was easier said than done, it meant really opening up and telling each
other what our sexual fantasies were. To get some more information I looked
online for help. I read stories about how good it had been for relationships,
but also that it had ruined others. One woman told how she discovered he had
rape fantasies, violent rape fantasies. She divorced him just months later
after which he acted upon his fantasy and brutally raped a young woman who
barely survived.

Reading all those stories made me afraid of what was to come, I totally didn't
want to do this. It's normal to have some secrets, I thought. I also knew
Travis really was into it and, like Julie said, we both needed to make
sacrifices to make our marriage work. Until then he had made the most, it was
time for me to make some too.

"So how will we do this?" Travis asked and I had no clue on how to start or
even where to start. We had been together for so long and I thought I knew how
to please him.

"I have no idea, let me just say that I would like to be charmed. Not just go
upstairs, do it and continue with the rest of the day. I like it to mean
something, I want to make love not just have sex."

"Ah, like that night when we renewed our vows. You were feisty that night."

"Yeah," I blushed, "like that. You made love to me that night, we both made
love. It meant something."

"That was a great night," he smiled and I couldn't help but giggle.

"Yes it was. Almost as good as when we did it for the first time. Remember? In
that stupid one bedroom apartment of yours. With those stupid football posters
on the wall, it felt like we were being watched all the time."

"Yeah, the walls were like paper there. I am sure everybody heard us."

I started to giggle again "Maybe that's what made it so exciting. I had never
felt like that with anyone before. I always thought it was you, but maybe the
fact we could be heard added something to it."

"Wait. What are you telling me here. Do you like it when there is some risk of
getting caught?"

I blushed, looked at him with my head slightly turned downwards and whispered
"Maybe."

"Wait a second. You are telling me that you, Laura Davis the most prudish girl
I know, secretly likes it when she could be caught doing it?"

"I not prudish," I replied, "just a little conservative maybe."

"You didn't deny the other thing I said, did you?"

"No, I didn't."

"So every time I wanted to -- _have_ you, I could have? Like that time we went
to the _Pussycat Dolls_? I wanted you so much that night."

"If you had made a move I might have responded." I said with a red face.

"Oh my god, now you tell me."

I giggled and said "Yes, it's always been a fantasy of mine. I'm just to scared
to actually do it. Sometimes I fantasize we're in public when were in bed
together."

"You do?"

"Yes, it helps me a lot."

"Wow, I never knew. Well, we might have to look into that."

"Okay, now it's your turn. What makes you tick?"

"Oh, I couldn't tell you. I know you will get angry and it's better that I keep
it to myself."

"That's not fair. Julie told us that it has to come both ways."

"That's true." He took a deep breath and told me about someone he met when he
was on a business trip. The man was sitting at the bar of the hotel and kept
looking at a woman who was sitting on the other end, talking to some guy. He
kept looking at her, not staring or anything, just glances and he had this
weird little smile.

"I sat down near him," Travis said, "gathering all my courage and then just
asked him. The man looked at me and said 'See that woman over there? The blonde
who is talking to that tall guy. That's my wife. She loves flirting with other
men, dancing with them, kissing them. Sometimes she even sleeps with them. But
she always lets me watch and we have the best sex after. I love her so much
that I am willing to give this to her. To let her satisfy her needs.'"

Travis was quiet for a moment, collecting his thoughts then said "Ever since
then I've been thinking about that. About how I would feel if -- but I know it
will never happen."

I was dumbfounded at first, couldn't believe what he had just told me. "What
are you telling me?" I asked him, "Do you want to see me with another man? What
are you saying?"

He took a deep breath, started to shake a little and said "I've been watching
these videos online. Of couples who _swing_, as they call it. Most of them say
that it strengthened their relationships. That they loved each other so much,
trusted each other so much they were willing to _open up_ their relationship.
Give room for other people, so to say."

If it hadn't been for the safe space I think I might have smacked him at that
moment, but I kept you our agreement, calmed myself down and said "That's a lot
to think about. I don't know how to feel about that."

"I know and I understand. We were meant to be open and honest, weren't we?
Well, this is it. There isn't anything else. That's my sexual fantasy."

I was quiet for a moment and then asked "So, when we're together do you ever
think about someone else? Imagine that you're with someone else?"

"Sometimes I do," he replied, "like you imagining we're somewhere else, I
sometimes thing about that. Yes."

I swallowed my pride and said "Okay then. That ruined the night for me." and
walked away.

There was some tension between us for a few days, I had to process what he had
told me and it was a bitter pill for me to swallow. Then one evening when he
got home I sat at the kitchen table again. When he sat down I said "I am sorry
about how I reacted, but it wasn't easy for me to hear you say that. Let's just
find a way how we can -- satisfy -- that fantasy. Let me just tell you I will
not sleep with anyone, but maybe there's a way we can make it more real."

"I would love that," he replied, "And I've been thinking about it too. I am not
sorry for telling you as it is the truth. I am rather glad I finally did, it
lifted a weight from my shoulders. Maybe we could try that role playing thing,
like we go to a bar and pretend we don't know each other. Something like that.
We could fulfill both our fantasies, we could do it somewhere more _dangerous_
and I could pretend you're someone else."

"I could wear a wig," I replied just to indicated I was willing to make another
sacrifice for him, "I mean, I could look like someone else. We could make up
back stories beforehand, not tell each other anything and play it out during
that evening. You could win me over all over again, sweep me off my feet like
you did the first time we met."

We both got more excited about the idea and that's how I ended up at this bar,
in this club wearing a nice dress and my wedding ring on the nightstand back at
our house. That night I was Iris, a woman who just got divorced, without any
children. I was waiting for Travis to come in so we could finally start the
role play, but it had been half an hour already and I started to think I was at
the wrong club.

Suddenly a man came standing next to me. "What is a girl like you doing in a
place like this?" he said. It couldn't have been cheesier and it wasn't Travis
who was saying it. I looked up and the man smiled with a beautiful smile. He
was quite handsome and I wished I still had the one thing that kept men like
him at bay: my wedding ring. I smiled slightly and said "Sorry, I couldn't hear
you. The music is quite loud."

The man laughed and said "We could sit over there, it's a little quieter. Or I
could just buy you a drink here." I stared at him for a moment and said "White
wine would be nice." The man chuckled and ordered two drinks, a wine for me and
a scotch for him. He sat down on the stool next to me and said "Well, you still
haven't answered my question. What's a girl like you doing in a place like
this?"

"Oh, you really expected an answer? I thought it was just one of those openings
men use on women. Like 'come here often?' or 'Did it hurt when you fell from
heaven?'."

The man laughed and said "Yes, I suppose it was something like that. Touche.
No, it was a real question. You don't look like you're comfortable here, I saw
you look around as if you were looking for someone. I just thought you might
want some company while you were waiting, that's all."

"You weren't wrong. I am looking for someone." I was amazed by how easy it was
to talk to him, he had something about him that was disarming. "Look," I
continued, "I can't do this. I am married and my husband is about to walk in.
We're going through a rough patch and reliving the night we met was supposed to
rekindle something. But it was a stupid idea. I just don't feel comfortable
doing this. And I have no idea why I just told you that. I mean I don't know
you at all."

"Well, my name is Mike and I'm 35, not married, no kids. I have a good job, I'm
a lawyer, and let me see what else can I tell you about me. Oh yes, I went to
Yale after I graduated high school. My parents are Bill and Mary, they are
still together and live out their retirement in Sunnyvale. My sister is
married, has two kids and she owns a gym. Her husband also works there. Any
questions?"

I chuckled, shook my head and said "Iris, my name is Iris. Or at least for
tonight it is."

"So you want to know all about me and all I get is a fake name?"

"Yes, for now that has to suffice. I am to scared to tell you who I really am,
just not ready to go that far."

"Okay, point taken. Iris it is." We talked for quite some time and I really
started to like him, the fact he didn't push anything helped a lot with me
feeling more comfortable in the whole situation. I laughed at his jokes, we
just had a good time talking. From the corner of my eyes I caught a glimpse of
Travis at the other end of the bar, he was looking at us with a slight smile on
his face. Suddenly I realized I actually was acting out his fantasy. He was
watching me being with another man, all of a sudden the whole situation changed
for me. It could have been the wine talking but I noticed I was having fun just
talking with this guy who I had just met. As soon as I realized that I felt my
nipples harden, it became a little moist between my legs. I hadn't felt like
that since the night I met Travis, I recognized the feelings I had.

I glimpsed at Travis as I sipped from my wine seeing him making the smallest of
nods as if to say 'Go on. Go for it.' I turned my attention to Mike again and
started to flirt with him a little. The moment I felt his hand on my leg I
panicked, said I had to go to the bathroom and walked away. Once inside I
looked at myself in the mirror whispering "What are you doing? You can't do
this, you're married for gods sake." But I had to admit the whole situation
felt exhilarating, exciting and it had turned me on a little. There was just
one thing: I couldn't do it. I had to stop.

I took out my phone, ordered a cab and told Mike I had to go. Within minutes a
man asked if anyone had called a taxi and I waved to him. Travis followed me
with his eyes and I ignored him as we had agreed that we didn't know each other
after all. After a 10 minute ride I walked into our home, sat down at our
kitchen table. I needed the safe space, I needed to talk. I dad barely sat down
when Travis arrived.

"What happened?" he asked and he sounded really concerned.

"Nothing, I just panicked. I needed to get out of there, I just couldn't do it.
I felt so guilty while I was doing whatever it was I was doing."

"Guilty? Why? You weren't doing anything wrong. From where I was sitting it
looked like you were enjoying yourself."

"Yeah, I was. Until he put his hand on my knee. Suddenly it became all too real
what he wanted and I just -- panicked. I am so sorry, but I can't do this
anymore."

"What if," he said softly, "what if we don't do it here where we could run into
someone we know. Would that make it easier? We could plan a trip to, let's say
Fort Dix. You always wanted to go there, don't you?"

I nodded. Fort Dix wasn't just the capital, it was the largest city in the
country too. I always wanted to go see _the old Town_ as it was called, the
city center where a lot of original buildings from the 17th century still were
standing. I wanted to see the _Guild master's Hall_, the place where our
independence was signed. Maybe even go see the _Blooming Grove_, the cemetery
where the original settlers were buried. All of them pillars of our culture and
I would love to go there.

"That would be nice," I said quietly, "maybe we could go there for a long
weekend."

"Why not a week, or maybe two." Travis said, "I've got quite a few days at
work, I could finally take that vacation you always talked about."

"Yes, could we rent an apartment or something. No hotel, I always wanted to
experience the real Fort Dix. Cook our own meals, go for groceries and the
likes. Could we do that?"

"Sure, why not? Let me take care of it. I want to surprise you."

"Okay," I said softly, "Travis? I am sorry about the way it went tonight. I
just couldn't help it."

"That's okay." He hugged me and whispered "Baby steps, just like Julie said,
baby steps."

## Chapter Two
It had been months since that night during which we held on to _date night_,
something we both started to look forward to. Even at his work they now fully
knew they couldn't bother him during that time. Travis even started working
less during the weekends, said no to offers of going golfing more often than he
accepted. It was like we had just started dating again.

Then one Friday he turned off the alarm clock in the morning and just turned
around again. "What are you doing?" I asked him, "Shouldn't you get up and go
to work?"

"Nah," he said, "We still have a few hours."

"A few hours? For what?"

"Until we have to be at the airport?"

"Airport?"

"Yes, didn't I tell you? We're going to Fort Dix. Tonight we have dinner at a
nice restaurant right outside the apartment I rented."

"You did what?!"

"I rented an apartment for two weeks. We're going on a holiday, just the two of
us."

"What time do we have to leave?"

"In about five hours."

"Five hours? I need to pack. You could have told me, three hours? That's not
enough time."

"Calm down, it's all been taken care off."

"What?"

"Yes, we're flying out there with just our carry-on bags. Tomorrow I am taking
you shopping and we'll buy you a while new wardrobe. Everything you want and/or
need."

"What?"

"I'm taking my wife shopping for the day. I will not complain and we're going
anywhere you want to go. Get you anything you want. I want to treat my wife on
a shopping spree."

"But I need --"

"Then we will get it there. They got shops. We will bring the necessary stuff,
nothing more. Anything else we will get there. You wanted to experience Fort
Dix, this is the way to do it."

"Oh my God," was all I could say, "but what if --"

"No buts, no ifs. Relax, it will all be okay."

It felt strange standing at the gate with just one small bag, I had to beg
Travis to bring my own makeup and jewelry. I also wanted to bring my own
brushes and other toiletries. In the end we had more with us than he had
wanted, but I just couldn't leave without it. Not having my clothes, just the
ones I was wearing, was hard enough for me.

We landed in Fort Dix almost five hours later as our flight was delayed for at
least an hour. Walking through the terminal I checked the signs which told us
where the taxi's were. "Next one left," I said but Travis had other plans. He
turned right and walked straight into a rental business. When it was our turn
he said "Good afternoon, Davis. We have reserved a car."

The girl checked her computer and said "Ah, yes. Welcome to Fort Dix, Mr Davis.
The car is ready for you. Please read and sign these documents while I make a
copy of your license." Travis did all the paperwork and about 15 minutes later
we got into our rental car.

"You wanted to experience Fort Dix," he said with a smile, "You can't do that
from a taxi, can you?" He checked his phone and set the navigation to some
street and house number. It took us almost 45 minutes to get there and I gasped
when I saw it was located in one of the oldest parts of Fort Dix. It was just
beautiful there. "The old town is just a few blocks from here," he said, "we're
also very close to _Baker Street_ and _45th avenue_." I just stared at him with
my mouth open, Baker street was renowned for it's theaters and 45th avenue was
_the_ shopping street in the world. All the major fashion labels were there.

He slowed down to almost a halt as if he was looking for something. "Where is
it?" he mumbled, "Where is it?" Then his eyes lit up saying "There it is." He
turned left, stopped in front of a gate and got some sort of credit card from
his wallet. As soon as he held it in front of a sensor the gate opened and we
drove inside. "If you see lot 12 -- never mind there it is."

We got out of the car, collected our things and stepped into the elevator. We
got out on the 12th floor where he opened the door of apartment 43. It was a
beautiful apartment, tastefully decorated and way bigger than I would have
imagined. "How -- what -- how did you get this?" I stumbled.

"Ah, yes. I told my boss about our plans. He told me he owned this apartment
and he offered it to us. We can stay here for two weeks for free. He gave it to
us as a anniversary present."

I was shocked, nailed to the floor, he hadn't forgotten. He hadn't said a word
about it the whole week. Previously he would have gotten me flowers or
anything. On our anniversary he just went to work and didn't say anything when
he got home. He even asked for a rain check on our date night, it was an
emergency he said. I was so sure he was telling me the truth, especially when
his boss called I could hear them discuss things as he had his boss on speaker
in his office. His boss also sounded agitated. It all had been a rouse.

"You lied to me," I said, "You lied."

"No, I was preparing a surprise. Didn't you think Mark was convincing? He had
me fooled."

I slapped his shoulder and said "You! You! This is beautiful, thank you. And
happy anniversary darling."

"Happy anniversary sweetie. I love you so much and this, this is all for you."

After we unpacked the little luggage we took with us, we went shopping for
something nice to wear to the restaurant. Where he surprised me again with the
anniversary special. It was such a lovely dinner and as we walked back to the
apartment I pulled him into an alley. We kissed and I pressed my body against
his. We moved further down the alley where I reached for his fully erect penis
and guided him inside me. "Oh yes," I whispered in his ear, "yes, this is what
I wanted. Fuck me, make me come." He slammed his dick deep inside me and it
didn't take me long to have an orgasm. He came all over my face and while I was
cleaning myself the best I could I couldn't stop giggling. It had been so
exciting and the release of all that tension made me giggle uncontrollably.

The next day we went shopping and we spent loads of money, way too much for my
liking but Travis insisted. He even bought me a purse I saw on 45th avenue, the
one I always wanted. "Don't worry about it," he said as we were walking back,
"There is another surprise I haven't told you about. I got another promotion. I
am the new CTO, Chief Technical Officer. I report straight to Mark now."

"What? Congratulations!" I hugged him right there on the street, "But does that
mean you have to work more?"

"No," Travis replied, "Date night was part of the negotiations and I had to
give them something."

"What? You cancel date night?"

"Yes, and I've changed it to date weekend."

"What?"

"Yep, from Friday at 4 til Monday at 9 I am all yours. No more golfing, no more
working weekends."

"Are you serious?"

"Yes, I am. I might be home a little later during the week, but I'm all yours
from Friday til Monday. These past few months have made me realize how much
I've missed being with you. You are not only my wife, you're my best friend.
And I want to make up for all the time I've neglected you. Starting with this
trip. We're going to spend my bonus on us this year, we do not need it for
anything else."

He opened the door to the apartment and when we were inside I asked him "How
big was the bonus?"

"Enough to last us a few months."

"How much?"

"150,000 dollars."

"What!?"

"150,000 dollars."

"You are kidding me. 150,000 dollars?"

"Yep, and we're going to spend it all these two weeks."

"No we aren't," I replied sternly, "We're going to spend a lot, but not all of
it."

He laughed "Okay, okay. Now you know why I said not to bring any luggage. We
couldn't bring our new stuff home if we had."

The next few days we spent seeing all the sights and Travis took a lot of
pictures with the new camera he had always wanted. His old camera had been
broken for a while and as he didn't have the time he stopped doing what he
loved to do: taking photos. I had to pose for most of them and I loved it, he
was so good at it too.

We also went to the nature reserve just to the east of Fort Dix. It had been
protected since the early 1800s and there was a memorial dedicated to the day
the first settlers arrived at these shores. There were several trails you could
walk and we decided to try the longest one as it would lead you along the most
beautiful sights at the park.

Almost halfway we were going up a rather steep hill and I was happy to see they
had carved steps into it. When we reached the top the view was amazing. "Stand
there," Travis said, "I want to take a picture." I leaned against the fence,
raised my arms and Travis took a few photos. Suddenly I felt an urge and just
as he was aiming his camera at me I pulled down the top of my dress exposing my
breasts to him. The shutter sound indicated he had taken the photo of me
standing there topless.

I pulled my dress up as quick as I could and burst into laughter when he showed
me the photo on the small screen to the back of his camera. "If you ever show
that one to anyone but me," I said sternly. He chuckled and said "Don't worry,
our little secret." We sat down on one of the benches, enjoying the view. It
was later in the afternoon and the sun started to set lighting up the sky in
all shades of red and purple. It was just beautiful. We looked at each other
and kissed. I smiled, stared into his eyes and placed my hand on his crutch.

Moment later I got on my knees in front of him, unzipped his pants and
struggled a little to get it out. I softly kissed the crown of his penis and
licked it. Then I opened my mouth giving him a blow job. I had closed my eyes
only to open them when I heard the shutter sound coming from the camera. Had he
really taken a picture of me sucking his cock? Yes he had and I giggled. I took
his cock in deeper and gagged on it. Giving him a blow job, right there on the
summit of that hill where anyone who walked up could catch me doing it really
excited me.

I stood up, took off my panties and straddled him. I placed my wet slit against
his hard pole and kissed him as I guided him inside me. He pulled down my dress
once again and I leaned backwards as I rode him, my breasts flopping in the
summer breeze. It didn't take long for the both of us to come and this time I
urged him to come inside me. "I'm not on birth control anymore," I whispered
right after he had exploded inside me, "I want to have a baby. I want your
baby." He put his arms around me, kissed me and said "I want one too."

After straightening our clothes we continued the rest of the trail and got back
to the car right before it got dark. At the apartment we made dinner and went
to bed where we tried to get pregnant one more time.

That Saturday we went out to a bar near our apartment. According to our
neighbors it was the best in town. "If you want to have fun, you have to go to
_Sloppy Joe's_" she said.

That afternoon we sat on the balcony enjoying the sun, we had been away for
every single day until then and just wanted to stay in for a day. "Maybe we
could try that thing again." Travis suggested, "You know, the two of us going
separately."

"Maybe, you want us to? I mean I can just be myself this time."

"Yeah. Let's try it one more time. I really would like to see if that role
playing thing is for us."

"Okay, we've done everything I wanted to do. It's time we do something you want
to do. It's the least I could do for you, you've done so much for me already."

"You deserve it. One other thing." He paused for a moment and I was eager to
know what he wanted to say. "I've been thinking the past few days and I think
it's a good idea." He turned to me before he said "You know that thing you were
always talking about when we met? That business idea."

"Oh you mean the cupcake bakery? What about it?"

"Well, why don't you look into that a little more. I mean we could spend the
bonus on that. Do some market research and what not. See if it's viable."

"You mean that?"

"Yes, we agreed to pursue my career first. You don't even like working at that
office. It's time we are going after your dreams. I am going nowhere any time
soon, I've reached my top. Let's see what you can reach."

I jumped up and hugged him. "Yes, yes, I do. Oh Travis, I love you so much. It
would mean the world to me."

"I know and I want the world for you. So let's do it." I kissed him a few times
more, then got up to get a notepad. I sat down next to him and started writing
down the first ideas I had. He was so happy to see how enthusiastic I was and
how many ideas I had.

After dinner I took a shower, did my hair and makeup, put on a nice dress and a
pair of heels. When I walked out Travis whistled saying "Wow, I knew you
cleaned up nicely, but this, this is something else." I blushed and thanked
him. Stood in front of the mirror in the hall as I put in my new earrings. "Go
get ready too," I urged him.

Half an hour later Travis was ready too, it was almost ten when it was time for
us to go to _Sloppy Joe's_. We had agreed I would leave first and he would come
about half an hour later. Just as I was going out the door, I turned around,
took off my wedding ring and placed it on the kitchen table. Travis put his on
top of mine, we kissed and I walked out the door.

It was about a ten minute walk to the bar and from a distance I could already
hear the music. My heart was beating faster the closer I got to it. I stood in
line for a few minutes, handed the bouncer my id feeling flattered that he
insisted to see it.

I walked into a nice bar with some chairs in front and a large bar in the back.
There were a few people sitting at the bar talking to each other. Behind the
bar a girl in her twenties came up to me and I placed my order, a dry white
wine. I looked around while she was preparing my wine. There were a lot of
photos on the wall, all of them from inside the bar. "That's Joe," the girl
said when I looked at the large photo at the back of the bar. "He opened this
bar in the late 60s. He passed away a few years back, you should have been here
when we celebrated his life."

"I can see he means a lot to you," I replied.

She nodded "Yes, yes he does. But what daughter wouldn't say that about her
dad."

"He was your father? Oh, I am so sorry for your loss."

"Thanks, but it's okay now. He was sick for a really long time. We all made our
peace with it and we all were with him when he passed."

"That's nice," I replied not really knowing what to say.

"But back to today," she said, "New in town?"

"You could say that, why do you ask?"

"All the people who come her for the first time stare at all the photos. It's
kind of a thing."

"Busted, I guess. I'm just here for two weeks. I rented an apartment down
the street. People kept saying to come here, so here I am."

"On your own? You came here on your own? Good on you!"

"Yeah, I just needed a break. Had a bit of a rough time the past few months. So
I thought maybe coming here would help."

"And did it? Help I mean."

"A little," I wanted to say more but she interrupted me with a "Hold that
thought, I want to hear more." She walked over to a man waving for her
attention, gave him his order, helped another patron before returning to me.

"Sorry for that."

"Oh no, you're working. I fully understand."

"So coming here helped a little. Do you mind me asking what happened?"

"Ah you know, relationship troubles. I don't want to go into it, I came here to
get my mind of it."

"I understand," she said, "just broke up with my boyfriend too. Found out he
had been cheating on me. The bastard. So I threw him out of my house."

"Good on you, um, what's your name?"

"Marisha," she replied, "my name is Marisha."

"Hi, I'm Laura. Pleased to meet you."

We talked for a while longer until it got to busy for her to spend more time
with me. I just watched her work for a while and checked my watch. I had been
there for almost an hour and didn't see Travis anywhere. He should have been
there by now. I got up, looked around if I could see him and made my way to the
doors with the words _Dancing_ and _Live Music_ painted on them in bright
yellow letters.

As I opened one of the doors the music got a little louder and I found myself
in sort of a lock. The music got way louder as I opened the next doors. There
were lights spinning, lasers and on the podium at the far end a band was
playing music from the 80s and 90s. The girl had a beautiful voice. I walked a
little more to the front to watch the band, still keeping an eye out for
Travis.

Sitting down at one of the tables near the dance floor I started wondering
where he could be. I wanted him to come to me, I wanted to have a nice time
with him. As I sat there watching the band a man came up to me, held out his
hand and asked me to dance. I waved him away, but he insisted. I finally gave
in and felt a slight sensation when he put his arms around me. We danced for a
while and he spun me around. During the second time I caught a glimpse of
Travis standing at the far end, leaning against the wall. He had a large smile
on his face as he raised his glass of beer to me.

With a shock I realized what he had done. He had asked this guy to ask me, I
was sure of it. This wasn't what we had agreed on, I also remembered what I had
said. 'It's time we do what you like to do.' the words rang loudly in my ears.
A that moment I wished I hadn't said them, but I had and I wasn't one who broke
her promises. She I leaned into it, shook off the shackles I had put on myself
and decided to just have fun.

The man was a really good dancer and I started to enjoy myself. It was just a
dance, I kept telling myself, just a dance. When the song was over I applauded
the band as they said they were taking a short break. I sat down at my table
again and the man I had been dancing with sat down across from me.

"That was nice," he said.

"Yes it was, thank you."

"So, what do I call you?"

"Laura," I replied.

"Hi Laura, I'm David. I saw you sitting here and I thought that girl wants to
dance. So I put on my dance shoes and just asked you. I am so happy you decided
to come with me."

"Thank you, it was fun." I still felt a little reserved, especially knowing my
husband was mere yards away watching all of this.

"Can I get you anything? Another one of those?" he pointed at my glass and I
nodded yes. While he was at the bar ordering our drinks I looked around once
more, couldn't find Travis anywhere. 'Stop looking for him,' I whispered to
myself, 'This is what he wants me to do, so just have some fun.'

David returned with our drinks and we talked for a while, until the band
started playing again. That's when he pulled me back on the dance floor and I
started to have fun. It was nice to be dancing again, especially as it wasn't
Travis' favorite thing to do. On top of that David was a really sweet guy and
very easy to talk to. He had a beautiful smile and deep blue eyes I could
loose myself in.

When the band started playing a slow song he put his arms around me and I put
mine around his neck. He was a little taller than Travis, then it just
happened. We looked at each other and kissed. Carefully at first, then a little
more passionate. In the end I felt his tongue in my mouth and I opened as wide
as I could. I couldn't believe what I was doing, I was kissing this guy who I
just met right there on the dance floor.

When the song was finished we sat down in one of the booths to the side and he
slid right next to me. Put his arms around me and kissed me again, this time I
leaned into him, putting my arm around his neck, my fingers in his hair. I knew
Travis was watching and somehow that really excited me. When we stopped I took
my glass of wine to take a sip and saw Travis sitting at a table across from
us, halfway turned to the band while still keeping an eye on us.

As soon as our eyes crossed I winked at him and leaned back into Davids arms,
we kissed again and I felt his had on my bosom. I moaned softly as I felt him
softly squeeze my right breast. "I know a spot where we can go," he whispered.
I looked at him, not knowing what to say. It all went so fast all of a sudden.

"Sorry, I said. I've just had a hard breakup. I'm not ready to go there yet.
I never planned to let it go this far."

"That's okay," he said, "I understand. Just so you know, you just have to say
the word."

I kissed him again, felt myself getting wet and really wanted to go with him. I
just couldn't get myself to actually do it, I had already crossed so many
boundaries by now. I just couldn't make myself cross any more. We had a lovely
night for the rest that remained, he even walked me home. Just before I went
inside we kissed one more time, our tongues dancing around each other. He
tasted so good and I really wanted him to come inside with me. But I couldn't,
not like this. Not on a lie.

As we stood there in the pale light coming from inside the building I said
"David, I have to be honest. I can't lead you on. I didn't have a bad time, I'm
happily married. As a matter of fact, my husband is watching us from across the
street. We had a rough patch and as a part of counseling we told each other our
sexual fantasies. He told me he loved to see me in the arms of another man. I
never thought it would go this far. It was just supposed to be a little dance,
a little flirtation here and there. But something happened when we were on that
dance floor, I just couldn't help myself."

"Okay," he said, "that's quite a lot." He turned around, saw Travis standing
there and waved to him to come closer. "And your name isn't Laura, is it?"

"That part was true. We tried it one time with fake names, back home. That
totally didn't work. So we came here, to a place where nobody knows us. That
way we could use our real names."

It was clear that David wasn't pleased with the whole situation and I felt so
sorry for him. He was caught in something that we had created. "I am sorry
David," I said, "We should have been honest with you. I just couldn't let you
go without knowing the truth. I couldn't lead you on like this."

David sighed. "That's one thing, I guess." he said, "Just know that you did
something stupid today. At least you were noble enough to tell me. Have a good
night now, I'm going home." With that he just walked away, Travis took me in
his arms because he knew how much this hurt me too. I almost started to cry,
but could hold it in until we were in our apartment. At that point I just
broke, told Travis I never wanted to do something like this ever again. We
needed to find another way, an honest way.

Travis was flabbergasted by what I said. "Do mean that? Do you really mean
that?"

I nodded slowly and said "Yes, I had a good time. It was exhilarating, exciting
and I had fun. It even turned me on a little when he touched me like that,
especially when you sat there watching us. I don't know why, but I did. I just
couldn't let him go not knowing the truth."

"It's one of the many reasons I love you so much," Travis said.

We stayed for another week where nothing really happened, we went sightseeing
some more, went to see a musical and all the other things tourists do when they
are in another town. Over all it had been a good vacation and we left feeling
well rested. It was time to get back to our regular lives and see what the
future would bring.

## Chapter Three
In the weeks after our trip I started looking into starting my own little
business. I quickly found out a cupcake bakery was not the thing I should be
chasing, there were larger companies already in that market and they were
actively buying out smaller ones. It wasn't something I wanted to do. If I were
to start something I wanted it to last.

We had several ideas, but nothing that really lit that fire so to say. I was
still working part-time at that office and Travis settled down in his new role
as CTO. He had kept his word about being off during the weekends and the bond
between us grew ever stronger because of it. Despite trying I didn't get
pregnant and I started to doubt myself. The more we tried the more I wanted it
to happen and every time I got my period it was a blow to my confidence, my
self esteem.

We went to see a specialist where we got the worst news we could have expected,
I was incapable of having children. I had growths around my ovaries, benign,
but they restricted my tubes and the eggs just couldn't reach my womb. They
suggested a surgery, one that would be very hard on my body and with just a 10
to 20 percent success rate it wasn't something I was willing to do.

Especially when she told me that if it didn't succeed I would go through
immediate menopause. I was 35 years old and did not want to experience that
just yet. Having my period each month was made me female, next to having
breasts and a vagina. And although it wasn't the most pleasant thing I had to
go through, I didn't want to loose it just yet.

I went through a face I can best describe as mourning, I mourned my unborn
children, the ones I could never have. At least none of my own. But I knew it
had been the right decision for me and Travis supported it fully. Although he
couldn't fully understand what it meant for a woman, he did his best and I
loved him for it. He did the one thing that he could do for me, being there for
me and listen.

Starting a business wasn't the first thing on my mind anymore, sure I didn't
really like working at that office but there were some nice people who worked
there and most of the time it was okay. Besides that I only worked for three
days a week, it wasn't that we needed the money or anything.

Online I found a support group of women who went through almost the same thing
as me, they helped me a lot. I even started to think about fostering or maybe
even adoption. Talking to them gave me a new perspective, ever so slow I
started feeling good about myself again. I made my peace with it and the sun
started shining again.

There just was this one woman in that group, it was something she said that
triggered me. In one of the chats we had she wrote 'ever since my father died I
wanted to have a baby. But I can't, not since that attack. That monster took
that from me.'. I didn't dare to ask her what had happened, figured she would
tell me whenever she wanted to. I just couldn't get rid of that feeling we had
met somewhere.

With a shaking hand I clicked on the send button. It was a private message to
her in which I asked her who her father was and if he had owned a bar. Within
seconds she replied "Yes, how do you know that?"

I replied telling her about the night we talked, totally sure she wouldn't
remember me but she did. "Yes, you were that lady with the wig. You said you
had some problems and came over to forget. I didn't see you anymore after that.
How are you doing?"

"I am better now. But I didn't tell you the whole truth. Yes I had some
personal problems, but not with a boyfriend. With my husband. We went through
counseling and she suggested role play. We tried and failed at that, but the
other things she said worked. We're still together and our bond is stronger
than ever."

"Wow, that's good to hear. I knew you were hiding something, but all of our
patrons are. That's nothing new." We send messages for over an hour until she
had to go to work. We communicated like that for weeks, until we exchanged
phone numbers. It felt so strange to me. We had met by accident and yet I felt
such a connection to her. Even Travis liked her after they talked.

During one of our calls I told her about why we were in her bar. "Yes, he
really wants me to do that. And I met a guy at your bar, we kissed, made out I
could say."

"You did? And what did Travis do?"

"He just watched and smiled. I can't explain it but it did turn me on, a lot.
More than I will ever admit to him."

"Wow, that's something. Just one question. If you liked it and Travis liked it,
what's stopping you?"

"I don't know. I really don't."

"Well I think that's dumb. He basically gives you permission to cheat on him.
That's not the right word. He gives you the room to explore your sexuality, to
see how far you're willing to go. You know what? There's this club here in
town, one especially for couples who like to change partners. Maybe there's
such a thing near you. You wouldn't have to lie or role play. You can just be
you and see if it's something you like."

"That's a great idea," I replied, "I would never have thought of such a thing.
Thanks, I think I might look into that. Maybe even surprise Travis with it."

"Just be prepared to see some nudity, that's what happens in those places."

I chuckled and said "I know. I understand. It's so nice to talk to you about
this. You don't judge me, thank you for that."

"Hey, working at a bar remember? I've seen it all."

"That's true. Can I call you later? I need to do some groceries and stuff."

"Sure, I just have to work at three, that's around six your time?"

"Something like that. Bye Marisha, thanks for listening."

"Always."

After searching for a while I finally found a club where they were very
welcoming to couples who wanted to explore. The woman I talked to assured me
there wouldn't be any pressure to do anything. "There are lots of couples who
come here just to have a good time. We offer the rooms for the ones who want to
take it a step further. Sure we do not oppose nudity, that's why we are
strictly adults only. All I can say is come and see for yourself one day, if
it's just to have a nice night out, it's okay."

We had been driving for almost two hours and all this time Travis nagged me
about where we were going. "You will see," I replied, "I've got it all
planned." The navigation guided us flawlessly to a small hotel, just outside a
small town deep in the mountains. It was so beautiful there and Travis had a
huge smile on his face. He had always loved the mountains.

I parked the car near the entrance and with our suitcases we went inside. The
girl behind the counter greeted us and we checked in. We had a beautiful room,
nicely decorated in the overall theme of the hotel. With lots of wood on the
walls, oak tables and chairs. Everything gave the room that cottage feeling, it
was just beautiful.

An hour or so later we explored the immediate surroundings of the hotel, stood
at the sign indicated all the trails that were there and just enjoyed the fresh
mountain air. "Oh I am going to enjoy taking photos," Travis said with a big
smile on his face, "Thank you for this. This is the best."

We stood on a small bridge, near a small waterfall. I turned to Travis and
said "You were there for me when we got the news. You did your best to
understand, you were patient and just there for me. I will never forget that.
You supported my decision, something I know has been hard on you too. This is
my way of thanking you. But this isn't all of it. Tonight after dinner I have
another surprise for you, something I hope you will like."

"I can't wait to see what it is. Or you could just tell me now."

"No, that will ruin it. We are expected to be there at nine. So we need to be
ready. A taxi will pick us up at 8:30. It's all been arranged, all you have to
do is be ready."

We spent the rest of the afternoon exploring some more, Travis took some more
photos and we just enjoyed our time together there. During dinner I could
hardly eat, I was so nervous about what was to come. Finally it was time to get
ready and we both changed into something nice. The woman had said "Just keep it
casual, a nice dress, a nice suit. Don't overdo it."

When the phone rang to inform us about our ride it startled me. I was excited
and anxious at the same time. The driver dropped us off at the entrance of
_Club Agatha_, Travis paid him and with a shaking hand I pressed the doorbell.
A woman in her forties opened the door. "Hi," I said, "I'm Laura Davis, we
called the other day."

"Ah yes. Welcome, welcome, nice to see that you're on time. Come in, come in."
I looked at Travis and he had this look on his face as to say 'what is this?'.
I took his hand and we stepped inside. The women walked in front of us saying
"Please follow me. We have to do some paperwork, before we can go any further.
I know, I know, it's dumb but the state requires it so we just do it."

We went into a small office and the woman sat down behind a desk. We sat down
in the chairs across from her. "Now," she said, "Welcome to my club. I'm
Dorothy, the owner and proprietor of this club. It's mandatory for us to screen
our guests so I will need some form of ID, so we can confirm your identities.
It's also mandatory for me to say that issuing a false ID or pretending to be
someone else is a crime in our state, punishable by up to 5 years of
imprisonment. You also have to sign these documents, stating that I informed
you about it and that the club isn't liable for anything that happens after you
leave this establishment."

Travis shook his head and asked "What is this for a club?"

Dorothy laughed and said "Oh yes, now I remember. This is a surprise for you.
That is it, isn't it? Yes, well let's just say we are a club for adults, where
we are more -- lenient with what happens here. Besides a bar, a dance floor and
something to eat and drink we offer other services too, to those who want to
take their night to another place, a more intimate space so to say."

Dorothy leaned forward and said "I know you are new to this, so let me say it
more clearly. We are a club for people who like to swing, to change partners.
To be with someone outside of their relationship. We offer a safe space to
people who want a more open and honest relationship with their partner. But!
And this is a big one. We do not condone pressure of any kind, if you just want
to come and have a good time, that's perfectly okay. Some of our regulars came
here for a long time before they took the next step. They all know it takes
time for some, others don't ever go there. They just retreat to a room with
their own partner and -- let's just say, enjoy each other company."

Travis was a little dumbfounded, but when he looked at me he smiled. "This was
such a good idea. Thank you."

"I just thought it might be what we needed. A safe place where we can just see
what happens, no pressure and above all no role play. We can just be
ourselves."

Dorothy started talking again. "Now, just to make sure you fully understand.
This is a safe space for everybody. We do not discriminate, on anything.
Straight, gay, lesbian, trans, light, dark, we don't care. We're all here to
have a good time. Understood?" We both nodded.

"Okay, then there is one more thing. This is sort of a tradition here. Turn to
each other and look your partner in the eyes. Now, repeat after me. This is a
safe space." We both repeated everything she said.

"We give each other the freedom to explore, to have fun. Everything we do
inside will stay inside. We will not be angry or upset when we leave. This is
just an experiment that we both agree to, without any pressure or ill will.
This is our choice and we grant each other the freedom to have fun."

When we were done Dorothy lead us into the bar, she showed us around,
introduced us to some other people who were already there. At the back of the
bar she stopped at a big red door. "This is off limits if you do not want to be
confronted with sexual acts. This is the big room. It's just a big space where
people can enjoy each other. If you want more privacy then you go in there."
She pointed at another red door in the corner. "A stairs will lead to the
second floor. There are rooms available. Now, I've informed Laura about the
prices. That includes everything, drinks, food and even the condoms if you need
them. It's all included. Well, that's about it. Just one last thing, if you
decide to come back we won't need to do this all over again. This is just a one
time thing. I hate it as much as you do. Now hurry along, have a good time. Go"

We sat down at a table and Travis got us something to drink. "What do you
think?" I asked him, "and be honest. If you don't like it we can go."

"I'm not sure yet. Let's just wait and see. I mean we're just arrived and
there's hardly anyone here."

"Okay," I replied, "just wanted to be sure. I was so nervous coming here, but I
think I'm a little more comfortable now. Let's just agree on one thing. No
matter what happens, we will not hold this against one another. This is
something we both wanted to try."

Travis nodded "Sure, I promise. Let's just wait and see."

We sat there for a while watching the people come in. It was clear to see who
were the regulars, they kissed to say hi and some of the women were dressed
very sexy. A man stepped into a booth and started playing music, he turned on
the lights and the dance floor was officially open. Two of the women started to
dance and more people came in.

After about an hour a couple came up to us. "New here?" the woman asked.

"New to all of this," Travis replied.

The woman smiled, sat down next to him and said "That's okay honey, we all were
new at one point. I'm Linda and this is my husband Brian. We're regulars by now
and we just love it here. So what are you two looking for?"

"We don't know," I replied, "We're so new to this. We don't even know if this
is something for us."

"Ah," Brian replied, "then I've got just one advice. Don't rush into it, do not
feel you are pressured. If you don't want to do something just say so. It's an
unwritten rule here and no really means no. But if you're taking the plunge and
go the extra mile, do it for real. Don't do it because your partner wants you
to."

"Yes," Linda continued, "we've seen couples break up after a while. Just
because one of them thought they wanted it for their partner. They crossed
lines they shouldn't have. All I can say it worked for us, we have never been
this close."

"How often do you come here?" I asked.

"Oh about once a month. We have agreed that we give each other the space when
we walk in the door. The moment we leave it's just us again. We don't do this
at home. It's a great way to start this lifestyle. Some of the people here have
totally opened their relationships, we haven't. Only within these walls, under
this roof."

A voice sounded over the speakers. "Ladies and gentlemen, welcome to club
Agatha. The night has officially started and tonight we want to open it with
our monthly raffle. For all the new people, let me explain. This isn't your
ordinary raffle. We pick a ticket out of this hat and if you hear your name you
can come up and hear what you can win. If you don't just shout no and we will
draw another name. There is just a catch: we will give you a challenge. You can
refuse and we will draw another name. If you succeed we will give you the
price. It's that simple. Understood?"

Everybody cheered and the DJ drew the first name. A woman screamed and rushed
up. The DJ drew a ticket from another hat and said "Okay, do you accept to walk
up to anyone but your partner and give them a kiss? If you do you will win this
nice set of lingerie." The woman nodded, walked up to the man closest to her
and kissed him. She screamed again held her new lingerie up high and walked
back to her seat.

Another few names were called and the challenges got more daring with every
name they called. "And the last one, ladies and gentlemen, the last one will
win this wonderful day at the spa. Fully paid for, courtesy by James over
there. Give him a hand ladies and gentlemen. Okay, the last name is -- Laura!"

I was in shock for a moment when I heard my name. I looked at Travis and he
said "Go on, see what it is. You can always so no." With a red face I got up
and walked to the front. The DJ put his arm around my waist and said "Well,
Laura. This is a nice price, so there has to be quite the challenge don't you
agree?" I just nodded, I was shaking so nervous was I.

"Oh, don't be scared. She's shaking, people. Let's give her some encouragement.
We're all here to have some fun. Nobody wants to hurt you. As I said, you can
always say no and we will draw another name, okay? Okay. Well, here it is. You
can go to the spa, any time you want within the next year if you -- strip down
naked and dance on that podium for the whole next song."

I looked at him with wide eyes and felt uncomfortable and excited at the same
time. I looked at the people staring at me, some were cheering me on. I turned
my head to Travis and he also encouraged me. I slowly lifted my hands, lowered
the straps of my dress, took a deep breath and pulled it down. Everybody
cheered as I pulled the dress down all the way. I stepped out of my dress and
walked over to the podium. The DJ started to play the next song and I started
to move. I watched another woman pick up my dress, indicating she would look
after it for me.

The more I moved the more people started to cheer and I got more confident. I
grabbed the pole, wrapped my leg around it and people cheered even harder. I
giggled and halfway through the song I had so much fun. I bent over, shook my
breasts and even spread my legs wide, covering my vulva with my hand. When the
song was over everybody applauded, whistled and even the DJ was a little
impressed. The woman handed me my dress and I put it back on.

"Wow, Laura! Ladies and gentlemen, I think she won the price! Give her another
hand. Laura everybody!"

As I walked back to our seat everybody complemented me and I sat down next to
Travis still laughing. "That was fun," I said as I kissed him.

Travis smiled and said "I never thought you would actually do it. I am so proud
of you." For me the ice was broken, but I could see Travis felt a little
uncomfortable still.

"Do you want to go?" I asked him, "Please tell me and be honest."

"No, I just don't know what to do when someone approaches us."

"Just be you," I said, "be the man I love. If someone is interested, just talk
to them. Don't think it has to go anywhere, just have a good time baby. You can
do whatever you want to do. Just as you give me my freedom to do what I just
did, I want you to have that same freedom." We kissed and got up from that
table, we mingled with the other couples and just had a good time.

A very nice man called Jacob complimented me on my dance and he introduced his
wife to us, Mandy. We talked for a while when Mandy got closer to Travis, he
looked at me and I just nodded to say it was okay. Jacob put his arm around me
and I felt myself starting to tingle. Mandy took Travis by the hand and they
sat down in one of the booths. When I turned to see what was happening after a
few minutes I was glad to see him smile, a lot. Then I noticed she had her leg
over his lap and her hand on his crutch. Instead of making me angry I felt
proud, proud that he was still attractive to women besides me.

Jacob had his arms around me as we danced and he pulled me even closer when a
slow song started to play. I put my arms around his neck and didn't resist when
his hand ended up on my ass. He softly squeezed it. After that song we sat down
in the same booth as Mandy and Travis. Her body was pressed against his torso
and I could see his hand on her leg. The lipstick on his face told me they had
been kissing and it turned me on.

Moments later we found ourselves on one of the rooms upstairs. Within seconds
Mandy was sucking on Travis's fully erect penis and Jacob slowly pulled down my
dress. I laid back on the bed, grabbed my husbands hand as Jacob began to kiss
me all over. Mandy took of her dress too and now both the women were fully
naked. Mandy looked at me, crawled towards me and put her arms around me. She
pulled me closer and Jacob told Travis to let us go.

Mandy stared into my eyes, pressed her naked body firmly against mine. It felt
so good feeling her soft skin. Our mouths were close together but not touching,
very carefully I started to touch her too. She moaned softly, her hands went
all over me finally resting at my breasts. She slowly went down and started to
lick my nipples, I couldn't resist a growl. She knew exactly how to treat me,
how to fully turn me on. At some point she spread my legs and softly licked my
clit. I had never been with a woman before and this was just so good. I placed
my hands on her head and pulled her in closer. She drove her tongue inside me
as deep as it would go.

After a few minutes she stopped and said "I think she's ready. Come here the
both of you. Travis, please sit next to her. Take her hand, this is very
important for a woman. She needs to know you are supporting her. Let her know
it's okay." My heart was beating so fast, was this really happening?

Travis took my hand, kissed me and said "It's okay. I want you to explore this.
Please enjoy yourself." I turned to Jacob and watched him put on a condom. He
spread my legs and got on top of me. I turned back to Travis, looked him in the
eyes and moaned when I felt him place his cock against my vulva. I squeezed my
husbands hands as Jacob slowly entered me. I moaned loudly and saw how much
Travis loved it. "Oh yes," he panted, "this is so nice. I want you to enjoy it,
have fun with it."

Jacob slowly started to pump and with every thrust I moaned a little louder. I
was fucking another man and my husband was holding my hand. It totally send me
over the top and I shouted "Oh yes, fuck me." Mandy laughed and said "She's
done it. Aren't you proud of your wife? She's pleasuring my husband and now I
am going to pleasure you. She pulled off Travis's pants and got on top of him.
She guided him inside her and started to ride him. At that moment I realized
she hadn't used a condom and when Jacob pulled out for a moment I took his off
too.

Feeling him enter me without protection send me over the top and I came almost
instantly. "Oh yes Jacob, fuck me. Fuck me hard." I looked over at my husband
and saw how much he enjoyed being with Mandy. He had his head in her breasts as
she moved her hips. I turned my attention to the man on top of me, locked my
legs around him and whispered "Come inside me, I want you to come deep inside
my pussy." Jacob started slamming me, harder and harder. I came multiple times
and when he finally exploded so did Travis. Just the thought of him coming
inside another woman gave me another orgasm.

With Jacobs seed still dripping out of me, Mandy laid back spread her legs and
showed me her pussy filled with my husbands cum. She then laid next to me,
pressed her soft body against mine and kissed me. Her fingers slipped inside my
cum filled pussy and she made me come once more. Then she lifted up my leg,
placed hers underneath me and pressed her cum filled pussy firmly against mine.
She started to move her hips and every time our clits touched it send
sensations through my body. We came both at the same time.

About ten minutes later we all showered together and put our clothes back on.
We had a lovely rest of the night until it was time for us to leave as the club
was closing. It was almost 3 AM. Mandy and Jacob dropped us of at the hotel and
once inside our room. Travis took me in his arms, lifted up my dress and took
me right there on the table. He had never been like this, he just ravaged me
and I loved every second of it. He came so hard inside me, mixing his cum with
Jacobs and that turned me on even more. I had a huge orgasm. That night we fell
asleep in each others arms, both knowing this wouldn't be the last time.

## Chapter Four
In the weeks after our weekend at the club I felt different, I can't really
explain it but for more myself perhaps. Even my co-workers noticed that
something had changed. "You seem to glow," one co-worker said. I just told her
that we found a 
