# How I became a hot wife

## Preface
_This story is purely fictional. Any resemblance with any person, living or
dead, is purely coincidental._

## Chapter One
We had been married for almost five years now and like every marriage ours too
had become stale and a runt. It just wasn't the same like when we first moved
in together almost eight years ago. We both had demanding jobs, hardly were
ever home together and acted more like room mates than husband and wife. That
doesn't mean we didn't love each other anymore, it just was different. For me
it had changed into the love I felt for my family, I still cared about him a
lot, a whole lot, just not as I did eight years earlier.

It was during one of those rare times we both were home when we both exploded,
he did one of the things that irritated me so much. It was something stupid,
something so small I can't even remember what it was anymore, but it was enough
to make me angry. For the first time in our relationship we had a shouting
fight, everything came out. We both felt the stress of our work, being in a
not-so-living relationship and everything else. In the end I sat at our kitchen
table, crying. Not because he had said painful things or something like that,
it was more how helpless I felt.

Travis sat down next to me. He took my hand and softly said "Look, I still love
you. I still want to be with you and if you are willing to fight for this, then
I am too. But we both need to want this, it can't just come from either one of
us."

I nodded, looked at him and for the first time in years I saw that boy, that
man I had fallen for again. I had missed that caring, loving man so much and I
wanted him back. "Maybe we should make some changes," I whispered, "maybe we
need some help."

Travis nodded and said "Maybe we do. I want to fight for this Laura, let's find
someone who can help us."

That evening I just had to call Marisha, she was my best friend since
kindergarten and had been the maid of honor at our marriage. She knew me better
than anyone, I had told her things I haven't even told Travis, if there was
someone I trusted it was her. She listened to me for almost half an hour while
I was sobbing on the phone. Then she said "If you want to fight for this, and I
think you should, then I know someone you can see. I'm willing to call her for
you if you want me too. Matt and I went through a rough patch too and we went
to see her. She's so good at what she does."

"Would you? Please, I am sure we won't make that call. Maybe if there's an
appointment we both can make the time to go, otherwise we will just put it off
for some reason or another."

A few weeks later I sat down anxiously in the waiting room of Julie Miller, the
counselor recommended by Marisha. I checked my watch to see what time it was,
Travis had mere minutes to arrive, but I was sure that it would start later.
Weren't all therapists or doctors like that? Mere seconds before it should have
started Travis stormed in. "I am so sorry," he said, "there was a huge accident
and I was stuck in traffic for almost twenty minutes. I tried to call you."

I looked on my phone and saw all the missed calls from him. "I am so sorry. I
turned off the sound." Travis just nodded and sat down next to me. I could see
he was quite anxious too. I took his hand to reassure him, knowing how much he
hated things like this and I was grateful he had even come.

During that first session we mainly spoke about how we met, how we fell in love
and what made us decide to want to spend the rest of our lives together. Julie
skillfully exposed the feelings we still had for each other, by the time we
left I saw our relationship in a different light. I could see now how much
Travis still wanted to be with me and it hadn't been an easy session. Julie
asked the hard questions, the questions I didn't dare to ask.

"I think, and correct me if I'm wrong, but I think she's asking if there is
anyone else." she plainly said with a face that didn't reveal any emotion.
Maybe that's why it didn't offend Travis as it would have if I had been the one
asking that question. Julie was neutral in this, just like she said when we
started.

Travis looked at her, then at me and with a slight tear in his eye he said "No!
No! No, there isn't anyone else. I would never..." It was the way in which he
said it, with indignation, he felt offended by that question. It was such a
relieve to hear him say that, it had been on my mind for quite some time and I
started seeing signs that weren't there. Even Marisha thought I was crazy for
thinking that. "He would never," she said, "no, anybody but Travis. He has way
too much honor and respect for you. I am so sure of it."

We both felt deflated when we left that office, like a lot of tension between
us had been released. "Let's go out for dinner," Travis said, "I think we've
earned it." My heart jumped as it had been so long since we went to dinner
together and I nodded profoundly. "Yes, let's do that," I replied with a smile
on my face. I felt the first batch of butterflies in my stomach, just like a
did when I first met him.

"No Marisha," I shouted, "I hate sports ball and I am not going."

"But it's the school football team, please. It's the state championship, please
come. Do it for me, please? I don't want to go alone." It was the sad look on
her face, her puppy eyes that persuaded me to go.

"Okay, okay, I'll go. But I won't cheer." I huffed.

Hours later we sat down in the stands and I was amazed by the number of people
who were there. I never liked football, thought it was a game for idiots who
liked hitting people. But Marisha's brother played in the team and she wanted
to come see him play. A marching band was performing on the field, walking all
kinds of figures as they played. At least something that I like, I thought.

When the players came on the field Marisha jumped up and cheered loudly "GO
TIGERS!". She even jumped up and down. When everybody sat down I noticed how
close we were to then bench of _our_ team. One of the players turned around to
see if he could see anyone he knew, when our eyes met I felt a jolt going
through my body. We kept looking at each other for a while, it may have been
mere seconds but it seemed like ages for me.

Marisha had noticed and asked "Seen something you like?"

I looked at her, bumped her shoulder and said "No, what makes you thing that?"

"That look on your face," she laughed, "and the fact you're turning red when
you lie." I giggled and turned away from her, she just knew me too well.

After the game, which they lost by just a few points, Marisha wanted to wait
for her brother. We stood near the changing rooms as player after player walked
out. Everybody there told them it had been a good game and did their best to
cheer them up. My heart skipped a beat when that boy walked out, I quickly
turned around so he wouldn't see me.

Then I heard Marisha shout "Liam! Liam! Over here." Her brother walked up to us
and Marisha told him it had been a good game.

"Yeah," Liam said, "It was tight. If we just had blocked that last pass. It it
hadn't been for Travis here, it might have been a touch down."

"Hi Travis," Marisha said, "Pleased to meet you. This is Laura." And she made
me turn around to greet him. I was flustered, didn't know what to say but "Hi"

"Hi," Travis responded, "I saw you in the stands, didn't I?"

I just nodded, threw some imaginary daggers at Marisha and said "Yeah."

Travis chuckled and about ten minutes later he walked me home. Marisha had very
tactfully made sure that we would be alone for a while. During that walk I fell
for him. Sure he was one of the football players, but he also was kind and into
nerdy stuff like me. We had a lot in common as well as lot's of different
interests. Just days later we kissed for the first time, the rest is history.

When we arrived home we sat down on the back porch and just talked like we used
to do. It had been such a long time since we just sat down to enjoy each others
company. More butterflies rose up within me and I felt like I fell for him all
over again. We had a lovely dinner together and agreed to do this more often.

The next session we Julie we told her about it and she said "Why don't make it
a regular thing? One day a week. The both of you clear your schedules and block
it. No more work, no mare excuses. Just the two of you. Call it _date night_ or
something. But you both have to tell everybody you cannot be bothered with
anything work related."

We both agreed and cleared our schedules, the first time possible was three
weeks later as we both needed to finish some projects and go to appointments
already made.

The first time my assistant walked into my office and with a big smile she said
"It's almost three. Date night" She chuckled when she left and I knew how much
this amused her. Lori had said she thought it was a great idea when I told her
about it. "I might even ask Dwayne to do the same," she said, "But I see him
more often than you see Travis. Go, do it. I will make sure nobody bothers
you."

Just after three I collected my briefcase and purse to leave, when my boss came
walking up to me. "Laura, before you go can you --"

"Oh no," Lori interrupted, "It's date night and Laura has to leave. This can
wait until tomorrow, can't it? Just give me it and I will make sure she looks
at it first thing in the morning. Bye Laura, have a great night. See you
tomorrow."

Tom was flabbergasted by Lori's action, one of the reasons I liked her so much,
she didn't really care who you were, she always looked out for my best
interests. I just smiled, waved and walked out. As I walked away I could hear
Tom grumble and resisted a laugh.

I arrived home before Travis, or so I thought. There was a note on the kitchen
table. "Hello my love, I didn't forget. Please get ready and meet me at
_Dante's Kitchen_. Travis." Dante's Kitchen? How did he arrange that? It was
only the best restaurant in the city and there was a waiting list.

An hour later I arrived there, saw Travis standing outside wearing his best
suit. He looked so smart. He complemented me on my looks and said "This is the
best restaurant in town and well, I tried but we didn't get a seat. Sorry. So I
thought of the next best thing." He took my hand and guided me to the back of
the restaurant. On a field I saw a table and two chairs, with a candle in the
middle. One of the waiters stood next to it and held the chair for me.

"Welcome to _Dante's field_," the boy said, "We do not have a menu, but we have
prepared a lovely dinner for two. Would madame like something to drink while we
wait?" The food was delicious and this might have been the best dinner we ever
went on. It was a nice Summers evening and it was just magical.

When we walked back to our cars I asked "How? Just how?"

"Oh," Travis laughed, "Dante owed me a favor and when I asked him he thought it
was such a good idea. He might do it more often, in very special occasions." I
chuckled, this was so typical for him. He always thought out of the box, which
made him so good at his job. At that moment I hated we had gone there in our
own cars, but we made up for it at home. We just sat down and talked again.

"I've missed this so much," I said.

"Me too," Travis replied, "it's nice to just relax and be with my best friend.
Come to think of it, I might call him." I stumped his shoulder and he chuckled.

We kept going on our date nights which became well known where we worked,
people started to adjust to it and even said "Oh wait, that's Thursday
afternoon. You can't make that. Let's find some other time." was something I
started to hear more and more. Having this time together made us feel closer
again and one day Travis surprised me with a long weekend to Malacau for our
anniversary.

We had wanted to go there for our honeymoon, but that didn't work out because
we couldn't afford it. We went to Fort Dix in stead. And although it was a
beautiful honeymoon, Fort Dix isn't the Caribbean by a long shot. "It's the
honeymoon we always wanted," he said and I was smitten that he even remembered.

We both cleared our schedules and were so excited to go. During the month we
had to wait we couldn't stop talking about it. Travis even dusted off his
camera, he had always loved photography but with his job he simply didn't have
the time for it. I loved seeing that twinkle in his eyes again, that boyish
enthusiasm in him. He even tested it by taking pictures of me which made me
giggle.

Finally it was time for us to go, we had spent a few days packing for it and
were very excited when we got in the car to go to the airport. As we were
driving Marisha called to wish us a nice trip. We checked in on time and spent
some time shopping in the tax-free zone until it was time to board.

Three hours later we landed on the island of our dreams. Rented a car and made
our way to the cabin we had rented. It was a very beautiful cabin near the
ocean. I hugged Travis saying "This is so beautiful, look at it. You can see
the ocean!" I opened the doors to the back porch and stepped outside. The sun
was high in the sky and it was very warm, the breeze coming from the ocean made
it very pleasant if you staid in the shade.

After we had unpacked I changed into a bikini, with a wrap around skirt. Travis
had changed into shorts with a simple shirt. We sat down on the porch as I
applied sun screen to my skin. "What are you doing?" Travis asked.

"Do you really think I am not going in the water?" I said with a slight laugh.
Travis raised his shoulders as if to say how could I be so stupid. When my skin
was dry again I got up and stepped onto the hot white sand. "We need to get
some flipflops or something." I complained and skipped to the wet sand as fast
as possible. I could hear Travis laugh when he saw me jump like that.

Feeling the cold ocean water on my feet was such a blessing and I turned around
to wave to my husband who was taking pictures of me. I posed for a few of them
and laughed. Without warning I took off my skirt, threw it on the sand and went
for a swim. It felt so good, the water was great. I rose up, threw my head
backwards so my hair would flip.

"You look like a movie star!" I heard Travis shout. I giggled and got out,
grabbed my skirt and skipped through the hot sand back to the cabin. "The water
is so nice," I said as I walked up to our porch. I squeezed my hair over Travis
who shouted "No" as I dried my hair.

"We need to get some groceries," I said and went inside to change once more. It
took us almost an hour to get to the closest store and smiled at the difference
between this and the stores back home. The locals were very friendly and the
woman behind the counter told us to visit _Kamalua Park_, the nature reserve
just around a two hour drive from our cabin.

That evening Travis prepared the fish we got on the grill outside. He loved
cooking and said "Oh, I've missed this. Maybe I should do it more at home."

"I would love that," I replied, "Every day I don't have to is a win for me."

After that dinner we sat outside for a long time, both of us with a glass of
wine in our hands. Watching him in the dimmed light coming from inside made him
so handsome and I couldn't resist to kiss him. That kiss turned into more
kissing after which Travis took the glass from me and placed it on the table.
He put his arms around me and we started to make love. I got on top of him,
smiled and unzipped his shorts, slipped my panties to the side and pressed his
half hard lid against my vulva. I stared into his eyes, rose up a little and
guided him inside me.

He slowly pulled down the straps of my dress, exposing my breasts. He kissed my
nipples sending shock waves through my body. I slowly moved my hips, feeling
his hard lid inside me. We kissed and I gyrated my hips, started to bounce and
moan softly. From the corner of my eyes I saw a dark shadow standing a few
yards from us. Someone was watching us. In stead of being startled, it excited
me. I leaned back which made the light fall on my breasts, I wanted the person
watching to see me.

Bouncing harder and faster made my breasts bounce even more. I moaned louder
and panted "Oh yes, yes. Fuck me." not really knowing if the one watching could
hear me. It didn't take me long to have an orgasm, when I looked to see if we
were still being watched the shadow was gone and I really thought I might have
imagined it all.

Travis put his arms around me when he had finished too, unloading his cum all
over his belly. "What came over you?" he asked, "not that I'm complaining, but
it wasn't like any other time."

"It's the island," I smiled, "I think it's the island." I didn't want to tell
him what I had seen as I knew it would make him angry. I got up, pulled my
dress up and went inside to go the restroom. As I walked inside I thought about
that shadow, did someone really watch us? And why didn't I just run inside? I
couldn't believe how much it had excited me to know I was being watched. Just
thinking about that moment excited me all over again.

The next day we went to the park that woman had suggested to us and she had
been right, it was beautiful. We stopped at a large waterfall and Travis took
some pictures of it and me standing in front of the falling water. It was like
we rediscovered our younger selves again, the people we were before we got all
caught up in work and the daily grind of being a responsible adult. We had fun
again, enjoyed teasing each other and basically had a good time.

On our way back to the cabin we stopped to get some more wine as we had decided
to stay at the cabin for the rest of the day. Right after we got there I
changed into my bikini, grabbed a blanket and went out on the beach. Travis
stayed behind to prepare dinner while I laid down to catch same late afternoon
sun. I was smearing sun block on my legs when I saw a man walking down the
beach. With a shock I recognized the silhouette, it was the one who had been
watching us last night. I was sure of it.

The man tipped his hat as he passed me by having this look on his face, a look
of recognition. I felt the butterflies rise up in my stomach, a tingling I just
couldn't quite place. I just kept staring at him as he slowly approached me,
still keeping a distance but close enough so I could hear him.

"That was quite the performance last night," he said with a slight smirk on his
face. I should have been angry or appalled, in stead I felt thrilled, flattered
and even more excited. I looked over my shoulder to see Travis was still
inside, I turned towards the stranger and said "Did you like what you saw?"

The man nodded slightly. "I liked what I saw," he said, "just a warning. It
isn't quite legal here, but I didn't report it." He looked over and smiled. I
blushed because of the way he made me feel. I lifted my head to look at him, we
didn't speak for a moment or two.

"Well," I softly said, "Maybe you would like a second peek?" With that I pulled
down my bikini, exposing my breasts to this stranger. His eyes opened up wide
and he shifted his stance a little. I giggled when I saw the bulge in his pants
grow. I covered myself again and said "Come by later. We might give another
show." I winked at him and laid down, the man stood there for a moment then
walked away. I chuckled softly, feeling good about myself. It was flattering to
know I was still attractive to men.

It was almost 10 in the evening and we sat on the porch overlooking the ocean,
it was remarkably calm that night. All this time I kept looking for that shadow
again, feeling a little disappointed not seeing it. Without any warning he was
there at the same spot as the night before, my heart started beating faster and
I leaned over to my husband to kiss him. As I did I took his penis out and
started sucking it. "What's this?" Travis asked totally surprised by my sudden
action.

I didn't respond, I kept sucking his cock. I got up, took a few steps towards
the railing closer to the man watching us. As I did I took off my dress and
winked for Travis to come closer. I lifted myself on the table near the fence,
spread my legs and whispered "Come fuck me." Travis got up quickly, undressed
too and pushed his hard cock deep inside me. I moaned as I felt him enter,
leaned backwards and saw the man standing there in the dim light.

I winked for him to come closer and moaned harder when the man softly touched
my breasts. I looked up at Travis who was very surprised to see that stranger
touching his wife, but in stead of getting angry he seemed to enjoy it. I felt
his hard cock getting harder inside me. I smiled at him, leaned my head
backwards and took out this strangers cock. After licking it a few times I took
it in my mouth, something that really seemed to excite Travis. I loved feeling
two cocks inside me and came so hard.

It didn't take Travis long to come seeing his wife suck a strangers cock. He
came all over my belly, but I needed more. I turned around, rested my ass on
the wooden railing, spread my legs and guided this stranger inside me. Feeling
this strange cock slide in to me, made me moan so hard. "Oh yes, fuck me" I
almost shouted, "fuck me hard." Travis smiled, kissed my nipples and I saw him
grow again.

The stranger fucked me so hard I came multiple times and when it was his time
to come, I closed my legs behind him, pulled him in closer and shouted "No,
don't pull out. Fill me up, come inside my pussy!" With a deep groan the
stranger exploded, sending his seed deep inside my fertile womb. I hadn't been
on birth control for months as we had decided to try to get pregnant. Travis
was startled at first when I told the man to send his seed inside me, but when
he saw how I orgasmed he smiled.

When the stranger pulled out, Travis turned me around and planted his hard cock
inside me once again. With just a few thrusts he put his seed inside me too.
Knowing I had the seed of two men inside me send me over the top once again.
When it all was over Travis said to the man "Well, now you've enjoyed my wife
you can just as well get something to drink. Come on, what's you name my
friend?"

"It's Thomas," the man said and he stepped onto our porch. I went inside to
clean myself a little and returned wearing a very loose summer dress. We talked
for a while and learned that Thomas lived a few cabins down from us. He was a
gentle man and he made us laugh a couple of times. All of a sudden I felt an
urge I couldn't resist. I got up, straddled Thomas and guided him inside me
once again. I took of my dress as I was gyrating my hips on his big black cock,
Travis moved in closer and sucked my breasts.

I moaned so hard, then whispered in Travis' ears. "I want you in my ass. Fuck
my ass, please. I always wanted to know what it feels like." I didn't have to
say that twice and after a few tries I felt Travis slide inside my ass.
Instantly I came feeling those two hard cocks inside me. "Oh yes, fuck me
hard," I panted, "Hurt me, I want it. Harder. Harder. Harder!"

I had the biggest orgasm I had ever felt in my life, and came all over again
when the two men almost came at the same time. One sending his cum up my ass,
the other up my fertile womb. We had a night full of sex and they double
penetrated me multiple times. I loved every second of it, I loved being the
slut for those two men. By the time it got light I was exhausted, but very
satisfied. My pussy was filled with both their cum and I felt it dripping out
of me.

Thomas excused himself as he really had to go, leaving me behind laying in the
loving arms of my husband. We both knew this wouldn't be the last time
something like this would happen and even more knowing he allowed me to do this
made me love him even more.

## Chapter Two.
