# My Story

## Preface
_Everything in this story is pure fantasy. Nothing in this story is real and
any resemblance to any persons, dead or alive, is purely coincidental._

## Chapter One
Despite our best efforts our marriage didn't survive and although I knew it
hadn't been okay for a long time the day he told me he was leaving me still
came like thunder on a clear sky. All of a sudden he moved in with the woman he
clearly had been cheating on me with for almost two years. How could I have
been so blind? Maybe I did see the signs on the wall, just didn't want to
recognize them as putting the aside and ignoring them is much easier than
actually confronting them. The hardest part of our divorce was actually
acknowledging my part in our marriage deteriorating and accepting the
consequences of the choices we both made.

We did our best not to involve our children into this, but at some point it was
inevitable, we just had to listen to what they wanted. Both our children
expressed their wishes to stay with me, thus it was decided I would keep the
house, the car and he would get a bigger stake of the money we had saved up
along the way. Simply put we split as amicable as possible as I didn't want to
take their father from them, me not getting along with him anymore should not
influence the way they thought about him.

It had been almost six months since we split up and I just kept seeing what I
had lost everywhere I looked. On top of that it was quite hard to bring the
kids to school, go to work, keep the house clean, cook dinner and everything
else I needed to do for them while still living in the suburbs. It would be way
easier to move closer to their schools. The moment I suggested moving closer to
the city both children were excited, Haley about being closer to the mall and
Jason about anything else. He just didn't like living where we did, he wanted
to be closer to whatever was happening in the city.

As the house officially now was mine to do with whatever I wanted I put it on
the market. It was sold way faster than I expected so the three of us went
looking for somewhere new to live. The three of us were smitten by a nice
apartment near the city center, in the old part of town. Especially Haley loved
it because it would mean she simply could walk to school, something I was quite
apprehensive about. Her being 15 and still in puberty ensured we had some words
about it, which as usual ended with her slamming her door shut.

The move went without any major problems. As the new apartment was smaller than
our old house we sold a lot of things and what we couldn't sell we donated to
charity. Even Haley did her part and donated the clothes she wasn't going to
wear anymore or just didn't like anymore. Moving had been a good thing for the
three of us, it felt like we had turned the page and started something new.
Being closer to the action really seemed to bring Jason alive. He had just
turned 17 and discovered the world outside of the house we lived in. His
interest in the opposite sex had roared it's ugly head and to me it was quite
amusing to see him struggle with it.

It was on a Saturday when the rays coming from the sun show upon my face,
waking me up. I turned over looked at the alarm clock on my nightstand and saw
it was 8:30 a.m. Even on the days I didn't have to work I woke up early. As I
was taught from a very young age I just got up and stepped into the shower. My
parents had always said "When you wake up, just get up and start the day." It
had been something I had taught my children too, I just couldn't see the
benefits of sleeping in late.

Haley was visiting her father so it would just be Jason and me this weekend and
through the slit of his door I could see he was still sleeping. He had come
back a little late from the party he attended and I just let him sleep for a
little while longer. I walked into the open kitchen and made myself some
coffee. A few minutes later I sat down on our balcony with a cup of hot liquid
in my hands, I just loved our balcony. At our old house I hardly ever sat
outside as it just was so boring, but from our balcony I could watch the people
passing by. Jason had been right, being amongst the people had been good on all
of us.

It was almost 10 when Jason woke up and I could hear the shower when I went to
my bedroom to put on a nice summer dress. Just as I stepped out of my bedroom
Jason stepped out of the bathroom, towel wrapped around his waist. For the
first time I noticed his abs and how strong he had become. "Hey mom," he said,
"sorry I was home late. I totally lost track of time, won't happen again."

He always had been like that. He didn't shy away from taking responsibility, in
that aspect he was more like me than his father. I smiled "It's okay. It was
just 15 minutes, I will live." It was Haley who was seriously rebelling, she
just didn't want to listen or take responsibility. Something her father and I
had been talking about for a while now, we had to find a way to real her in. We
both knew that wasn't going to be a simple task. We also knew this was just a
phase and we trusted her implicitly, she just needed to understand her actions
could have consequences.

Seeing him like that elicited a reaction from me that I totally didn't expect,
I felt my nipples harden. I shook it off as an one time thing and continued to
do what I wanted to do, the laundry. Jason had sat down to eat his breakfast
and I gathered his laundry from his room. As I was pulling off the sheets
something caught my eyes, a magazine hidden underneath his mattress. I took it
out and gasped when I saw what it was called: _MILF Magazine_. I took a peek to
see pictures of women my age, older women, mature women. Still in shock I put
it back where I found it and rushed out his room.

That afternoon I sat down at my laptop, checked where Jason was and search for
the meaning of the word _milf_ only to gasp even harder when I found out. I
looked over my shoulder at my son sitting on the couch watching some football
game. Knowing he liked older women somehow excited and frightened me. Did this
mean he had a girlfriend my age? He was just 17 and he loved women twice his
age? I still couldn't quite believe it.

For the rest of the day I wondered whether I should confront him with it, but I
didn't want him to feel awkward or get angry with me. I could see how he could
see this as an invasion of privacy, but it had been a total accident. It wasn't
like I had been searching his room or anything like that.

It was getting warmer outside and I decided to catch some sun. In my bedroom I
checked my bikini when something came over me, an urge, a feeling that I just
couldn't shake. I opened the drawer and got out another bikini, a smaller one.
I giggled like a schoolgirl and changed into that one. With some special glue I
made sure it wouldn't slip, grabbed a towel, sunscreen and walked towards the
balcony. The moment I had to pass the TV in front of my son felt exciting
somehow, different from the thousands of other times I had done so. It was
difficult to suppress the smile on my face, I knew he would be watching me.

I took a deep breath, stepped into his view and kept on walking towards my
goal where I sat down on the lawn chair and started to rub the lotion over my
skin, starting with my legs. I fully well knew my son could see me, I even
turned a little towards him when it was time to protect the skin of my upper
body. From the corner of my eye I noticed him looking at me, his face was aimed
at the television his eyes turned to me. I did my best to act as if I hadn't
noticed and if felt so nice to feel sexy again.

It had been such a long time since I had been with a man. I hadn't been on any
dates since the divorce and even before my ex and me didn't consume our
marriage for almost two years. I laid down, placed my sunglasses on the small
table next to me and enjoyed feeling the sun warm my skin. At moments like
these I missed the pool at the old house, but this was just fine too.

I had been laying there for almost an hour when Jason popped his head outside
to tell me he was going to see his friends. "Just be back at six," I told him,
"I will have dinner ready by then." He just nodded and with that I was home
alone. I got up when I heard the front door open and shut, walked inside and
sat down where Jason had been sitting, the pillows still smelled a little like
him. Almost instinctively I squeezed my breasts, spread my legs a little, my
left hand found it's way to my Venus mount and slipped underneath my bottoms.
Wriggling my finger until I touched my clit, sending shocks of pleasure through
my body. I opened my legs a little more as I transitioned into full
masturbation. After taking off my bikini I masturbated while smelling the
pillows. "Oh yes Jason," I whispered, "take me. Fuck your mother."

The moment I spoke those words I was shocked and stopped what I was doing. "I
can't think like this," I told myself, "this is so wrong. I can't be doing
this, not about my own son." I got up, took a cold shower, got dressed and
proceeded to change the sheets on his bed. My eyes continuously turned to the
spot where the magazine was, resisting to grab it, lay down and get off on it.
It just wasn't done, I kept telling myself.

The floodgates had been opened and for the next couple of weeks I kept seeing
my son as a potential partner, a lover. The longer I resisted the stronger that
feeling became. One evening I came home to find Haley in her room listening to
music on her headphones, she was singing along to it not knowing how loud she
was singing. She had a beautiful voice and I always let her be. As I passed
Jason's room the door was ajar and I could see him sit at his desk, watching
some video. When I noticed what it was I gasped, froze in utter disbelieve. He
was watching a porn video and had his hard penis in his hand.

"Oh yes son," I heard the woman say, "fuck your mother." I gasped once again,
turned around and rushed into my room. I should have been a responsible mother
and stormed in, scolded him or something like that. In stead I felt aroused,
excited and couldn't believe the size of his hard cock. Oh how I wanted to just
walk in and suck it, taste it, take it deep into my mouth and gag on it. I just
couldn't. Not just because Haley was home, it just wasn't done. Such taboo,
just the fact I was even thinking about it felt wrong. And yet it felt so right
at the same time, like it was destined to happen.

That evening as I laid in bed my mind went back to seeing my son watching that
movie. I started masturbating, dreaming about being with my son. The moment I
whispered "Oh yes Jason, come inside me. Come deep inside your mother" I had a
huge orgasm, my whole body shook as the orgasm took hold off me. For hours
after my body tingled. I felt so ashamed about what I had done I didn't even
dare to look my son in the face the following morning.

A few days later I caught him again sitting at his desk watching another video
where a mother and her son were having sex. In stead of fleeing to my room, I
got a little closer, leaned against the wall of his room and listened to the
video but more to his breathing as he was jerking that big hard dick of his.
Every now and then I glimpsed into his room, staring at his hard penis and
leaned back again. I felt myself getting so wet and without really thinking
about it I started rubbing my clit. The fact that I was watching my son jerk
off and the risk of getting caught by my daughter made me come so hard that I
moaned a little too loud. I was so sure either one of them or maybe both had
heard me. I fled to my room, leaned against the closed door and listened for
any response, but I kept quiet and I really thought I had gotten away with it.

I had to stop this, this just couldn't continue like this. I resisted the urges
for the next couple of weeks and as time went on it all but disappeared. The
moments it returned I was able to resist and shake it off. It simply wasn't
going to happen.

## Chapter Two
It had been such a fun night and we had promised each other to do it again some
day, to make it a tradition. For the first time we as a department had gone out
to dinner and a movie. Seeing my co-workers like this changed my opinion about
some of them. Take Cary for instance. At work she was stiff as a board, always
following the rules. That evening I saw a whole other side of hers, a fun side.
She just took her job a little too serious, I thought.

Feeling the effects of two glasses of wine I had a little trouble opening the
front door. I hadn't drank alcohol in such a long time, two glasses were my
absolute limit it seemed. I walked inside and was a little surprised not to
find my children watching TV. Wondering where they were I walked towards the
bedrooms. I had taken off my heels the moment I went inside and made my way to
my room to change into something more comfortable, fully expecting to find
Haley in her room listening to music.

I knocked softly and opened her door. Her room was empty, which was rather
shocking to me. I walked over to Jason's room to ask him where she was and
through the opening I could see him laying on his bed. He didn't wear a shirt
and then I heard the noises of sex. I heard someone moan and I noticed his
hands in a slight upwards angle. He had a girl in his room! That would explain
why Haley wasn't home, I thought. Curious who it would be I peeked around the
corner, making sure they couldn't see me.

I gasped when I saw who it was. It was Haley! She was fully naked, her breasts
were bouncing up and down as she was riding her own brother. I should have
stormed in and stopped it, but I didn't I kept watching them. "You feel so
good," I heard my daughter pant, "I love feeling you inside me, brother." Jason
just grunted. "I think I'm gonna cum. Yes, I coming all over that cock of
yours, it feels so good," I heard her say.

I couldn't take it anymore. I slipped off my dress, took off my underwear and
threw open the door. My two children shrieked and Haley dropped down covering
herself with the sheets. The light behind me made me just a shadow and it was
only when I took a few steps towards them when they noticed I was naked.

I crawled onto my sons bed, looked at my daughter and got on top of my son. "My
turn," I said and guided my son inside me. "Oh yes," I said, "Finally!"
