# The New Boss
an erotic story by Transgirl

## Chapter One
Being married for almost ten years, having two kids and a husband that I would
die for had made me happy, or at least that's what I always thought. That idea
was blown to pieces when my new boss was announced at a company meeting. I felt
a shock throughout my body, something I hadn't felt for a long time. I felt so
guilty, never thought I would ever think this way but I couldn't deny this
feeling it just was too overwhelming.

I had been working for the company for almost eight years by then. Was selected
to lower management by the former CEO, a man who reminded me a lot of my own
father. He took me under his wings, trained me, taught me and within three
years I became the head of the sales department. A position in which I reported
directly to the board. I always felt like I would be on there one day.

That all changed when he announced his retirement, a shock went through the
company for he was the last of the family who had started the company to leave
it. The day of his retirement we had a huge farewell party and it was so
heartwarming to see his tears when he addressed the company for the last time.

Three days later Jason was introduced as the new CEO, he had come over from
another company and the moment I saw him I didn't listen to anything that was
said anymore. All I could see was is handsome face, his square jaw and
especially his deep blue eyes. For the rest of the meeting I shuffled around on
my seat as my panties kept getting wetter and wetter. The moment there was a
break I excused myself with a "Sorry, but I needed to go for a long time."
Hoping it would explain my moving around on my chair.

As I rushed to the bathroom I almost bumped in to Jason. "Oh, so sorry," I said
without looking at him. He chuckled and I jumped into the bathroom as quick as
I could, my heart was pounding in my throat. I hadn't felt like this since
high school, I felt like a teenager with her first crush all over again.
Butterflies were roaring in my stomach. Had he really just touched me? I did my
best not to giggle and retreated in one of the stalls.

The first few weeks I did my utmost to avoid being alone with him in one room.
I arrived at meetings just a little too late, hoping the last seats available
would be as far away from him as possible. During those meetings I looked at
him as little as possible, mostly at the papers in front of me. I was so scared
he or anybody else could see how I really felt. "Just get through this," I told
myself, "This will pass. It's just a phase."

But it wasn't just a phase, it was more than that. My marriage had become
stale, a runt. Our children were well looked after by a nanny and we both loved
them so much, we wanted them to have a good life. Therefore we both worked long
hours to the detriment of our marriage, we didn't even sleep in the same room
anymore. Don't get me wrong I still loved him, more than I would like to admit,
we just had grown apart. Despite our marriage I trusted him with my life, I
knew he wasn't cheating on me because that had been the reason his parents got
divorced. Maybe that was the main reason I felt so guilty about what I was
going through at that moment. I just knew I had to be cautious because I had no
idea what would happen if Jason and I would get half the chance.

Suddenly it was time for the yearly review. The one meeting I would have to be
alone in one room with Jason, there was no way out of it. This review had to be
done by the CEO and I had been nervous for it for days beforehand. As I sat
down in the chair across from him I could feel the tension between us. Maybe it
was just in my mind, but I could see he wasn't quite comfortable as well.

"Now Laura," he said as he looked up from my file, "You've had quite the year I
see. Sales up by 3.5 percent. Quite the accomplishment during a depression,
congratulations."

"Thank you," I replied. I could hear my voice crack and scraped my throat.
"Thank you so much," I repeated myself. "Sorry, a bit nervous."

"Why?"

"I don't know. These reviews always make me nervous."

"Don't be. You did wonderful and we have decided to give you a raise. We also
made some other changes. In stead of reporting to the entire board, you are to
report directly to me. I used to be in your position and have some ideas where
we might improve. I would love to hear your thoughts on it."

Reporting directly to him? That would mean more meetings in which we would be
alone in a room. I felt myself blush and tried my hardest to sound calm and
collected. "That would be wonderful. Looking forward to it."


