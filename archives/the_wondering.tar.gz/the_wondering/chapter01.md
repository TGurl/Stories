# The Wondering

## Chapter One
It had been 10 years since the calamity had started, storms were raging,
jungles were on fire and lava took back the lands that got taken from it so
long ago. Primeordials ruled the lands, wars were fought, towns and cities
destroyed.

In the midst of this destruction ordinary people did their best to survive, to
make a life for their own. With crops failing hunger ruled the lands, fights
broke out everywhere for something simple as a loaf of bread. These were hard
times, people had lost all hope.

Every now and then people rose up against the primeordials and the betrayer
Gods only to be squashed within hours. This was a war between beings stronger
and mightier than anyone had ever seen. Most of the people still remembered the
age of Arcana, with the flying cities, the way life was back then.

Not all deities were ready to give up on the people of Exandria, some of them
did try to help them. One of these deities was the Wildmother, the goddess that
ruled over nature. She hadn't lost trust in the people and knew the only way
the Primeordials could be defeated was by the people.

Along a path a little girl made her way back home, she had tried to sell some
of the products her parents had made. In her small hand she clutched the three
copper coins she had gotten for one of the baskets her mother had made. It
wasn't much, it was the only thing she was able to sell. A single tear rolled
down her cheek as she walked back home.

"Don't cry little one," a voice said in her head. The girl looked around to see
no one was there, she was all alone. Frightened she started to run. "Don't
run," the voice said, "I'm not going to hurt you. I've been searching for you
for a long time." The voice sounded comforting, motherly, safe.

The girl stopped, looked around and whispered "Who are you?"

It was like the leaves of the tree near her changed shape, the rustling leaves
formed the shape of a face, a smiling face. "I am the Wildmother," the voice
said, "I am here to help. But I can't do that without you. I have powers but I
can't wield them myself, we need people like you to do that for us. I've spoken
with the raven queen but she has betrayed us and I can't trust her anymore."

"Who is the Raven Queen?" the girl asked.

"Not important right now," the voice said as the face in the leaves
disappeared, "Go home now. When you get there go into the garden and think off
me. It's the only way I can prove I'm here to help." The voice disappeared
