# Chapter One
The world was an ugly place for me, my father had left us when I was very
little and my mother worked three jobs to make ends meet. When she wasn't
working she either slept or spent her time drinking. The trailer which we
called home was always a mess, as was the park were it stood. I couldn't wait
to get out of there and finally I had passed my final exams, just graduation to
go and I would be out of there.

My mother was sleeping on the couch, a bottle of booze in her hand. I didn't
want to wake her as it would lead to yet another screaming match between us,
but this was my graduation day and despite everything I wanted my mother to be
there for me. Ever so carefully I woke her up and another screaming match later
we sat in my car, she had cleaned up the best she could but still smelled of
alcohol.

I stood aside from all the other kids who were graduating, this would be the
last time I would ever see them. It took a while before my name was called and
proudly I stepped onto the podium to receive my diploma. My bags were already
packed in my room, as soon as I got home I would place them in my car and
leave. That would be my graduation present to myself.

I could hear my mother cheering loudly as I was congratulated by my teachers
and I smiled as I shook their hands. When it wall was over I ran to my mother
showed her the certificate and she was truly happy for me. "Let's celebrate,"
she said, "we're going out for dinner tonight."

"That's okay mom," I replied, "I know you have to work later." I hadn't told
her about my plans as it would only have led to another fight between us. Don't
get me wrong despite our differences, despite all our fights I still loved her,
how couldn't I she's my mom. As soon as we got home she made herself another
drink "This calls for a celebration!" she shouted and emptied the glass at
once. Not long after she was simply too drunk to do anything and I knew she was
about to loose yet another job. 

I waited for her to fall asleep, placed all my bags in my car, left the letter
I had written her on the kitchen table. To be sure she would find it I had
placed it against a bottle of her favorite drink. I looked back at her one last
time before I took a deep breath and closed the door behind me.

Almost three hours later my mother called me. "Where are you?" she cried, "Why
did you leave? Please come back home, we are celebrating!" I could hear the
tears in her voice. "Wait mom," I said, "I have to park the car." It took me
about 10 minutes to find a spot where I could safely stop. "Mom? You still
there?" I asked.

"Yes," her voice sounded small and she was clearly crying. "Just found your
letter. Why though? Why did you go?"

"I have to mom," I replied, "if I don't do this I am so scared I will never
leave. I need to stand on my own two feet, I don't want to work in the factory
or whatever. I want more and I will never get there when I stay." My mother was
quiet for a moment and said "Why didn't you just tell me?"

"And then what? Another fight?" I replied, "I thought this would be better. I
still love you mom, but I really can't stay any longer." We didn't say a word
for a few minutes.

"Okay," she finally said, "I need to get to work. We will talk later, please
let me know that you're safe."

"I will mom," I said softly, "I love you." She didn't answer, just hung up and
I continued my journey towards my destination: Fort Dix. Just another few days
in the car and I would arrive in the city of my dreams, the town of
possibilities. After saving up for almost a year I had enough money to get
there, it I stayed at the cheapest motels or hotels, maybe even slept in my
car. What I would do when I arrived in Fort Dix? I had no idea yet, but that
was part of the excitement.

The sun was already going down when I stopped at a somewhat decent looking
motel, the clerk handed me the key without even looking at me and as I entered
the room I thought it was rather decent. If you added some more trash
everywhere it could have been a carbon copy of our trailer. The room was almost
at the end of a long row of rooms. I locked the door behind me and fell on the
somewhat hard bed. I was so tired from driving all this time. As I looked at
the clock on the nightstand I wondered what my mother would be doing right now.

If she had made it she would be working the night shift at the factory, most of
the people I knew worked there. I turned on my back and looked at the ceiling
for a while thinking. 'What am I doing?' and 'Will it all be okay?', a slight
panic took hold of me now I had finally left home. I got up, took a shower in a
rather clean bathroom if you ignored the cracked tiles and got back in my car
to get something to eat.

As I returned I could see some girls walking the street near my motel. The way
they were dressed told me they weren't there for fun, they were working girls
and I knew why they had chosen this spot. The motel I was staying at also
rented the rooms on an hourly basis. I parked my car near my room and rushed
inside. As I sat there eating my burger and fries I kept thinking about those
girls.

I got up, opened by bag and got out some nice, rather sexy clothes. I spread
them out on the bed and sat down next to them. What was I thinking? Somehow the
idea excited me and it was so close, all I had to do was walk out the room,
cross the parking lot and I would be amongst them. What if I just tried? Not to
actually do it, but just got out there to feel what it was like.

Ten minutes later I stepped out of my room, wearing the shortest skirt I had, a
short crop top and a nice pair of heels. I crossed the parking lot and stepped
on to the sidewalk. Some of the girls gave me the stink eye, which I simply
returned. I started strolling up and down the street, popping my hips a bit
more that usual. Suddenly a car slowed down next to me, a window opened and I
heard a voice say "Hola Chicka!." I turned towards him, smiled and leaned over
as I reached his open window.

"Hey," I smiled, "looking for a good time?"

"Yes, but what would it cost me?"

"Oh, 50 dollars for a blow job, 150 if you want all of me."

"150 dollars? Are you crazy?" he shouted and sped up. I giggled as this was
exactly what I wanted. I felt elated, this was so exciting. I didn't actually
want to do it, I just wanted to feel the excitement of offering my body for
money. It didn't take long for another car to slow down next to me.

I repeated what I said before, but this time the man said "Get in." It was like
my heart stopped beating, this isn't what I wanted. This was just too much, but
I had offered and he had accepted. My mother had always said you have to do
what you said you would, so I got into the car with my heart racing fast.

"I got a place," I said, "just turn onto the parking lot over there."

He parked his car next to mine and we went inside the room I had rented. He
fell on the bed and asked me to strip before him.
