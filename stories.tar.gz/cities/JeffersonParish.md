# Jefferson Parish
Jefferson Parish is a small town in the South of the United States. It's a
farming community and there are a few small shops, one bar and a school.

Main street is a broad street with parking on both sides. On the North side is
the _Iron Shoe Bar_ next to it are a few buildings that used to have shops, but
they were closed a long time ago. 
