#Chapter One
From a very early age I knew I wasn't like the other children, I loved playing
with dolls and for my 4th birthday I wanted an easy-bake oven, just like the
girl next door had gotten. At first my parents tried to convince me otherwise
and gave me the toys that were appropriate, but one morning my mother saw me
sitting in my room not doing anything.

"Why don't you play with your toys?" she asked me.

"Because they're dumb. I don't like playing with them, I want a doll and a
pram. I want to clothe her, feed her and take care of her."

My mother almost started to cry when she saw how unhappy I was and she decided
to do a little experiment. She took me to the toy store and said "Okay, you can
pick anything you want. I won't get angry, just look around and choose a toy."

She watched how I ran towards the girls section, grabbed a baby-doll and ran
back. "I want her," I said, "She's so pretty and she drinks milk, you see?" and
I pointed to the little bottle that was in the box. She saw how my eyes
twinkled when I looked at the doll and she decided to do another experiment.
After paying for the doll we went to a department store where we stopped in the
clothes section.

"Now," she said, "You can choose again, anything you want."

I turned around, looked at my mother who gestured for me to go and slowly I
went over to a rack with dresses. I had seen a pink dress I wanted earlier and
said "This one. Look it has little horsies." My mother wiped a tear away and
when we got home she told me to put on my new dress. I was so happy when I ran
back in the room and twirled around.

When my father came home I ran up to me and said "Look daddy! I got a new
dress!" and although he wanted to tell me I couldn't, the moment he saw how
happy I was and that my eyes lit up he changed his mind. Instead of a grumpy,
unhappy child he now saw one that was happy, bright and outgoing.

My parents had talked to the school and despite their initial resistance they
allowed me to come in the clothes I wanted to wear. In class they talked about
people being different and that there was nothing wrong with it, us children
had less problems with it. We just played and finally I was allowed to play
with the toys the other girls were playing with.

By the time I was 12 I only wore the clothes for girls, I had a vanity and
experimented with makeup, my hair and everything else girls do. My mother had a
talk with me and said "Look, you're getting older now and we want to help you
be a girl. So we got pills from the doctor that will help you with that." I
started taking hormone blockers so puberty wouldn't hit me and I am so happy
they have done that for me.

There was just one thing doctors couldn't do for me, they couldn't prescribe
female hormones so I would be more like all the other girls. Somehow my parents
got hold of them and from 13 I started growing breasts. I couldn't have been
happier. My parents loved me so much they were willing to break the law for me.

When I turned 18 I went to court to change my gender officially and after a
long process it was granted. The first time I saw my drivers license and there
was an F behind my gender, was one of the best days of my life.

That's in short the story of how I became a woman and if you saw me back then
as I walked the streets with my friends you couldn't have seen the difference,
I just had a little bit more to offer.

I never hid that I was trans, not for anyone. If someone approached me it
always was one of the first things I told them. Normally it would put them off
and it was a great defense not to get harassed when we went out. Even some of
my cis girlfriends started using it. They treated my like they would any other
girl, I was invited to slumber parties, we went shopping at the mall and we
loved getting our hair and nails done.

The first time someone didn't back away and told me he didn't really care was
another of milestones for me. We started kissing and ended up in a dark spot
backstage where the band was still playing. He lifted up my skirt, licked me
and when he pushed his cock inside me I cried from happiness. Feeling him slide
in and out of me was the best feeling ever. Just before he came he pulled out
and I took his lid in my mouth, he came so hard I had trouble swallowing all of
it.

When I returned to my friends and told them what had happened they all cheered
for me. From that
