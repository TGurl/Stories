# Chapter Two
It had been a few weeks since I had moved into the dorms, the first week was
introduction week in which we got to know my teachers, me fellow students and
the campus in general. It also was the time for me to get used to my new life
and find a way to combine going to school, doing my homework and still find
some time to relax. Like all the other students I found it preferable to study
at the library as all the books I might need were there.

It also was quite the thing to eat in the on campus restaurant, it ensured you
were eating fresh food and it wasn't that expensive either. Every month you
could by a scratch card good for at least 10 meals, depending on how much you
spent. All in all it was cheaper and easier to eat there than to cook yourself
in one of the shared kitchens at the dorms.

To make it easier on my parents I also started searching for a job, but it
wasn't easy to find one which I could easily combine with my studies. In the
end I found one as a hostess at a hotel near my school, the fact my parents had
a hotel surely helped in me getting that job. It wasn't the biggest of hotels
so I had enough time to spend on my studies while I worked, something my
manager even encouraged me to do. After just a few weeks she told me how
satisfied she was with my performance and offered me a contract for at least
one year. I didn't hesitate one second to sign it as I really liked working
there.

During this time Marisha and I got to know each other a little better and
although some of our interests were different we had a lot in common too. For
the first time I had met someone who also was interested in fantasy novels,
comics and other nerdy stuff I liked. We spent more and more time together when
we had the space to do so, we had many dinners together during which we talked
about anything, sometimes even some personal things. The trust between us was
still growing so we didn't go as far as we both might have wanted.

Sharing a room had made it near impossible for me to give in to the urges I
felt at some moments. I just was too scared to be caught by anyone, especially
by Marisha. The tension slowly built up during that time leading up to me
releasing that tension on the bathroom at school one day. It was so exciting to
do so, just the chance of being caught made it all the more special. One time I
was pleasuring myself as someone walked into the bathrooms, she got in the
stall right next to me. I pulled up my shirt to put it in my mouth so I had
something to bite on as I kept on masturbating. The moment I heard her run the
tap to wash her hands was the moment I couldn't hold in it anymore and
orgasmed, doing my best to keep as quiet as I could.

It was a Sunday morning and I had planned to go study at the library for a few
hours before Marisha would return from visiting her parents. I had worked all
day the day before and as the midterms were coming up I really needed to spend
some time in my books. As I walked in I noticed it was rather quiet, the
librarian was even a little surprised to see me enter. I greeted her, got a
coffee from the machine and searched for a spot where I could spend my time.

On the third floor there was one spot a little more secluded and still near the
section of books I needed for my studies. The floor was totally empty as I sat
down at the table in the far end near the windows overlooking campus. I looked
at the almost abandoned central square for a while, only a few students were
dotted over the lawn underneath the big tree in the center. It was just after
nine in the morning as I opened my books to start reading.

As I sat there reading the first few pages I felt an urge coming up, I looked
up to see if anyone had joined me on the floor. Still no one was there. I took
of my jacket and undid the first few buttons of my blouse. I waited for a few
minutes before I unbuttoned some more, after about twenty minutes the front of
my blouse was loose. I smiled a little knowing if someone looked closely they
could see my bra, I then proceeded to unclasp my bra in the back. Just as I was
done doing so I heard footsteps and I leaned a little more forward, holding my
blouse closed as best I could.

The librarian looked at me, smiled and continued placing back some books where
they belonged. I didn't dare to look up hoping she didn't see that I had opened
the front of my blouse. Those few minutes seemed to last for ages, finally she
walked away. I kept on reading for a while longer to make sure she was gone
before I looked up to see I was alone again. In a swift move I removed my bra
and put it in my bag. I leaned back to stretch for a little, my blouse fell to
the side exposing my breasts. I giggled as I stretched, turned around to look
out the window a little more. I got up and stood there for a while, my blouse
open. If anyone had looked up they could have seen me and it gave me a total
rush.

I looked over my shoulder only to see I was still on my own, I had to start
working on the assignment and needed a book to help me with it. After taking of
my blouse I walked towards the shelves where I could find the books I needed,
being topless at the library gave me another rush, the adrenaline was racing
through my veins. I walked back a little quicker than I normally would have, as
soon as I sat down I put my blouse back on. I couldn't stop giggling for a
while, this was so very exciting to do and I loved every single second of it.

I didn't want to jinx it so I closed my blouse back up. Right after I had done
so the first people sat down at one of the other tables on that floor, I
giggled softly as I realized that if they had arrived just a minute sooner they
would have caught me. I spent a few hours finishing my assignment, by the time
I left all the other tables on that floor were occupied. It felt nice not
wearing a bra as I walked out of the library.

Once back in our room I gathered my toiletry bag, a towel and made my way over
to the showers down the hall. There were a few girls in there doing their
makeup, hair while they were talking about clothes, boys and how much fun they
had the night before. "Oh, he totally wanted to have sex with me," one of the
said, "don't be dumb. The way he looked at me? I am so sure of it." I softly
chuckled to hear her talk like that. I never had a friend I could be so open
with about things like that, I had always kept that part of me to myself.

When I returned to our room after taking a shower I was quite happy to see
Marisha had arrived. "Oh hey," I said, "you're here. A little earlier than I
expected, but welcome back."

"Thanks," she replied, "I just couldn't take it anymore. My mother was a pain
in the ass as usual. 'Are you eating good? Are you sleeping well?' Not once did
she ask about school, the only thing she did was tell me to eat well, sleep
good and how I should dress. She totally wants me to be more girly, to wear a
lot of makeup and such. Ugh, I hate that so much about her."

"But she's your mom --"

"Yeah, I know. And I do love her, it's just that part of her that irritates me.
I wish she would accept me for who I am, but she always has something to
complain about. Even if I do everything she wants me to, she still will find
something she can criticize."

"I'm sorry to hear that."

"Don't you have that? Isn't there something that irritates you about your
parents?"

I was raised to always be respectful to my parents, to always accept their
decisions, not to do anything they didn't want me to do. "What would the
neighbors think if they saw you like that?" was one of the sentences I had
heard multiple times. Maybe that's why I did the things like I had done that
morning at the library, maybe that was my way to rebel against them. Because I
knew they would be so embarrassed by it when they ever found out, it would be
so shameful for them. Realizing that made me feel good and sad at the same
time, I didn't want to embarrass them nor to make them feel ashamed of me, but
it was a need I felt, something I just had to do at times.

"I don't know," I replied, "My parents were rather strict and I really didn't
want them to be ashamed of me. It was just easier to comply, I guess."

"But how would you know what you liked then? If you always did what your
parents expected of you."

"What do you mean?"

"Well, let's just talk about the clothes you're wearing. Don't get me wrong,
they are nice but they are the same clothes my mother wears and she's almost 40
years old. Get where I'm getting at? Why not wear something a little more our
age, like a nice shirt or a skirt. I mean, as far as I can see, you have a
beautiful body but it's all obscured by the clothes you wear."

I blushed softly replying "But these are decent clothes. What would one think
if they saw me wearing anything else?"

"Who cares what people think? I do not say you have to wear lingerie to class,
just something a little more our age. A nice t-shirt or something, maybe even
something a little more low cut. You know what? Let's go to the mall, there's a
sale and we both could use some new clothes."

A few hours later we got back carrying three to four bags each full of new
clothes, almost all of them were nothing like I would have bought for myself
ever. I even had bought a very tight red dress, fully on the encouragement of
Marisha she just kept saying how good it looked on me. We had such a good time
shopping that we promised to do it again sometime, we even had talked about
more personal stuff as we sat down at one of the coffee shops at the mall.

"Have there been boyfriends?" She asked me, "or some one-night-stands?"

I blushed and said "No, not really. The longest I was with someone was just a
few weeks, White Rock doesn't have a night life and I worked at the hotel most
of the time. You?"

"Oh, I had a boyfriend for three years, it didn't work out. He didn't want me
to leave. I tried to explain how big this opportunity was for me, he just
didn't see it that way. All he wanted was an obedient wife who would take care
of his kids. I don't even want kids, at least not at the moment."

"Oh I would love kids," I replied, "ever since I was little I wanted three or
four. Maybe it's because I'm an only child, I always envied my friends who had
siblings."

"Funny, I'm always jealous of the ones without siblings, they can be a pain in
the ass. My brother for example, he's a huge pain. He plays football, he's your
typical jock. Now he's set his mind of coming here next year, I just can't seem
to get away from him."

"Is he that bad?"

"No," Marisha laughed, "I love him, he's the best brother anyone could have.
Just don't ever tell him that, you hear!"

I chuckled, it was something I was so jealous of that banter between siblings,
having huge fights but still knowing you had each others back when needed.
"Yeah," I replied, "That's something I will never know. My mother got sick
after I was born, they had to take it all out."

"What? All of it? I am so sorry."

"Well, she always says if you have a choice between that and dying, the choice
gets a lot easier."

"That might be true, but I'm sure she's strong for you. If she doesn't seem to
mind it, why should you?"

I had never thought about it that way, it made me see her in a total different
light. Maybe it was true that she was keeping up appearances for me, I was so
young when it all happened. Maybe she was just used to it by now. "You could be
right, I never thought of it that way," I replied, "It does explain a few
things."

"Like what?"

"Like how protective she is of me," I replied, "I can't go anywhere without
them knowing where I am. I know it's normal to tell people where you are, but
if I don't she will call me no matter where I am. One day she forgot that I
told her I was going to the movies, she called me to come home immediately. I
was so embarrassed, she called the theater and they searched for me row by row.
Even though it was dark I was sure everybody knew it was me they were looking
for."

"The last part is a bit over the top maybe, but I don't think it strange for
her to want to know where you are. Now that you live here on the other side of
the country, it must be difficult for her to let you go. You're her baby no
matter how old you get. She didn't call you, did she? Not even once. So maybe
call her, tell her you're alright."

"I might do that," I replied, "actually that's a great idea."

Later that day I went over to the central phone, remember this all took place
before cell phones were a thing. I threw in a few quarters and called home.
