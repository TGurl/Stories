# Chapter One
White Rock is a small town in the north of the country, it's the place where I
grew up. The only claim to fame is the mountain the town was named after, for
the rest White Rock is surrounded by fields of corn and wheat. Only during the
winters visitors came to our town as the mountain has some of the most
challenging slopes in the country. My parents were always busy during the
winter months as we owned one of the two hotels in town.

During the summer months the lake just south of town attracted people too, but
not as much as the mountain did during winter. The summer was the period of the
year I loved the most as my parents had more time for me and I always loved to
go fishing with my dad. Not that I liked the actual act of fishing, just
spending time with him was the part I loved.

As I grew older it was expected of me to help in the hotel too. At first I had
to clean the rooms, do the laundry and other simple tasks. When I allowed to
start working I helped my mother checking in the guests on top of the other
tasks that needed to be done. I really didn't mind working there, especially
when my parents actually started paying me for the hours I worked. There was
just one rule they had for me, I had to finish my homework before I was allowed
to do anything. It was second nature for me to go to the hotel right after
school instead of going home.

During the summer break before my final year of high school I had a big
decision to make, was I going to a college nearby or did I follow my dream and
apply to Kingston College in Fort Dix on the other side of the country. My
teachers always told me to apply there as it is the best college there is and
it would be so nice if I were to be accepted there. The only problem were my
parents, I knew for sure they wanted me to go to school close to them. They
sure wouldn't like me going all the way across the country.

Somehow I felt like I just had to go there, I needed to be on my own, carve my
own path and not depend on my parents anymore. Looking at the pictures of
Kingston College I was smitten by the old buildings, the beautiful center
square and the immediate surroundings of the school. Even though Fort Dix was a
city of millions the college was situated in the middle of a national park.
Legend had it Kingston was one of the first settlers who came ashore there. He
was a teacher and started the first school, which grew into the college it is
today.

The more I looked at it the more I wanted to go there and not just for the
school. White Rock counted almost 4,000 citizens and although we didn't know
everybody by name we sure knew each others faces. On top of that there were
only 19 in my class so there weren't many peers my age. Besides that I always
felt different from them, I had other interests and wanted to see the world. My
best friend Luna for example, she didn't want to move far away or understood
why I was interested in the things I was intrigued by.

We both loved reading and books, but she loved romance novels and literature
while I was more into fantasy like Lord of the Rings and such. She just
couldn't understand why I was so smitten by worlds full of magic and mystery.
Then there was that part of me that I kept hidden from everybody, even from
Luna. That part of me I wasn't prepared to talk about, nor willing to admit it
even existed.

During that summer break Luna went of to stay with her grandparents for a few
weeks. Although it meant I would be on my own I was very excited for her as she
was looking forward to it. Her grandparents had a large ranch almost 250 miles
from White Rock and Luna loved to ride horses, a thing she could do almost
every day while she visited them.

It was a Saturday morning and my parents were up early as the hotel was fully
booked for a change. I woke up to the sounds of my parents getting up preparing
for the day, I also got up to take a shower. As I got out my mother walked up
the stairs and said "Oh, you're awake. I just wanted to tell you we're about to
go. You can have the day off today, just go and have some fun. Maybe go to the
lake and catch some sun."

"That would be nice," I replied, "I'm reading this book I really want to
finish."

My mother smiled "Then go do that. Just don't be indoors all day. You could go
to the lake and read there, couldn't you?"

"Maybe," I said, "But how..."

"You can take my car," my mother interrupted me, "We're taking dads car as we
really need to get some groceries for the hotel."

I jumped a little "Do you mean that? I can have the car for the day?"

"I don't know about the day," she laughed, "I said you can take my car if you
want to go to the lake."

"I know, I know," I jumped for joy as I had just passed my drivers exam and
this was the first time she would allow me to drive her car without her being
next to me.

"Just don't go far," she said while she hugged me, "I know you are a careful
driver but accidents happen, so just be careful okay?"

I nodded and whispered "Thanks mom."

A few minutes later my mother shouted "We're leaving! Have a nice day!" Once I
went into the kitchen there was a note with her car keys on it. "Just be
careful!" my mother had written on it. In my fathers handwriting it read "Any
tickets you pay yourself!" The large smiley face underneath it told me he was
joking, but I had always said I wanted to pay my own tickets if I ever got one.

I placed the bag I had packed on the table, made myself some toast and sat down
to eat breakfast. As my father was the cook at the hotel I was raised eating
the best foods and loved toast with marmalade together with a cup of breakfast
tea. After clearing the table I grabbed my bag, the car keys and felt like a
true adult as I walked towards the car that was waiting for me. I even giggled
as I started the car to drive to the lake.

Almost ten minutes later I parked the car on a nearly empty parking lot, it was
still too early for most of the tourists or the locals to be there. I counted
just three other cars besides mine. Another few minutes later I sat down at my
favorite spot overlooking the lake. In the distance I could see White Rock and
a few sails of boats on the water. I sat there for a few minutes before I got
up again to see if I could find a different spot, a little more secluded.

While I was walking a greeted a couple walking their dog and watched how the
man threw a ball into the water for the dog to fetch. The dog jumped quite far
into the water before swimming towards the ball. The whole scene made me giggle
and hate the fact my father was allergic to dogs, a thing that always prevented
me of ever getting a puppy. As I walked along the water I looked at the boats
sailing the waters and imagined myself in one of them, exploring the seas,
sailing towards adventures.

I sat down at a nice spot, spread my blanket, got out my book and started
reading. The adventure had reached it's climax and I really wanted to know how
it would end. The chirping of the birds combined with the murmur of the water
made the story feel more alive somehow and soon enough I lost myself in the
world I was reading about. By the time I looked up again almost an hour had
gone by and the sun was getting hotter. I got a drink from my bag and looked
over the water for a few minutes reminiscing about the story I had just read.

As it was getting hotter I took off my shirt feeling glad I had put on my
bikini when I was home. After applying some sun screen I opened my book again
only to be disturbed when a man walked by with his dog. It was the old man
Miller who greeted me and said "So having a day in the sun?" he said. I nodded
saying "Yes and a good book." He smiled saying "Good on you. Enjoy it. MARCUS!
No not in the water! MARCUS! Oh that dog..."

I chuckled and watched the dog enjoying the cool water. Mr Miller looked at me
and said "Never get a retriever, they love the water a bit too much." He sighed
and called his dog again. "My oh my," Miller sighed, "and I don't have a towel
with me." The dog shook the water from his fur and barked loudly wagging his
tail. The moment the dog saw me he came rushing up to me wanting to be petted
by me. We talked for a while before Mr Miller had to move on, he had to open
the store, Marcus was still dripping wet.

It was always nice to talk to Mr Miller, he had recently lost his wife and as
they didn't have any children he was all alone now, I felt sorry for the man
and wished I could do more for him. Still it was good to see he was getting
better, a little of the old, cheery man we all knew and loved had returned even
though there was still a fair amount of sadness showing.

A woman walking her dog passed by, she hardly even acknowledged me sitting
there. This was typical for a group of people who had recently moved to White
Rock, they made no effort to get to know the locals who had been living there
for all their lives. One thing I noticed about her was the size of her boobs,
she clearly had work done on her, but instead of making fun of her I imagined
myself having breasts like that, not that mine were particularly small or
anything quite the opposite, they were on the larger side for a girl my age.

I looked down wondering how it would look if I had breasts like that woman, how
would it feel? Something inside me got triggered the butterflies in my stomach
and I had to resist the urges I felt by telling myself I couldn't or shouldn't
think like that, I just couldn't help it. They were thoughts I had for as long
as I could remember, ever since I went into puberty I had these thoughts.
Thoughts I couldn't talk to anyone about as I was sure I was the only one who
had them, plus I was just to scared of getting ridiculed, exposed and what not.

My parents had taught me to be respectful, modest and above all prudent. "A
woman always dresses descent," my mother had once told me, "A lady dressed
fine." She even made me bring back clothes I had once bought because they were
_too revealing_, as she called it. It wasn't like they were showing my breasts
or anything, it was a somewhat low cut shirt showing just the smallest of
cleavage possible. She would literally kill me if she knew I was sitting at
the waterside wearing a bikini instead of a swimsuit or at least make me go
home and change.

I felt more like my aunt in that aspect. As modest as my mother was, so
flamboyant was her sister. Not that she was dressed like a slut, she just
embraced her femininity with her long hair, long nails and they way she
dressed. If you saw the two together you wouldn't have guessed they were
sisters, let alone twins. Sure they looked a lot alike, they were twins, but
you had to look closely to see the resemblance ever since aunt Martha had her
nose fixed and her chin reduced.

Still feeling the butterflies in my stomach I got up, gathered my belongings
and with the blanket under my arm started walking down the path a little
further. There was a more secluded area just down the path, a spot only the
locals knew about. After about a ten minute walk along the waterside I reached
that spot and checked if anyone had seen me, again it hit me how quiet it was
that day. I spread my blanked out on the grass again, placed my bag at the far
end and sat down once more. This spot was off the beaten path so it would be
very unlikely for someone to pass me by.

I looked over my shoulders quite a few times before I took off my bikini top
feeling the rush going through my body as I did so. I massaged them after I had
put the top in my bag, it always felt so nice taking off a bra or a top. I
loved the feeling of the girls being free. The massage changed into squeezing
them and after another check if anyone could see me I proceeded taking off my
bottoms too. It felt so nice feeling the sun on my now naked body and I laid
down on my blanket. The adrenaline was going through my veins as I closed my
eyes, a little smile on my face as I finally was doing what I always wanted to
do.

It didn't last long, maybe a minute or two before I heard a noise that startled
me making me put on a shirt and shorts as quickly as I could. A check on my
phone indicated it was time to head back home. From the bottom of my back I
took out a bra and put it on underneath my shirt. I packed my stuff and headed
back to the car. Near the parking lot I stepped into one of the changing rooms
there to put on a pair of panties. Wearing that bra felt so restrictive to me,
all I wanted was to be back in that spot and be naked again.

Half an hour later I was back home, my parents were at the hotel and I was
rather bored being home alone. I took a short shower, put on the hotel uniform
and made my way over to the hotel. My mother was quite surprised to see me walk
in. "Why aren't you at the lake?" she asked me.

"Oh, it was so quiet over there. None of my friends were there, I don't know
why. I got bored and thought maybe I could help out here." I replied. My mother
smiled, hugged me and told me how proud she was off me. 'If only you knew,' I
thought. A few minutes later I knocked on a door shouting "Housekeeping!" It
was tradition for us to do so on the days we knew guests were staying in the
rooms we were about to clean.

I didn't hear anything so I proceeded to go in, carrying a stack of towels. As
I turned around I saw a naked man laying on the bed jerking his hard cock. I
gasped as I noticed what he was doing and with a giant red head I turned around
again to leave. "So sorry," I said, "I thought no one was in here."

He didn't even flinch, kept on jerking and even smiled. I felt my face turn
red, dropped the towels and rushed out of there. I couldn't believe what I had
just seen and knew I had to tell my parents for him to be thrown out of the
hotel. Behavior like this wasn't permitted, on top of that I was still a minor
so it was criminal at best. But I didn't tell my parents, I kept it to myself.
That night I fantasized about it, I dreamed about walking up to him, exposing
myself and helping him get off.

It was that moment when I understood what made me different from my friends,
where they were more _conservative_, I was more _progressive_ and not only in
my political ideals. I always felt more _free thinking_ than anyone I knew
around me. One of the downsides of living in a small community I guess. To
explain it a little better, this all took place before the internet was a
thing. It wasn't as easy to find like minded people as it is today. To me it
was like I was the only one in the world feeling like this, which made it all
but impossible for me to talk about it, let alone explore that side of me.

As I laid there in my bed seeing him pleasuring himself in my head I started
masturbating imagining myself taking his lid in my hand, licking it, sucking it
and tried to feel him entering me. After just a few minutes I had to bite my
pillow to muffle my scream as I had a big orgasm, after which I still didn't
feel quite satisfied. I wanted more, I needed more.

The next day I was quite nervous when I knocked on the same door to bring some
new towels. This time he wasn't in the room, somehow I felt a little
disappointed by his absence. All I could do was clean the bathroom, place some
clean towels and go to the next room I had to service.

As it was a Sunday my mother told me to go home around noon. "You've done
enough for today," she said, "go home and be a teenager, it's summer break
after all."

"Can I borrow your car again?" I asked her, hoping I could go back to the lake
again. Sadly she said she needed hers that day as my father was off to the
closest city to get the necessary groceries for the upcoming week. As I walked
home I did my best to think off something to do as I had no intent to stay home
for the rest of the day. All I could think of was going for a hike in the
mountains, even though it almost was too hot to do such a thing.

As soon as I got home I packed a backpack with some bottles of water and
changed into something comfortable for what I was about to do. I had walked the
nearby trail many times before, could almost dream where I had to go. Just to
be sure I left a note for my parents so they knew where I was, just in case
they got home before me.

As I walked to the start of the trail I remembered the first time my father
took me into the mountains. I was just about eight years old and felt so proud
that he wanted me to come with him. Whenever we saw a bird he told me what kind
it was, he told me all about the wildlife in the mountains, especially about
the dangers of being there. "Whenever you come here," he said, "always bring
more water than you think you need. Also bring this." He showed me a small
metal box with some tablet looking things in it. "These will purify water, now
it won't taste too good but at least you can drink it." he said.

Almost an hour later I found myself deep into the mountains, I had left the
trail almost 20 minutes before. The trail I walked was only known to locals,
passing by some of the most beautiful views I could imagine. This trail was
only recommended if you knew your way around the mountain. As I walked I
remembered the times my father had to rescue tourists who thought they knew
what they were doing. Since about a year I had become a member of that rescue
party, luckily enough I had not yet had to go on a rescue.

For that reason it was recommended to go explore the mountains on a regular
basis as it always changed more than you would expect. I sat down in the shadow
if a large rock to drink some water. As I sat there I felt an urge I hadn't
felt before. As I was all alone in that part of the park I took of my shirt and
my bra. It felt so good to be free. Just moments later I took off the rest of
my clothes, got up and walked the rest of the trail totally naked, it felt so
nice having the sun warming my skin. Just before I was to rejoin the regular
trails I got dressed again, leaving off my bra.

By the time I got home I had all but depleted the water I had brought with me.
My father greeted me as I walked in the house. "How was the trail?" he asked
me. I told him all about it, leaving out the getting naked part. "Good, good,"
he said, "maybe I will go soon myself. I haven't been there for a few months
now."

For the rest nothing special happened that break, my friend Luna returned and
we spent some time together at the lake. We went shopping with her mother in
the big city nearby where Luna told me she wanted to go to college after we
would graduate. "Fort Dix?" she exclaimed when I told her I wanted to go there,
"That's all across the country! Why?"

"Well, Kingston is the best college in the country," I replied, "If I get
accepted there it would be such an honor, wouldn't it? Who do you know that
went there for school?" Luna felt a little betrayed she said, she always
envisioned us going to college together. "But I always talked about Kingston
ever since the dean talked to me about it," I replied, "Remember how excited I
was when she first talked to me about going there?" Luna nodded saying "Yes,
that's true. Still --"

"Oh Luna," I said, "Me going there will not mean I will forget about you.
Never, we've been friends since kindergarten, how can I forget about that?"
Luna put on a little smile "That's true, still feel like everything will
change, though."

Her mother butted in and said "That's all part of growing up, Luna. I had a
friend like Laura when I was your age, we hardly see each other these days. But
you know what? Whenever we do it's like all that time didn't exist, it's even
more special when we're together now. It all will be okay. And -- if you really
like her you would want the best for her. Even if that means she will move
across the country."

I nodded saying "Yes, I would want it for you too. If going to college here is
the best for you, go do it. But take a look at other colleges too, not just
this one because it's close." Luna smiled, she had never been as adventurous as
me. She was more the practical kind. "Let's stop talking about this," I said,
"We're here to have some fun and we still have this year to think about. Like
whatever will we wear to prom?"

Luna laughed and said "Oh, I got some ideas..." She was way more into fashion
than I was making me trust her completely in her choices. She had always said
she wanted to dress us for prom and I had agreed to it. We spent the rest of
the day looking at dresses, shoes and other things for prom. All in all we had
a lovely day.

That year passed quite quickly, I spent my time between going to school, doing
my homework, working at the hotel and some other things. Weeks before I had
received an invitation from Kingston for an interview which I had, after
spending a long weekend in Fort Dix for that I was certain I wanted to go
there. My mother, who had come with me, also got a little more enthusiastic
about it. Just days before my graduation I received another letter from
Kingston, this one would have their decision in it. With a shaking hand I
opened it only to read "we are glad to inform" and "accepted". I started
screaming, jumping around the room "I'm going to KINGSTON! I'm going to
KINGSTON!".

My parents were so proud of me, it was even mentioned during my graduation
which lead to a small applause. A few days after the graduation ceremony we had
our prom. My mother was so happy to see me in my dress coming down the stairs,
Tom was there to pick me up, he was one of the football team. We had a good
time at prom, especially me knowing that I didn't wear any underwear underneath
my dress. As he drove me home we stopped at what we called lovers point, there
were a lot of cars there. I looked at the car to our left where the girl
clearly was on top of the boy, at some moments I could even see her breasts.

Tom leaned over for a kiss, a thing I allowed him to do but I just didn't like
him enough to go beyond that. Not long after he dropped me off at home and just
before midnight I walked back into the house. My parents were happy to see me
home, a few minutes before the deadline they had set. It had been a very nice
evening, but I wanted to start getting ready for college.

That summer was mostly spent looking for a place to live as I didn't really
want to stay at the dorms, that would be a last resort for me. In the end I
didn't have a choice but to accept a room in the dorms. Three weeks before I
had to move we received the information about the girl I would share my room
with, we talked on the phone for a while and she seemed like a nice girl.

"Hi," I said when she answered the phone, "Is this Marisha? It's Laura."

"Oh hi Laura! Yes, it's me. Nice to talk to you, looking forward to college?"

"Yes, a little bit. Just a little anxious about moving into the dorms. I live
in a small town and just the amount of people in the dorms is almost half our
town."

"I can imagine," Marisha replied, "My town is a little larger, but my school
isn't. But we'll make it fun, won't we?"

"Sure, it's just a big step for me. I'm moving to the other side of the
country, into a dorm. All in all it's a bit overwhelming."

We talked for some time longer, by the time I hung up I thought I might like
her and I felt a little better about moving into the dorms. We planned a road
trip across the country as my aunt would take over running the hotel for two
weeks. My parents would take a well deserved vacation around me moving to Fort
Dix.

My father had rented an RV for it, which was mostly filled with all the stuff I
wanted to bring with me. Or at least the amount I was allowed to bring. It
meant that we would need to move all my stuff each night, but it was just for a
few nights so we didn't really mind. We stayed at a few beautiful camping sites
and enjoyed the time we had together, it was nice to see my parents relax.

On the sixth day we arrived at Fort Dix, just a day or two before I had to move
into the dorms. We found a nice spot where we could park the RV and spent most
of the time exploring Fort Dix. Finally the day had arrived, the day the rest
of my life was about to start. I checked in, got my student pass and searched
for the room I was assigned. When I arrived Marisha was already there to greet
me.

"Oh hi, Laura?" she asked me, I just nodded. "I waited for you to arrive. Which
side of the room do you prefer? I don't really mind." I looked around the small
room, noticing it didn't really matter which side would be mine. "I will take
this one, I guess," I replied. My parents carried in the rest of my luggage.
"Hello, I'm Marisha, pleased to meet you." My mother asked her where her
parents were. "Oh they are gone already, my father had to go back to work."
Marisha replied.

My parents stayed for almost 15 minutes before it was time for them to leave,
something that was harder on me than I expected it to be. Suddenly it was real,
the moment I had been looking forward too somehow felt heavy to me. When they
were gone and I watched the RV drive off, all of a sudden it was real: my new
life had started.
