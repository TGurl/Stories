# Chapter Two
The first thing I had tried was to get a loan from the bank, but they declined
to give me one. They said they didn't give loans for medical procedures and
they thought it was too risky because of my age. "You do not have a regular job
and therefore we can't be sure you will repay the loan on a regular basis."
they said.

So I had to find a different solution and because the only time I could be home
for a period of four to six weeks was during summer break, I decided to try and
safe up the money. I created a new account and put away as much money each
month as I could.

After a year of saving I just needed to find the last 500 dollars and I could
make that appointment for real. I had posted on the site I was getting a little
anxious about it.

> I've been saving for almost a year now and there have been some unexpected
> costs, now I might have to postpone because I'm missing the last bit of
> money. I am so afraid I can't afford it this time. What am I going to do? I
> don't know anyone who could help me with this? My parents do not have that
> kind of money and all my friends are students too. What am I going to do? I
> am getting desperate.

One of the women responded and said she could send me some private messages if
I wanted her to. Within a few minutes I read her message.

> Hi, thanks for allowing me to contact you this way. What I am about to tell
> you isn't something I am ready to talk about openly yet. But as I read your
> post I thought it might be a solution for you.
> I'm also going to college and if I hadn't found what I am about to tell you,
> then I couldn't have. Now I'm in medical school and the best thing is I won't
> even have a debt when I graduate. How? Well, I found this site where you can
> look for a _sugar daddy_. Basically someone who is willing to support you
> financially. All I have to do is be with him whenever he is in town. I'll
> join him on a Friday and stay with him all weekend. And I show him my
> gratitude with everything I have to offer him.

I understood what she meant without actually saying the words. As a reply I
asked her if what she did wasn't just another form of prostitution.

> I don't see it that way. He supports me financially, when we're together we
> go out to dinner, a movie or to go see a play. We just spend time together
> and have a good time. He doesn't have a wife, nor children. He works hard and
> has a very good job. He supports me of his own free will. What we do in bed
> is between two consenting adults. I like him very much and he is very
> handsome. If he would ask I might even marry him. We just met through the
> internet.

They way she put it made me really think about it. What she said was actually
right, she didn't sell her body. She just spend time with a man who was willing
to support her. I thought about it for a few days and then one day while I was
working at the store I took out my laptop and visited the site the girl had
mentioned. I registered an account under the same alias I had used on the
support site: _Desdamona71_.

> Hi, I am looking for someone to support me. I'm a student and need someone to
> help me get the surgeries I want. I've tried to save up and now I'm missing
> the last amounts. Someone told me about this and I thought I might try this,
> because I am getting rather anxious I can't afford it at all and I don't know
> what I will do then.

It was after closing time when I posted that message and to make my account a
little more attractive I needed something to show them. I looked around and saw
the dress that was returned that day. On a whim I tried it on and it felt so
sexy. I placed my phone on a table, checked if the door to the front of the
store was closed and posed for a few photos. Totally unhappy with the results I
decided to take a big risk and find a spot in front where I could get some nice
photos.

I found a good spot and repeated the process. With every photo I showed a
little more of myself, on the last one I had spread my legs and with two
fingers I spread the lips of my slit. I took off that dress as quickly as I
could and placed in the coat hanger. Then I sat down at my laptop again,
uploaded the photos to my laptop, made some adjustments to the photos and with
my heart throbbing I uploaded them to the site.

> I hope these will interest someone and I would love to hear from anyone who
> has the financial room to support my efforts to become more like the girl I
> really am.

I couldn't believe I had actually done. Not only had I posted _dirty_ pictures
of myself I had made those photos in a place where I worked. The whole thing
excited me so much.

After just a day I had a few responses to my ad, but no one was really serious
about supporting me. Then suddenly there as this post from _DillonCEO_

> Hi, I love what I see and I am looking for someone to support this way. I am
> a CEO of a company and work hard. I don't have time to date and staying at
> hotels gets lonely. You can check my profile to see that everything I say has
> been verified. I've gone through the process and would love to meet you one
> day. Then we will decide what will happen after. Does that seem reasonable to
> you? Please let me know. I would love to get to know you a little better.

I did what he said and checked his profile, it was like he said everything had
been verified to be true. He really was a CEO of some company and he was
financially independent. I agreed to meet him that Saturday because he was in
town for just a few days longer.

I had decided to wear my best dress, washed my hair multiple times and wore the
best makeup I could. As agreed I had a yellow flower in my hair and sat down at
a table outside the restaurant we had agreed upon. I had insisted to meet
somewhere crowded to feel a little more safe. My heard was racing and if it had
been beating just a little faster I thought I would have a heart attack. Every
fiber in my body told me I should get up and walk away, but I didn't and just a
few minutes later a man sat down across from me.

"_Desdemona_?" he asked. I just nodded, couldn't speak because my mouth was as
dry as it could get. He was a handsome man in his early forties and he clearly
noticed how nervous I was. "Don't be nervous," he said, "we're here to get to
know each other. Just relax and have anything you want. It's on me." We just
chatted for a while and because he was so easy to talk to I started to relax.
At the end we went for a walk through the park to have a little more privacy.

"So," he said, "tell me why you are looking for someone like me."

"Oh," I replied, "yes I guess that's fair. I am not happy with the way I look,
not even a little bit. I want to have surgeries and have been saving up for
almost a year now. But, as it happens, I had some unexpected costs and now I am
missing the last amount. As a student I can't have anything done during the
school year. The only time I can properly heal up and take time off is during
the summer break. If I do not find that last bit I might have to postpone."

"It bothers you so much that you are willing to have surgery?"

"Yes, I can't even look at myself in the mirror. Like when I put on this
makeup, I do my best not to look at my whole face. I just concentrate on my
eyes for example. I hate my reflection, it makes me want to puke. What I see is
a boy looking back at me, that's the best I can explain it."

"So, this might not be the last one." he said.

"No, I want to have more done. I want my jaw line changed, my hips wider and
bigger breasts. I want saline extenders, that way you can easily make them
bigger by just adding saline. To get the hips I want all I have to do is build
up some fat and then they can put that anywhere I want."

"Those are quite radical things," he said. We sat down on a bench overlooking
the ocean. It was such a beautiful spot where we were. He seemed to be thinking
for a moment and then said "Okay, if we are doing this I might be willing to
support you in this and I mean all of it. All I want in return is your company
for a full weekend. What will happen during those weekends we will see, I do
not expect much. I just want someone who can be like a daughter to me." He
turned to me and said "I have a very busy job. I travel all over the world all
the time. I live in hotels and that gets lonely at times. And I do not want to
pay for escorts or anything like that. The women I meet just like me for my
money and that's not what I am looking for either."

I could see he was really serious when he looked at me "As I said I do not
expect anything more than your company. If anything else happens than it should
be because we both want it to. For spending the time with me I will award you
like I do my best employees with a good salary, what about 4,000 dollars for
the weekend. That's a decent hourly wage and similar to what I pay my staff."

I was amazed by the amount he was offering, that kind of money just for my
company? I didn't know what to say but "When can I start?"

"Well," he chuckled "Got anything to do this weekend?" I shook my head and said
"Nothing I can't cancel."

"Good," he said, "What should we call you? Desdemona sounds so -- official."

"Just call me Desi then." I giggled.

"Desi it is, you can call me -- Peter, I always liked that name."

We had a lovely day as we went to a museum, a movie and he took me shopping. He
bought me a lovely dress so I could wear it during dinner that evening. We
ended up in his hotel room and he was sitting at the table as I slowly took off
my dress. With a pounding heart I stood totally naked before him. I knelt down
and stared into his eyes as I unzipped his pants.

Ever so slowly I licked his lid and it got hard in no time. I looked up as I
opened my mouth and took his crown into my mouth. He started to pant and seemed
to enjoy what I was doing. "Oh my Lord," he said, "you are good." It made me
feel so good to hear him say that and I took it in deeper. I started to gag as
I took it as deep as it would go.

After just a few minutes I straddled him, looked into his eyes and said "Let me
show you how grateful I am, _DADDY_" I groaned deep when I called him daddy, I
placed his crown against my now fully wet slit. Slowly I went down on him and
moaned as I felt his penis spread my lips. He placed his hands on my hips and I
leaned forward and whispered "Oh daddy, it feels so good having you inside me.
Do you like it when I call you daddy?" He nodded and I whispered "Fuck me
daddy! You can even come inside me. I want it daddy, I want you to fuck me. I
am your cum slut, our whore."

He lifted me up and placed me on the table. I spread my legs wide and he
started to pound me. "Oh daddy!" I shouted, "Oh yes daddy, fuck me! Fuck me as
hard as you can! Fuck this little whore!"


