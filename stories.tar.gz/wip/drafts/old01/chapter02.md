# Chapter Two
The first week was introduction week and most classes were about getting to
know your class mates as well as the teacher. There were activities to learn
where everything was on campus and there were some parties. The various
fraternities and sororities were busy getting new members and I was seriously
tempted to join Alpha Omicron Pi, a sorority dedicated to _integrity, 
tolerance,  generosity, and personal dignity, aiming to enrich women through 
lifelong  friendship_. AOπ was a serious contender in my mind, but joining it
would mean I had to find a job to pay for it as they asked 217 dollars per
year.

I talked to Marisha about it and she just scuffed "A sorority? Why? What's the
benefit?" "Oh," I replied, "there are so many. I really want to travel the
world, you know that and joining them would seriously open doors for me."

"Well, if you feel that way join them. It's just that a sorority will take so
much of your time besides school. You would have to get a job and such. We
would hardly see each other anymore."

"That might happen anyway," I replied, "We have different classes and therefore
different schedules. But I promise you I will never, ever forget my best
friend. I mean we laid in the same cods when we were babies."

Marisha smiled softly and said "You might be right on that one, I'm just a
little scared I guess."

I couldn't have known how much she would be right at that time. School combined
with the job I got to pay for it all left hardly any room for us to spend time
together. So I couldn't have joined AOπ, even if I had wanted to I just didn't
have the time.

I the weeks and months that followed we got into the rhythm of going to
classes, studying and working for a few hours a week. The few moments we did
have together were therefore extra special to us and we cherished those moments
together. We both knew it was a sign of what was to come once we left college,
got married and started our own lives for real. But for now we were just
college students enjoying our time there.

During one weekend Marisha flew home to visit her parents, she had been
homesick for quite some time and really needed to see them. I couldn't go, as
much as I wanted to there was just no way I could. I had exams the following
week and I really needed to study. That evening I dropped Marisha off at the
airport and as I drove home I remembered I had to get a new bulb for the lamp
on my desk. On my way over to the mall I drove through streets I had never been
before and saw some girls walking up and down the street. They were dressed
really sexy and their hips were clearly visible in their short skirts.

I drove by wondering what they were doing there as it was already dark. I
parked my car near the entrance of the store and went inside to get what I was
there for. Once back in my car I was still wondering what the girls were doing
and parked my car in a dark spot so I could watch them as they paraded up and
down the street. At one point a car stopped nearby one of them and she leaned
over to chat with the man inside, then she opened the door and got in. They
drove off somewhere and I was intrigued by what I was seeing.

My heart started pounding a little as I got out of my car to move in a little
closer to them. I leaned against a wall still in the dark and I could hear one
girl talking on her phone. "No, I haven't had any customers yet," she blasted,
"it's still early, they will come!" Just as she spoke those words a car stopped
nearby and she walked over to it. She leaned over and I heard her say "Hey
sugar! Looking for a good time?" The driver said something I couldn't hear and
I almost gasped when I heard her say "Well, it's 50 for a blow job and 150 if
you want to go all the way." I clasped my mouth as I heard her say those words.
"And I only do condoms," she added before she opened the door and got into the
car.

I rushed back to mine still astounded by what I had heard her say, she was
selling her body for sex. I had heard about hookers before but I had never seen
one for real, let alone been so close to one. Totally flabbergasted I drove
home and couldn't stop thinking about what I had seen. On my way over all I
wanted to do was tell Marisha, but realized she wasn't home when I entered our
apartment. For the rest of the night the images of those girls getting into
those cars didn't leave my mind and I started to wonder how it would feel like
being one of those girls out there. Not only was it very, very illegal what
they did it also was very dangerous, still the thought of me being one of those
girls really excited me somehow.

The next day I went to the mall and got myself a mini-skirt, a crop top and a
pair of high heels, just like the girls were wearing the night before. I also
got myself a pair of big earrings and some dark makeup. When I got home I
showered, did my hair and makeup and put on my new clothes. I looked at myself
in the mirror and just seeing myself dressed like that excited me. I spent the
day dressed like that and ignored the pain in my feet. I wanted to learn how to
walk in those heels.

Later that afternoon I had to get some groceries and really didn't want to
change into my regular outfit, but I did so anyways. After taking off all that
makeup I had been wearing my face felt a little empty and once in the store I
added another outfit, more makeup and an even higher pair of heels to my
shopping cart. This time I had added an almost translucent shirt to my haul.

Once I got home I sat down to do my makeup again, I put on my new outfit and
this time I only wore the translucent shirt. Looking in the mirror I smiled as
I clearly saw my nipples through the fabric. As I stood there looking at myself
I didn't feel like it was me anymore, a different girl was looking back at me
as I stared into the mirror.

I walked into our living room and was so happy I had practiced walking in those
heels before I wore these. I loved the way they made me feel and I embraced the
femininity they oozed as I heard the clacking sound of my heels on the hard- 
board floor. I wanted to memorize these moments I had so I got out my phone,
placed it on the dining table and took a few steps back. The flashes indicated
photos being taken and my heart was pounding as I posed before each shot it
took. After 10 of them I looked at them and giggled when I saw myself on them,
they didn't look like me and that's how Ashley came into my life.

Ashley was the girl I could never be. She was independent, didn't care what
anybody thought of her and felt comfortable in her body. She oozed femininity
and embraced it with both her arms. "Ashley, you did it girl. You are here to
stay," I whispered to myself. At first it felt strange referring to myself as
Ashley, but it also felt rather comforting. I could blame her for as long as I
was her.

The next day I didn't even think about being me, I got out of the shower, did
my makeup and hair and spent the whole day as Ashley. Every time I referred to
myself I used Ashley, just to get used to it and I developed a while backstory
to this character I was playing all day. At some point during the day I was
sitting on our balcony and I pulled down my panties. Feeling the soft fabric of
my tight mini skirt felt so nice and I put my underwear into the hamper. The
rest of the day I spent not wearing any underwear and it felt so freeing to me,
just knowing how I was dressed. I felt sexy, nice and like a real woman, not a
girl anymore.

When the clock informed me it was almost 7 I was sad, really sad to get into
the shower and wash Ashley off my face. I got into my regular clothes and put
all that was Ashley into my wardrobe. I kissed my heels just before I closed
the door on them. It felt a little strange walking into that living room as me
and I giggled the moment I noticed it.

Not long after I got into my car to pick up Marisha from the airport, she would
land in about half an hour. On my way over I made sure to drive through that
street where I had seen the girls and smiled a little when I saw them parading
the pavement on the other side. They looked so beautiful and I even stopped for
a moment to check what they were wearing. One of the girls looked so nice in
her short pink shirt, clearly showing her underbusts. A look at the clock on my
dashboard informed me I was late and I rushed towards the airport.

"I am so sorry," I said as I stopped in front of Marisha who was standing in
the pickup zone. "It's alright," she replied, "I liked stretching my legs for a
while."

The moment she sat down I asked her "How was it in Whitestone?"

"Just wonderful," she replied and with a serious undertone she added "I'm
moving back after this semester. I've talked to the dean of Dearborn college
and I'm able to enroll there. He even welcomed me and told me he knew my mother
from when they both were studying there. I am so sorry, but I can't help it."

It came as a blow to me. My best friend, the one I would navigate this 
adventure, with was leaving me? What about all the plans we had made? How would
I afford the apartment on my own? Question after question popped into my head.

"What?!" I cried out loud, "you are going back? What about me? What about us?
What about all the plans we had made?"

"I am so sorry," she said, "but I can't do this anymore. It felt so good to be
home again. Just to be able to drive home and see my parents, my friends. I've
felt so lonely the past few weeks. Our schedules are too different and we
hardly ever see each other anymore. And I can study English in Dearborn too,
plus I am closer to home. I just can't deny it any longer, I have to go back
home."

I looked at her and saw the tears rolling down her cheeks, she did feel bad
about it I could see that. It still felt like she was abandoning me, like she
was betraying me. And I knew that wasn't what was happening, but I still
couldn't stop feeling that way. "What did my parents say?" I asked her knowing
full well they knew already.

"They were sorry for me, but understood. They told me to tell you to call them
as soon as I had told you. I asked them not to call you right away as I wanted
to be to one to tell you, I needed to be the one to tell you."

I just nodded and said "Well, maybe I can get a few more hours at the store."
Our parents had agreed to pay for half the rent, just as long as Marisha and I
paid for the other half. Now the rent would be split between my parents and me.

"My parents offered to keep paying their half," Marisha said, "and --"

"No," I interrupted her, "I won't accept that. I'm not going to ask them to pay
for something they don't need to. I will call them and thank them for the offer
but I would rather see that money go to you."

"I told them you would say that," Marisha smiled, "but they insisted on me
telling you, so I did."

"You know me," I replied, "no charity!"

Later that evening I called my parents and we discussed how to move on from
this. They agreed to keep paying half the rent just as soon as I had made
arrangements to come up with the other half. I couldn't start paying for it
until I had either secured more hours at the store or gotten myself a better
paying job, until then I would keep paying the same I had done until then and
my parents would pay the rest.

I didn't have to hurry just yet, there were still a few weeks left in this
semester and we made the most of our last weeks together in that apartment. I
had learned how to cook by this time and started experimenting a little too.
Marisha seemed to like what I made and we both knew a period of our lives was
coming to an end.

The last night we spent like we had done dozens of times before as little
girls, in our pajamas, watching movies, eating pizza. We had a lovely night and
didn't want it to end any time soon, but the morning came sooner than we wanted
and the knock on the door sounded extremely loud when it came. Her parents had
come to help her pack and when everything was done Marisha and I held each
other for almost ten minutes, the both of us crying.

I stood on the balcony watching Luke's van drive off with my best friend
inside, I couldn't stop crying for a long time and the apartment felt different
once she was gone. Her side was empty, her pictures were taken from the walls
of our living room and I cried when I saw the last one remaining. It had a
post-it on it "Don't you forget about me!" it read, after our favorite song. I
raised my fist like they did in the _Breakfast club_, our favorite movie we had
watched the night before.

I walked into her now empty room and sat down on the empty bed. I sighed deeply
and laid down, the room still smelled like her. After spending some time in
that room I got up to get ready for work. They had offered me some more hours
at the store and if I hurried I would just about get there in time. My
co-workers noticed I was a little off and when I told them about Marisha
leaving they all felt sorry for me. "You will get there," one of them said to
me, "You will get used to it. It's all part of growing up, honey." It was
Latisha who said it, a big black mamma, that's how she described herself. "I'm
big, black and a mamma of three." and after that she laughed her infectious
laughter that always made me giggle.

Hearing her laugh made me feel a little better and every time our eyes met she
smiled at me, followed by that laughter. No matter how bad things were for her
sometimes, she always had that smile and that laugh. She simply was a beautiful
woman on the outside as well as the inside. "God gave me this laugh for a
reason," she told me once, "and I can't deny what the good Lord has given me,
neither should you. You are so beautiful, just look at you girl! Flaunt what
you got from the good Lord, don't hide it!" She told me that right after I
confided in her how insecure I felt sometimes. I always felt my breasts were
too big and I wore baggy clothes to hide it all.

As I spent my hours doing my job I thought back to those words and how easy it
would be for me to be Ashley more often now I lived alone. I could be her all
the time now, I thought and feelings of excitement went through my body. From
that moment I no longer dreaded going back home, to that empty apartment. I no
longer was scared of being on my own, I was sure I was going to make it and
find a way to make it work.

Right after work I stopped at the mall on my way home and got myself a very
tight and sexy off-the-shoulder dress. It was on sale and only cost 5 dollars,
so I got three of them. All with different styles and in different colors. I
also bought a nice heavy necklace and some big ear rings. The moment I got home
I took a shower and transformed myself into Ashley once more. This time I
didn't want to look sexy, I wanted to be glamorous and really feminine. It took
me some tries to get my makeup just right, but after following a tutorial on
YouTube I achieved what I was aiming for.

I placed my phone on the table once more and posed for a few picture to
commemorate how I looked. Right after I opened a bottle of wine I had bought a
few days earlier and poured myself a glass. I sat down on the couch and
pretended to be in a large company of people. It might have looked strange to
see me going around my apartment, talking to imaginary people but to me it got
more and more real the longer it lasted. I made up names, ages and even flirted
with an imaginary man who was so handsome he made my juices flow.

I felt his arms around me, slowly making their way up and just as he was about
to touch my breasts I slapped him away. "I am not that kind of lady," I hissed
to him, only to take his hand and guide him to a darker spot where we could be
alone. Once there I imagined how he would feel me all over my body, how he
would squeeze my breasts and how I would let him. We kissed and slowly he
lifted up my dress, I sat down on the table and spread my legs. He would
whistle the moment he saw I wasn't wearing underwear. I moaned as I felt his
imaginary rod entering me. Through the closed door I could hear the people
enjoying the party as I was being ravaged by this beautiful man.

I started rubbing my clit as I leaned back on that table, totally lost in my
fantasy and within a few minutes I came, I came so hard. "Oh yes," I moaned
softly, "Come inside me, give me that cum." In my fantasy he took me hard and
unloaded his batter deep inside me. After he had regained his breath, he got
up, threw two 50 dollar bills on me and said "Thank you for your service, time
for us to leave."

I thanked him and folded the imaginary bills and put them in my bosom. After
straightening my dress, we joined the party once more and I told him I would
stay for a little longer. He nodded and left as I stayed to have another wine
and to spend another intimate moment with a few men there.

The next day I went to school, worked for a few hours, studied and when all was
done I changed into Ashley once more. This time I dressed as slutty as possible
and acted like I was one of those girls on the street. The couch was one of the
cars stopping nearby and I leaned over saying "Hey sugar, looking for a good
time? You are? What? Oh, it's 50 for a blow job and a hundred if you want all
of me. No? I only do it with condoms. What? Sure I brought my own. Okay then."
and I sat down on the couch, pretending to be in a car with a stranger that had
just picked me up.

After a few moments I bent over to the other seat pretending to pleasure an
imaginary man sitting next to me. I pretended he ejaculated all over my face
and I opened up my purse to wipe the imaginary cum. "Wow, you came a lot," I
giggled and a few minutes later I got up from the couch and pretended to be on
that street again. Another car, another customer. This time I pretended to get
onto his lap and bounced as I moaned "Oh yes, yes, this feels so good." I
reality I was humping a pillow and it did really feel good. After just a few
moments I came again, maybe even harder than the night before.

I repeated this almost every night for a month or two. Then the novelty started
wearing off and I needed to find another way to get to the same level of
excitement. So I started recording myself on my phone, just how I was dressed
at first but that later escalated into showing more of myself, much, much more.
Slowly I got addicted to it and recorded how I pleasured myself almost every
single evening.

As I didn't want to show anything recognizable, besides myself that is, I
recorded most of those _sessions_ in Marisha's old room. All I changed was that
I made the bed, for the rest the room was empty.

Having those recordings on my phone on it's own was already exciting for me,
every time I handed the phone to someone to show them a photo there was always
the risk of them swiping too far back. One day a girl came very close to
exposing me, all she had to do was one more swipe to the right and she would
have seen a picture of me almost naked. Just before she could swipe any further
I said "Darn it, I forgot something. Could I have my phone?" She didn't even
think twice about it. Almost unnoticeable I sighed a breath of relief as she
handed me my phone. I had to find a better solution, I thought to myself.

Right after school I had to work for a few hours and during the break I had a
conversation with Latisha. She told me her son had gotten a new laptop from
school and that he was trying to sell his old one. "Oh, how much does he want
for it?" I asked her. "Are you interested?" she asked me. I nodded and told her
I had been looking for one for quite some time now, it wasn't a complete lie
but I could hardly say that I just thought about it, could I? "Well," Latisha
said, "as you are a poor college kid what about 50 dollars?" We made a deal and
shook hands. "Just follow me after work," Latisha said, "You can get your
laptop and a decent meal for once. You look like you could use a good meal."
And again she laughed that infectious laughter of hers.

When work was finally done Latisha drove in front of me and I got to the other
side of Fort Dix for the first time. The majority of people from African decent
lived over here and it wasn't because I was afraid to go there or something,
until now I had no reason to be there. Latisha parked her car on a driveway and
I parked on the street. "Come on in," she said as she opened the door, "Wipe
your feet and please take off your shoes."

"Dante!" she yelled, "Dante! I've got someone here for your old laptop. We
agreed on 50 dollars! Dante!" I heard someone stumbling down the stairs yelling
"50 dollars? Mom, that's way to low. I could at least -- Oh, hi. Welcome, I'm
Dante and you are?"

"Laura, pleased to meet you Dante. You were saying?"

"Oh, yes. I was saying 50 dollars is more than enough." He said with a slight
smirk on his face. I could see he was checking me out and somehow it felt a
little flattering. I held up a 50 dollar bill and he rushed upstairs right
after he said "Let me get it for you. I just finished installing windows again,
so it's ready for you to go. All you have to do is setup a new user and stuff."

A few minutes later he returned with a bag and showed me the laptop inside.
"You can test it if you want to," he said, "but I promise it's a good one." I
said that it wouldn't be necessary and that I trusted him. "It it isn't I will
tell your mom all about it." I whispered in his ear. He took a few steps back
and said "In that case let me check a few things before I hand it over." I
laughed and joined Latisha in the kitchen. "He's a good kid," she said,
"typical 16 year old, but a good kid." I nodded, sat down at the table and
took in the smells of good food being prepared.

"You should start a food truck or something," I said, "this sure smells nice."

"Oh," Latisha said, "I had one a few years ago. But someone lit it on fire one
day and the insurance only paid half of it. Just about enough to cover my
losses, but not nearly enough to get a new truck. Oh yes, baby, I was the mamma
of a whole lot of people. All regular customers, some came by every single
day." She looked up and said "I wonder how they all are doing now." She was
quiet for a moment before she said "Ah well, can't change the past, always look
out for the future. That's what my mamma always said and she was right."

About half an hour later I sat down at a table with the whole family, they
prayed before dinner and I just sat there quietly, respecting their wishes.
Loraine, the eldest started the conversation with "Laura? You are going to
college, right?" I nodded as I took my first bite of a very delicious meal.
"So, what's it like living in the dorms?" she continued her question.

"Oh, I wouldn't know. I have an apartment in _the Harbor_, you know it?"

Loraine nodded and said "Wow, you must be rich then?"

"Hardly," I replied with a laugh, "I just come from far and was lucky enough to
get in there. At first I stayed with a friend of mine, but she had to go back
home. She missed everybody too much and now I have to work hard to be able to
live there. If it weren't for my parents paying half of the rent I do not think
I could stay there."

"Wow," Loraine uttered, "but couldn't you just move into the dorms?"

"No," I replied, "I've rejected the dorms and now I could never move in there.
If I had to move out I would have to look for somewhere to live like any other
person has to. But as I said, I'm lucky my parents help me out."

Dante, the middle child, said "So what do you study?"

"Hospitality and Tourism Management," I replied, "I want to travel the world
and see what is out there."

Delilah, the youngest, replied "Mommy, I want to travel the world too, can I?"

"Once you're old enough," Latisha replied, "and have gone to college just like
Laura, then maybe -- I would have to think about it still."

Delilah prowled her lips and said "But I want to mamma."

"Yes, just like yesterday when you saw that ballerina on TV? How long did that
last? A day? Just eat your vegetables, honey." Latisha laughed. I chuckled and
it felt nice to have a decent meal with a family for once.

After dinner I helped clear the table and the children sat down in front of the
TV. Latisha looked at them with a look only a mother could give her children
and said "Loraine is almost done with school. She's the daughter of my sister
and when she passed I took her in as my own. That's three years ago now and I
love her so much. She doesn't realize how much she's like my sister. What I was
saying is she's looking out for colleges and she's set her mind on Kingston.
When I told her about you she couldn't wait to meet you. You better prepare for
a whole lot of questions coming your way."

I smiled and said I would be ready for it. "You better be, she's a smart kid
and she's applied for several scholarships already. All on her own, I didn't
have to do a thing."

"Smart," I said, "and she's willing to do the work."

Latisha nodded "Not a lazy bone in that body of hers. You know she had her
first job at age eight? I kid you not, she started a doing chores for the
neighbors and for three dollars she would help out a few hours a day. Then at
age 12 she started a babysitting service. She helped a lot of families out that
way. But when her mamma passed away she lost herself for a while, quite
understandable, so I gave her all the room she needed. It melted my heart the
first time she called me mamma, until then I had been auntie. It was on a card
for mothers day. She wrote that from that day onward I was here mamma too." A
single tear rolled down her cheek.

"I am so sorry for your loss," I said and offered her a hug.

"It's okay sugar," Latisha said, "My sister was very very sick, ovarian cancer.
She slowly deteriorated as the cancer ravaged her body. The treatments didn't
help and one day she was told they couldn't help her anymore. She passed away
in her sleep one night and Loraine was the one who found her. And although it
was hard on us all, it hit her the hardest. When child services came around to
ask who would take her in there wasn't a fiber in my body that would have
allowed them to take her."

I was taken by the love she showed her children, all three of them and I knew
she was a good mother, a very good mother to them. I looked at the three
fighting over the remote control and chuckled. "Come on now," Latisha shouted,
"Cool it down over there. Dante give Loraine the remote you know it's time for
her daily show, you just go upstairs and do whatever it is you do on that
computer of yours." The three of them froze the moment Loraine raised her voice
and Dante got up to go to his room. "Can I play some Minecraft?" he asked
Loraine, who replied with a "Sure, sure, but no internet you hear?" Dante
nodded and ran upstairs.

"Him and his Minecraft," Loraine sighed, "Do you know that game? I don't
understand what's so attractive about it. All he does is build things." I
didn't know that game at all and couldn't answer her. We sat down at the
kitchen table and Loraine offered me a cup of coffee. "We should do this more
often," she said, "I like this."

"Me too," I replied, "but I don't want to be a burden."

"You? A burden? Come on now. I always cook for four and it's not that you ate
that much either. It's not a burden, not to the least. I like you and I like
this. I normally don't have someone to talk to like this after work and you are
a good person. I know, I can see that. Even if you are an atheist, I can see
there's no evil in you."

"How did you know?"

"You didn't pray for dinner," Latisha laughed, "but you respected us by sitting
there quietly until we were done praying. I can respect that."

"Sorry," I replied, "I wasn't raised religiously. We never went to church or
anything. But I wouldn't call myself an atheist, I've never thought about it,
really."

"Well, we might make a good church-going girl out of you still," Latisha
laughed, "You know what? What do you have to do this Sunday? How about you
coming by and we could have dinner together again. I know Loraine would like to
see you again."

"That would be nice," I said, "but I think I have to work on Sunday."

"Until when?"

"I think until six? Yeah, I think so."

"Well come by after work then. We usually don't eat until 7 or 8 on Sundays."

I knew I couldn't say no and with that I had a dinner date set on Sunday. It
was already getting late when I left and as I drove back to my side of town I
couldn't help but drive through that street again. As I drove by the girls I
looked at them one by one, they all looked so nice and I wished I would have
the nerves to join them one day. But I knew I wouldn't dare to do such a thing
right at that moment.

When I saw the mall was still open I went inside to get some small things I
needed for school when I saw they had a camera on sale. As it only cost 50
dollars I grabbed one together with a tripod. When I got home later I read in
the manual how I could charge it and was a little disappointed to learn the
first charge could take up to 12 hours.

I booted up the laptop for the first time and smiled when I noticed Dante
hadn't been lying to me. It was a good laptop and after completing the setup I
was happy with it. I connected to the WiFi that was offered to all the people
how lived in the building and was happy to see it offered a decent speed.

I browser the internet for a while, reading the latest news from all around the
world. Now at least I have my own computer, I thought. The one I had gotten
from school had all kinds of restrictions on it and I could only use it for
schoolwork. One check on the clock told me it was time to go to bed and as I
stood in the shower brushing my teeth I thought of all the things I could do
the following evening.

The next day was a hard day at school, I had one class after the other and it
was almost eight in the evening when I walked home though the park. It was a
nice evening and I always enjoyed breathing the fresh air after such a long day
inside. As I walked through the park I took a left turn where I normally would
go right. I wanted to walk for a little while longer as it had been a very
stressful day.

I came across the old ruins in the park. They were the only remains of a
building from right after the first settlers. I took some time to read the
plaque once more and when I looked around I noticed I was the only one there.
Without thinking I stepped over the low fence and stepped into the old ruins. I
checked if anybody had seen me and hid behind the largest wall.

With my heart pounding I placed my phone on one of the protruding bricks, set
the camera and just before it took a picture I lifted up my shirt exposing my
breasts to the camera. I had set it to take five pictures and I moved my body
in between every photo. Right after the last one I pulled down my shirt,
grabbed my phone and got the hell out of there.

With my heart still pounding I entered the apartment building and Jose asked me
why I was breathing so hard. "Oh," I said, "I just ran the last bit." When he
asked me why I answered "Because I thought it would be fun. I was surely
mistaken, I need to start exercising." Jose laughed and said "You kids are so
dumb sometimes." I chuckled and got into the elevator.

Once inside I checked my phone to look at the pictures I had just taken and
giggled when I saw how I was standing very uncomfortably. The photos were
blurred and I deleted them, but I knew I wanted to do it again some da Jose
laughed and said "You kids are so dumb sometimes." I chuckled and got into the
elevator.

Once inside I checked my phone to look at the pictures I had just taken and
giggled when I saw how I was standing very uncomfortably. The photos were
blurred and I deleted them, but I knew I wanted to do it again some day and
when I did I wanted to have good pictures in the end.

I made myself a simple dinner and sat down at the table eating while I watched
a video or two on YouTube. After dinner I did the dishes and sat down to study
as I had to catch up for the upcoming finals of the year. An hour or two into
my studies Marisha called to see how I was doing, we hadn't spoke since she had
left and it was so nice to speak to her again. I told her all about Latisha and
everything else. I didn't tell her about my alter ego though, that still was my
little secret.

We spoke for about an hour and right after I went back to my books. When I
stopped the clock told me it was almost 2 AM and I quickly went to bed as I had
to get up early in the morning. I felt good about myself as I had made good
progress in my studies.

The next day I got up early, went to school, my job and got home around seven.
I had another quick dinner and started studying once more, just one more
evening like the day before and I would have caught up, I thought. This time I
turned off my phone as I didn't want to be disturbed. It was another late night
but I had achieved my goal, I was all caught up and ready for the upcoming
finals the next week.

That Sunday I went to work and took a nice bottle of wine to give to Latisha
that evening. When I arrived there I saw a couple of cars there and the house
was quite busy, I wasn't the only guest. I rang the doorbell and Loraine opened
the door. "Laura!," she shouted, "Finally! Come on in, please." She hugged me
as I stepped into the door. "Hi Loraine," I said, "so nice to see you again."

I took off my shoes and walked inside. There were a few people there and when
Latisha saw me she yelled "Laura! You're here. So nice to see you again.
People! This is Laura, she works at the store with me and she's good people.
Laura, the people." I raised my had and waved "Hi, I'm Laura." was all I could
utter.

A nice young man walked up to me and said "Hi, I'm Steven. Nice to meet you.
You're studying at Kingston I heard."

I nodded "Yes, who told you that? Let me guess, Latisha did."

Steven laughed and said "Who else?"

I chuckled and guessed he was around my age, maybe a little older. He was
handsome and a real gentleman as he offered me a chair when we sat down at the
table to eat. He sat down next to me and we talked during almost all of the
dinner. He was a student too, but he want to one of the Ivy league ones and was
home visiting his parents. "I chose to do law school," he said, "but I'm
tending to switch to politics as my major and you?"

"Hospitality and Tourism management," I replied, "I want to open my own travel
agency and see the world."

"Wow," Steven replied, "that's a way better answer than I have. 'I want to sit
in a cubical of some large company and do legal stuff.'" With the quote he
slightly changed his voice and it made me chuckle. We had a good chemistry
during dinner and when I felt his hand on my knee I didn't protest. When he
slid it a little higher I didn't protest and just as he was about to go too
high I stopped his hand and smiled a shyly to him. He just smiled back and
didn't say a word.

After that dinner I gave him my phone number, fully expecting to never hear
from him again. But he did, just a few days later he called and we had a nice
conversation. He was charming, funny and made my juices flow so to say. It was
just so sad to know he was so far away from me, we couldn't just hop into a car
and visit each other.

Right after that call I had to tell Marisha and although it was rather late she
didn't mind. She was so happy to hear how happy I was to have met Steven. "Oh,
you should have seen him," I said, "his eyes, ah, I could lose myself in them
and his voice! So deep it made my chest resonate. I don't know what would have
happened if he hadn't to go back that evening."

"Wow girl," Marisha laughed, "looks like someone has a crush." She then began
to sing "Laura and Steven sitting in a tree --- K I S S I N G!" I told her to
stop it but she continued and then said "No but seriously, I am so happy for
you. How long has it been since you last saw Travis? A year?"

"Almost, I guess. But that was never that serious. I mean, we had an on and off
thing going on."

"Oh, but I think Travis has other ideas about that. He's all about how he's
moving to Fort Dix and be with you again. He's telling anyone who wants to
listen. I am not kidding."

"He is? Aw, that's so sweet and somehow disturbing." I laughed.

"Isn't it? I told him to let you go, you're living your own life now and he
needs to move on. But he doesn't want to, I guess."

"Ah, just let him be. He's harmless. Sure he's a big guy, but he hasn't got a
bad bone in his body."

"That's for sure. Whenever you see him play he's this rough dude tackling
anybody who comes near him, but after the game? He's all about taking care of
people and asking how they are doing and stuff. He's a really good guy. Gosh, I
might have a little crush on him."

"Go ahead," I replied with a chuckle, "I'm sure Matt wouldn't mind. Oh, talking
about Matt, how's he doing these days?"

"Matt?" Marisha said, "I wouldn't know. Haven't talked to him in a while. Matt?
MATT! Laura wants to know how you are doing? What should I tell her?"

From a distance I heard him say "Tell her I'm doing fine."

"He's doing fine he said," Marisha said to me, "I didn't know. Hadn't talked to
him in like 10 minutes or so."

"What? Is he there with you? Did you guys move in together?"

"Oh yes, a few weeks ago. Didn't I tell you?"

"No! Why would you keep that from me?"

"I was sure I told you. Yeah, I did, didn't I?"

"Nope, this is news to me. But congratulations! I am so happy for the both of
you."

"Matt! Laura is happy for us."

"What? She's happy? Tell her it's a total nightmare!" I heard Matt chuckle in
the background.

"You heard him," Marisha laughed, "Apparently I am a nightmare to live with."

I started laughing. Those two had been together for a few years now and was a
big part why Marisha wanted to move back and now they had moved in together,
finally! They are the embodiment of people who can't exist without each other.
Marisha fell in love with him and never looked at anyone else, the same goes
for Matt. It was almost love at first sight for the two of them and I'm sure
they will get married one day.

"Oh, one moment Matt wants to talk to you."

"Hey Laura," Matt said, "I just wanted to know when you are coming back here
for a visit? We haven't seen you for such a long time. You could stay with us
if you want to."

"I don't know Matt," I replied, "It's not that I don't want to, but it's just
so far away and plane tickets are expensive."

"That's just an excuse, so what is it? Why aren't you here more often? Is there
a boyfriend?"

"No, no boyfriend. Not even one for a single night if you were wondering. No,
I'm trying to build a life here and it's so busy with school and work and all,
I just don't have the time."

"Okay, was just wondering. I'm sure Marisha would love to see you again and her
birthday is coming up so I will call you about that later. Whow, are you
slapping me? See what I have to endure living with her? This is total abuse!
Please Laura, come home and safe me! Please!"

I chuckled and a second later Marisha was back on the phone "Huh, I hate him
sometimes! Oh don't give me those puppy eyes, I'm not falling --" her sentence
was interrupted by what clearly was a kiss. "Darn it, he made me forgive him!
Darn it!" Marisha started to laugh once more and then whispered to me "I love
him so much, but never ever tell him that!"

"It will be our secret," I replied. We chatted for a while longer and when I
laid down my phone I suddenly felt the distance between us. Right at that
moment I wished I could just walk over to her house and be with them. I looked
around the apartment and ended up looking at her old room, I still hadn't
furnished it or decorated it. It still was as empty as she had left it. "I
might have to change that," I thought.

For the next few weeks Steven started to call me more often and we had a good
time talking on the phone. He helped me install Skype on my laptop and we
started talking to each other using that program. The nice thing was that we
could see each other and the calls were free. After a few weeks we contacted
each other every night and I started to look forward to it during the day.

We talked about anything and I started to open up to him ever so slowly, I
always was cautious opening up to anyone. It's not like Whitestone where
everybody knew everything about you, over here in Fort Dix it was different.
Heck I only knew the neighbors from passing in the hallways, it's not that we
ever spoke to each other let alone go for a visit.

With that all being said Steven had something disarming about him, something
that made me trust him. I don't whether it was his smile, his eyes or just his
general demeanor, somewhere deep inside me I knew I could trust him. So I told
him things I only ever told Marisha or Travis. I told him things about how I
felt about myself, how insecure I felt most of the time.

"You? Insecure? Why? Just look at you! You are beautiful, intelligent and you
have nothing to be insecure about!" he said.

"Well," I replied, "there are things you might not understand, you being a man
and all. There a are _girl_ things I'm talking about."

"Like what?"

"Like -- this is so embarrassing -- like the size of -- well, the girls."

"The girls? You mean -- oh," he said a little embarrassed.

"Yeah, that's what I mean. You could never understand that and I don't think I
can really explain it either."

"But what about them?" he said a little shyly, "I'm not trying to be creepy, I
am just curious."

"Well, their size," I replied, "They are just so -- big. And sometimes it's all
boys are looking at when they see me. It feels so demeaning to be reduced to
what's on my chest. So I wear baggy clothes all of the time, just to hide
them. I am sure a lot of guys in my class don't even know the color of my
eyes."

"I think I understand what you are saying and don't get me wrong now, I'm not
saying this to be creepy or to be demeaning in any way. I don't think there's
anything wrong with them. Sure I've noticed them, any guy would, but I also
know your eyes are blue, with slight dashes of green. It's the eyes that make
you attractive to me, the rest is just packaging."

I chuckled and said "Do you mean that?"

"Oh yes, I do. Look I grew up in a household full of women. My dad left when I
was about 2 years old. My sisters and my mom raised me to be a gentleman and to
respect women and I sure hope they did a good job."

"They did," I replied, "and thank you."

"For what?"

"For being so nice to me."

"Oh, you're welcome and don't ever thank me again for that. It's who I am and
who I was raised to be. You just be more secure about yourself, you have no
reason to diminish yourself. You are so beautiful and you have a good soul.
That's all that counts. And just remember this, who cares what people think
about you? They will be talking about you whether you comply to them or not,
you can never ever live up to their expectations. So just do you. Be who you
really are and know this. You only have to make one person happy in this world
and that person is yourself. If you do that then others will follow. That's
what my mother taught me and she was right."

"Wow, I might try that. _you only have to make one person happy in the world
and that person is yourself_. Mind if I steal that one?"

"Be my guest, just attribute it to my mom. She would be honored."

"You said your father left when you were two, mind if I ask why?"

"Oh no, he's a total scumbag. I tried to contact him once or twice and he
totally ignored me. He's a drunk, a criminal and I don't want anything to do
with him or from him anymore. He had his chance and he blew it."

"But your mom and he were together once, weren't they?"

"Yeah, for one or two nights until she told him she was pregnant with me. Then
he just left, never to be heard from again."

"And he's also the father of your sisters?"

"No," he replied, "That's a sad story, their father died in a car accident.
My father took total advantage of a grieving wife and mother, he took all her
money, got her pregnant and left. I hate that man so much for what he did to
her. If she hadn't been the strong woman she is..."

"I understand and do not want to open up old wounds," I said softly, "I'm sorry
if I did."

"Oh, don't be sorry," Steven said, "it's part of my life and my story. It made
me who I am today, respectful and loving. I don't ever want to be like my
father, not ever. Maybe that's why I chose to go to law school."

It felt so nice talking to him, I really felt I could open up totally to him. I
felt like I could introduce him to Ashley, my alter ego. The girl who didn't
give a rats ass about what other people thought, but I also felt it might be
too soon to do so. What Steven and I had at that moment was an ultimate
friendship and maybe it was meant to be that way. Maybe we shouldn't go further
than just this, I was afraid anything more would ruin what we had.

All I knew that by talking to him about my feelings of insecurity, by opening
up to him about what I felt I got a little more secure about myself. Whenever I
looked at myself in the mirror I thought about the words _you only have to make
one person happy in the world_ and ever so slowly I started to like the girl
that was looking back at me. Ever so slowly I started to change.
