### Removed section about one night stand with Steven

After dinner we talked some more and I told him where I lived. Just as I was
about to leave I whispered in his ear "The Harbor, apartment 12c." smiled and
stepped into my car. Almost an hour later there was a knock on my door, with a
pounding heart I opened the door to let Steven in. We ended up in Marisha's old
room and within seconds we both were naked. I knelt down and took his big black
cock deep inside my mouth. I hadn't had a real dick for such a long time.

After sucking it for a while I pushed him on the bed and got on top of him,
guiding his big dick inside my very wet pussy. "Oh yes," I moaned as I sat
down, feeling him stretch my tight little pussy. "It's been so long," I sighed
and had to wait for a moment before I was able to move.

He squeezed my boobs and I leaned forward so he could suck them, sending
shivers through my body as he nibbled on my nipples. I started to move my hips
and slid up and down his big fat cock inside me. "Oh my God," I moaned, "this
feels so good." He started panting too and I raised myself to bounce up and
down his cock. Within a few minutes I came hard on his cock and shouted "Oh my
Lord, I'm coming, I'm coming, I'M COMING!!" When the orgasm slowed Steven
lifted me up and laid me on my back. I spread my legs wide and he plowed his
dick deep inside me, he started pounding me hard and I urged him to go harder
and faster. "Oh yes, fuck me!" I shouted, "fuck me hard. Harder! I want you to
hurt that pussy! Oh yes, yes, yes. I want that cum, I want it deep inside my
pussy. Come inside me! Come deep inside my cunt!"

With just a few more strokes he came hard and I pulled him close to me. I felt
his cock deep inside me, thrust and twist as he ejaculated his sperm deep
inside my womb. When he regained his breath again he rolled off me and it took
us a few minutes more to start all over again. I started by jerking his cock a
little and when it got harder I sucked it once more.

When he was ready again I got on top of him once more, this time I guided him
inside my ass. I moaned when I felt it slip inside me and sat down on it. I
felt him go so deep inside my ass and I leaned backwards to show him where his
dick was. I started to fuck him and it felt so good I instantly came again.
Right after I got off him and he took me from behind, pushing his rod deep
inside my ass once more.

He fucked me so hard that I could keep up with him, I just let him go and
ushered him on "Oh yes, fuck that ass. Fuck it hard, give me that cum once
more. Fill my ass with your cum!" He didn't need to hear that twice and
unloaded deep inside my ass.

When we both regained our breath we got up, showered together, got dressed and
he kissed me as he left. The next day he had to return to his school and it
would be quite some time before we saw each other again. Right after I shut the
door I rushed to the room and grabbed the camera from the dresser it had been
in. Unbeknownst to Steven I had recorded our get together. I rewound the tape
and was happy to see the both of us and although some of it was out of frame,
most of it was clearly visible. I started rubbing my clit as I watched the tape
and came all over again.

As I walked out the room with my camera in hand I felt his cum drip out of both
my holes and giggled. I had never done anything like that before, the last time
I had been with a guy had been with Travis and that only happened after we had
dated for almost a year. Somehow Steven had felt what I needed and was willing
to give me just that, a simple evening of sex without string attached. It was
at that moment I knew I wanted more of that, I needed more of that.

I needed to find a way to scratch that itch without people knowing about it. I
needed to become Ashley!
