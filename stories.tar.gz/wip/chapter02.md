# Chapter Two
It had been several months since I had seen or even spoken to Carina, not that
it was concerning to me I had to concentrate on school anyway and I went to
visit my parents during that time. When I walked up to my mother she almost
started to cry. I was wearing a 1950s vintage dress and had done my hair and
makeup were period appropriate.

"Oh my word," she said, "you look so beautiful. You're wearing a dress! My
word, you made me so happy. Can't wait to see how your father will react. Oh my
baby is all grown up now." She hugged and kissed me. She took my arm and we
walked towards the car.

When we got home my father pretended not to recognize me. He got up and said
"Hello, I'm Mr Davis. Pleased to meet you." then he turned to my mother and
asked "It's nice you brought a friend, but when is Laura coming home?" I hugged
him and said "Hey dad."

He put his arms around me and whispered "You made and old man cry. You are so
beautiful. Hello pumpkin, I've missed you."

During that visit I realized this wasn't home anymore, I was visiting my
parents. Home was my apartment in Fort Dix. That realization made me feel happy
for some reason. We had a lovely time and it was wonderful to see them again
but on the same hand I was also happy to go _home_ again. Back to Fort Dix, my
school and above all my friends.

As I sat in my apartment, not really knowing what I wanted to do, I sat down at
my laptop to read the latest news and update the few social media I had. The
only followers I had on there were old friends, well more like acquaintances,
and family. Suffice to say it didn't take long to check, while I was doing so
something I had read stuck in my head. I reopened her timeline to verify and
yes, I had read it correctly. She openly admitted she had undergone breast
enlargement. Now she didn't have the biggest breasts to begin with but being so
open and honest about it?

She wrote how happy she was now and how she finally felt more feminine. I liked
her post and went on with my day. All during the day her words kept popping
back into my head, I could simply not believe she had posted that on social
media for anyone to read. On the other hand I admired her for it too. It all
was a little confusing to me. I contemplated if I would be so open and honest
about it if I had done what she had done. 'Well, I couldn't hide it I guess' I
thought and started to giggle a little.

A few minutes later I found myself standing in front of my mirror trying to
imagine how bigger boobs would look on me. I got an old bra from my drawer and
filled it with two t-shirts. I tried to make it look as natural as possible and
while wearing another shirt I looked in the mirror again, ignoring all the
strange bumps I liked what I saw. I liked it a little too much.

At the store where I do all my groceries they have this isle where they sell
all kinds of items. It's always fun to see what they have because it changes
from week to week. This time my eyes fell on some bras and instinctively I
looked for the biggest ones they had. When I got home I first put away the
groceries before I went into my bedroom. I folded four t-shirts and padded that
new bra I had purchased. I put on another shirt and checked myself in the
mirror, it still didn't look quite natural but it was better than the first
time I did it.

I got a mini skirt from another drawer and put it on too. I smiled when I saw
my figure now and loved it so much I decided to keep wearing it for the rest of
the day. Having those big bulbs made me feel so good about myself I did the
same every time I got home. To make it look more real I started looking online
for examples and got fascinated by the women I found who all had 1000cc or
bigger breasts. I thought they looked so beautiful, so feminine.

At a crafts store I got myself a thick piece of foam and after quite some
trials and errors I finally had made the perfect replacement for the shirts I
had been using. I could stuff it in the bra underneath my boobs, it went around
and up to my nipples where it almost seamlessly transitioned into my real
boobs. Now I could wear lower cut shirts and tank tops showing some cleavage at
the same time.

It started to feel so normal to me that whenever I didn't wear my padded bra
was feeling unnatural. I checked online for information about breast
enlargements and found the perfect solution for me: saline expanders. During
the surgery they would place an _access point_ underneath the skin so you could
add more saline without needing surgery again. That was what I wanted, I wanted
those big breasts for real. The more I looked into it the more I was convinced
I wanted them too.

In order to do so I did have to do one thing, I had to tell my friends and
family about it. It wasn't something I would be able to hide and I really
didn't want to do it without their support. So when I was ready for it I
invited Ashley and Marisha over as I wanted to tell them at the same time. We
sat on the couch and chatted for a while before Marisha said "Well, this is
nice and all, but you said you needed to talk to us."

I felt my face turn white, the moment of truth had arrived. "Yes," I said as I
looked at the glass in my hands, "there is something I need to talk about. But
it might be easier if I just showed you guys. Now, bare with me this is going
to look stupid and I'm fully aware of it. But it's something that makes me feel
so good and then I am going to say what I need to say. Okay?"

They both nodded and I went into my bedroom. Just before I stepped out I said
"And please don't laugh, I'm serious and this isn't a joke."

"We won't," Ashley said.

I took a deep breath, opened the door and stepped out with my padded bra
underneath a low cut shirt. They both gasped and then burst into laughter, I
wanted to retreat into my bedroom and never come out again. They clearly
thought it was ridiculous. It was Ashley who said "No, no, come back. We didn't
mean it that way. It was just so -- unexpected. I was so sure you ware going
to show up in rainbow colors and tell us you were a lesbian. We even made bets
about it and Marisha won. Come back, please."

I turned around again and stared at them with tears in my eyes. "Aw," Marisha
said, "we didn't mean to hurt you. Come here, sit in between us. However did
you do that? Come, come here."

I sat down and just stared at my fingers. "Now," Marisha said, "what is it? You
want bigger boobs? Go for it. Do whatever makes you happy." Ashley nodded and
said "Yes. Just one question. Why?"

"Well, I was on social media the other day and an old friend posted about how
she had them done. It made me think and when I checked online a came across
these women who had large boobs, on of them even breached 3200cc. As I looked
at them I wondered how it would look and I tried it out. I loved it so much and
then I made these padding out of foam. I wear them every day while I am here
and whenever I take them out it's like loosing a little of me every time I do.
So I did some research and decided I want implants."

"What kind of implants?"

"Saline, they're called expanders. They put a little access point underneath
you skin so you can add more saline just by injecting it there. You can add a
max of 100cc every two months, so your skin stretches more naturally. I've
decided I want the ones you can expand the largest. Not that I will go that
far, but I would like to have the choice to do so I I wanted to."

"But isn't it dangerous?" Ashley asked.

"Yes, but not as dangerous as silicone. When one of the expanders pops your
body just gets filled with saline and it's disposed of naturally. Silicone on
the other hand is a different story. Plus you can't expand silicone. If you
have silicone implants and you want to go bigger you need another surgery."

"Wow," Marisha said, "you really looked into it. I'm impressed and happy that
you told us. I will support you in any way I can, but I don't have that kind of
money."

Ashley agreed "Neither do I. Just one more question if that's okay. Why? Your
natural breasts are so nice."

I looked at her, thought for a moment and said "Did you ever had that feeling,
about anything, where you didn't know you missed something until you did it? Or
just made you feel that it was so right when you did it? That it just seemed to
fit although you never tried it before?"

Ashley thought for a moment "I think I understand what you mean. Like that time
when I had my mole removed. I never thought it would make me feel the way it
did when it was gone. If the doctor hadn't told me it was malignant I would
never have removed it."

"Something like that," I replied, "well that's how I feel whenever I put this
bra on. The moment I padded my bra for the first time felt like coming home
after a very long journey. I can't explain it otherwise."

Marisha butted in and said "You feel more like you, is that what it is?"

"Basically," I replied, "that's why it hurt when you started to laugh. I was
showing you the real me, the one I keep hidden. The woman who desperately wants
to come out and step into the world."

Ashley hugged me and said "What can I do to help?"

Those words made me cry. When Marisha also put her arms around me I started to
cry even harder. "Thanks," I said through my tears, "this was really hard."

"Why?" Ashley asked, "You should know by now you can tell us anything. We'll be
right here, we might not agree with everything, but we will always have your
back. No matter what." Marisha just said "Hear, hear, truer words have never
been spoken."

Just one more hurdle to take, telling my parents. Probably the hardest part of
it all was confronting them with this. They came over for a visit and I thought
this was as good a time as any. So I sat down and just said "Mom, dad, I want a
breast enlargement. I didn't know how to tell you so I just said it."

My mother was shocked and my father just leaned back, I wasn't able to read him
at all. "Why?" my mother asked, "you're so beautiful."

I told her how I felt and how I came to this conclusion, I tried to keep my
emotions out of it as much as possible. "I really need this mom, when I looked
at myself in the mirror it just felt so -- right." I said to her. My father
hadn't said a word until then.

He leaned forward and said "First let me say this. I don't think you need it,
not one bit. I really think you'll regret it and I think it's a huge mistake.
That being said my second point is this. You're an adult now and we can't stop
you even if we wanted to. I'm just happy that you told us before you did
anything. Now, although every fiber in my body tells me that I should lock you
up to prevent you from doing this, I will support your decision. If you think
that will make you happy then I say go for it."

If looks could kill at that moment my father would have been a dead man. "Are
you kidding me? I'm not allowing my daughter to harm herself. No way, never.
Not going to happen!" she shouted and then started to cry "We just came over to
have a nice time with our daughter and now she tells us this? Why Laura? Why?"

I put my arms around her and just hugged her. When she calmed down she said "Oh
my baby, I just don't want to see you get hurt. What if it all goes wrong? It's
still surgery. Anything can go wrong."

"Yes," I whispered, "so does getting in my car. Every time I drive to school
anything could go wrong. That doesn't prevent me from driving, does it?" My
mother just stared at me. "What I mean is," I said, "we accept risk every day
of our life. And yes there is a risk, but it's almost zero if you go to a good
hospital. That is what I will do, seek out a good hospital with a good
reputation. If it's more expensive to do so, so be it. I want to minimize the
risk as much as possible."

"That makes me feel a little better," she whispered, "I still don't understand,
but it does make me feel better. Are you sure? Are you really sure you want to
do this?" I nodded and she said "Well, as your father said. You're an adult
now." I hugged her a little harder and said "Thanks mom, I just didn't want to
do it without telling you first."

My mother nodded and said "I appreciate that, I really do."

A few weeks later I had my first appointment at a reputable hospital, together
with my doctor we had decided on a plan. Although I was an adult I really
wanted my parents point of view on this. On my way over I tried to call them
but there was no answer, which was a little strange. I parked my car on their
driveway and opened the backdoor. If they weren't home it would have been
locked, I thought. Everything was quiet downstairs and I didn't find anyone
there. So I went up the stairs and heard a noise coming from the bedroom.

The door was ajar and when I looked in I gasped. There, on their marital bed,
was my mom with a black man on top of her. Her arms around his neck, her legs
spread wide. They were clearly having sex. Startled by my gasp I heard my
mother shout "Laura?" I ran downstairs and wanted to get out of there. My
mother was cheating on my dad? I couldn't believe it, but I had seen it with my
own two eyes.

Just as I had unlocked the front door my mother grabbed my arm and said "Laura
please, let me explain." I just stared at her through my tears "What is there
to explain mom, your cheating on dad!" I opened the door hearing her breaking
voice saying "Laura pleas, it's not like that. We wanted to tell you for so
long, but didn't know how."

"Tell me what mom? That you're sleeping with other men?"

"Laura please, come back inside." she cried.

I turned around, stared at her and went back inside. I mean, she still was my
mother and I owned her a favor for supporting my decision. We sat down on the
couch in the living room and the man walked by saying "I think I better go
now." My mother just waved and turned to me.

"Laura, please listen to me. When you moved out I fell into a hole, suddenly
your room was empty. For the first time in years your father and I talked,
really talked. About the two of us and how to move forward. We opened up and
told each other everything. He told me about one of his fantasies, one he had
for almost as long as we are married. He wanted to see me with another man. I
was so nervous the first time, but when it happened it felt so right. I didn't
know what I had been missing until that moment."

I just looked at her "Now," she continued, "I have _friends_ over or go on
dates. I feel so alive again and afterwards I tell your father all about it.
Nothing is hidden, no secrets. Then I started recording it, so he could watch
it whenever he wanted to. This whole thing has made us closer than we ever
were, he gets to see his wife with another man and I get my pleasure out if it
too."

"So," I said as I wiped away my tears, "dad knows?"

"Yes, and he encourages me. If I haven't been on a date in a while he finds me
one. It's all between consenting adults and it's all perfectly legal."

I looked at my mother and they way she looked at me was as if she had gotten a
little younger. We had never had a talk like this, one where she was open about
her own sexuality. She had always been this respectable, conservative woman to
me and now that illusion was shattered. "So what you said when I told you about
my surgery was all an act?"

"No, I still think you are making a mistake on that one. I think the biggest
reason why I cried was you were being honest and we were still keeping a secret
from you. I wanted to tell you right there and then, I just couldn't. I knew it
would hurt you and I just couldn't. My role as a mother is to protect you, not
hurt you."

"Yeah, finding out this way was a good way to do it," I replied.

My mother chuckled and said "I didn't want this to happen either, but somehow
I'm glad it did. Now it isn't a secret anymore."

"And you are both good with this?"

"More than good. As I said I haven't felt this alive in a long, long time. And
they make me feel so good."

"Do they?" I turned my head to her, "Come on mom. We've gone this far, let's
take it all the way. Let's have our first girl-talk."

My mother chuckled, pulled her legs up and said "Oh, my Lord. This isn't easy,
you're my daughter. But okay. The first time, let's start there. After he told
me about his fantasy I had to think about it for a while, then I thought if I
wanted to keep the love of my life I had to make sacrifices and we agreed that
I could stop at any moment. So we found a mutual friend and invited him over.
One thing led to another and we ended up in bed. He was so caring and loving,
he first made sure I got _everything_ out of it."

"Just say it mom."

"Say what?"

"You came, you had an orgasm."

"Oh, not just one, multiple." she laughed and blushed. I had never seen my
mother blush before.

"And then?"

"Then came the ultimate moment. He came on top of me and while we looked into
each others eyes, he _entered_ me. It was at that moment I knew what I had been
missing all my life. Feeling him entering me was -- was like coming home. I
looked at your father and took his hand. He sat there on that chair, pleasuring
himself. I turned my attention back to my lover and had the most exciting sex I
had in years! At some point I made him pull out and I removed the condom.
Feeling him inside me without it felt even better, especially when he came.
Sending all the sperm inside me, oh just the idea made me come again."

"Wow, mom. A little too much detail." I chuckled. I could see on her face as
she told me the story she really meant what she said. How could I be angry at
her if this was really what she wanted? They supported me, the least I could do
was support them. I wasn't happy with it, but I could at least try to
understand.

"Mom," I said after thinking for a moment, "If this is what makes you happy --"

"It is Laura. It is."

I looked in her eyes, my eyes drifted down to her now half open robe and I just
couldn't speak anymore. We sat there for a moment and kissed, not like a mother
kisses her child, but like passionate. My hands opened her robe and I squeezed
her boobs a little, kissed her neck.
