# White Mountain
White Mountain is a ski-resort in the North of the Country and became popular
in the late 60s when celebrities found out about the pristine mountains
offering the best slopes in the country.

Living in White Mountain is not only costly, during the winter months the
population triples in size, making it even more expensive. During the summer
months tourism slows down making WM another sleepy small town like all the
others.

## History
WM was founded by loggers over 150 years ago and was almost abandoned until the
late 60s when celebrities flocked to WM for the mountains and the skiing. Ever
since then it has grown, but there are strict building codes to keep the
overall look of the town. So there are lodges, bungalows for rent, but no
high rises. This policy has made WM only more popular because it has managed to
keep its small town vibe despite everything.

## Where did Laura grow up?
Laura grew up in WM. She doesn't particularly likes it there. Sure during the
winter months when all the people come it's fun. But during the summer she
dislikes it and thinks everything is happening anywhere else.

Her father moved there after meeting her mother and they were married 9 months
later. Only 5 month after that Laura was born.

## How far is it from Fort Dix?
WM is roughly a 36 hour drive from Fort Dix. So most people from WM fly there
from the airport near Stillwater, a town almost 60 miles from WM.
