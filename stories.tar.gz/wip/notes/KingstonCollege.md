# Kingston College
Kingston College is the most prestigious college in the country and only a
select view are accepted each year. Kingston College offer a variety of college
grade education ranging from law to engineering.

## History
Kingston College was founded over 200 years ago and has many of the most famous
poets, scientists and judges as its alumni. Probably the most famous of them
was the most beloved president of all time, Joe Jackson. The first black
president of the country, he has changed a lot for the better and is beloved to
this date. His state funeral was attended by millions and watched on TV all
over the world.
 
## How many students?
Kingston college houses roughly over 5200 students each year, of which roughly
1200 are first year students.

## What does Laura study there?
Laura attends law school, just like her father did before her.

## How long will it take?
4 years

## What will it cost?
enough :)
