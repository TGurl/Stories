# Chapter One
I still remember the day I told my mother how I felt. I was 8 years old and
finally had the courage to tell her that I felt more like a girl than I did a
boy. She was shocked at first but said she had always known something was up.
"I just thought you were gay," she said.

"No mamma," I replied, "I want to wear dresses, have long hair. And I love to
play with dolls. Every time we visit Emma we play with her dolls. I want my own
dolls." It took her some time to come to terms with it but when she saw my eyes
lit up when she told me I could get a dress, she knew and felt peace with it.
At the age of 11 my mother made sure I got hormone blockers, by this time I had
long hair, was playing with makeup and even at school I was always grouped with
the girls.

When I was fourteen I was with a man for the first time, he was almost 45 and I
was in seventh heaven when I had his cock inside my mouth. I took it as deep as
it would go and after a short while I climbed on top of him. We put so much
lube on my little hole he slipped right in and I moaned loudly. I started to
bounce up and down feeling his cock slide inside me. After a few minutes he
send his white juices deep inside my little ass and I loved it.

I started to visit him every day and every day he nailed me.
