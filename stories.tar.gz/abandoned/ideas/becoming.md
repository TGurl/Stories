# Becoming
_an erotic tale by Transgirl_

## Introduction
Let me start by telling you I don't have any regrets or feel any ill will
against anyone. I am happy to be who I am today and feel so lucky to have
someone who understands and supports me.

I grew up in a small town and had a very happy, sheltered childhood. Although
it was hard for them, they have accepted me for who I am and what I do. My
little sister now even works for me, together we travel the world. I've been to
places I would never have imagined I would go, from the best tropical beaches
to the hustle and bustle of downtown Tokyo. My job has brought me everywhere
and I love it.

But let me start at the beginning: the last year of high school. The moment
when it all started to change for me.

---

The halls were filled with students and I just leaned against my locker wishing
for this day to end. It had be rough on me the last year of high school and I
couldn't wait to go to college. All I wanted was to get out of this small town
and see the world. My mother always called me a dreamer, but I was determined
to do it. I had been accepted into college to get a degree in communications and
hospitality so I could become a flight attendant and I couldn't wait for this
year to end so I could finally move out.

But that was still months away, first I had to graduate high school. I huffed
as the bell rang, got my books from my locker and made it to English class just
before the second bell rang. I sat down at my favorite spot in the back of the
class and pretended to listen to the teacher. I just couldn't be bothered
today. After a while the teacher slammed his hand on my desk to awaken me from
my daydream and the whole class chuckled. My face turned red and I wished the
earth would swallow me alive.

"Luna? Back to the living I see." Mr Jones was one of my best teachers, but at
that moment I could have killed him. I didn't like being in the center of
attention, especially not like this. I looked up and saw him smiling at me
before he turned around to continue the class. Even though it was uncomfortable
for me I did pay attention the rest of the hour. When the bell rang Mr Jones
asked me to stay behind.

"Luna," he said, "is everything okay? It's not like you daydreaming in class."

I nodded and said "I'm just having an off-day, I guess."

"We all do some days," he replied, "I understand. But just so you know, if
there is anything you want to talk about, I am here." Mr Jones was one of the
guidance councilors at school, someone you could trust.

"It's just," I stumbled, "like, I don't know. I just want to graduate and get
out of here. It's like this town is smothering me, like I can't breath."

"Ah, yes, I understand," he replied, "well, let's just say I felt the same way
when I was your age. Then I went to college and look where I am now. Back here,
teaching you brats English. Just be patient, Luna, your time will come. Just
let it go and breath." He had a little twinkle in his eyes and nodded slowly.
"Now go or you will be late for next class." he said.

I rushed off, got my books from my locker and just before the next bell I
walked into Chemistry class. The words from Mr Jones still rang in my head and
I felt a little more relieved as I sat down at the only table available, this
time in front of the class.

Finally the last bell rang and I made my way over to homework class. This was
available for students who lived a bit further away or who's parents weren't
home for some reason. I attended mostly as a tutor and loved helping my fellow
students. As a bonus I got my homework done before I went home. An hour or two
later I walked outside and waved to my mother who was there to pick me up.

"How was school today?" she asked and as always I gave her the same answer,
"Just like yesterday, mom." She chuckled and started the car. She was still
wearing her nurses uniform and smelled like disinfectant. When we got home she
said "Be a dear and make us some tea. I will be right back." She went up the
stairs to change and I filled the cooker with water for tea. It was a ritual we
did since I was very young and when my sister was old enough we included her
too.

"Dani? Tea!" I shouted and my sister came running into the kitchen. Even though
she was only two years younger than me, she had the mental capacity of a six
year old. But I had never seen anyone more happy then her and I loved her just
the way she was. Dani hugged me and said "Do you know hippo's are dangerous?
I learned it at school today." I smiled "Yes Dani, I know." Dani chattered
about all she had done at school and at the neighbor's. She was best friends
with their daughter Marie, who actually was about 6 or 7 years old.

Just when tea was ready my mother came down and sat down at the kitchen table
with us. "Now ladies," she said, "tell me all about your days." Dani repeated
what she had told me and my mother gasped "No! Hippos are dangerous? Who
knew?". She winked at me and listened intensely to what Dani had to say. Then
it was my turn to talk, there wasn't much to say but I told her about what Mr
Jones had said to me.

"Mr Jones is a wise man," she replied, "listen to him. And you know you can
always talk to me, don't you?" I nodded "Yes mom, I know." Just as we were
having out second cup and Dani started playing with her dolls, my twin brother
came home. He threw his bag in the pantry and sat down at the table with is.
"My God," he said, "practice was excruciating." As captain of the school
football team he was one of the popular kids at school.

"Josh, one cup and then you know what to do." my mom said. Josh nodded and said
"Yes mom, one cup and then I will wash my clothes." He huffed as he said it,
but smiled at me. Although we were twins we couldn't have been more different,
he was a real jock and I was more of a nerd. He loved sports and I liked books.
But despite all of that I loved him more than I would ever had admitted at the
time, for we had shared a womb for nine months.

"Yes, Josh. You are the eldest, as you always say, so you have to lead by
example." my mother chuckled. I huffed "It's only fifteen minutes mom!" My
mother started laughing "Yes, you just wouldn't come into this world. But then
suddenly you couldn't wait, started crying when just your head popped out." It
was a story my mom loved to tell to everyone who wanted to hear. I huffed again
but couldn't resist a silent giggle.

After Josh had put his training gear in the washer he went upstairs to take a
shower. I got up as soon as my mom put away the cups and went into my room. On
my nightstand was the book I was reading, but I just sat down in my chair near
the window and stared outside. Our house was on the outskirts of town and my
room was in the back so I had a nice view over our backyard and the fields
beyond it. My eyes fell on our neighbor who was mowing his lawn and as soon as
he waved I waved back. I kept watching him, wishing for him to take of his
shirt. He might be way to old for me, but he was a handsome man and his torso
was one to admire.

As soon as my father came home we sat down for dinner and the first thing Dani
said was "Dad, did you know hippos were dangerous?" I giggled realizing how
important that fact was to Dani, one of her favorite plushies was a hippo. My
dad acted like he didn't know either and said "Now that's news to me. Did you
know that mom?" My mother shook her head and said "I learned it today too."
Dani smiled a big smile and said "Mrs Riviera told us today in biology. It's
true."

After dinner we sat down together to watch some TV and it was one of those
rare moments we were all home together. My father and Josh talked about
football, Dani was watching cartoons and my mother was reading her book. I just
sat there realizing how much I loved them all, feeling content with just being
there with them.

The next few months nothing really changed. I went to school, went to see Josh
play and studied hard to graduate. The feeling of being smothered by it all had
passed and I was back to my happy self. One day at school the photographer came
to take pictures for our yearbook. I had dressed nicely and when it was my turn
I sat down on the stool, feeling awkward. The woman said "Smile!" and I did.
When she had taken the picture she said "Wow, you should really think about
modeling. You have a great face and you really pop."

She looked at me and continued "I would love for you to come by and talk to me
about it. I would pay you of course. Interested?" I shrugged my shoulders and
replied "I have to talk to my parents first."

"Sure, sure," she said, "but please tell me you'll think about it."

I nodded and went on with my day. But her words never really left my mind and
when she left and saw me she repeated "Think about it." and handed me her card.
I really didn't know what to think, I hated being photographed. I never knew
how to act or pose and most of the photo's were awful, at least that's how I
thought of them. My mother always loved them, but she is a mother and therefore
biased.

After school I got home with my sister and we had tea together, it was one of
the days my mother worked the late shift and she wouldn't be home for a couple
of hours. I chatted with Dani about her day and when she started to play with
her dolls again I looked out the window thinking about what that lady had said
to me. Somewhere deep inside me I wanted to know what it would be like and I
started to get interested. But there was nobody home besides the two of us, so
it was impossible for me to go at that moment. But I had made my decision, I
would go and get some nice photo's for my parents as it was their anniversary
real soon. Maybe we could all go together and get a picture of the three of us
for them?

A few hours later my father came home and started making dinner, Josh came home
too and the four of us sat down at the table. We talked about the day and I
kept what the woman had said to myself. It was the first time for me not to
tell my parents everything and somehow it felt exciting having a little secret.

The next day school ended early and I was excused for homework class. My
parents were still at work and Josh was on his way to practice. I wanted to go
to see what that woman wanted, but I had no way of getting there besides taking
the bus downtown. Something I had promised to never do by myself. At that
moment I wished I had my license and my own car, but my parents had promised me
that for graduation.

I got that card from my backpack and looked at the address, it was way too far
to walk and taking the bus was out of the question. Not only had I promised not
to go on it by myself, I didn't have the money for it either. How could I ever
get there without my parents knowing? I turned around and walked over to the
stands to watch my brother practice.

When he was done he saw me and waved. Together we were dropped off at home by
his coach. "It was very nice to meet you, Luna," he had said as I got out. "It
was nice to meet you too, coach." I replied. He laughed and said "I'm not your
coach, but I'll take it." He drove off and together we entered our house. Josh
put his clothes in the washer and I sat down at the kitchen table.

"What's up sis?" he asked when he walked in, "you were so quiet. I know
something is up."

I shrugged my shoulders and said "Sometimes I wish I had my own car. I so tired
of being picked up or dropped off. Aren't you?"

"Sure," he said, "but we've got to graduate, remember?"

"Yeah, yeah." I huffed, "I know. It's just --"

"It's just what?" Josh said after a while.

"Okay. You've got to keep this between us. Twins promise!"

"Twins promise," he huffed.

"Really? Come one, promise me."

"Okay, I promise. Say it already!"

"Well, you know picture day? That lady that took our photo's for the yearbook?
Well she told me I should think about modeling. She invited me to come over to
talk about it. She would even pay me. And now their anniversary is coming up so
I thought it might be a good idea for the three of us to go and give them a
nice photo of us, just the three of us, as a gift."

"You modeling?" he chuckled, "they really want everybody, I guess. But all
jokes aside, it's a really good idea. So what's wrong?"

"Well, today we were out early and I thought about going. But I had no way to
get downtown. No money for the bus or anything. If I had my own car I would
have gone already."

"Ah," Josh said, "well, where is it?" I handed him the card and he said "Oh,
that's near the mall. Just ask mom to drop you off tomorrow. Say you are
meeting friends and you will call when she can come to pick you up." That was a
brilliant idea and I said I could hug him. "Oh no," he replied, "those nine
months were enough for a lifetime." He chuckled as he got up from the table to
take a shower.

A few moments later I got up too and walked up the stairs. I could hear the
shower and automatically I looked over. I noticed the door was ajar and went
over to close it, when my eyes fell on him as he let the water fall on his
face. His broad shoulders, muscular arms and how they moved underneath his
skin. I just couldn't stop watching. I leaned against the wall as I watched him
shower. When he turned around I quickly pressed my back against the wall in an
attempt not to be seen. Carefully I peeked in again and Josh was washing his
hair with his eyes closed. I leaned a bit more in and saw what he had between
his legs. It was huge and with my hand I had to muffle a gasp. I couldn't stop
watching his lid as it dangled with every move he made. I wondered how big it
would get if it was erect as it was this large already.

Suddenly I realized I was watching my twin brother, shook my head, shut the
door with a bang and shouted "Close the door already!" From the shower I heard
him shout "Sorry, I thought it was closed." I giggled and went into my room
with the image of him in my head. At that moment I realized I had wanted more
than just a look.

An hour or two later my mother came home and I asked her to drop me off at the
mall the next day. She agreed to drop me off on her way to work "But you will
have to call dad to pick you up, okay?" I nodded and felt excited. As soon as
Josh came into the room I couldn't help but look at his crutch. 'Luna no' I
thought and walked into the living room, switched on the TV and zapped across
the channels until I saw something that slightly interested me.

The next morning I slept in a little and when I got downstairs Josh bumped into
me saying "If you know how much that photo will cost Brandon's dad will bring
us. Just ask her how much and when we can do it." When I asked him how he had
arranged that he just smiled and said "Come on sis, I can keep a secret too."
Then I remembered he had gone over to Brandon's the night before. I punched his
arm and went into the kitchen to get me some cereal.

My mother was busy doing the laundry and when she saw me she asked "Oh, who are
you meeting with at the mall? Maybe one of their parents can drop you off,
seems like dad is too busy today." My heart froze a little and in my head I
went through a few possibilities, but nothing felt right. "Oh no, Lily's mom
was counting on dad. Ah, now she can't come." My mom stared at me as if she
didn't quite believe me, but then she said "Okay, just call your dad and tell
him to pick you up when you are ready." I walked over to my purse and got out
my phone. "Hey dad!" I said when he picked up, "Yeah, it's just -- what? -- oh
yes, I need you to pick me up -- what? -- yes mom said so. Thanks daddy."

I turned to my mother and said "It's like he knew already." My mother chuckled
and said "He just can't say no to any of you kids, but especially you." She
finished what she was doing, went upstairs to change and we got in the car.
After my mother had dropped me off at the mall she went on to go to work. My
heart started racing a little and I walked into the mall, just to be able to
tell my parents honestly that I went there. I looked around for a little bit,
waved to someone I knew and went out the side entrance. After a few minutes I
saw the studio of Miss Natalia Davis, photographer. According to the card.

As I opened the door a buzzer sounded from the back and it took a few minutes
for Miss Davis to appear. "Ah," she said when she saw me, "so you were
interested." I smiled and said "Well, there are two reasons I came actually."

"Okay, what's the first one?"

"Well, it's my parents anniversary soon and I thought it might be nice to get a
picture taken of me and my siblings. To give them as a gift, but I wouldn't
know how much that would cost."

"Ah, well, that all depends. How large should it be?"

I looked around at the photo's hanging there and pointed to one I liked, "Like
that one. That's a nice size."

"And should it be framed as well?"

"Depends on how expensive it is." I replied

"Well, the photo would come at about 100 dollars, 60 for the frame --"

"160 dollars?!" I interrupted , "we don't have that kind of money. We're just
three kids who want a nice photo for our parents."

Miss Davis started to laugh and said "I can't make it any cheaper, sorry. But I
like your honesty. So you know what? Got a few hours for me today?" I stared at
her not understanding what she meant, then she continued "If you work here for
let's say 4 hours, then I will do the photo for free and you would only have to
pay for the frame. So 4 hours work and 40 dollars for the frame."

It was a good deal, but I really didn't know what to think. I could spare 4
hours that day and it was better than wandering around the mall all day. So I
agreed to the deal and we shook hands. "Miss Davis, I have to be honest. My
parents don't know that I'm here. As I said it needed to be a secret."

"First, just call me Nat. Miss Davis is my mom. Secondly I understand, you were
looking for a gift for them. Trust me you are safe here and all I want you to
do is help me organize my office. It's a bit of a mess and I do not have the
time, there are a few families coming for the pictures and I need to get other
ones ready as they will be picked up later today. So if you could do that it
would be such a blessing for me." She smiled and took me to her office, I
gasped when I saw the boxes of paperwork that needed to be filed.

"Don't worry," she said, "you don't have to get it all done today. Just the
boxes marked 'filed'. They can go into that cabinet over there. Just sort them
by date and it will be fine." I opened one of the boxes, sighed and said "Okay,
I will do my best."

I grabbed a box marked 'filed, 2020' and started sorting the papers in there.
It took me almost an hour to sort them all and when I was done I got a folder
from the cabinet, marked it '2020' and put all of the papers in it. I was
halfway through another box when Nat appeared again. "Want to watch?" she said.
I looked over at her and she said "Come on, you can use a little break."

When we arrived in the studio there was a family waiting, I nodded my head
slightly and smiled. "This is Luna, she's helping me today. Now, how do you
want to do this?" Nat said. The family took their place and when it was all to
their satisfaction Nat took a few photo's, asked them if it was to their
liking, made a few more changes and took another couple of photo's. All in all
it took her most of an hour before the family was satisfied with the result.
Now I understood why it was so expensive to have your picture taken, Nat made
it a whole experience for her clients.

"Now I will have to develop the photo's, frame them and they will be ready on
Wednesday, is that okay with you?" she asked. The woman said it was fine and
together with Nat they went back to the front of the store.

"As agreed half upfront and half on delivery." I heard Nat say. A few minutes
later the buzzer indicated the family had left. I walked into the store and Nat
asked "What did you think? Did you like it?" I nodded not really knowing how to
posture myself. "Sit down," Nat said, "want a soda?"

"No, tea would be nice though." I replied.

"Tea? Wow, that's a first. I don't know if I have any tea. You know what? Let's
both take a break and go to the coffee shop next door. I know they have the
best tea in the world."

I sat down at a table in the coffee shop and Nat placed our order at the counter,a few moments she joined me saying "They will bring it over. Now, I haven't asked
you about the other thing yet. About maybe modeling for me. Anything change
your mind?"

"I don't know," I replied, "I always look stupid in photo's."

"Oh I disagree," Nat said, "and I am a professional. You pop in photo's, the
camera loves you, as they say. You just need to learn how to pose, how to
handle yourself. And I could teach you, it's not that hard."

She thanked the girl who brought our order and I chose a tea from the box held
in front of me. When the girl was gone Nat continued "Look Luna, modeling isn't
that hard and if done correctly a lot of fun. Think about it. Lot's of makeup,
accessories, clothes you can wear. It would be just us girls having fun. I
promise you that I won't do anything with them as long as you don't want me to.
I even burn them if you tell me to, including the negatives so to say."

"Well, I think it could be fun. But that's something I really need to talk to
my parents about. I won't do that behind their backs, this was something
different because of their anniversary and stuff. But to be honest, I don't
really feel comfortable doing this, like lying to them. I don't like keeping
secrets from them."

"You are a good kid," Nat said, "I wish there were more like you."

"There's my brother and my sister," I replied, "we all are like this."

Nat started to laugh. "Honest to the bone," she chuckled. We sat there for a
while drinking our tea and coffee. When we both had finished we went back to
the studio and Nat walked into the office. "Oh wow," she said, "you've done
more than I thought you would. This is great, thank you so much. And we have a
deal, you just come with your brother and sister and we will take a nice photo
to give to your parents. And you know what? I had such a great time I will
throw in that frame too, as I gift from me."

I called my brother to confirm we could come on Friday after school. A few
minutes later he called back to say Brandon's father was able to come with us
that afternoon. Now there was just one more thing to do, making sure Dani kept
it a secret too. Now everything was arranged I felt a little more relaxed and
started to really like Nat. She was kind to me and I let go of my guard a
little. "Okay, I will finish that box I started with and then I will go, I
guess." Nat said it wasn't necessary, but I was taught to finish what I started
and didn't want to stop doing so.

After another hour the box was finished and I went to see if I could find Nat.
In another room she was bent over some sort of light box, she was staring
through a magnifier at some negatives. "Sorry," I said, "I don't want to
interrupt, but it's time I go." Nat looked up, smiled and said "I will see you
Friday. Bye honey, it was fun having you around. You can come whenever you
want, okay?" I said goodbye and walked back to the mall, when I got there I
decided to walk a little further. My dad's work was just a few blocks from the
mall and it was such a nice day.

About ten minutes later I walked into the lobby where my father worked and the
woman behind the front desk smiled when she saw me. "It's been a while since
I've seen you. Luna right? Are you here for your father? Well, just go up to
the third floor, second office on your left. He should be there. So nice to see
you again." I waved to her as I got into the elevator and my father was a
little startled when he noticed it was me who knocked on his door.

"Luna! Why, what are you doing here? I thought I was to pick you up? What a
nice surprise." he said. I told him I walked over because it was such a nice
day. My father looked at the clock hanging on the opposite wall and said "My
Lord, it's 4 already. We need to go." He put away whatever he had been working
on, turned of his computer and after he grabbed his jacket he said "We need to
hurry Josh will be waiting." I chuckled and we both made it down to the lobby.

"Night Phyllis, have a good weekend." he said to the woman behind the desk.
"You too Dave." she replied. We walked over to the car and the first thing my
father did was take of his tie. "Now," he said, "let's pick up Josh and go
home."

The week seemed to creep by very slowly, but finally the day had arrived. Dani
had promised to keep it a secret and when school was finished Brandon's father
picked us up to take us to Nat's studio. We had some fun taking some stupid
photo's and then we took some serious ones. We picked the one we all liked and
Nat promised to bring it the next day, on my parent anniversary.

"Come," she said, "let me show you how you develop a photo." She took us into
the room with the red light. It was a bit cramped with all of us and Natalia
showed us how she developed the photo. It was like magic how the photo appeared
on what seemed like an empty piece of paper. Especially Dani was totally blown
away. Natalia hung the photo up to dry and switched on the normal light again.
"Now it has to dry for a few hours and when it's ready I will frame it and
bring it by tomorrow, okay?"

Dani cheered and said "I can't wait to tell mom about this." I told her she
couldn't tell until tomorrow as it was still a secret. Dani looked a little
disappointed but hesitantly agreed. "You can tell her tomorrow, okay" I said.

"Tomorrow after we have given it to them, then you can tell her all about it."
Josh added to it. Almost fifteen minutes later we were dropped off at home and
we could only hope Dani would keep it a secret until the next day.

It was around noon when the doorbell rang. "I will get it!" I shouted and was
happy to see Nat standing there with a package in her hands. "Thank you so
much," I said as I took over the package. "Just congratulate them for me, will
you?" she said as she turned back to go to her car. "I will, thanks again."

When I walked back I called for Josh and Dani to join me and together we walked
into the backyard where our parents were sitting. "Mom, dad," I said, "I know
you didn't want to do anything special today, but it still is your anniversary
and we wanted to give you something to celebrate." I handed the parcel to my
mother and my father got up to stand next to her as she opened it.

"Oh you guys," my mother said with a tear in her eye, "you shouldn't have. But
thank you so much. Should I open it now?"

"Nah," Josh replied, "open it next year, it's okay." Dani shouted "Open it,
open it." My mom smiled and carefully tore off the paper. She started to cry
when she saw what it was and my father gasped "When did you guys do this?"

"It's wonderful," my mom cried, "this is just the best. Look at Dani. This is
who you guys are, thank you so much. I love it." Dani crawled on my mothers lap
and told her all about the studio and how she saw the photo appear on paper.
My mother hugged her when she was finished and I could see Dani was relieved
now she had finally told her the story. My parents hugged Josh and me before my
father shouted "Sod it all, we're going out for dinner. Let's celebrate."

My mother sat down next to me and asked "When?" I told her everything and felt
relieved when she said "This is such a nice surprise, thank you Luna." I turned
to her and said "There's just one more thing, mom."

My mother turned to me and said "Yes, tell me."

"Okay, it's like this. Nat, the woman who took the photo, well she asked me to
model for her. She said I popped on photo's. And she also said she would pay me
for it. And now I've spent some time with her I really would like to try and
see if I like it. Taking this picture was so much fun, mom, it really was."

My mother stared at me and then said "Okay, if that's what you want to do. But
I want to meet her first, okay? I will come with you on the first day, just to
see what's it all about and I want her to sign a contract. Just to be sure."
Sometimes I hated my dad was a lawyer, it had rubbed off on my mom. "But now we
have to find a nice place for this!" she said. We got up and decided where the
photo should hang. My father got a hammer and a few minutes later we all looked
at it hanging above the fireplace. My mother hugged me again and whispered
"Such a nice gift."

A few weeks later my mom went with me to go to Nat's studio. As soon as we
entered she came rushing to the front and shook my mother's hand. "Hello, I'm
Natalia, Nat for my friends. Come on in. So nice to meet you." she said. My
mother replied her and asked "Okay, let's talk business first. My daughter is
still under age and I want to be sure nothing nefarious is going on." Nat
agreed and we went into her office.

"Look, this is the contract I have with all my under age models. You can read
through it, show it to a lawyer if you want to. It's all perfectly legit." she
said. My mother replied with a chuckle and said "My husband is a lawyer and I
will make sure he goes through this, thanks." Nat went on by saying "What we
are going to to today is make what we call mugshots, just a few photo's to show
potential customers. We're just going to have some fun today. You can stay if
you want to."

My mother said she wanted to and we went into the studio. To the left there was
a rack of clothes, a makeup table and lot's of shoes. Nat asked me to sit down
while she did my makeup. I put on the clothes she had handed me and took my
place underneath the lights. Nat gave me instructions on how to pose and took a
couple of pictures, the longer we went on the more fun I had and after an hour
I was having the best time. Even my mother laughed at the stupid faces I made
for the photo's. When it all was done and I had changed into my regular clothes
again, my mother helped my take off the makeup.

Nat had picked a few photo's and together we decided on top ten for my
portfolio. Nat printed some copies for me and put them in a binder. "When the
portfolio is ready I will come by and show them to you. If and only if you have
a signed contract I will show them to clients. If you don't agree I will leave
it with you and we just had a nice day today. Can we agree on that?"

My mother shook her hand and said "Deal. And I must say it's been a while since
I have seen Luna have so much fun, besides reading a book. This has been fun,
thank you." When we got in the car my mother said "She's a nice woman, I like
her." I knew at that moment my mother would make sure they signed that
contract and I felt elated. All the way back home I browsed through the folder
with my pictures and for the first time I didn't hate what I saw.

A few days later Nat came by with the portfolio, it was a really nice binder
with my name in gold on the front. The first page was a short bio of me that my
mother had agreed upon and then there were my photo's. They were different from
the ones I had, Nat had altered them slightly. Some were a little darker,
others were lighter. They were just beautiful. My mother chuckled when she saw
the one where she threw a bucked of confetti at me, my eyes just popped on that
photo. I finally understood what Nat had meant by that.

My father came in the room and introduced himself to Nat. He sat down and went
over the contract with her, there were just a few small changed he wanted to
make before he would sign. Nat agreed to his terms and said she would come by
with a revised contract. "But we've got a deal?" she asked. My father looked at
me and then back at Natalia "Yes, with those changes we have a deal."

It didn't take Natalia long before she called for my first assignment. She had
asked us to come to a nice estate in the next town over. My mother went with me
and we learned it was for a teen magazine. Another woman did my makeup and
someone handed me my outfit. This was totally different from that day in Nat's
studio, this was way more professional. I changed into the outfit and walked
over to where the photo's were taken. "Ah Luna," Nat said when she saw me, "let
me introduce you to Dillon, he's the photo editor for 'Teen'." I shook his hand
and he said "Yes, she will do nicely."

Natalia made it just as much fun as the first time and I loved it. Almost two
hours, five outfits later we were done. Dillon had selected a few of the ones
he wanted and said to me "This has been fun Luna, I will need you for some new
ones in the future." And with that he got in his car and drove off.

A few days later Nat called and said "Luna! You are going to be in 'Teen',
Dillon just called to confirm. You are going to be in the next issue, next
week." I cheered loudly and my mom rushed in to hear what all the commotion was
about, she cheered even harder when I told her about it. I thanked Nat for
calling and jumped into my mothers arms. I was so happy.

The day the new issue got out I was in the store with my mother, we flicked
through the mag and cheered when we saw me in there. My mother bought a couple
of issues and we giggle all the way back to the car. "This one is going to you
grandparents, this one is going to my sister and this one is going to your
uncle. This one is for the hospital and this one we're going to frame. Oh I am
so proud of you, Luna."

There were a few more shoots before my graduation and all the school knew I was
a model for 'Teen' magazine. Somehow that had elevated my stature at school,
but I didn't feel any different nor did I want to be treated any different. I
just concentrated on graduating and luckily I did, with flying colors as my mom
said. Josh graduated too and was given a scholarship to play football. I felt
so proud of him and congratulated him when he told us.

After our graduation my father started teaching us how to drive, together we
also attended driving school and we both got our license on the same day.
During the summer break we celebrated our birthday and we both got a car. They
weren't new but they were beautiful nonetheless. Mine was a nice red Toyota and
I loved it, when I took it for a spin it was even better. My mom sat next to
me, Dani was in the backseat and together we drove through the neighborhood.
Suddenly a klaxon sounded behind us, I looked into the rear view mirror and saw
my dad waving behind us, he sat in the passenger seat as Josh was driving. I
giggled and said "We're being followed, should I shake them?" My mom laughed
"Don't you dare!"

When we got home again I hugged my parents and thanked them. Dani got out of
the car too and shouted "Now Luna can drop me off at school!" My mother
explained that both Josh and I would move out to go to another school. I could
see how disappointed she was and I said "Dani, whenever I can I will pick you
up, okay. I won't be that far away and I will come whenever you need me. Just
call me and I will come. I promise." Josh walked up to us and said "The same
goes for me Dani, just call and I will be there too. I will always come when
you need me, no matter what."

For the rest of summer break I prepared to go to college and there were a few
more shoots. Now I was 18 and had my own car I could go by myself, to dismay of
my mother. She loved coming with me to shoots and most of the times I took her
with me, but this time she had to work. I got in my car early in the morning
and made my way over to where the shoot was. It was another nice house, this
time somewhere in the mountains on the other side of town.

Natalia greeted me and I handed her the revised contact now I had turned 18. My
father had looked it over and given me the green light. "Ah, nice. Thank you so
much Luna." Nat looked it over and then signed on the dotted line for her. She
handed me a copy and I put it in my purse.

"Okay, now that's done. Tell me, any plans for summer break?"

"Not really, preparing for college. It will be strange to leave the house."

"I know," Nat replied, "I remember when I went to college, oh man did I cry.
But it was all for the best, look at where I am now. I'm living my dream.
Taking family photo's or weddings pays the bills, but this, this is what I love
to do." I chuckled and went over to the dressing area. I got handed my outfit
and changed, then I sat down for my makeup. After the shoot Nat walked up to me
and said "Luna, I need to ask you something."

We sat down on some chairs a bit away from everybody else. Nat looked seriously
at me and said "I've gotten this offer and it's for a lot of money, for the
both of us. But I really need to know if you are okay with it. A client want's
you for their annual swimwear issue and it would mean you have to pose in a
bikini. Are you up for it? I mean if you aren't, just say so."

I couldn't believe what she had just said. Me in a bikini? Who? What? It was
like Nat could read my thoughts "I see you don't want too, never mind."

"Oh no," I said, "I just need some time to think. I mean, I hardly ever wear a
bikini and -- I don't know. When?"

"Well, we're at a nice pool now." Natalia answered and I've brought some of
their collection just in case. And they even said you could keep them if you
agreed to it. They are really nice bikini's" Natalie bent her head a little
downwards and looked up at me with a little twinkle in her eyes. I couldn't
help but giggle and said "Okay, but I want to see them first before we do
anything with them." Nat agreed and jumped up. Together we walked into the
house and went into one of the bedrooms. On the bed were four sets of bikini's,
one smaller than the other.

"Which one?" I asked.

"All of them," Nat answered, "Let's just start with this one." She handed me
the largest one and said "Just put it on, when you come out you can wear that
robe." As soon as she left I closed the curtains of the room and felt a bit
uncomfortable getting undressed in a strange house. When I was done I put on
the robe and anxiously I walked outside. Natalia had moved all the equipment
near the pool and on of the lounge chairs was moved to a better spot.

Natalia instructed me to lay down on the chair and to just close my eyes as if
I was sunbathing. When she was ready doing her thing she said "Okay, now take
of that robe and we're doing it." I looked around at everybody who was looking
at me and took off the robe. Handed it to someone and laid down again. I could
hear the shutter from the camera and Natalia instructed me where to place my
arm or my hand, to turn my head. After a while I forgot all about the people
looking at me.

For the next series I had to put on the other bikini's until it was time for
the smallest one. The top hardly covered my nipples and I felt uncomfortable in
them. But I had told Nat I would do it, so I did. This series of photo's
Natalia wanted to take from her hand instead of the tripod. We walked over to
the lawn and I disrobed again. Natalia gave me instructions once more and I
had fun being photographed, even in this small of a bikini.

When all was done I was handed my robe and together with Nat I looked at the
results. They were beautiful pictures, even the ones in the smallest were just
beautiful. "You have such an amazing body," Natalia whispered, "Look at you."

A few weeks later I gasped when I saw the amount of money Natalia had
deposited in my account. I immediately called her "Nat, you made a mistake.
This is too much." "No," she said, "the client bought ten photo's and this is
what we agreed upon. 60 percent for you, 40 for me."

"But this is 8000 dollars!" I shouted, "When do they want more of these?"

The next thing I did was call my mother. "Mom, are you sitting down?" I said
and I told her about the bikini shoot and how much money I made. My mother
gasped when she heard the amount and then said "But does this mean you will be
in a national magazine? In a bikini?"

"Yes mom," I replied, "In a bikini. But they are beautiful, classy pictures
mom."

"Oh I don't know what to thing about that," she replied.

"Just think about how I am paying my way through college," I replied, "and I
will graduate without a debt to repay."

"That's true," my mom replied, "and you're an adult now so I couldn't stop you
if I wanted to. But still, you in a bikini in a national magazine? Ah well,
times change, I guess."

When the issue came out my mom bought another couple of them and I could hear
she was proud when she had seen them. "They are beautiful, Luna."

The swimwear issue had put me in the spotlight of more companies and Natalia
started to act more like my agent than a photographer. But she always said she
didn't mind, it was nice for the both of us. She just looked at things
differently and she knew almost all of the artists I was going to work with. On
top of that, doing this she made more money than she ever did with her studio.

During my third year in college I had another shoot for a renowned magazine and
I would work with a photographer who also shot for Vogue and Cosmopolitan. He
worked with the biggest names in the business. I was elated when Nat told me he
wanted to work with me. When I arrived at the shoot, he hardly paid attention
to me and it was one of his assistants who told me what was expected from me.

After changing and makeup I went over to the shoot and was introduced to the
male model, Dillon. I stood where I was supposed to stand and Dillon put his
arms around me. We were given instructions on how to stand and look, then he
instructed me to turn towards him and look into his eyes. I had to act like I
was in love and with every sound of the shutter he instructed Dillon to move
closer to me. On the last photo our lips nearly touched, another few photo's
and the man shouted "That's a wrap, beautiful, beautiful." Dillon let go of me
and walked away as if nothing out of the ordinary had happened.

"Luna," the man said, "that was just mesmerizing. Beautiful. Thank you so much
for coming over. I've talked to your agent and we've agreed on the
compensation. Thank you so much for coming and I hope we will work again real
soon." With that he walked away talking to his assistant. I made my way over to
the dressing area, took off my makeup and changed into my regular clothes
again. Dillon had long gone and I drove back to school.

The next day I received a text from Natalia "Congrats! They are publishing your
photo's in Vogue. Check you balance!" I did and I gasped when I saw they had
deposited 15,000 dollars. I called Natalia and said "How much?"

"Yes," Natalia cheered, "and the best thing is: I made a deal for another 1.5%
of the total sales of that issue." I was stunned by what she had done, Vogue
sold millions of copies all around the world. I could not comprehend how much
money that would be.

During the following months I had a couple of shoots before I went home for
Christmas. As promised I picked up Dani from school for the few days she still
had to go. In that week the Christmas special of Vogue came out and Natalia had
told me to go to page 43. There it was: the photo of me in Dillon's arms almost
kissing. On the next few pages there were three other photo's of us. They
accompanied a story written by a famous author and I felt proud of myself.
Even my parents were proud when they saw the photo's in a worldwide magazine.

We spent the holidays together and on New Years Day I screamed when I saw my
bank balance, when I showed my parents the gasped. A total of 1.3 million
dollars was deposited by Vogue and I received a text from Nat that they wanted
me for another shoot. And although I got my compensation as agreed upon those
photo's were never published and I was never called upon by them again.

Not that I felt sorry about that, the shoots were way different than I was used
to and they weren't as much fun anyways. On top of that I had put way the money
I had earned on the advice of my father and every month an amount was deposited
in my account, the rent I got from the bank. Besides that amount the balance
grew steadily.

Josh's name had risen in college football and there were some teams in the NFL
that showed interest in him. I went over to watch him play as often as I could
and was proud of seeing him play. Especially when the girls sitting next to me
swooned at seeing him. One of them said "Oh I would love to have breakfast with
him." The other girls giggled and I said "Oh no you wont. He burps when he eats
breakfast." A girl turned to me and asked "Do you know Josh?"

I laughed and said "Well, we shared a womb for nine months, so yes I know him".
"You are his sister?" one of the screamed, "oh you got to introduce us to him,
I'm Mellany." I waved her away and said "No, I won't do your dirty work.
Introduce yourself and if he's interested he will say so. But I sure think
someone will be very pissed off at you."

"Who?"

"Inez, his girlfriend. She's sitting her right next to me." I laughed.

Inez leaned over and said "Hi, I'm Inez. Josh's girlfriend. Nice to meet you."

The girls started to blush and Inez couldn't stop laughing. "You are just
crazy, Luna, you really are." I laughed too and waved to the girls when the got
up to sit somewhere else. "I hate it when the act like that, he's my brother. I
can't imagine being interested in him. No offense, but I really can't."

"None taken," Inez replied, "I feel the same about my brother."

I looked in her deep brown eyes and the both of us burst into laughter. Inez
was such a beautiful Latina and when she laughed her eyes just sparkled. Josh
had made a good choice in this one, I thought. Even though we had met for the
first time that night, it felt like I've know her for all my life.

Just before graduation Josh called me and said he wanted to propose to Inez and
he needed my help. We cooked up a scheme and I felt excited and happy that he
would even want to include me. I had called Inez and asked if she wanted to go
shopping with me, she agreed and I told her I would pick her up. During our
shopping spree I asked her what kind of dress she would want to wear if there
was a special occasion. She took me to a store and showed me the most beautiful
dress I had ever seen. "Try it on," I said, "just for fun." Inez said she
couldn't and I had a hard time convincing her, but finally she did.

While she was changing I went over to the counter and paid for the dress. 800
dollars well spent, I thought. Inez got out of the booth just as I had returned
and she looked just beautiful. I handed her a pair of heels I had found and
told her to put hem on too. Inez looked at herself in the mirror and said "Oh
how I wish I could keep this."

"Then this is your lucky day I guess," I giggled, "It's yours. I already paid
for it and the shoes." Inez protested she couldn't possibly accept this when
suddenly through the speakers of the mall sounded her favorite song, the song
on which she had met Josh.

Inez gasped and looked at me "What's going on?" she asked. I took her by her
hand and guided her outside. In the middle of the square stood Josh, in a nice
suit. Inez put her hand in front of her mouth and ignored the alarm going off
as she passed the gates. Slowly she walked over to Josh and I followed her
closely. I stopped a few yards from them and Josh went down on one knee. "Inez,
meeting you was one of the best days of my life. And although I already have
one meddling female in my life, I can't imagine my life without you. Asking my
sister for her help wasn't easy for me, but I did it anyway. Inez, will you
make me the proudest man on this planet and become my wife? Will you marry me?"

Tears shot in my eyes and Inez just nodded not able to speak. "What?" Josh
asked, "I didn't quite catch that?" Inez raised her arms and shouted "YES! Yes,
I will be your wife." Everyone watching started to cheer and Josh took his
fiance in his arms after he had put the ring on her finger. I ran up to them, 
congratulated them and marveled at the ring.

After graduation I got a job in retail as I shop manager. Before I could apply
to become a flight attendant I had to have at least two years of work
experience. Although I didn't hate my job it wasn't what I wanted to do and
felt lucky that I still had my career as a model, which was one of the reasons
the shop hired me.

Natalia had returned to being a photographer and I managed my own shoots ever
since I graduated. She had told me how she missed her work and we both agreed
to go our own way. We still met for coffee sometimes, but it wasn't like it
used to be and the periods in between just got longer and longer. Then one day
her studio was closed and she was gone.

As the months went by I got in to the grind of going to work every day and I
started to think how I ever could stay in this job for longer. The customers
were rude and offensive sometimes, especially some men when they had to deal
with me. It was hard to hear they would contact corporate every day at least
once. But I had to struggle through this if I ever wanted to become a flight
attendant as I had dreamed of for as long as I could remember. On the other
hand I thought if they customers were the same in an airplane then there was
nowhere to go and hide, now at least I had my office where I could let go of my
frustration at certain moments.

The wish of becoming a flight attendant got smaller as time went on and at a
certain point I started the believe I didn't want to become one anymore. I
wanted out of a job where I had to attend to the whims of customers. I talked
to my mother about it and cried when I told her I had let go of my dream. She
felt so sorry for me but said "If that's what you think, then find a new job.
Something you like to do. I know for sure you won't be happy as a flight
attendant when you follow through on that. See this as a lesson you had to
learn, now just keep working there until you find something you like."

She was right and I felt a little better after that, but it still hurt to let
go of my dream. During some of my days off I at least had my modeling to fall
back on to, even though they jobs had become smaller I still had fun doing it.
At one of them I had to pose with a guy, the both of us in swimwear. He was a
nice dark man with a very nice body and I was wearing the smallest of bikini's.
For one of the photo's I had to come out of the water and felt my top slip off
just as the shutter sounded. I felt embarrassed and put the top back on, but
the cat was out of the bag and when they showed me the photo it was just
beautiful.

"We should take a few more like that," the photographer said when I walked back
to my male companion. She reached for my top and slid the triangles to the
side, exposing my breasts. She took her camera and started shooting photo's.
Then she asked for my companion to place his hands on my boobs, I gasped a
little but felt excited at the same time. This was way more fun than I would
have admitted. Feeling his hands on my breasts sent a shiver down my spine.

The photographer kept on snapping pictures of me topless in the arms of a dark
man and I loved it. After a few more she sent him away and kept on snapping
pictures of me, this time I had taken off my top and posed topless. When she
was done she said "That was just wonderful. You should really think about
becoming a nude model. You have a great body for it and there's a lot of money
in it too."

A few weeks later I was told they had sold my topless pictures for almost 5000
dollars and asked if I was available for another shoot. I agreed and at that
shoot I posed naked, I was over the bump of feeling embarassed by my body and
it felt good hearing all those compliments. Just a few weeks later I was
invited to come over to Hawaii for another shoot, this time on the beach. They
paid me enough for me to agree to it and I was having so much fun with it too.

When the company I worked for got notice of what I did in my spare time I got
fired, but I really didn't care anymore. Being a nude model paid enough for me
keep on doing it and it gave me to opportunity to do other things when I wasn't
at a shoot.

One evening my phone rang, it was my mom. As soon as I answered she shouted
"Luna! What are you thinking? I can't believe what I am seeing right now. Did
you really pose naked for PornHub? I can't believe you." I knew there was no
way of denying it and said "Yes mom, that's me. And you know what? You told me
to find something I like doing and this is it. Those photo's were taken on
Hawaii, mom. Hawaii. They even paid for my ticket and hotel. And I get 10% of
all the royalties for the next year, mom. That's almost 500,000 dollars.
Tomorrow I fly to Tokyo for another shoot."

My mother calmed down a bit and said "I just wished you would have told me. Now
it was one at work who showed me. It was so embarassing."

"I know mom, I just didn't know how. I am so sorry." I cried.

"It's okay honey," she said, "just promise me to be careful."

That shoot in Tokyo was just amazing, I was there for a couple of days just
experiencing the culture before I went to the country side for the shoot. It
was in a beautiful piece of the mountains, near a waterfall. The photographer
explained what he wanted and we did the shoot. All I wore as a small silk scarf
around my hips, as I stood there in the water. Then we moved to a chair that
was there and I layed down on it. He asked me to sit on my hands and knees and
my tripple-D breasts hang down as I stared into the camera. He then took a few
steps to the side and asked my to spread my legs a little, he snapped a picture
from behind and I knew my slit was on it. That thought excited me more than I
would have expected and when I laid down on my back I opened my legs a little.

With every photo I spread a little wider until I couldn't go any further, with
my fingers I spread my lips a little, exposing the pink underneath. I got
arroused by the thought of him taking pictures of me like that. I could feel
myself getting wet. He then suggested to continue in his hotel room and we
drove back to town. In his room he shot pictures of me undressing and when I
laid down in his bed I was totally naked. At some point I slid a finger inside
me and just stared into the camera. Any form of shame I had felt was gone and
with every shot he slit another one inside me. When he offered his cock I took
it in my mouth as he kept on taking pictures. At some point he stopped and put
away his camera.

I kept on sucking his cock and when he laid down I got on top of him, guiding
his cock inside me. I wanted to fuck him so badly, but more than that I wanted
him to fuck me, to take me. At that moment I turned into a slut, a whore and I
knew what I wanted, what I had always wanted.

On the flight back home I decide to make my wish come true. Josh had been
working for a company near my parents for a few years now and he was still
married to Inez. As soon as I landed I called him asking if it was okay to
come over. I got in my car and an hour later I parked in front of their house.
Both Josh and Inez were home and I told them what had happened during the shoot
in Tokyo, how I had been a model for porn. Although Josh had a little more
problems with it, it was Inez who said "I can't believe it. We have a genuine
porn star in the house, Josh."

She saw the look on Josh's face and said "Ah, don't act like you don't like it,
you love it. Your sister the porn star. Luna, as you've been honest with me,
it's time for us to be honest with you. Josh and I have what you would call an
open marriage, we still see other people if you know what I mean. Just as long
as we are open and honest about it, it's all okay. He's sees other girls and I
see other men."

I couldn't resist a gasp and Josh said "Yeah, it's true. I love seeing her with
another man. Watching her get pleasured is the best thing there is."

"You actually watch?" I gasped.

"Oh yes," Josh said, "it's the best porn ever. Especially if she's with another
girl."

Inez slowly slid closer to me on the couch. "Yes, especially if I'm with
another girl. And there's one I've been dreaming about for a long, long time."
She touched my leg with her fingers and placed her head in my neck. "I've
dreamed about this for so long, so long" her voice was breathy and I could feel
it on my skin. A shiver went down my spine as her lips touched my skin, I
couldn't resist a moan. Slowly she went up to my breasts with her hand and slid
I finger underneath the top of my shirt pulling it down slightly.

I looked at Josh who had sat down on a chair on the other side of the room not
intending to leave. "Let him watch," Inez said, "let him enjoy this as much as
we do." She kissed my neck again and slowly went up to my ear. She nibbled on
my lobe and I felt myself getting arroused. When she pulled up my shirt I
didn't resist and even held up my arms. There I was on my brothers couch in my
bra, being caressed by his wife as he was watching. The whole situation excited
me so much I almost came at that instant.

Inez kept on kissing me everywhere and with one hand she unclamped my bra and
took it off. She kissed my nipples and threw my bra towards my brother. She
then rose up, took of her shirt and bra too. She positioned herself so our
breasts touched and she kissed me on the lips. Softly and gentle at first, but
the more we kissed the more passionate the became, ending with our mouth wide
open pressed against each other, our tongues touching. I let go of every brake
I had and put my arms around her.

She then got up and guided me to their bedroom. Josh sat down on a chair and
watched how Inez undressed me, when she was naked too she pushed me on the bed
and got on top of me. We kissed some more and I felt her hands going all over
my body, finally resting on my clit. I spread my legs and she started to rub it
gently until I was wet enough for her to push a finger inside me. At some point
she went down on me and started to lick me, to eat me and all I could do was to
place my hands on her head to pull her closer. She sucked on my clit, pushed
her tongue inside me until I came. Then I did the same to her until she came
too. We laid in each others arms for a while when she rose up, put one leg
underneath me the other one over. She moved in closer until our clits touched,
she started to grind and I felt something I had never felt before. I was
getting an orgasm, a deep dark orgasm. I almost fainted when it rolled over me,
every muscle contracted and I started to shiver uncontrollably.

When it finally passed Inez laid next to me and said "Wow, that was a big one."
She smiled as she carressed me with her finger nails. She looked over at Josh
and said "Look at him, jerking that cock. He loves it." I looked over and saw
my brother sitting there with his hard cock in his hand. It was way bigger than
I had immagined and just couldn't stop watching. Something came over me and I
slid over to the side of the bed, spread my legs and showed my twin brother my
wet pussy.

"Come brother, fuck me. I want you to fuck me hard." I said. I watched as he
got up and on top of me. I took his cock and guided him inside me, finally I
had what I wanted. I wanted my brother to fuck me, to make me his bitch, his
slut. "Oh yes. Fuck your sister." Inez encouraged him, "fuck her hard. You
always wanted to fuck a pornstar. Now here she is, your own little sister."

The moment he started to pump I came. I couldn't believe I was really fucking
my own twin brother. I placed my hands on his ass and pulled him in as deep as
he could go and when he was about to come I clamped my legs around him so he
could pull out, I wanted him to come inside me, as deep as he could go. "Oh
yes, Josh. Come inside me, give me all your cum. I want to have your baby! Oh
yes, brother, make me pregnant." Josh tried to pull out but it was too late, he
exploded deep inside me and I could feel his cum entering me. "Oh yes, I'm
coming!" I shouted, "I coming all over my brothers cock."

Josh sagged down on me catching his breath. When he was 
