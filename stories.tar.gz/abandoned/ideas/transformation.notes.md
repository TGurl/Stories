# Notes

## Character sheet

### Main Character
Name            Luna Davis
Age             26
Married         4 years
Children        No
Short history   We met in college and got married right after. Josh works at a
                lawfirm and hardly spends time with me anymore. I start
                spending time on the internet and get sucked into the world of
                swingers.

### Bio
Eye Color       Brown
Hair Color      Brown
Height          5"2 - 158cm
Weight          160lbs - 73kg
Measurements    36L - 34 -40
Boobs           Natural

Inspiration     Liza Biggs

### Friends and Family
Husband         Josh
Josh's sister   Lindsey
Best Friend     Natalie (Nat)
Josh's Boss     Peter
Bosses Wife     Bridget
My Boss         Imani


## Removed excerpts

Even though the whole situation had satisfied me I started to need more than
just an online fantasy. I sat down on a chair after setting the timer, I had
put on a nice set of lingerie and held up a sign stating:

_Available for sex in real life, DM me_

As I did since a few months I wore my mask which covered most of my face,
because of that mask my nick name on the site was changed to _SexyKitten_. I
took a few more photo's but still wasn't satisfied with the result. So I
changed into a new outfit. Restarted the timer on the camera and sat down in
the same chair. With every photo I undressed a little more, until I finally was
fully naked and people could see the message on my belly:

_I need a big black cock. DM me_

The were perfect, before I posted the series I talked to Josh about it. He
asked me if I was sure I wanted to do this and I answered truthfully. Even
though he had a hard time with it he said "If you really want to do it, do it.
But tell me everything and always use a condom. And no kissing."

"Don't worry, I will insist we wear masks and yes I will use a condom, it it
ever gets that far. I just want to know how far I will let it go. I need to
know, I've been thinking about it for so long now. It's time I experience it."

"Okay, but you have to let me know where you are at all times. Promise me."

"I promise. Oh you have no idea how happy you just made me. I love you so much,
you will always be my number one. I want you to know that, there's just one
person in the world I make love to and that's you. The rest is just sex."

Soon after I had posted the series someone responded and we made plans to meet
in a small hotel just outside of town. As I didn't want to go alone Josh and I
booked a room there for the weekend. We arrived around four in the afternoon
and checked in. For the rest of the day I didn't want to leave the room, too
afraid I would check every black man there to see if he was the one I was
supposed to meet that evening. I checked the clock almost every minute and time
seemed to slow down.

Finally it was time for me to get ready. I showered, washed my hair, did my
makeup and put on some sexy lingerie. After I put on a long coat I grabbed my
purse, kissed Josh and went out the door. My heart was beating so loud I was
sure people could hear it. I went up one floor and arrived at room 32.
Anxiously I put on my mask and knocked on the door.

It took almost a minute before the door was opened and a man in a ski mask was
standing there. He invited me in and I almost said I couldn't do it, but I
stepped into his room. I felt really uncomfortable standing there without
seeing his face.

"Oh, I am so nervous." I said, "would you mind if we took off our masks. I
thought it was a good idea, but it makes it more awkward. Lets just use our
nick names, if you are okay with it."

"I was thinking the same thing" he said, "I feel like a criminal wearing this
and I don't like it at all. Just call me Richard. That's not my real name but I
don't really like _LongJohn128_." I snickered and replied "Okay, then you can
call me -- let's see -- Becky. Yes, Becky will do nicely."

When he took of his mask I could see how handsome he was and it made me feel a
little more at ease. "So nice to meet you, Richard." I said as I shook his
hand. We sat down to drink some wine and we chatted mostly about the site and
he told me how much he liked my stories and my photo's.

"Well," I said as I stood up to open my coat, "you get to see it for real." I
slid of my coat and dropped in on the floor. Richard whistled when he saw the
lingerie I was wearing and he put his arm around me. The moment he touched my
skin it sent a shiver down my spine, it was going to happen. For real.

His hands went all over my body and I stood in front of him in between his
legs. At one moment he unclasped my bra and took it off. "Oh wow," he said,
"they are even bigger than the looked in the photo's." He softly kissed my
nipples and I felt them getting hard. With my hands I crawled through his hair
and I pulled him closer when he started to suck on my breasts. I started to
moan softly and felt his hands go down on my ass. The pulled the cheeks apart
and with one finger he touched my ass hole.

Nobody had ever done that to me and it send shivers all over my body. He stood
up and carried me to the bed, laying me down softly. He bent over me and I
couldn't help to kiss him. I had broken the first of the rules I had set with
Josh, but at that moment I didn't care anymore. He slowly went down kissing me
everywhere until with two fingers he pulled down my panties. I lifted my hips
and held my legs up in the air. He spread my legs and kissed the inner parts of
my thighs, slowly making his way down to my slit. With his tongue he touched my
clit ever so slightly. I let go of a deep moan and realized at that moment my
husband was sitting in an empty room just a floor below us.

That idea turned me on so much and when Richard started to lick my pussy I just
crawled on the bed from pleasure. His tongue went in deep and I felt my fluids
starting to stream. I had never felt myself getting so wet. "Oh my god, keep
doing that. I yes, I'm gonna come. Keep going, yes, yes. I'm coming." I panted
and when he lifted my hips and started to lick my ass hole I couldn't resist it
anymore and just exploded. Richard didn't stop, he just went on and pushed his
tongue inside my ass. I felt myself relax a little and accepted his tongue
inside my ass. It felt so good.

Finally I got him to stop and pushed him down on the bed. I walked over to my
purse and handed him my phone after I had opened the camera app. "Take some
pictures of me or maybe even a video. I want to show my husband what I did." I
said and knelt down. I started to lick his big black cock and I could hardly
fit it in my mouth. But I did, gagging on it, my saliva dripping down on his
cock. Richard took a few photo's of me sucking his cock and I looked into the
camera a few times.

Suddenly Richard got up, changed a few setting son the phone and placed it
against the light on the nightstand next to the bed. On the screen I could see
the both of us. He laid down so his cock was clearly visible and without
thinking I got on top of him, guiding his giant dick inside me. I had just
broken cardinal rule number two: there was no condom. I moaned loudly as I felt
him entering me, stretching me out as his giant lid slit inside me. Once it was
in I had to rest for a moment, to adjust to the intruder inside me. "Oh my god,
you are so big," I moaned and slowly started sliding up and down. I bent over
forward and kissed him. This time we had our mouths fully open and our tongues
were dancing around each other. 

I rose up again and started riding his cock, my boobs were bouncing and I lost
all control over my body. I wanted him, I needed him. After a few minutes, he
lifted me up and laid me on my back. I spread my legs out wide and he started
pounding me. He went in so deep. "Oh yes, fuck me. Fuck me hard with that big
black cock, oh my god, this feels so good!" I shouted. "Fuck me harder, make me
hurt." Richard kept on pounding me and started breathing heavily. "Oh yes
Richard, fuck this slut. Make me a whore! I am yours for the night, I want you
to fuck me all over this room. I want you to fuck me all night!"

Richard got of me and laid down behind me, he turned me towards the phone that
was still recording us, I lifted up one leg and watched him on the screen
placing his cock against my wet pussy, slowly pushing it in again. "Do you see
this Josh? Are you watching your wife getting fucked by this black dick. Oh
yes, this is what I needed. This is what I wanted. I am a whore for black dick
and I want more of this. Oh my god Richard, show him how a real man fucks a
woman. Oh yes, yes, yes, I coming, oh my god, I'm coming all over your dick
Richard, just keep going. Right there yes, yes yes. I'M COMING!" Richard
pounded me relentless and I felt an orgasm coming on.

"Oh my god, this feels so good." I shouted, "Keep fucking me, Richard, fuck me
hard. Oh my god -- " I groaned as the orgasm rolled through my body, I closed
my eyes as every muscle tensed up. I could feel ever inch of that big black
cock inside me. I got even tighter than I had been before, then I felt him
twitch and throb inside me. Richard started to groan "I'm almost there, almost
there" he started to pull out and I laid down on my back, he jerked for a
little while longer until he exploded all over my body. His cum went everywhere
and there was so much of it. I started to smear it all over my body and showed
Richard how I pushed my cum covered fingers inside my throbbing cunt.

I reached over to my phone and stopped the recording. I laid down in his arms
and said "I can't show him this one. I had promised we wouldn't kiss and we
would use a condom. Oh and I forgot about the masks I promised him that too. So
I guess we're bound to for round two."

While we lay on the bed with another glass of wine I started playing with his
fine cock again and soon enough it was hard again. I started sucking it and
Richard took another couple of pictures. He put on a condom and took another
view of him inside me. Then he threw away the camera, pulled out and took the
condom off again. I spread my legs wide when he entered me again, this time his
full weight was on top of me and I put my arms around him, kissing him
passionately. He pounded me until we both came and this time I sucked him until
he exploded inside my mouth, I swallowed as best I could but there was just so
much cum it leaked out of my mouth.

This time it took him a bit longer to be ready again, he took me to the
balcony, bent me over and pushed his rod inside me again. He fucked me where
anyone could see us and it was so exciting to me. I lifted my leg to give him
better access to my cunt. Then he lifted me up, his cock still inside me and
carried me back inside. On the bed he placed the tip against my ass hole, it
was so slippery by now it slid in a little. "Be careful," I said, "I never had
anyone in there before." Richard took his time and ever so slow he pushed in
deeper. I felt a sharp pain and cried out to stop, but he didn't. Instead he
pushed hard and his dick went deep inside my ass.

"Oh my god!" I shouted. He kept still for a moment to let me adjust to that
giant dick inside my ass. "Oh my god you're in my ass," I shouted, "Oh my god
this feels so good. I never knew how good this would feel. Oh yes, fuck my ass.
Make me hurt. Oh my god yes." Richard started to move slowly and went faster
the more he went on. "Oh yes, fuck me hard. Fuck my ass, you are so deep inside
my ass. Oh my god, I'm coming again. Keep going, fuck me. I want you to come
inside my ass, Richard. Fill my ass with your cum. Oh my god yes, give it to
me. Come inside my ass."

With just a few more thrusts Richard exploded inside my ass and the moment I
felt him come I came too. He pulled out of my ass and I pushed him on his back
and slid his still throbbing cock inside my pussy. I started grinding and
panted "I want you to fill my pussy too. I want to come on that cock of yours
while you come inside me. Oh yes, I want it. I need it. Within a few minutes I
felt him getting hard again and I rode him until he came once more, this time
filling my pussy with his cum. Knowing that in a room downstairs my husband was
waiting for me while I was in this room getting bred by this black man sent me
over the edge and I had another orgasm.

We sagged down on the bed, the both of us exhausted. But I felt so satisfied,
especially feeling his cum dripping out my holes. We kissed some more and at
that moment I wished I could just stay in this room. But I had to go, I got up
and into the shower to clean up. While I was in there Richard joined me and
within a few minutes he pushed his dick up my ass again. We fucked on last time
and he filled my ass with another load of his cum. We both showered to clean
ourselves up and I put on my coat. I put my lingerie in on of the pockets,
grabbed my phone and my purse and thanked him for a wonderful evening.

Back in the room with Josh I decided to be fully transparent and told him
everything that had happened. I told him we had kissed and how we didn't use a
condom. I even told him how Richard had come inside my ass and pussy. But
instead of getting angry it seemed to arouse him. He got up, took me to the bed
spread my legs and started to suck my still throbbing pussy. I knew Josh could
taste Richards cum mixed in with mine, but he didn't seem to care.

Like a wild man he got on top of me and slid his cock inside my aching pussy,
he fucked me so hard that I almost came instantly. Josh kept on fucking me
until he came inside me, mixing his cum with Richards. When he was done he
rolled of me and we didn't speak, we just laid there until we both fell asleep. 

At some point during the night something woke me up. I checked the time and it
was just 1:30 at night. I looked over and Josh was fast asleep. As quietly as I
could I got out of bed to go to the bathroom. When I was done I looked at Josh,
took of what remained of the lingerie I was wearing, grabbed my coat and the
key card. And a few moments later I knocked on the door of room 32.

Richard pulled me inside, almost tore of my coat and took my right there in the
small hallway. He kept on fucking me all through the night and I returned back
to our room when it was daybreak. I opened the door and snuck in quietly. I
walked into the room and Josh was still sleeping. I got a chair and placed it
at the end of the bed. I bent over Josh and whispered for him to wake up. Then
I went back to the chair, climbed up and slid down on Richards cock.

I wanted Josh to watch me while I was fucking my big black bull. Josh opened
his eyes and was immediately awake when he saw me on top of this big cock.
"Look at your wife," I said, "She's been fucking this man all night while you
were asleep. This whore was fucking this big black cock. Watch me how I come
all over this cock. I rose up and Richard slipped out of me. He placed it
against my ass and I went down again. This time his cock went deep inside my
ass. "Look at your wife being fucked in the ass. And I love it, I love it so
much. Oh my god, I come so hard when he's inside my ass."

##

