# Transformation
_an erotic tale by Transgirl_

## Chapter One
"Luna?" my husband whispered in my ear, "Are you awake?" I had gone to bed when
it became clear he wouldn't be home until late, again. "Pss," he repeated,"are
you awake?" I grunted a little, wanting him to let me be and just go to sleep.
But he was persistent in his efforts to wake me up, so I turned over and
grunted "Yes, now I am." I opened my eyes a little and in the dim light I could
see him smile. "I'm home honey," he said and started to tough me.

"Not now," I protested, "go to sleep. It's late." I turned my back to him and
tried to fall asleep again. It had been like this for a long time now. He had
to work late at least a couple of times a week and then just expected me to be
there for him. He had to learn it didn't work that way. Especially not this
evening, he had promised to be home in time for dinner and I had prepared his
favorite only for him to call it off at the last moment. For the millionth time
I had dinner on my own.

The next morning I woke up to him stumbling around in our bedroom, he was
getting dressed already. I looked at the clock to see it was only 6:30 and said
"What? Are you going already? You just came home." He looked at me with sad
eyes and said "Yeah, we really need to get this deal done. I know honey, I know
I blew of dinner last night, but I had no choice. Really I didn't." He leaned
over to kiss me and I turned my cheek to him. He kissed me nonetheless and went
out the door.

That evening I didn't wait for him and prepared dinner for myself, eating it in
front of the television. It felt like I was on my own again and I felt lonely.
After dinner I decided to call my best friend Angela and we talked for about an
hour. She offered to come over for the weekend, but we had made plans already
so I blew her off. "Even though I suspect he will be working, I can't take the
risk," I said to her.

"Oh Luna, there comes a time when you will have to choose for yourself," Angela
replied, "this just doesn't work, now does it. He needs to make a choice,
either his work or you. There are no gray areas, no room to maneuver."

"Yeah, you might be right." I said hesitantly

"Now be honest with me, when was the last time you had sex?" Angela asked. She
had always been as upfront as this, at least for the time that I knew her.

"Oh my, I can't even remember and if we have it might have been a quick one." I
replied. It was the truth, when we first started dating the sex was steaming
and we just couldn't get enough, but lately it had cooled down to almost zero.
I missed the days when we just had enough with each other, when we could fill
the day laying in each others arms chatting about nothing in particular.

After the call the emptiness of the house weighed on me like a ton of bricks, I
shut of the TV and then the silence added to it. It almost gave me a sense of
dread, fear of what was to come: we needed to have _the_ talk.

It was almost 11:30 at night when Josh came home. He looked totally knackered
and fell down on the couch next to me. "I am so tired," he said, "I'm going to
bed. Need to come in early again tomorrow." At that moment I felt sorry for
him, he worked so hard for that company and did he ever get any acknowledgment
for it? Not really, he was passed for promotions a couple of times now and he
always waved it away with explanations like "they have more seniority than me."
But they didn't work as hard as he did, at least not as far as I knew it.

Josh got up and went upstairs. I heard him turn on the shower and a few minutes
later everything was quiet again. I suspected he had turned into bed and when I
followed a few minutes later he was fast asleep. I reached for my pillow, put
it under my arm and with the other hand I grabbed my nightgown. That night was
the first time I slept in the guest bedroom, not knowing there would be many
more to follow.

The next day Josh came home early, the deal was done and they had been
successful, but instead of celebrating Josh was so tired he just wanted to
sleep. When he woke up a few hours later he looked like a zombie and he acted
like one too. He poured himself a coffee only to realize he already had one on
the kitchen table. This wasn't the opportune moment to have _the_ talk, I
thought and I just let him be.

A few hours later I asked "Are we still going to the cabin this weekend?" I
asked him carefully, almost expecting him to blow. He looked up at me and said
"I am so sorry, but I don't think I want to go. I am so tired."

It was the reply I had expected and didn't really feel disappointed. I rather
felt sorry for him, but I knew we really needed to talk about this and
everything else. "Honey, if you feel up to it I could drive us to the cabin," I
tried, "I was really looking forward to it."

"Yes, I know," he replied, "but I can hardly move, I just want to sleep. Let's
see tomorrow. If I feel better then, we can go. Okay? Just let me be for now, I
really need to rest."

An hour later his phone rang and he had to come in immediately, Josh tried to
protest but it was clear the other side didn't want to hear it. With a huge
sigh he got up, got dressed and in the car. With that I knew we weren't going
to the cabin this weekend. Another disappointment, another blow. I had had
enough, this just had to end.

I went upstairs, packed my bags and wrote a note to Josh:

_Darling,

You know I love you more than anything in the world, but I can't go on like
this. I need some space, some time to think.

I will be at the cabin, if you want to come you are welcome under one
condition. You leave your phone at home and choose to be with me. When you come
we need to talk, I mean seriously talk.

If you can't abide to that one condition don't bother to follow me.

Don't call me. Don't text me. When it's time I will come home or call.

I still love you more than you will ever know, but this has to change.

Luna._

I placed the note on the kitchen table, got my bags and locked the door behind
me. After putting everything in my car I drove off towards our cabin. Tears
filled my eyes, but I also felt a sense of freedom. I finally had put my foot
down, drawn a line in the sand. Let the standoff begin, I thought.

Once in the cabin my eyes fell on the one photo we had in there. It was taken
when we first bought the cabin, we were so happy then. I started to cry and
took the photo off the wall, sat on the bed and just stared at it. I rolled
down on the bed, holding the picture in my arms and just cried so hard,
everything came out.

An hour later I got up, put my stuff away and checked the cupboards for food
and water. I made an inventory of what I needed to get from the store and just
as I was about to go my phone rang. It was Josh, despite what I said in the
letter he called me. Even though I didn't really want to, I did answer it.

"Where are you?" he asked, "Oh stupid question. Why? That's what I wanted to
ask."

"If you need to ask," I said, "then you really don't get it. I need some space
to breath, some time to think. Some time on my own. As I said you are welcome
to come, but leave your phone at home. You've got a choice now: me or work.
It's that simple."

"Luna! --"

"No" I interrupted, "this is it Josh. I just can't take it anymore, I need to
know. Do you want me? Do you even love me? I just don't know anymore. Now, I'm
going to the store and if you decide to come you know the condition. Bye Josh,
I really hope to see you here soon, I really do." And with that I disconnected,
threw my phone on the table and went to the store.

When I came back I saw he had tried to call me several times and there were a
bunch of texts. They all basically had the same message of how he couldn't
believe I was doing this to him. I huffed and threw the phone on the table
again. He just didn't get this wasn't about him, it was all about me and how I
was feeling. I put the groceries away and made myself an omelet, something I
hadn't had for a long time as Josh didn't really like them. I sat down on the
patio and looked over the pond as I ate. I watched the birds land and swim,
listened to them chirping in the woods. It all just felt so peaceful.

It started to get dark when a set of headlights illuminated the room, I could
hear it was Josh's car. A door slammed shut and he came storming into the
cabin. He saw me sitting on the couch and said "Luna, if I have to choose I
will always choose you. Every time, always. I love you Luna, I love you so much
that I quit my job. You made me realize what they were doing to me, to us and I
can't do it anymore. I am here Luna, I will always be here for you."

I rushed up to him and jumped in his arms "That's what I wanted to hear. That's
what I wanted to tell you. But I couldn't say it, you had to see it for
yourself. You had to come to this conclusion on your own." He held me tightly
and told me how much he loved me.

That night we slept in each others arm again, the first time for a very, very
long time. I fell asleep with my head on his chest, listening to his heartbeat.

In the weeks after that weekend Josh got a new job, one where he didn't have to
work as hard as he did. His new job felt like a promotion and we slowly grew
closer again. His new boss invited us over for dinner one night and I was
introduced to him and his wife. "Luna," he said, "so nice to finally meet you.
This is my wife Gianna and you can call me Peter. Sit down, please. Want
anything to drink, white wine maybe?"

"A wine would be lovely, thank you." I replied as I sat down on the couch next
to Gianna.

"A wine for me too please, darling," Gianna said and then turned to me. "So,
what do you do?" she asked.

"Oh, nothing at the moment. I used to work at the hospital, but they made some
cutbacks and I was one of the people the let go. I've been looking for
something to do, but I don't quite know what."

"Well, if I can help, don't hesitate to ask," Gianna replied, "I know some
people who can be of assistance." She smiled when she spoke the last words. We
chatted some more and I started to like her. She was clearly well off, but down
to earth at the same time. She didn't make me feel like I didn't belong.

We had a lovely dinner and afterwards the two men went on the patio to smoke a
cigar. "I don't let him smoke those awful things inside," Gianna said. I replied
with "I didn't even know Josh liked them." Gianna laughed and said "I knew Josh
had good taste in women the moment I laid my eyes on him." I was a bit
flustered by those words and looked at her inquisitively.

"Oh don't get riled up," she said, "it's just a figure of speech. Although I
wouldn't mind seeing him next to me." I didn't know how to react and Gianna
quickly apologized "Oh I am so sorry, I keep forgetting not all people are
like us. I am so sorry. Peter and I have what you would call an open marriage.
We see other people and allow each other to have some fun on the side. Just as
long as we are open and honest about it."

"What?!" I couldn't believe what she just said. "You mean --"

"Yes," she interrupted, "we have sex outside of our marriage. It's so good
sometimes. Those men give me everything Peter never could have. And it might
sound strange, but we are closer then we ever were before we started this
lifestyle. We trust each other blindly and enough to give each other the
freedom to enjoy other people. I love him more now than I did when we got
married. And trust me, there were times I wanted to divorce him. Always
working, never time for me, you know what I mean. Then someone told us about
becoming _swingers_. She thought it might help us and it did."

"I don't think I could ever do that," I replied.

"That's what I thought too. Now look at me. I've got three or four, I call them
my bulls, I go to on a regular basis. Sometimes I even have them all at the
same time." She chuckled as she spoke the last words and bumped me. "That being
said, being with those men made me realize money isn't everything, status
doesn't mean a thing if you are six feet under. It's all about the here and
now. And now I decide to have some fun."

I was flabbergasted and we changed topic the moment the men came back into the
room. We said our goodbyes and on the way home I said "You smell like smoke,
ugh. Don't ever smoke again, please. No matter how much your boss likes it, I
don't."

"Sorry, honey. I won't do it again, I didn't even like it that much. I let it
burn the most of the time. Just before we went back in Peter said it was a
waste of a perfectly good cigar, so I think he knows." He chuckled a little and
I could resist a giggle. It had been a good evening and that night when we lay
in bed I thought back at what Gianna had told me, about being swingers, about
giving each other the space to be with other people. Maybe that was something
we could try too, I thought.

A few weeks later I started to work in my favorite boutique, they were looking
for someone and the moment I asked if I could apply, Shione the owner said
"When can you start?" On the second day Gianna walked in and was amazed to see
me behind the counter "Luna? Since when do you work here?"

"Honestly, since yesterday. But this had always been my favorite and Shione
needed the help, so I applied. It's just part-time at first, but I do like it
here."

"Congratulations," Gianna said, "well then, got anything new in the store. I
have a date tonight and I want to look my best." She winked at me and laughed.
I helped her choose a nice dress with matching shoes. Shione looked on from a
distance and when our eyes crossed she just smiled. "Well, thank you so much
Luna, you were great. Bye Shione, come over dinner on time. The both of you."

Shione walked up to me and said "You know Gianna?"

"Yes, her husband is the owner of the company my husband works for. It's a bit
complicated."

"Ah, well she's our best customer and we need to keep her happy." Shione said
and then leaned over "Do you know she's cheating on him? She once came in here
with a man that clearly wasn't her husband."

"Ah," I replied, "that's not for me to tell."

"You know something, don't you. Spill it girl and remember who the boss is."

"I can't. I really don't know if it's a secret, so I choose to be safe on this
one."

"Good choice," Shione replied. She was a bit disappointed, but she accepted my
decision. We started talking about other topics like the new collection that
would arrive the next week. Shione asked if I was available for the full week
and I told her I would be there.

During all this time Gianna's words never really left my mind and the more I
thought about it the more I felt like we needed to try and see if it could work
for us. Ever since Josh had started his new job we had been together a couple
of times, but it just wasn't as satisfying as it used to be. I was missing
something but I just couldn't put my finger on it.

In the following week we fell back into the grind of everyday life, sure it had
changed a lot like Josh being home every night, we went on trips during the
weekends and slowly but surely I got my Josh back. The only thing was something
had changed within me, the period of being alone at home, being disappointed so
often had done something to me and somehow I never quite believed him when he
said he would be home in time. Somehow I always kept my doubts and it wasn't
fair to him or to us.

So one day when he sat at the kitchen table reading his newspaper, yes we still
got a real newspaper, I sat down next to him. "Josh," I said, "I think we
really need to have that talk. I know you think everything is okay ever since
that weekend at the cabin, but I don't think it is. Please, can we talk?"

Josh turned his head to me and when he saw I was being serious he laid down his
paper and said "Sure, what's up? I thought we were doing okay."

"That exactly it, we're doing okay. I want more than okay, okay just isn't
enough for me. I need more than just okay."

"I don't understand."

"I know, and it's hard for me to explain. Mostly because I really don't know
how or what I feel, I just know it isn't enough. We used to be so close, we
used to do everything together. And now, now you get up, put on your robe and
sit here reading the paper for hours. When you're done, you're going to take a
shower and maybe go golfing. But you don't spend time with me, or do the things
I would like to do. Sure we go on our weekend trips, but the last time where
did we go? Right, to a place with a golf course. You were gone all day and I
just sat there on the patio waiting for you to come back. You had a wonderful
time, but I didn't. I felt miserable, ready to go home at any time."

"Why didn't you say anything?" he asked.

"Because I didn't want to ruin your weekend, I didn't want us to fight. Not
when we weren't home, anyway. And when we got home, you unpacked the car, took
a shower and went to bed. You hardly spoke to me all weekend."

"I am so sorry, but I really thought you liked it too. Okay, let's make a deal.
Why don't you plan the next weekend and we are going to do anything you want to
do and I will do them with you. Let's go to a spa."

"No, that's not the point I'm trying to make. Sure we can go to a place where
you can golf, that's perfectly okay. What I'm asking for is for you to be there
for me too, to spend at least a few hours with me. To say to one of your
buddy's there that you're sorry but you're going to spend time with your wife.
I want to give you all the freedom to do what you want, but I need to know that
it's okay for me to do the same."

"What are you really saying right now? Because I get the feeling you mean
something else and I don't know if I like what I'm hearing."

"I don't know, that's part of the problem. I need to think about it a bit more,
I guess. I know that I'm not making sense right now. Let's just say that I want
you to spend some more time with me, for now. I miss you baby. Even though
you're sitting here, I miss you."

"Okay, but promise me you talk to me when everything is clearer. And you know
what? I'm going to get ready and we'll go do something you want to do this
afternoon. I want to spend time with you, I really do. I will even go shopping
with you without complaining."

I smiled as he at least made an effort "Nah, I rather take Angela, she's a bit
more fun to go shopping with. But we could go hiking? We loved to go hiking,
remember?"

"Oh God yes, that's an excellent idea. Bring your camera, you loved to take
photo's back then. Why did you even stop? You were so good at it."

I tilted my head side wards and said "Really? You really want to go there?"

Josh chuckled and said "Oh no, I'm not falling for that one again.
Retreating."

I giggled and watched him as he went upstairs to take a shower. I put on my
hiking shoes, got my camera and waited for him to be ready too. About 45
minutes later we arrived at the nature reserve and decided to take the shortest
route this time as it had been a while since we went hiking. Back at the car we
were so happy we did as the both of us were knackered, but I did take some nice
photo's. This hike had rekindled my love for photography and I said "Maybe I
gotta start taking photo's again. Now I remember how much I liked it."

"Sure, go ahead. Do it. Go where ever you want to go and take some nice
pictures. Heck, you could make an account on one of those websites where you
can sell them. You could even make a buck or two."

"Only two? Are you saying my photo's are crap and only worth 2 dollars?"

"Oh no, not going there. Retreating again. Retreat! Retreat!" Josh chuckled and
ducked into the car. On the way back home we passed a nice restaurant and
without asking he turned into the parking lot and said "We're going to have
dinner here. I made up my mind and I'm taking my wife out to dinner tonight.
Might you know where she is?"

"Oh, I don't know. Let me get my phone. Ah yes, she's sitting RIGHT NEXT TO
YOU!" I laughed.

After a lovely dinner we went on home and that evening I laid in his arms as we
were watching a movie on Netflix. For a moment I felt satisfied, just the
feeling we had done something we both liked and we had done it together, as a
couple. But still there was this emptiness that I just couldn't seem to fill,
there was something I needed that just couldn't get satisfied.

During the following week I started searching for information about _swingers_
on the internet. It was hard to ignore all the porn links, but one got my
attention. It was a link to a community of _swingers_ and after I clicked on it
I read:

_This site is not only for people active in this lifestyle, it is also for
everyone interested in the topic. If you're thinking about it this is the place
where you can get all the information you need to get into the lifestyle._

I chuckled at the words _lifestyle_, that's what Gianna called it too. I
clicked on the _Enter_ button to confirm I was older than 18 and a picture of a
very happy woman appeared on my screen.

_To protect our patrons and their identities we require everyone to register
an account. Please choose your username wisely, don't make any reverences to
your real life. Don't choose Rose for instance if you like roses. Make it as
general as possible. To make it easy we will make some general suggestions. You
can always click the spin button to get some new suggestions._

The name they suggested for me was _MrMaryland182_, I chuckled and clicked on
the little button to say I was female. A new suggestion appeared: _MissSexy42_,
but I really didn't like it. So I tried _MissCurious_, the site told me that
it was taken and suggested _MissCurious65_. It wasn't bad so I accepted the
name and after setting up a password I got a questionnaire which I completed
and when all was done there was a message telling me the admins would check my
application within four hours and get back to me.

Now I had four hours to fill and I really didn't want to spend them behind my
laptop, so I got my camera and went out the door. I drove around for a while,
until I reached the outskirts of town. It was a part of town where I hardly
ever went to and I parked near a strip mall because I wanted to get something
to drink. As I walked over to the store I passed another one that intrigued me.
_Paula's Pleasures_ it was called and I couldn't see what it was about because
all the windows were darkened making it impossible to look inside.

After purchasing my soda I couldn't resist to check _Paula's Pleasures_ and
gasped when I saw it was a sex shop. The girl behind the counter didn't look up
and kept on checking her phone. "If you need lubricant it's behind the
counter," she said in a monotone voice. My heart started beating faster, I had
never ever been in a shop like this before. I didn't even know there was one in
our town. I started browsing and giggled at all the outfits they sold. I held
up a french maid outfit and thought about how much Josh would love to see me in
one of those.

In the back of the store there ware hundreds of porn videos, in almost all
categories. I moved on and came across the section with dildos, vibrators and
other toys for females. I had heard Angela talking about them a few years ago
and she had encouraged me to get one too, but I never dared to purchase one.
Not online, let alone in a store like this. But now I was in one and here they
were in all shapes and sizes, in all colors.

My eyes fell on a set of five dildos. _Anatomically perfect_ it said on the
box. I looked around for another box like this one as there was no price on it,
but I couldn't find one. With my heart beating in my throat I asked the girl
how much they were. "Oh those are on sale, it's the last box. 15 dollars and
they are yours." the girl answered without being actually interested.

I looked in my purse to see if I had enough cash because I didn't want it on my
credit card. After handing her the money she put the box of toys in a nice
brown paper bag. "Have fun with them," she said and that was the first time she
actually looked at me. "No really," she said, "I have them too, they're great.
You know what helps me a lot when I play with them? I've given them names. You
might try it too. Have a good day, miss."

I rushed back to the car and my heart was beating so fast, I started the car
and couldn't out of there quick enough. Now I had another problem, where was I
going to keep them? I couldn't believe that I actually had bought them, that I
actually owned a set of dildos. And for now I had no idea what to do with them.

When I got home again I did my best to act as normal as possible and once
inside I rushed to our bedroom trying to find a spot where I could hide them.
Once I found the perfect spot (underneath my underwear) I went back downstairs
and checked my e-mail. The site had accepted my application and I was able to
log in.

At first I was a bit overwhelmed with all the possibilities on the site. And if
it wasn't for the big yellow button with _New to the lifestyle, click here_ I
think I wouldn't have found what I was looking for. A new page opened and it
was more like a forum now where you could post your questions and someone would
answer. I read a couple of posts and was pleased to see people were being
honest. One of them even had typed how exploring this lifestyle had ruined
their marriage and how devastated she was. But there was a silver lining: she
had met someone through this site and now they were a happy swingers couple.

There were lots of warnings telling me that both parties in a couple needed to
want to do this. That there were no gray areas, you either committed to the
lifestyle or you didn't. What I also read was a lot of people saying how much
closer they felt to their partners now they had embraced this lifestyle. One
woman even went somewhere I never wanted to go. She had gotten pregnant by
three men not her husband, on purpose. "It's the only way I can orgasm," she
said, "knowing I could get pregnant at any moment."

I shivered when I read her story and couldn't believe someone was prepared to
take such a risk. After spending almost an hour reading all kinds of posts I
couldn't really find an answer to the question I had, so I started a new thread
and typed:

_Hi, I'm so new to this and really anxious posting this here. But recently
someone I know told me they were active in this lifestyle and ever since then I
couldn't stop thinking about it. But I wouldn't know where to start or how to
even talk to my husband about this. Heck, I don't even know whether I want to
do this? Is there a way I could find out for myself if I really do want to do
this? I mean without actually cheating on my husband? It needs to be a safe
place, somewhere I don't feel pressured or something. Heck, I don't know.
Thanks for reading it anyway I guess, M_

Within seconds after I posted it, someone reacted.

_Dear M, Please don't take this the wrong way but if you're still questioning
whether you want to do this, you really shouldn't. Please take my advise and
don't start._

Another one replied.

_That's a true statement, but how are you going to find out? Well, maybe this
will help. There are nightclubs for couples where you can experience the
lifestyle. Most of them don't pressure you to do anything you don't want to.
Don't want to have sex? Then don't. Just want to be with your spouse? That's
okay too. When you are ready to take the next step everybody there has been
where you are now, so they all understand and can take it as slow or as fast as
you want to. Just an idea. There's a list of clubs available on our site, the
ones in green are specialized in first time couples. Trudy, admin._

After reading her post I noticed a little red dot near my name, indicating
there was a direct message for me. It was from Trudy.

_Hello, I'm sorry if you don't like DMs but I thought you might find it a bit
more comfortable this way. So if you have any questions for me you don't want
to ask in public, feel free to DM me._

I replied:
_Thanks for your message. And I think I might prefer it this way. I think going
to a club is a bridge to far for me at the moment. I've heard of role play,
might that be something? Thanks, M_

_Sure, Role play might be a good start. But make sure you take off your wedding
rings, make it as real as possible. Relive your first date, but act like it
really is. It's hard to do sometimes and if you can't just stop. Decide on a
safe-word on which the both of you will stop playing. Another thing might be to
get yourself some nice toys, give them names and talk to them like they are
real. If that gets you off then you're on the right track. If you still feel
like you are cheating stop. I mean it, I've seen to many relationships bust
because of this. When you are ready to take the next step, involve your
partner. But make sure you do it as early as possible. Don't make them find
out, you have to tell them and be honest with them._

_Thank you so much, this helps me a lot. M_

I logged off and thought it might be a sign. Now there were two people who had
told me to give the toys names. I looked at the clock and it was still a couple
of hours before Josh would come home. I turned off my laptop and went up to our
bedroom. I got the box with toys from their hiding spot and sat down on our bed
staring at them. I opened the box and one by one I got them all out. The felt
different than I had imagined, they weren't hard at all, but soft and a little
dangly. After getting them all out of the box I had to decide what to do with
the box, I could hardly put it in our trash. I decided to put the box in the
back of my car, I had an old bag still in there.

After doing so I got back in the bedroom and just stood there looking at the
five black dildos in different sizes. My blood started racing through my veins
and I laid down on our bed. I took the smallest one in my hand and whispered
"You are Josh, just because you're almost like him. And you are Marc, Damien,
Peter and you big one, you are my Master." I held them in my hand one by one
and each time I repeated their names. After a few minutes I took Master in my
hand and whispered "You Master, you are just a little too much for me at the
moment. Maybe later I can become yours, not now." I got up and put him back in
the back of my underwear drawer.

As I turned around a rush came over me and I checked the time once more, still
an hour or so. I undressed and laid down on our bed. I took Josh and kissed
him, licked him and took him in my mouth to make it a little wet. With my heart
beating in my throat I placed him against my slit and pushed it inside of me,
it almost felt like Josh really penetrated me. The dildo was practically the
same size. As I was holding it inside me I looked over at the other ones. First
I tried Marc, then Damien finally stopping when I pushed Peter deep inside me.
I could feel myself stretch as I pushed, I started moaning.

"Oh yes, Peter! This is what I want, this is what I miss. Stretch me Peter, I
want you to destroy my pussy." I started sliding the dildo in and out of my,
faster and harder. It went in so deep and after just a few pushed I could feel
myself come. "Oh yes Peter, I'm coming. I'm coming all over your dick, Peter.
Fuck me hard, fuck me Peter! Oh yes, I'm coming!"

Just saying someones name and knowing that they were names of people I really
knew had excited me more than I thought it would. When I had regained my breath
a little I could help myself, I placed Peter down and sat down on him. I
started to bounce up and down, holding the dildo in place with my feet. "Oh
yes! Peter, you feel so good inside me, Peter. I want you to fuck me hard, fuck
me so hard Peter. Are you watching me Josh, are you watching how your wife is
fucking with your boss? See how she loves it, oh yes, your wife is a little
whore, a slut. Oh my god Peter, I'm coming again. Oh my god! I'm coming all
over that nice big cock of yours."

After I caught my breath again, I quickly went into the bathroom cleaned the
toys and put the away in the drawer. The I grabbed a towel and my robe to jump
under the shower. A few minutes later I heard Josh shout "Luna? Where are you?" 

"I'm in the shower!" I shouted back.

When I got downstairs Josh asked "Why were you in the shower?"

"Oh, I just wanted to wash my hair. It felt a little sticky. It's girl thing."

In the weeks after that day playing with my toys became a daily occurrence, in
the end the only one I used was Master. He filled me up just right and every
time I had played my vagina hurt a little, just like I wanted it to feel. It
even went so far as I was fucking myself in the shower while Josh was at home.
One time he was still in bed and I had to keep myself from moaning too hard. It
just was so exciting to know he was just mere feet from me and I was bouncing
on a big black dildo in the bathroom. Sure the door was still locked, but it
was exciting to me anyway.

It all escalated for me when I was upstairs pleasuring myself with Peter while
Josh was reading the newspaper downstairs, the door to our bedroom was open and
feeling the excitement of getting caught at any moment made me come multiple
times, I just couldn't stop and ended up riding Peter on the stairs completely
naked, my boobs bouncing as I slid up and down the dildo, whispering "Oh yes
Peter, fuck me. Fuck me hard."

One day I decided to share my stories on the site and I got a lot of karma for
them, people seemed to really like them. One of them said I was a born story
teller. The more complements I got the more I shared and I started to like
telling stories, so I decided to post this:

_Hello, first of all thank you so much for all your complements on my
adventures. I really like having them and I like it even more to share them
with you. I like telling those stories so much I decided to write down my
fantasies too. I will clearly mark them as a fantasy, so you can distinguish
between the two. See it as a sort of valve for me, I need to get them out
otherwise I might do something foolish like actually act upon them without my
partner knowing and I don't want that to happen. So thanks again and please
stay safe. M_

That post again gave me a lot of karma and soon enough my account was upgraded
from bronze to silver status. Which basically gave me a few more abilities on
the site, like marking my stories as premium so people had to pay with karma for
them to read them.

After posting one of my fantasies someone commented that it would be nice to
see some photo's of me. His post was given a few karma points and I didn't
really know what to do with it. On one hand I thought it was just too
dangerous, on the other the thought of me posting pictures like that really
excited me. I answered that I would have to think about it.

A few days later I checked the _Multimedia_ section and went into the _Posted
by patrons_ category. There were a lot of photo's of women in all states of
undress, some even were of them having sex with another man. But on most of
them either the faces were blurred or simply cut off. There were just a few in
which the person was fully visible.

In the _Frequently Asked Questions_ category there was even an item on how to
post a video or photo. It had all kinds of things to think about.

_1. Only post an item in which you are fully recognizable when you really want
to do so. Please inform us about your intentions so we can verify you really
are doing so of your own free will. This will be reflected in your account so
others know this too. Otherwise items will be removed without prior notice._

_2. If you post an item make sure there is nothing visible that might indicate
who you are and where you live. Make sure there isn't any mail visible for
instance. We stand for the privacy of our patrons and for their safety. Items
will be removed without prior notice._

_3. Every item that is removed will lead to a warning, after three warnings you
will receive a strike. After the first strike we will only give strikes. When
you receive your third strike you will be banned from this site for life. There
is no discussion possible. We don't want to police this site, but we will do so
when necessary._

_4. If you do not want to follow these simple rules, don't post media on this
site. There are plenty of other sites where you can do so._

_5. This isn't a rule but a suggestion we advise you to follow. Before you
start posting media, make sure your partner knows about it. We strongly suggest
you be honest with your partner about everything you are doing here. We won't
be responsible for any consequences coming from posting any kind of content on
this site. We do not take any responsibility whatsoever as per our guidelines
you can read here._

That last sentence really felt like it was meant for me, even though the last
change made to that post was almost a year ago. Reading it really struck me
hard and I knew they were right. I had to tell Josh, I had to tell him
everything. It would be so hard to do, but if he really loved me he would
accept it. It wasn't like I was really cheating on him, they were just
fantasies and they were just toys. I decided to tell him that evening, after
dinner. It was Friday and he didn't have to work the next day so we could talk
all night if we had to.

I felt really nervous after I had made that decision and had to keep myself
from thinking about it as it would only make things worse in my head. It looked
like it took ages for him to come home and during dinner he said "Okay,
something is up. I know it, you've been acting strangely for a couple of weeks
now and it's really getting on my nerves. So tell me and please be honest with
me. Are you seeing someone? Is there someone else? Please tell me, it's driving
me crazy."

Okay, this was a bit sooner than I expected but now was a good time as any, I
thought. I looked down at my plate and started "Well, do you remember when we
had dinner with your boss? Yes? Right. Well, Gianna told me something that
really stuck with me and I couldn't stop thinking about it. Did you know they
have an _open_ marriage?"

"You mean as in they can see other people? Yes, Peter told me about it."

"Oh, I didn't know that. Now I've been thinking about it, a lot. And I joined
this site online where people like that meet. It's all anonymous of course. At
first I just wanted to get some more information about _the lifestyle_. But,
well one thing led to another and come let me show you." I got up and reached
for his hand. He took it and I guided him to our bedroom.

"Well, I've got five _friends_, who are there for me when I need them."

"I knew it! What are their names, I'll sue them!" Josh shouted, "And you--" His
face turned red with anger as I opened the drawer and reached for the first
dildo.

"This is you," I said, "I called him Josh, because this is the one I always
return to. This is the one I love and cherish. And this is Marc, he is there if
I need something more. Sometimes I need Darius here, or Peter. But sometimes I
need to really feel it. Sometimes it needs to hurt a little and then I turn to
my Master. I finally got out he largest dildo."

Josh just stood there staring at the five black dildos on the bed. He didn't
know what to say until he finally stuttered "You -- ehm -- you mean those
people you talked about earlier are just toys? Why did you give them names?"

"I don't know, it just makes it feel more real. That's why I chose names of men
I know in real life. There's you, Marc is the letter carrier at the boutique,
Darius is the owner of the coffee shop in the mall. Well, Peter you know too
and I didn't want to give him a real name, because I knew when I started using
him he would own me. And he does, that's why he is Master."

Josh sat down and started to laugh "I am so sorry, I didn't mean to laugh. But
this is such a relieve to me. I really thought you were cheating, but this,
this I can accept. No problem, I might even like watching you. Heck, buy as
many toys as you want to. Just don't ever shut me out like that again."

"I am so sorry that I did. But I really didn't know what I wanted or needed, I
was so confused for a long time. I didn't know how to tell you and today I
decided to tell you anyway. I wanted to do it after dinner, but you beat me to
it."

"And you joined a site, you said?"

"Oh yes, let me show you. I want to be totally transparent with you. I will
even give you the password to the site. Just promise me not to post anything in
my name that I don't know about. I trust you to honor that."

Josh nodded and I logged in on the site. Josh spent some time browsing the site
and reading the things I had posted. "You really did that on the stairs? Wow, I
wish I had known." and "Wow, you really fantasize about that?" were some of his
comments. When he was done reading he was quiet for a moment and then said
"First of all, wow you can write. Second I never knew you had fantasies like
that. Tell me the truth now, do you ever think about acting upon them? I mean
to really do it?"

"Sometimes I do. Sometimes the toys just aren't enough. Sometimes I fantasize
you being someone else as we have sex, but it just isn't the same. At least
that's what I think."

"Wow," was all Josh could say. He laid down on the bed and I grabbed the laptop
to prevent it from falling. "Wow" he said again. I closed the laptop and said
"Okay, now you know almost everything. There is one more thing." Josh rose up
and said "There's more?"

"Yes, some of the patrons on the site have asked me to post some pictures of
me, you know, naked pictures. I'm really thinking about it, it's so exciting to
post them. Of course I would blur or blackout my face and there will be nothing
recognizable in it, but I'm really thinking about doing it."

Josh just stared at me and said "Wow, I can't believe it. You really mean that
don't you?" I nodded and before I could say anything Josh said "Okay, now it's
my turn. The reason Peter told me about their _marital arrangement_ is that
Gianna hit on me at work one day. When I confronted Peter about it he told me
it was okay and if I wanted to I had his blessing. That was before we went to
have dinner with them. I told him I wouldn't and couldn't. But as with you I
kept thinking about it. So now we're both being honest, I have been thinking
about it too. I might even have fantasized about it in the bathroom a couple of
times."

I giggled "Oh sorry, I didn't mean to giggle, I am so sorry. Continue."

"Okay then, well let's just say this. Why don't we take it slow. Let's be
honest with each other at all times. Don't hide anything anymore. You don't
have to give me the password, just show it to me whenever I want to. Heck, I
might even create my own account and I could read them that way. Yes, that
might be a better idea. And if you want to post pictures, go ahead. Just make
sure nobody recognizes you, not everybody is okay with this."

"Just to be sure," I said, "We are giving each other the freedom to explore a
little, just as long as it doesn't go too far."

"Yes, I might even talk to some women on that site. Just fantasize, role play
if you will. Doing the same in real life is a no go zone. Agreed?"

"Agreed" I felt so relieved now I had finally told him and I hugged him so hard
while I whispered "I love you so much" in his ear. We went downstairs and
created an account for Josh, _MrDarington12_. I logged in right after and send
_Trudy_ a message if she could activate his account. She responded a few
minutes later that it was done. 

It was a whole new experience for the both of us sitting at that kitchen table,
both with a laptop browsing the same site and talking about the things we read.
Josh started browsing the photo's and showed me some of the women he liked,
they all had one thing in common with me: large breasts. I felt so good talking
to him about this, about the things he liked and the things I liked. It was as
if a wall between us had been torn down and we were being deeply honest with
each other for the first time. I had told him my deepest secrets, some of which
I didn't even tell Angela, my best friend since high school.

At one moment we shut down the computers, opened a bottle of wine and sat down
on the couch in the living room. We told each other about all the ones we've
been with.

"There was this one time. I was at a party and I was so drunk I took off my
shirt in the backyard. I was so hot from dancing. Angela pulled me to the side
and made me put my shirt back on. She immediately pulled me to the car and
drove me home. The next day I was so embarrassed when she told me what I had
done. But that was ages ago, a thousand miles away."

"One time I was in Cancun with some friends for summer break. We were in some
bar and on a dare I asked a girl to give me a blow job, fully expecting her to
slap me. But she didn't, she took my hand and in the back ally she got on her
knees and sucked me until I came. When she was done she looked at me and said
'50 dollars'. She was a hooker and I didn't even know it. But my friends did
and they all laughed so hard when I got back."

We talked for hours and laughed at our escapades and about the ones we dumped
or got dumped by. In the end we both felt closer than we had even been, there
were no more secrets between us. 

The next day we cleared the cellar to make room for my _girl cave_, as Josh
called it. "I've got my office, it's about time you get a place of your own
too." he said, "this will be your domain and you can do with it whatever you
like." The previous owners had used it as a gaming room for their kids so it
was fully insulated and there was heating. It was one of the reasons we had
stored things there that we didn't want to get wet or something.

We spent almost two hours clearing the space and when it was finally done I
felt happy with the space it had. We painted the walls white, except for one
which became a dark gray slate color. We had the carpet changed with one I
liked more and I placed a large sized bed in there. Across from the bed I
placed a small desk with a chair, just enough space for my laptop.

Josh made shelves on one of the walls which also had a desk of drawers. After
accessorizing the room with lights, plants and other bits and bobs, the room
was a bit more feminine that I had expected, but I loved it. Along the ceiling
I had put a string of lights that could change color and they were bright
enough to illuminate the entire room if I set it to full power.

Josh surprised me with a small stereo set he had bought for me so I could have
some music in there and he replaced the door with a thicker one. We tested it
and you couldn't hear anything upstairs even though the stereo was on full
blast. When it was finally done we christened the room by making love in the
bed and it was one of the few times I orgasmed while he took me as hard as he
could. Afterwards I said "I need one more thing: a nice large mirror on that
wall. I would love to be able to see myself."

After buying some equipment like lights, a sturdy tripod and some other things
I needed I was finally ready to do what I wanted to do. I set up the lights by
taking some test photos and when I was happy with the result, I changed into
something sexy, started the self timer on the camera and sat down on the bed.
My heart was racing as I undressed with every shot the camera took, until
finally I laid on the bed totally naked. With every shot afterwards I spread my
legs a little more, exposing myself to the camera. In one of the last shots I
spread my lips with my fingers exposing the pink underneath. All through this
process I felt myself getting so wet and didn't even think about the camera
anymore. I got hold of Master and sat down on it. I even made sure it was
clearly visible on the camera how the large dildo penetrated me.

Almost an hour later I showed Josh the photo's on my laptop. He chose the one
were I was sitting on Master as the one I had to post as my first picture. I
opened it in Photoshop and blacked out my face with a black oval. With him
sitting next to me I logged in on the site and went to the media section. I
started a new threat and typed:

_By huge demand, the first photo of me. Hope you like it._

I uploaded the photo and said "Well, here we go." as I clicked on the _Post_
button. A few seconds later it was online for the whole community to see. It
didn't take long for the first comments to be made and all of them were so
positive. My karma rose by a lot. They even wanted to see more of me and I
posted that I would take some time to make some good ones.

Josh kissed me and said "I am so proud of you. I can see you had fun doing
this, you just glow." The rest of the evening I spent on the site talking to
people about my photo, about my fantasies I posted and Josh sat there right
next to me as I did. Suddenly there was a DM from Trudy.

_Hi, let me start by saying I love your photo. But that's not why I contact
you. I loved your stories and how you interact with our patrons. We are
actively looking for people to moderate the site. This would grant you certain
privileges and I just want to make sure I pick the right people. Would you be
available for a chat via Skype one day. It doesn't have to be on camera, I just
need to hear your voice. DM me if you are interested or not. Trudy_

I looked at Josh "Wow, that's quite the honor. Wonder why she picked me of all
people."

"I know why. Because it's you. You have a way with people. You don't even know
it and that's why it so endearing. Trust me, people have told me how good you
are with people. It's one of the reasons Shione hired you in the first place,
she saw it too. She told me."

"Ah I don't know, I just treat them the way I want to be treated."

"No it's more than that. Shione told me about that one customer who got so mad
at her when she didn't get it her way. You stepped in and with two sentences
she calmed down and when you basically told her the same thing as Shione did
the woman accepted it and even thought she got a better deal than she did.
Trust me, it's more than just treating people right."

I blushed as I listened to his compliments and said "Tell me again how good I
am, I can hear it all day." I laughed and kissed him, "Thank you. But what
should I do? Should I accept?"

"That's up to you, do you want to?"

"I'm thinking about it."

"Then just talk to her and hear what she has to say. Then make up your mind."

"You are right as always." I turned to my laptop and answered the DM. We agreed
to Skype right away as we both we're available at that moment. I went down into
my basement and sat down at my desk. Trudy had sent me her Skype address and a
bit anxious I dialed it.

One side of the screen lit up as Trudy accepted the connection. She was a woman
in her 40s, with long red hair. The freckles on her face made her look a bit
younger, but she was just drop dead gorgeous.

"MissCurious?" she said.

"Yes, wait. Let me activate the camera too." I said. I sighed with relieve when
the little red dot lit up and my side of the screen filled with my face. "Oh
hi," I said, "Please call me Luna if we are going to do this."

"Luna? That's your real name?" Trudy said.

"Well yes. If I am going to be more involved in this it seems fair to at least
let you know my real name."

"I had a feeling you would say something like that. I don't know why, but I
just knew it. My real name is Jasmine, but my friends call me Jaz, with a z at
the end. Don't ask me why."

"Jaz it is," I replied, "Nice to meet you, Jaz."

We chatted for a bit and in the end I accepted her offer to become a moderator
on the site. It basically meant I got access to all the parts of the site,
except for the admin things. I could move or remove posts, give warnings and
strikes and I could even give or take away karma points. In short I could do
anything admins could do except for maintaining the site. Once a week we would
meet in a Skype group call which would be audio only and we only would use our
nicknames from the site.

"But I appreciate your trust in me by telling me your real name," Jaz said when
we were about to disconnect, "I trust you to keep mine a secret."

"I will and I trust you will do the same." I replied.

In the weeks and months after I settled into my role as a moderator and people
even gave me karma when I issued a strike to someone. "There's nothing better
than to read a moderator slam someone down with nice and kind words. This is
brilliant!" someone replied. During the same time I kept telling them my
stories, almost all of them were just fantasies and when I suggested to start a
new topic all the others accepted it and it didn't take Trudy long to implement
it. I wrote a nice opening post and with that the _Story Time_ section was
officially open. The topic was meant for erotic stories in all kinds of topics,
we started with just a few like _Erotic Horror_, _Exhibitionism_, _Group Sex_
and _Lesbian Sex_, but we ended up with almost 20 categories.

Trudy had made me the main moderator in the topic and every time we had a
suggestion for a new category we discussed it in our meetings. The one we all
had the most difficulty with was _Incest_, but there were so many requests for
it that we finally included it too. I was amazed to see how popular that
category became, it had the most stories in it and they were read the most.

Even the _Bestiality_ topic was quite popular, more than I would have
imagined. Most of the stories in there were fantasy style stories, where they
were talking about werewolves, demons and such.

As time progressed I spent most of my time on the site if I wasn't working and
even then I was thinking about it. At first I hated only working part-time, but
now I loved it as it gave me enough time to spent on the site and to talk to
people online. I had purchased a small notebook in which I wrote ideas for
stories, characters and things like that. Sometimes it were our customers who
would make it to a character in my stories.

When I noticed I was spending too much time on the site or with writing stories
I suggested to plan two hours a day for just the two of us. From 6 till 8 in
the evening we would take the time to spent with each other. We both blocked it
in our agenda's and after doing so for a few weeks everybody knew not to call
us during those two hours. We simply wouldn't answer the phone, only if family
called and then it had better be important.

Almost a year into this new arrangement I was downstairs in my _studio_ and was
interacting with some of the patrons on the site. By this time I was one of the
most active members and sometimes it was like everybody wanted to talk to me. I
did my best to answer them all, but sometimes it was just too much.

After another two hours of answering questions and just responding to posts, I
wanted to do something else. By now my collection of toys had grown and I now
even had a wardrobe with all kinds of sexy outfits. My photo's were quite
popular on the site and I got many requests to meet in real life. Men sent me
messages through the site with pictures of their penises and I didn't really
mind getting them. I complimented them all because I didn't want to hurt
anyone's feelings. I had gathered quite the collection of _dick pics_ and I had
saved them all in a special folder on my laptop.

On the nightstand next to the bed was one of them, a giant big black cock. I
had it printed out online and framed it. When they saw it in one of the photo's
I took I received even more of them and I welcomed it. On one of the photo's I
had posted I had written _Send me your dick pics_ on my belly.

