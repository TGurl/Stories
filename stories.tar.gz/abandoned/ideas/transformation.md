# Transformation
_an erotic tale by TransGirl_

## Chapter one: Feeling lonely
We had met in college and only after a year he had gotten the courage to ask me
for a date. Neither of us knew at that time he would be proposing right before
graduation. That was almost 5 years ago now and a lot had changed. We were so
close in the beginning, couldn't wait to be together, but nowadays he buried
himself in work and hardly ever was home. Sure it came with the territory of
being married to a successful prosecutor, but still I felt nothing more than
arm candy sometimes. People just couldn't believe I had a degree in Business
management and administration, a degree with honors I might say.

But as with many wives I had put my career on hold to support him. Just so one
day I could pick it up again and pursue my dream of opening my own store. That
day never came and I started to believe it never would. There always was some
excuse from him that prevented me from starting. "What if it all fails? How
would that reflect on me? Wife of prosecutor bankrupt. I can see the headlines
already." Josh always saw his career as a prosecutor as a stepping stone to
politics, he wanted to become president one day.

At first I fell for the charm of it all, but now it had gotten more serious. He
was polled to go to congress by the Democratic Party and he had shown he was
interested. This all would mean I got in an even more restricted life, one as
the wife of a congressman. I had to admit I wasn't looking forward to it.

During one of the long days I had to spend at home I was browsing the internet
somewhat and felt so lonely. If I had seen Josh for three hours that week it
would have been a gross overestimation and now he had called to say he had to
go to New York for a few days, something about a case.

I felt so bored and I couldn't find anything that peeked my interest, so I shut
the laptop down and leaned back. I sighed and looked around the empty house.
The silence was deafening. I had wanted kids, but Josh always had an excuse for
that too. I walked outside to the backyard, sat down in a chair and tried to
read my book. I got into a few sentences when the phone rang, it was Natalie my
best friend since high school.

"Hey," she said, "got something to do?"

"Not really," I replied, "Josh had to go to New York for a couple of days. I'm
all alone here. Want to come over?"

"Sure, I'll be there in 15."

"Josh is in New York?" she said as she sat down next to me.

"Yes, for some case." I replied.

"Girl, you need to find yourself a hobby. You just can't sit around the house
all day. You need to get out more."

"I wish I could. But there are some developments I can't talk about and I need
to be careful."

Even though I didn't say anything Nat knew exactly what I meant and nodded her
head. "I understand. But that doesn't mean you can't do nothing, now does it?"

"I wouldn't know where to start. I admit I am so bored most of the time and
rather lonely. Josh is always working and I knew what I signed up for, but I
didn't realize it would be this restrictive."

"Sure, but girl you need to find something. Now let's talk about some other
things." She started gossiping about the things she had heard in her salon.
Natalie had one of the best salons in town and catered to the rich and famous.
We chatted for a few hours until she had to leave. As she started the car she
said "I mean it girl, find yourself something to do."

I walked into the house and the silence hit me like a ton of bricks. Natalie
had been right, I really needed to find something I liked to do. I made myself
a simple dinner and afterwards I sat down in the living room to watch the news.
The ringtone of my phone startled me and I saw a number I didn't recognize.

"Mrs Davis?" the voice said on the other side.

"Yes"

"Hello, my name is detective Moreland. I am afraid I'm calling with some bad
news." At the same time he spoke to me I saw a banner on the TV: Prosecutor
killed in drive by shooting.

I screamed out loud and my knees buckled. I fell down on the floor and I could
hear him say "Mrs Davis? Is there anybody with you? Can we call someone?" I
just couldn't speak. "Have someone contact local police and send someone over
there. Hurry, I think she's home alone. Mrs Davis? Hello?" He kept on calling
my name until someone entered the house, it was a local deputy who took my
phone and said "Hello, this is deputy Hanson. I'm here right now, thank you for
calling us."

She hung up the phone and helped me on my feet. "I am so sorry for your loss,"
she said, "he was an honorable man. A pain in the ass sometimes, but a good
man." She sat me down on the couch and got me a glass of water. She didn't say
a word and just sat with me letting me cry. Suddenly I heard Natalie's voice
say "I'm her best friend. I've got this. Thank you so much for coming and
taking care of her. I came as soon as I heard the news. Again thank you so
much, I am in your debt."

The rest of the night I don't remember anymore, as soon as Nat took me in her
arms I gave myself permission to black out. I woke up in my bed and when I got
down Natalie was sitting at the kitchen table. She was on the phone and I heard
her say "..no she just got up. I gotta go. I love you, I will be home when
she's up for it. I need to be here right now, I can't leave her alone. Yes, her
parents are on their way, but won't be here for another couple of hours. Yes, I
love you, see you soon."

"Barry says hi and how sorry he feels." she said when she turned to me. I was
just numb, didn't feel a thing. I turned on the TV but every channel was
talking about Josh and I turned it off. Nat made me a cup of coffee and handed
it to me. "You got to drink something, Luna. Please." I took a few sips and
handed it back to her.

"Thank you for being here," I stuttered.

"Where else would I be?" she replied and with those words I started to cry
again, uncontrollably. "He's not coming home now, is he?" I uttered through my
tears, "They took him from me, didn't they?" Natalie took me in her arms not
knowing what to say, but her being there was enough for me.

A few hours later my mother stormed in the room. She ran up to me and took me
in her arms. "I am so sorry baby," she said, "so sorry." I started to cry again
and it felt good being in her arms again, the safety of my mothers arms. She
held me for I don't know how long, then it was my fathers turn to comfort me.

"Oh sugar, what can we do to help?" he said, "Leave everything to us. We will
take care of everything. Just point us to the papers and we will do it. Okay?
Please let me do this for you." I nodded on his shoulder and said "Thanks dad."

He held me for a while and said "Todd is on his way over. He's coming back from
Europe." I cried even harder this time, I hadn't seen my brother in over two
years and now he was coming over for me. He had dropped everything and gotten
on a plane home, for me.

My mom made me something to eat and thanked Natalie for being there for me.
Just before she left she hugged me and told me she would be back later. I just
nodded and thanked her. Everything else is a bit of a blur, I know I helped my
dad find all the paperwork, but beyond that I can't really remember.

The following day loads of flowers were delivered all with their sincere
condolences. There was just one that stood out. A bouquet of pink roses, the
card read "On my way, sis." I started to cry when I read the card and if by
magic he walked in the door shortly after. I ran up to him and jumped in his
arms. "I am here sis," he said, "just like I promised I would. I am so sorry
for your loss, I really am."

I just held him tight. He was my older brother and he always had protected me.
One day when I was about 11 we got in an accident and it was Todd who dragged
my out of the car. He held me in his arms and pressed his hand on the wound in
my side. He whispered "I am here for you. I will always be here for you. I will
come when you need me, no question asked. I promise I will always come." And
now he had kept his promise.

A few days later there were so many people at Josh's funeral. I didn't really
listen to all the speeches and just wanted it to be over so I could get away
from all the camera's. I felt like I couldn't breath all day and was so happy
when we were home again. My parents stayed for another or so until everything
was in order. Josh had left me everything in his will and it all just felt so
utterly useless.

During that period there was just one spark of good news, they had caught the
perpetrators and they would be prosecuted to the fullest extend of the law. It
took a few weeks before the trial started and I attended every single day. I
wanted them to see what they had done to me. When it was time to give my victim
statement I said:

"I'm standing here for my husband. He's the true victim here, I'm not a victim,
I'm a survivor. You have taken the love of my life, my reason for living. But I
will not give in to your terror, I will not bow. I am standing here and I'm
looking at you. None of you dare to look me in the eyes. You are all just a
bunch of cowards. You think you are all that? Shooting at an unarmed man from a
car? No, you aren't brave men, you are just boys and I am stronger then all of
you. I want to address the court if I may?"

"Granted"

"Your honor, I do not believe in the death penalty. Therefor I want to ask the
court to give them the longest prison time possible, but not sentence them to
death. I want to be able to walk in that prison one day and to be able to say
to them that I've forgiven them. But I'm not there yet. The wounds are still
too fresh. I hope from the deepest of my soul the court will grant me that wish
and I thank the court for their attention."

"Thank you Mrs Davis, and might I give the courts deepest condolences for your
loss."

After my words it was silent in the court, Natalie grabbed my hand and squeezed
it a little. The judges gestured and the clerk said "Will the defendants please
rise."

"You have been found guilty by a group of your peers of a most heinous crime,
the one of premeditated murder. I therefore should sentence you to the fullest
extend of the law. And I was prepared to do so, until I heard the words of his
widow and how she asked for me to spare your lives. Although I don't understand
her fully I will grant her that wish. I hereby sentence you all the life
without the possibility of parole." He then proceeded to complete the
procedures of the court and the two boys were pulled away.

As we left the court all the news outlets pushed their camera's in my face
shouting questions about why I had spoken out against the death penalty.
Natalie just shouted "No comment. Please let us through. No comment." But at
some point I had enough and said "Okay I will answer that question, but please
give me some space."

"If there was one thing we never agreed upon it was the death penalty," I said
after a while, "I've always been against it. Josh had tried many a time to
convince me otherwise, but I just couldn't accept it. Finally we agreed to
disagree on that point. I've never spoken out in public like this, because I
supported him in all the choices he made. Even if I didn't agree with them. I
am his wife and that's what I had to do. Today I still couldn't step over the
moral dilemma's I feel regarding the death penalty. I know my husband looks
down on me and I know he's proud that I kept to my believes. Even in this
case. Thank you, now please I want to go home."

Later that night there was a short interview with one of the mothers. "I thank
Mrs Davis for her words, but my son is still in prison and he didn't shoot that
gun. But thanks to her it wasn't the harshest penalty it could have been and as
a mother I thank her for her words and might I say something to her? Mrs Davis
if you see this. I am truly sorry for your loss and I hope you can forgive him
one day like you said. Until then I will be grateful to you."

I had tears in my eyes when I saw that and felt my heart well up a little. She
had lost someone too and I felt sorry for her.

It took almost half a year for the storm to calm down and for me to start
living again. I had sold the house, the cars and everything. Until I only had
my suitcases with my clothes and my own little car.

To escape being the prosecutors widow I had set my eyes to move to Portland. I
had visited that town a few years earlier and loved it. I had booked a hotel
for the first couple of weeks until I could find a job and an apartment. Not
that I was in a hurry, selling everything on top of the will had left me with
enough to last a lifetime.

Natalie hated to see me go so far away, but she supported my choice and had
helped me sell most of my belongings. My parents had taken all the photos with
them when they came to visit one last time in the old house. I had told them to
give them back to me when I was ready. Todd had returned to the States and was
working in a hospital in DC. Life was getting back to normal a little.

The drive to Portland felt like a new start, the farther I left my old life
behind the more I felt like I could breath again. I stopped a couple of times
and stayed at a cheap motel for the night. I didn't really get that much rest
that night as I didn't feel quite safe and I left as early as I could. At one
point I stopped to enjoy the view and I whispered "Josh, if you can hear me. I
still love you and that will never change. But I need to start living again, I
need to let you go. Bye my love and I hope to see you again one day." As if it
was a sign a butterfly landed on my hand and I smiled. It felt like Josh had
given me permission to start living my life again.

It was already late when I arrived at the hotel and after parking my car I
checked in. Once in the room I just dropped my luggage anywhere I fell down on
the bed. I must have fallen asleep almost immediately and when I woke up I had
a little headache. I took a quick shower, got dressed and walked downstairs to
the lobby. I asked the man sitting there if there was a place I could get a
bite to eat and he pointed me to the place across the street.

I sat down at one of the tables and ordered a burger with fries. A simple meal,
but I was hungry. After eating I wandered the streets a little and found a bar
that appealed to me. I ordered a beer and sat down at the bar. It didn't take
long for a man to walk up to me saying "Now what is somebody like you doing all
alone in a bar like this?" I looked at him and pointed to my wedding ring. I
hadn't had he courage to take it off and at that moment I was happy I was still
wearing it. "Oh, I am so sorry Miss, my apologies."

I giggled a little as it felt good to know someone was still interested in me.
I finished my beer and walked back to the hotel. Back in my room the heaviness
of my new situation hit me like a ton of bricks and I started to feel lonely.
It was almost midnight so I couldn't call Natalie, even though she had told me
to call her anytime I wanted to. 

I got up and started unpacking my bags, the small cupboard didn't fit a lot so
I put the rest of the bags along the wall in the room. When everything was
done I got my laptop, connected to the hotel's WiFi and browsed the internet
for a bit. Caught up on the latest news, responded to a few messages on
Facebook and then just did whatever came into my mind.

At one point I typed _how to pick up your life after your spouse dies_. There
were a bunch of results and most of them were nonsense I thought. I did another
search _woman seeking for a change_. The results were mostly to porn sites, but
there was one that stood out to me: _Silvia's List_. I clicked on the link and
the site opened.

"Silvia's List is a dating site for people who have lost someone in their
lives. We are a community of people who have all experienced the same loss and
are trying to pick up their lives again. And if you're ready, you could even
start dating someone using our services. Please register, it's free."

I clicked on the Frequently Asked Questions link and read what it was all
about, one of them was answered the question if _Adult material_ was allowed.
The answer was yes. I giggled and thought "That could be interesting."

Without thinking more about it I registered an account and when I logged in I
had to fill in a whole list of questions. This clearly was a dating site and I
filled it in as much as I could. The last question was "Are you ready to date?"
which I answered with _No_. The page took some time to refresh and the page
opened up with my new online profile. I browsed through the site a little and
found a forum for moral support. I read a few posts before I posted my first
one.

"Hi, I just wanted to take some time to introduce myself. I'm a recent widow
and decided to leave my old life behind. I sold everything and now I'm here
sitting in a hotel in a new town. I won't go into detail, but believe me I just
had to leave. Now that I'm sitting here, in a dark room in a place where I
don't know anybody. I'm starting to believe I made the wrong choice. What would
you do in a situation like this? Go back home or give it a chance? Thanks for
reading this. Bye"

It didn't take long for someone to respond.

"First of all welcome to this community. And I am sorry for your loss. I lost
my partner a few years ago and felt lost too. Until I found this community
where there's always someone to talk to. Some of them have become my closest
friends. I don't want to seem pushy but if you want to chat you will have to
send me a friend-request. I can't because your profile is still hidden. Just to
be clear: according to your avatar you are female and I am gay. Just to let you
know I'm not coming on to you."

I giggled when I read the last words and replied:

"Thank you for responding. Yes I am female and I don't think I ready yet to
start making new friends, I need some more time. There are just so many changes
at the moment. I need to find an apartment, a job and all that jazz. When I'm
ready I will sure keep you in mind. Thanks again. Bye."

We reacted to some more posts of each other and he made me feel a bit better.
He said to at least give it a chance and not to judge because it was just the
first night. "You can go back home at any time. I'm sure your friends would be
happy to see you again." and he was right. They would be.

There was just one more post from him before I shutdown my laptop and it read
"I think you made a new friend today, even though you didn't want to." He ended
it with a smiley face and I giggled softly.

The next morning I got up early to look for an apartment. I wanted one
downtown, I wanted to be in the hustle and bustle of things. There was one
available on Park Ave and it was reasonably priced too. I went inside the
office and talked to the agent who was selling it. She told me it was in a nice
part of town and when I asked if we could take a look she said "Wait, let me
get the keys."

We walked a few blocks until I saw a large green banner stating _Roosevelt_ and
as we entered she greeted the building manager. "Now," she said, "you will have
to pass the committee, but I don't think that will be a problem. There's is a
monthly pay of 200 dollars to maintain the shared spaces. Down there is a
launderette, but this particular apartment had spaces for you own machines
too." She kept on talking until she opened the door. It was just beautiful,
with a nice wooden floor and even though it was just a one bedroom apartment I
fell in love with it.

"I don't want to pry, but you look familiar to me. Do I know you from
something? It's just that I don't forget faces and yours is somehow familiar to
me."

"Yeah, that might be right. I'm Mrs Davis, my husband was killed in New York,
almost six months ago. He was a prosecutor."

"Yes, that's it. Oh, I am so sorry, that came out wrong. So sorry for your
loss --"

"I wished people would stop saying that. It's been almost half a year."

"You are so right. I won't say it then. But wouldn't you be interested in
something -- bigger?"

"No, this is perfect. This is all the space I need to get my life back
together. Do you take credit card?"

"What now?!"

"I'm kidding, I will talk to my bank and I'm sure they will guarantee the pay.
Let's just say I made a good turn on my old house."

"And with you credentials passing that committee shouldn't be a problem."

We went back to the office and I called my bank. With them on speaker we made a
deal that would go in affect the moment I passed that test. The agent called
the contact and she pushed for a meeting that evening. "Look, she's new in town
and lives in a hotel. She really needs this apartment and I promise you she's
good for it. Just talk to her and you will see that I'm right. I was about the
last one right? Oh wait, the last one was you." She laughed and winked to me 
"Okay, this after noon at 5. Please don't be late."

I arrived at the _Roosevelt_ 10 minutes early and pressed the doorbell of the
appartment I was having my interview. "You are early, good sign" the buzzer
sounded and I made my way up to the apartment. There were a few people there
and I got a bit nervous at that moment. We all sat down and the eldest of them
started by saying "Welcome to this meeting. We understand you are here for
number 11. Well, that would mean you would become my neighbour and I'm sure I
will have some questions. But please introduce yourself first."

"Hello all, my name is Luna Davis. I am the widow of Federal procedutor Josh
Davis who was shot and killed almost 6 months ago. I am here because I wanted
to move to a new town as almost everything there reminded me of him.
Momentarily I am between jobs, but trust me paying the bills will not be a
problem. I am just looking for an apartment large enough for me alone and this
one seemed perfect to me. It's in a nice location and it's reasonably priced.
And I can assure you I do not need a loan to pay for it, if that might answer
one of you questions. I have a business degree from Harvard, that's were I met
my late husband, and I'm looking for something I would like to do. Let me see,
is there anything else? No, any questions?"

"Yes," one of the younger women spoke, "Why did you oppose the death penalty in
your husbands case? You did answer that but I always kept wondering."

"Good question. As I stated on TV I do not believe in the death penalty. Josh
and I used to fight about it until we agreed to disagree. When he was a
prosecutor I always supported him whether I agreed with him or not. I was his
wife and that's what you are supposed to do if you love someone, and I did with
whole my heart. Does that answer your question?" She nodded sheepishly and
leaned back.

There were a couple of questions more and I answered them all truthfully, the
meeting ended with the man who spoke the first. "Well, that concludes it then.
Let's vote. All in favor?" Everybody raised up their hands. "Let me then say,
welcome to the building neighbor."

The next day I got my keys and I bought a bed at a place who could deliver it
later that day. I had already checked out of the hotel and was standing in a
totally empty apartment. The next few weeks I was busy looking for furniture,
accessories and everything else I needed. Until the day they came to connect my
internet I did almost everything on my phone. I was so happy to see that a
fiber connection was available for me.

My neighbor, Mr Niedermeyer had told me that ever since they had insulated the
walls there was hardly any noise disturbance. He also told me about the
policies of the building and I promised I would keep to them.

When everything was done I could finally say I had really moved in and within
days Natalie came to visit. She had insisted to sleep in a hotel, but I had
said she could sleep with me. We had shared a bed when we were in high school
so this wasn't any different to me.

"Wow, this is completely different than your old house. Only one bedroom? You
could afford something bigger couldn't you?"

"Yes, but why have 4 or 6 bedrooms I never use? Here I have my bedroom, a
bathroom and my living space. That's all I need for now."

"You're right, but a balcony would have been nice."

I giggled, typical Natalie always finding something wrong. Even when there
wasn't.

We spent the time exploring the city and in the end she said "You've chosen
wisely, it's beautiful here. I might come more often and I will bring my own
bed next time." We had a nice dinner together and spent the rest of the evening
chatting in my new apartment. I was sorry to see her go the next morning, but
she had to be at the salon later that day.

After I had waved her off I went back inside and greeted Jose, the super. I
talked to him a little bit and asked how his wife was doing. I was glad to hear
she was out of the hospital and asked him to give her my well wishes. Much
later I learned I was actually the only resident who even talked to him when I
didn't need anything from him.

I sat down on my couch thinking of something to do, when I thought about that
site again. I hadn't logged in for quite some time and when I did I noticed
there were a few more responses to my original post. Most of them were words of
encouragement and it was time I gave them an update.

"Sorry, but it has been a little hectic lately. I am glad to say I've decided
to give it a chance and am now sitting in my new apartment. It's just a one
bedroom one, but it's enough for me right now. Thanks for all the kind words
and now I am in my own place I might be here more often. We will see. Bye"

Within seconds the post got quite a few thumbs up and I decided to update my
profile a little. I uploaded a nice photo of myself and updated some of the
answers I had given. But the question whether I wanted to date I kept the
same. I hesitated for a moment before I clicked on _Publish_. The page
refreshed and I landed on a timeline. The first post was _MysteriousKitten has
published her profile_. I decided to post something on my timeline so there was
at least one post.

"Well, it's official I own my new apartment and I have officially moved. It
took me a few days as I had to buy all my new furniture but I am so happy with
the result. I have my late husbands picture on a nice place of honor and for
the first time in a while I think I might be happy again. Maybe I'll stick
around here as well as where I am in real life."

During the next few months I spent my time looking for a job that I liked and
exploring the city. In the evenings I spent most of my time on the site,
chatting with people online. The more I spent on there, the more important the
site became to me. It was the one place where I could truly be open about
myself. Mostly because it still felt anonymous. I could really talk to people
there and tell them how I felt. I had made some online friends to whom I really
opened up and felt save enough to talk about my desires.

One morning I was sitting at my kitchen table browsing the site, looking for
nothing in particular. I had never enabled the _Allow Adult Content_ option in
my profile, but now I decided to change that. Luckily that didn't lead to an
update on my timeline, but it made a few more items available in the top menu.

I clicked on _Adults Talking_ and a new page opened with a photo album, a forum
and an online text and video chat. I opened the forum and there were all kinds
of threads. I was simply amazed by how open people were talking about their
experiences, their desires and just about everything. I opened the first thread
called _New to the Adult Content_ and I read all the do's and don'ts  of that
forum. It ended with an invitation to write something in the _Introduction_
thread.

"Hi, not really sure what I'm doing here. But here I am. I guess I got a little
bored with the non-adult content and wanted something new to experience. It's
my first time on a forum like this, so please be patient with me. I've read
some threads and can't believe how open some of you are. I'm not there yet,
maybe I will be in the future, who knows. I just wanted to say hi that's all
for now."

Within seconds I got a reply

"Welcome to the dark side! Just kidding. I just wanted to say this is a safe
space. You can talk about anything here and you don't have to be afraid to use
strong language. That's why this was started in the first place. It grew into
something more than just that. People started sharing things and we totally
support that. That being said, there are some things out of bounds, but I trust
you read the rules already. I just wanted to say, if you need to this is the
place where you can share your deepest, darkest secrets. Nobody will know it's
you. We hide everything that could lead to your real identity. So please feel
free to share. Trudy, admin."

"Thank you for your kind words, Trudy. It's just hard for me to talk about
things like that. We never did where I grew up. And I still feel like I'm
cheating for just being here. I know I have to move on at some point, but
that's how I feel. Sure I've shared some things with friends I made here, but
somehow that feels different than sharing it here for anyone to read. I hope I
make myself clear. Just typing this is hard enough for me."

"I understand, I just wanted to let you know you can feel safe here. And if you
don't alert me or one of the moderators. We will take the appropriate actions
when needed."

"Thanks again. I will keep it in mind."

I opened a few more threads and started reading what people had shared. One
woman told her story about how she totally lost control and slept with a lot of
men during the first year after her husband had passed away. Because she had
shared her experiences on the site she had met her current husband who totally
supported her in her new lifestyle. She still had sex with other men, but not
by the amount she did. She now had her _Bulls_ as she called them and she was
very happy now.

After closing the site I thought about what I head read, especially the thread
about feeling guilty stuck in my mind. I had no reason anymore to feel guilty
and I looked at my hand. For the first time since Josh passed I took off my
ring and placed it near his photo. "I'm sorry Josh, but I need to move on. I
still love you and miss you, but I can't be stuck anymore. Giving you my ring
is the last hurdle I have to take. I picked up the photo and stuck my ring in
the back. I kissed his photo and whispered "Goodbye my love, I'm letting you
go." I walked over to a dresser, opened a drawer and placed his photo inside.
Slowly and carefully I closed it.

Doing that ritual felt like I turned a page in my book. The spot where his
photo stood looked empty but that's what it was meant to be. The one spot in my
apartment symbolizing the emptiness I felt inside. With my fingers I rubbed the
spot where my ring used to be and shook my head when I felt the urge to put it
back on. I grabbed my jacket and purse and went out the door.

I roamed the streets for a while, sat down at a coffee shop for a latte and
just enjoyed watching the people pass by. Whilst I was walking again I came
across I nice little boutique called _Portland's Rose_. I went inside and
looked at the things they had. My eyes fell on a translucent dress and wondered
what someone would wear underneath such a dress. From somewhere in the back a
young girl walked up to me and said "Hi, my name is Laura. Welcome to the Rose.
How can I help?"

"Oh I was just browsing, thanks." I said.

"Please feel free, everything is half price this week. We're getting a new
collection soon, feel free to try something on if you want to."

I got a nice blazer from the rack which was in my size and tried it on. "Oh,
that one looks really nice on you. Would be wonderful when you're wearing a
dress." Laura said from behind her counter. With the discount it was only 40
dollars and it did look nice on me. I placed it on the counter and browsed some
more. Found a nice one-size-fits all dress and tried in on. It was way tighter
than I was used to, but it wasn't uncomfortable. Laura walked up and said "Now,
that's what I'm talking about. You can show those curves. That's simply
amazing. And now only 20 dollars."

I turned to her and asked "I've just got one question. That dress over there,
the translucent one. What would one wear under such a thing? I'm just curious."

"That's what everybody asks. But anything you want. That dress for example
would look very nice as it's sleeveless. It's meant as something you wear over
another dress to give it some oomph, so to say. But if you're feisty you could
just wear some nice lingerie underneath."

I changed into my regular clothes again and as I walked to the register I
grabbed on of the translucent dresses as they were one-size-fits-all I thought
I'd take the risk. Laura laughed softly when she saw I laid it on the counter.

"Somehow it appeals to a lot of women, including me." She giggled. I paid for
my new clothes and thanked her for all her help. As I left the store I told
myself to remember this place. As I walked through the streets I came across a
mall and went inside. There were lots of shops and I decided to spent some time
looking for things I liked. In one store I saw a beautiful pair of heels and
after trying them on I left the store with them.

When I arrived back at my apartment I had quite a few bags with me. I didn't
have the intention to go shopping and as always those were the moments you got
some good deals. I got everything out of the bags and when I reached for the
translucent dress I got an idea. I went into my bathroom, undressed and put
that see-through dress on. I sat down on the toilet to put my new heels on too
and walked out into my living room. I wanted to know how it looked and got my
phone from my purse. I opened the camera app and changed the settings so I
could see myself on the screen.

I giggled a little when I saw my nipples clearly through the dress, but I
thought it looked fine. Laura's words about feeling feisty and to wear a nice
set of lingerie underneath stuck in my head. I thought to myself that I needed
to see it more clearly and took a photo of myself in that dress. I felt stupid
just standing there so I set the self timer and posed for every picture. With
every shot I tried to look more provocative. I was having so much fun I started
the timer again and posed some more.

After uploading them to my laptop I wasn't totally unhappy with them. But I
wanted to get better photos. I got dressed again and drove to the outskirts of
town where the large mall was. In the electronics store I bought a real camera,
a tripod and a thing they called a ring light.

On my way back to the car I passed a lingerie shop and bought myself three nice
sets of lingerie. At the checkout my eyes fell on a bag of black nipple
stickers and I threw in two of those. When I got home I put on the panties of
the black set I had purchased and took my time placing the stickers on my
nipples. I put the translucent dress back on and my high heels.

I got the camera out of the box and connected it to one of the sockets. I
placed the battery in the charging bay and turned the camera on. In the book I
read how to connect the camera to my laptop so I could see what was in focus. I
pointed the camera towards my couch, turned the laptop so I could see the
screen and sat down. I marked the spot with a pillow and set the self timer of
the camera. After every shot the screen froze for a second or two before it
returned to the live image.

I set the timer to take unlimited pictures as they were uploaded to my laptop
instead of the internal memory. With my heart racing I sat down on my couch and
looked into the camera. With the next shot I held up my breasts with my hands
and took another pose with every shot until I leaned backwards and opened my
legs a little. Then some more and more until I spread the wide. Then I pulled
away the fabric a little until my slit was fully exposed to the camera. Shot
after shot I went I little father until I had my panties in my hand. I spread
my legs again and this time I also spread my lips with my fingers exposing the
pink underneath. I was having so much fun doing this and didn't really want to
stop. But I did and turned off the camera, disconnected the laptop and sat down
at the table to look at the pictures.

I deleted most of them and decided to wait for the batteries to be fully
charged before I tried again. But I did feel nice wearing that dress and put my
panties back on. I kept wearing it for the rest of the evening and just felt
good about myself.

At one point I found out that during the day my bedroom had perfect lighting
and I started holding my own little photo shoots during the day. The longer I
did that the more explicit the photos became and one day I ordered a set of
dildos online. Next to photos I started video recording myself masturbating and
although I was quite active on the site I didn't share any of it online. It was
still my little secret.

It was on a Friday night and it was one of those hot summer nights. I had the
windows open a little to get some fresh air in and I heard the sounds of music
coming from the bars. I looked outside and watched the people in the streets. I
turned around, showered, put on a nice dress, did my hair and makeup, grabbed
my purse and went outside. I wanted to experience Portland at night. I had been
her for so long now and I had never done it before.

There was a pleasant atmosphere and I hopped into a bar. Got myself a drink and
tried to find a place to sit outside. Every seat was taken, but one man offered
me his chair and said "Here you are, ma'am. I should be going anyway, have a
good one y'all." I sat down and enjoyed my drink. As I sat there I wanted to go
somewhere where I could dance. I hadn't gone dancing in so long. I asked the
people at the table where I could go and they pointed me to a place around the
corner.

I went there and saw the line to get in. No way I was going to wait for that
long and started to look for something else. Across the street was a smaller
establishment and as I approached it became clear it was a more _adult_
environment. I hesitated for a moment and then just thought: heck let's do it.
I went inside and had to hand off my purse and jacket. The girl gave me a card
and explained how it all worked. I went through the door and entered a dark lit
room with tables and booths to one side and a dance floor to the other. There
were quite a few people there. I ordered a drink at the bar and handed the man
my card. He swiped it and handed it back to me. I went over to a booth near the
dance floor and sat down.

After finishing my drink I stepped on to the dance floor and started to dance.
The longer I was on there the more people followed. Some girls were dressed
very sexy showing a lot of skin and I got excited to see them that way. I
minded my own business for most of the night and just had some fun. After
dancing for a while I sat down at the bar and a woman came up to me.

"I don't think I've seen you before," she said, "I'm Carla."

"Hi, Luna," I replied, "I'm new in town. And I wanted to dance but the place
across the street had a line."

"Oh yes, they always have. But this is way more fun. You can be more _loose_
here, if you know what I mean."

We chatted for a while and I liked her company. "Come" she said at one point
and pulled me back on the dance floor. We danced some more and before I knew it
it was almost 2 in the morning. I didn't want to walk back home so I ordered a
taxi and was dropped off in front of my building.


