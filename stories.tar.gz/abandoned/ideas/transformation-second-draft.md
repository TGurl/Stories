# Transformation
_an erotic tale by Transgirl_

## Chapter One
We had been married for four years and Josh was working for one of the biggest
law firms in town. He worked on the largest cases and insane hours, he went to
work early and got home late. By that time he was so tired all he wanted to do
was go to bed and sleep. As with a lot of nights I just sat in the living room
thinking back to better times. Times when we were a _real_ couple and did
things together. But lately it felt like he was ashamed of me, like he didn't
want to be seen with me anymore.

Sure I never was the thinnest person in the world, but I wouldn't call me obese
either. I did everything to get his attention, started to wear makeup all the
time, sexier clothes around the house when he was home, nothing seemed to work.
It was like he didn't see me anymore. I started to feel resentment towards him,
I had put my career on hold so he could go to law school. Not that I hated my
job at the local supermarket, I was one of the managers and I loved the people
I worked with, but that wasn't what I went to college for. I had a degree in
Business and always wanted to start my own company.

It had been the plan that after he got his degree I could start planning my own
business, but it never got to that. He was recruited right after he got his
degree and now all he did was work. Even when he was home he was in his office
going over papers and preparing cases. And it wasn't about the money, I could
easily stop working as Josh made enough for the both of us. But I wanted, no I
needed to work. Just to get out of the house and have something to do.

It was on one of those evenings when I was home alone that I started to browse
the internet for something to do. I didn't want to watch Netflix or read a
book, I needed some excitement in my life. I came across lots of sites for
women and they just weren't what I was looking for.

I typed _woman looking for excitement_ in google and got a few results, the top
one was for a site called _Silvia's List_ and I was intrigued. I clicked on the
link and the page opened with:

_Silvia's List_

_A dating site for men and women who are looking for an exciting affair or
adventure._

All it showed was a photo of a woman smiling at a man and a large registration
form. I clicked on the button for more information and read what it was all
about.

_As a member of Silvia's List you can post and manage your own profile with
photos. That's how easy it is to cheat on dating site Silvia's List._

_You can cheat (dating) online by sending messages to other members._

_Dating site Silvia's List also offers a vibrant, much-visited chat for quick and direct contact._

My heart started beating faster, it felt so exciting just to have the site open
at all. I decided not to do anything and closed the page, a seed had been
planted though and for the next couple of days I couldn't stop thinking about
it. "If I only do it online, it isn't really cheating, is it?" I thought to
myself.

I was in my small office at work and things had been slow for me that day, I
looked up through the window out on the work floor and everything seemed to go
smoothly for once. The deliveries were on time and although it was rather busy
there hardly were any queues. All the paper work for that shift was done and
there wasn't a lot for me to do. Even though it was a bit boring, I loved it
when I could just sit there in stead of running through the store getting
things organized.

My thoughts went back to the site and I opened it up on the computer. If it had
felt exciting to have it open at home, this was way more exciting. My door was
always open and someone could walk in at any moment. Without really thinking I
started to fill in the registration form. All it asked for was a username, a
password and my e-mail address. "Oh, I don't want Josh to find out." I thought.
As a sign of trust we had granted each other access to all our accounts and he
could simply login using my password manager. If I really was going to do this
I needed to create an alternate e-mail account, one he didn't know off. I also
wanted it to be a secure one and it had to be free.

"Luna?" a voice behind me sounded. I quickly closed the site and turned around,
I felt like I was caught and the girl asked "Everything okay? You look a bit
flustered."

"Yeah, I was just concentrated, you startled me a bit. How can I help?"

"It's Jean, she's not feeling well. Could you come please?"

Besides manager I also was one of the emergency response officers and followed
Misty to where Jean was. She was sitting down, all pale and I knelt down.

"What's going on Jean?" I asked

"Nothing, it will pass. Just let me be for a moment, please."

"No, you don't look so good. Please tell me." I looked up at all the people
watching and said "Okay, that's enough. Go back to work, nothing to see here.
Give this woman some space." Everybody walked away and I helped Jean up so we
could go somewhere more private.

"Now, tell me. What's wrong?"

"It's just I get so nauseous from time to time. Especially in the mornings."

"In the mornings? Jean, did you do a pregnancy test?"

"No, why should I?"

"I think you might want to take one. I will get one for you, stay here."

After I got one I went over to the register and the girl behind it smiled. I
shrugged my shoulders and said "You never know, right?". When I got back to
Jean she was laying down and I handed her the test. "Don't worry about it, I
paid for it. Now do the god damn test."

After a few minutes Jean came back, she held up the test and said "I guess I
have some news for Mike." I cheered and congratulated her. Jean smiled and
thanked me. "But please keep it to yourself for a while," Jean said, "I really
want to tell Mike before I tell the world. He won't like it if I tell him you
already know. So please --"

"My lips are sealed, as far as I know he was the first one you told."

The next day Mike came to the store with Jean, in his hands he had a big cake
and he shouted as loud as he could "I'm going to be a father!" The store was
still closed and everybody there congratulated them. When it was my turn to
congratulate him he looked at me and said "You already knew, didn't you?"

"I'm so sorry," I said while I hugged him, "it's just she felt so sick and we
did the test here."

"Thank you for taking care of her," Mike said. Then he turned to his wife and
said "Now, you go to Luna if you need anything, okay? And call me at any time
any moment. You are not alone anymore, you have to take care of the baby."

I turned to Jean and said "He's going to be a wonderful father, again
congratulations."

"That's why we came here," Jean said, "Can we talk?"

I took them to my office and closed the door behind us. Jean told me how she
had two miscarriages and that they wanted to see a doctor. "Sure, let me see
who can fill your shift today. Ah, Mariah will do. Wait let me call her?" I
called Mariah and she said she would be there. Just as I wanted to hang up the
phone Jean waved she wanted to talk to her. "Thanks Mariah. I owe you an
explanation. I'm pregnant again and we really want it to work this time. Oh,
thank you so much. Yes, and thanks again for covering my shift."

My heart melted a little. Jean was such a wonderful woman and she deserved the
world. I really wanted her to have this baby. After they left I looked around
the office, tears in my eyes. This whole ordeal had made me want a baby too and
I wasn't getting any younger.

That evening I came home to an empty house again, Josh was still at work and I
made myself a simple salad for dinner. The silence was deafening and the weight
of loneliness weight heavy on my heart. I started to cry for at that moment I
realized I felt lonely whilst being married. I rolled up on the couch and cried
myself to sleep.

It was past midnight when Josh woke me up, he had just gotten home. "Why are
you sleeping on the couch?" he asked. I just looked at him and said "I must
have dozed off, I'm sorry."

The next morning I woke up to hearing Josh stumble around the room. I raised
myself up to see him putting on a suit. "What are you doing?", I asked, "It's
Saturday and we were supposed to go visit your sister today."

"I am so sorry," Josh replied, "it's this case. We need to prepare our briefs
for Monday and we're nowhere close to being finished. I really need to go to
work, please call her and tell her I'm sorry." He gave me a quick kiss and then
asked "Do you know where my blue tie is? I can't seem to find it anywhere." I
pointed out to him where it was and helped him tie it.

"She will be so disappointed," I said, "this is the third time we cancel on
her. No, you know what? You canceled on her, I didn't. I'm still going."

Josh kissed me and said "Tell her I said hi and that I'm sorry." And with that
he was out the door. Almost an hour later I got in my car and started the three
hour drive over to Lindsey's house. On the way over I tried to amuse myself by
listening to the radio, but nothing could take away the empty feeling I had
inside me. A feeling expressed by the empty chair next to me.

When I drove into her town I stopped at the mall to get a nice bouquet of
flowers and arrived at her house almost twenty minutes later. Lindsey was
surprised to see me alone. "Yeah, Josh had to work again and I didn't want to
break another promise. So here I am, please accept these as an apology." I
said.

"You don't have to apologize for anything sister." Lindsey said, "it's that
lame duck of a brother of mine who has to do that. Come on in, come on in. Sit
down you must be tired, let me get you something. Lemonade? Maybe something
stronger?"

"Oh no, it's not even noon yet. A coffee would be fine." I replied.

I sat down in the tastefully decorated living room, it was clear an interior
decorated lived here. "What do you think?" Lindsey asked, "It's the latest
trend. Darius has gotten used to the changes I make, sometimes he doesn't even
know he's home." Lindsey laughed, "maybe I should cool it down, but I love my
work so much. I can't help it."

Lindsey worked for the rich and famous so she could easily afford changing the
whole house a couple of times a year. Besides that she sold her old furniture
on the internet which compensated part of it. Lindsey sat down next to me and
asked "Now tell me, how are you doing?"

"I'm okay --"

"Now, don't you lie to me. Don't you dare lie to me."

It was in these moments Lindsey clearly showed her African American roots. She
was adopted into Josh's family at a very young age and for a long time she
struggled with her identity, being the only black kid in a Caucasian family.
But in college she had embraced her roots, but never felt resentful towards her
adopted family. On the contrary, she was extremely grateful. If she hadn't been
adopted who knows what would have become of her.

Now she was had a very successful career, was married to a very handsome man
and led a good life. "Without my parents I would never have had all of this"
she once said.

"Now girl," she said, "spill it." At that moment her husband came into the room
to welcome me. "Darius, not now. Shoot. Let us girls talk for a minute."

"But I just wanted --"

"Not now!" Lindsey snapped.

"It's okay, Darius. Thank you." I said to him.

Darius waved like he surrendered and disappeared. "Men," Lindsey sighed, "can't
live with the, can't live without them. I do love him though."

I snickered and felt tears well up in my eyes. I remembered the time Josh and I
were like that. I could feel the love the both of them shared.

"Hey there girl, now I really know something's wrong. You can tell me, come on
talk to me."

"It's just -- I don't know. Josh is working all the time and I get to feel so
lonely at times. I wake up in an empty bed and come home to an empty house. If
it wasn't for the mess he makes in bed I wouldn't even know he had been home
sometimes. And now this. He got up early this morning to go to work, he didn't
even tell me last night. I had to find out as he was getting ready and if I
hadn't woken up I guess he would just had left. It's like he has shut me out,
somehow."

"That bastard!" Lindsey snapped, "wait until I get a hold of him."

"No please," I cried, "don't make it worse than it already is. I just needed to
get out of the house for a day. So I said that he broke his promise to you, but
I didn't. So I came alone, I didn't want to disappoint you again."

"I am so happy you are here, Luna. You know I love you like as if you were my
sister. Heck, you _are_ my sister. And I am so sorry you feel this way. Can I
give you a hug?"

I nodded and we hugged. Her embrace felt like a warm blanket and every time I
was amazed by the amount of love Lindsey was able to give. There wasn't a bad
bone in her body and I loved her so much. She was the sister I never had.

"Okay," Lindsey said, "enough of this. Let's have some fun today. Let's go
shopping and spend some of that hard earned money of his." She handed me a
napkin to dry my tears. "Oh, third door on the left is our bathroom. You are
free to use my makeup if you want to."

A few minutes later I walked into the kitchen where Darius was sitting at the
table. He got up and said "Now can I welcome you?" He hugged me and said "You
are always welcome here. I don't know what you girls were talking about and I
don't really care. But I want you to know this is always a home for you."

"Thank you Darius," I said, "but I just did my makeup again and don't want to
ruin it."

"Ruin it all you want," Lindsey said from the kitchen, "he knows I have enough
makeup for an entire year and then some. So you go ahead girl."

Lindsey made us some coffee and a few minutes later we sat down on her back
patio overlooking a beautiful garden. "You must think we're crazy. Me
redecorating all the time and Darius, the architect he is, is always building
something. Now he's set his mind on a shed over there and he wants a pool
somewhere in here."

It felt good being out of the house for a while, being in a different
environment, a different town. "Are you still working at that super market? Not
that there is anything wrong with it, but you always wanted to set up your own
company, didn't you?"

"Yeah, I still work there. I love the people there and it might not be what I
wanted but it's nice there."

"Come on now girl, don't you have a Business degree? Don't you want to do
something with it. You can do so much better. I know it."

"Yeah, but --"

"No buts, no more excuses. Do something. For once do something you want to do.
Choose for yourself. That isn't being selfish, you parked your career for him.
Now it's time you reap the rewards for doing so."

"You may be right, but there just isn't a moment I can talk to Josh. He's
always working. I can't remember the last time we did something fun together."

"That's bad girl, that's not okay."

"I know, but what can I do?"

"Choose you for once."

"You are right of course, but it's so hard."

"I never said it was easy, did I?"

I giggled "No you didn't."

"Good, it's nice to see a smile on that pretty face. You know what? We're going
out for dinner tonight and then we're going dancing. I'll tell Darius we're
having a girls night out and I will not take no for an answer."

She got up and walked into the house. A few minutes later she came back as she
was talking to Josh on the phone. "No, you listen to me brother. Your wife and I
are going to have a girls night out and that's it. She will be home tomorrow
and there's not a thing you can do about it. Yes, I love you too brother. Bye"

"Now that's all arranged. Josh was happy to hear we're going to have a girls
weekend. He said you deserved it and then he said he could come over later
tonight, but I said no." She sat down and continued "Don't worry I didn't tell
him anything else. That's between us."

"What are we going to do?"

"We're going to get us a nice outfit for tonight. I'm thinking nice dresses,
some nice heels, accessories, everything. The day is ours and we'll start at
the spa. Come on, let's go."

An hour later we laid down on the tables, only covered by towels getting our
massages and facials. "Oh this is just the best, isn't it?" Lindsey sighed. I
had to admit it felt good treating myself. After the massages we went into a
steam room and ended up in a Jacuzzi. When we were done there Lindsey drove to
the mall where we went on a shopping spree. I hadn't had this much fun in a
long, long time. We ended up with bags and bags of clothes, shoes and
accessories.

After our spree we sat down at a coffee shop and just chatted about anything
but our daily life. Lindsey was very good company and time flew by. She checked
her watch and said "Oh my, we need to get ready." We got up and in stead of
walking to the car she pulled me into a hair salon.

"Hi Christa, got time for two? We're having a girls night and really need to
get our hair done." Christa checked her book and said "Sure, I can squeeze you
in." She called two girls to help us and an hour later we were done. Lindsey
handed Christa her credit card and we got back in the car.

"You shouldn't have," I said when we drove back home, "but thank you."

"You paid for your own outfit," Lindsey said, "the rest is on me. My gift to
you, don't worry about it."

Once we were home we changed into our new outfits and Darius dog whistled when
we got downstairs again. "Ooh Lord," he said, "If I wasn't married." Lindsey
threw him an ice cold look and then said "Thank you darling. Well, we're going
out. Don't expect us home any time soon. Have fun with your game." We got into
the taxi that was waiting for us.

We had a lovely dinner at a very nice restaurant where the staff treated us
like royalty. "I did the interior here," Lindsey said, "ever since then they
treat us good. You should have seen it before I got my hands in this."

After dinner we ended up at a very popular club in town. There was a long line
to get in which we just passed by. Lindsey walked up to the VIP entrance and
said "Hey Clarence, nice to see you again. How's your wife?" The big tall man
melted a little and said "Oh hey Lindsey, she's okay. Thank you for asking.
She's out of the hospital now and she's doing good. Is she with you?" Lindsey
nodded and he opened the door.

In the small hallway you could hear the low sounds of the bass, you could not
only hear it you could feel it in your stomach. "This club is owned by a friend
of Darius, Michael. You gotta watch out for him, he's a slippery fellow and
renowned for chasing skirts. Whatever you do, don't ever get involved with him.
If you know what I mean." I just held up my hand and pointed to the ring on my
finger. "Ah, he doesn't care about those." Lindsey said.

The lady at the counter said "Good evening, Mrs Porter. Everything on your card
again?"

"For the millionth time, call me Lindsey! And yes, on the card please."

"Just following the rules, Mrs Porter" the girl laughed. Lindsey sighed and
said to me "I always feel like my mother when she does that. Thank you Lauren,
you have a good night now."

I was simply amazed by the fact she knew all of the people's names. I had been
with her for a couple of hours now and I had forgotten half of them by now. But
Lindsey? She just looked at a person and knew their names, their family and
sometimes even their birthday. It was simply amazing.

We walked into the club and the music was loud but not overwhelming. You only
had to raise your voice a little without straining it. "Let's get us something
to drink." We made our way over to the bar and Lindsey waved to the bartender
"Two cosmopolitans please." She handed him a club card which he swiped and
prepared the cocktails.

With our glasses in our hand we sat down at one of the tables. I looked around
and it was just so beautiful everywhere you looked. "Now there, you see those
two doors with the pink lights above it. That's the VIP lounge, we've got
access to it and maybe we can go in there later. But for now let's finish our
drink and dance."

We got on the dance floor and I was amazed by how much louder the music sounded
when you were on it. The beats made you simply move and after a while I lost
myself on the beat. We had a few more drinks and danced the night away. It had
been a few hours when we sat down on a couch and I grabbed the card to get us
something to drink. At the bar while I was waiting for my order I noticed a man
looking at me, I was sure he was checking me out. It felt good to be seen again
and as I walked back to where Lindsey was sitting I decided to wiggle my ass a
bit more. Once I was back I said "I need to use the bathroom, I'll be right
back."

There was a short line and the moment I sat down in a stall I looked at the
ring on my finger. I licked it, pulled it off and put it in my purse. For the
first time in four years I had taken my wedding ring off my finger. I rubbed
the empty space a little, then got up, checked myself in the mirror and went
back to Lindsey. It felt exciting not to wear my ring, as if I was signaling I
was available.

It took Lindsey a while before she noticed "Hey, where's your ring?"

"Oh, I need to get it adjusted and didn't want to loose it. It's in my purse,
just to be safe." I lied, "I lost it the other day at work and it took me
almost three hours to get it back. If it hadn't been for Jean I thing I would
have lost it forever."

"Ah okay," Lindsey said like she didn't quite believe me.

"Okay, you caught me," I replied, "I took it off just to see how it would feel.
There was this guy at the bar checking me out and the moment he saw the ring he
turned away. I just wanted to feel being seen again."

Lindsey laughed and said "That's my girl, but you better not act upon it or you
will have to deal with me. He might be a lame ass brother, but he still is my
brother. You feel me?"

I laughed and said "Yes, I feel you and I don't ever want to get on your bad
side. Let's drink."

We had a fee more drinks and danced for a while longer. As I was moving on the
dance floor another guy got a bit closer to me and I turned around towards him,
he put his arm around me and pulled me in. His leg was in between mine and I
almost touched him. We danced for a short period of time and then I pulled away
from him turning back to Lindsey laughing hard. "That was nice," I said, "a bit
too nice."

Lindsey started laughing and shouted "This is our night girl, as long as you
keep it to dancing it's fine by me."

I spun around and the man was still there. I moved in closer to him and he
embraced me again. This time I moved my hips a bit more until his thigh touched
my crutch. Instead of pulling away I moved my hips a little more forward and
started grinding on his leg to the beat of the music, I pressed my body against
his and laid my head on his shoulder. I felt myself getting wet and moaned
softly as I slid up and down his leg.

Suddenly I realized what I was doing and pushed him away. I took Lindsey by the
hand and said I wanted to go. Lindsey didn't ask for a reason, just looked at
her watch and said okay. In the small hallway we waited for a taxi to arrive
and went home. Never did she ask what had happened.

As I lay in that bed, in that strange house I thought back to that moment on
the dance floor. How it felt to be held by a stranger, grinding my slit on his
leg. Thinking back I felt myself getting wet again and I couldn't help but
masturbate while I fantasized about what could have happened. I buried my face
in the pillow as I came hard to the fantasy.

After I woke up in the morning I had a nice shower and a lovely breakfast on
the patio in the backyard. It was around 11 when I got back in my car to go
home. I thanked Lindsey for a wonderful night and kissed Darius on his cheek.
"Just for being who you are." I said.

The backseat was filled with the bags I had taken with me and the bags filled
with the clothes we bought the day before. While I was driving my thoughts went
back to the dance floor and it was at that moment I decided to become a member
of _Silvia's List_. Halfway home I stopped at a small diner where I realized I
still didn't wear my ring. I grabbed my purse and put it back on.

After another hour and a half I arrived home and was happy to see Josh's car in
the driveway. I put my bags on the kitchen table and shouted I was home. Josh
came out of his office to greet me and said how much he had missed me. We sat
down at the table and I told him all about last night, everything but what had
happened on that dance floor.

He was happy to hear I had had such a good time. "Yes," I said, "and we made
plans to do it again." He smiled and said "Good on you. Now, I am so sorry, but
I need to get that brief done. It's almost ready. It's nice you're back." And
with those words the deafening silence I had felt before came back with a
vengeance. Somehow I had hoped this weekend would have changed something, but
clearly it hadn't. There was a time he wanted to see what I had bought, this
just felt like a cold shower.

I got up and did the laundry, put away my new clothes and stuff, sat down on
the bed thinking everything was still the same. At that moment, after that
night, it felt more like I was being smothered then ever before.

It was almost dark when Josh came out of his office to grab a bite to eat and
in he want again. It was like I was his secretary when he asked if I could
bring him a coffee later. At that moment I had had enough, I stormed into his
office and said "No, I will not bring you a coffee. I am not your secretary, I
am your wife, for gods sake! It's time you start treating me like that again."

I rushed of and jumped on our bed crying my heart out. Josh came in a few
minutes later and sat down on the bed. "What's wrong?" he said.

I rose op and shouted "What's wrong? This weekend was supposed to be for us.
Us, doing something together. But all you do is work. You never pay attention
to me anymore and I've had enough. I can't take it anymore. I wake up in an
empty bed and get home to an empty house. I clean, do the laundry and you just
take it for granted. When was the last time you thanked me? When was the last
time we did anything as a couple? Lindsey was right. I need to choose me for a
change. I want to start my own business, like I dreamed of ever since I was a
little girl. But you smothered that dream, I put myself in second place so you
could get your degree. Now it's time I get to do what I want to do."

I turned my back to him and when he touched me I shivered. He pulled away and
whispered "I am so sorry you feel this way. I never meant to hurt you, I really
thought you were happy. But I need to get this done. If we succeed I could make
partner and then I would have more time."

"That's what you said when you started working there. But it never got any
better, it only got worse."

"What do you want me to do, quit?"

"No, I don't want you to quit. You love what you do. I just want you to make
some time for me too. To see me again, to be my husband again. I love you so
much I want to give you everything you want, but I need to choose me this time.
I need to do something that excites me again."

"I thought you loved working at the store?"

"I do, but it isn't my dream. You are living your dream. You've become that
lawyer at a big firm. Now I want to reach for my dreams, to reach for my
stars."

"I understand," Josh said, "so why don't you? What's holding you back?"

I was dumbfounded by that question, but he was right. There wasn't anything
holding me back but me. I turned to him and said "Do you mean that?"

"Yes," he said, "I am so sorry I made you feel this way. And for what's it's
worth I am grateful. I am so grateful you made it possible for me to chase my
dreams. Now I want you to reach for your dreams too. I will support you in any
way I can."

I moved closer to him and hugged him, "Thank you." I whispered.

"You're welcome," he said, "I love you so much Luna. Don't ever think I don't."

We hugged for a while longer before he got up to go back to work. Relieve I had
finally told him how I felt I was at peace with him going back into his office.
Ten minutes later I did bring him that coffee and he thanked me for it with a
kiss. "You're not my secretary," he said, "my secretary is almost 80 years old
and she isn't half as pretty as you are."

Although I had finally told him in the days and weeks after nothing really
changed, one high profile case followed another. The only thing was I spent
time on writing down ideas for a business. Soon enough I had so many
possibilities I didn't which one to pick. At that moment I decided to spend
some time downtown to see if there was anything I was missing, something that
might spark something inside me. I had set my mind on opening a store or to
offer some kind of service. I wanted to work with people. I knew for sure I
didn't want to end up in an office like Josh did.

I informed by boss that I wanted to cut down in hours and he offered me a
part-time position as middle management. In that function I would manage the
people in my old position, which basically meant I would have fewer people
under me. But I accepted the offer gladly because it also meant I didn't have
to work the late shifts anymore or the weekends.

It was on one of my days off when I saw it was beautiful weather outside. I got
in my car and went downtown. I walked the streets for a while, had a coffee and
tried to find something I was missing. But nothing came to mind and I went back
home. Disappointed I fell down on the couch and felt a bit beaten. "I will
never get a good idea," I thought. I got up, changed into something comfortable
and sat down in the backyard with my laptop.

Without thinking I opened up _Silvia's List_, created an alternate e-mail
address and registered an account. After I logged in for the first time I had
to fill in a questionnaire, like you had to do on any dating-site. I filled it
in and clicked the _Send_ button. A new page opened up asking me to upload a
photo. "Oh wow," I thought. I got up, did my hair a little, applied a little
makeup and took a couple of selfies with my phone. But they felt a little to
modest to me.

I went into my closet and got a tight shirt, pulled it down to show my cleavage
and took another selfie. This one was perfect I thought and uploaded it to my
laptop. I worked the colors a little in Photoshop before I uploaded it to the
site. The page refreshed again and now it said _Our staff will moderate your
request shortly, we will get back to you with 24 hours. Please be patient._

I had done it, I had become a member of a dating site and I felt excited about
it. Now there wasn't anything I could do but wait. As I sat there I thought
"Why don't I wear this shirt anymore?" and adjusted the straps of my bra a
little. I went upstairs and checked myself in the mirror. I looked nice I
thought and opened my wardrobe again. A few minutes alter I checked myself in
the mirror again. I wore that tight shirt, a short skirt and some nice heels. I
grabbed a jacket from it's hook and decide I wanted to go downtown again. This
time I just wanted to go shopping or something.

Just before I left Josh texted me that he was going to be late again. I looked
at my phone and just replied "Okay". I put my phone in my purse, looked at my
finger and took of my ring again. This time I placed it on my vanity and I
walked out the door after checking my make up one last time.

It felt good being downtown again, being out of the house. I went window
shopping and got myself another coffee. I entered the mall to use the bathrooms
and as I sat there in the stall I decided to do something wild. I took off my
jacket and unclasped my bra underneath my shirt. I pulled the straps down and
got it out from under my shirt. After I put it in my purse I adjusted my shirt
and put the jacket back on. Just as I was about to pull up my panties I decided
against it and they also went into my purse.

My heart was racing as I stepped into the crowded mall, knowing I wasn't
wearing any underwear I started walking. My breasts were moving with every step
I took and I could feel the dampness between my legs. I went from store to
store and in one of them I bought myself I nice short dress. In the shoe store
I tried on a pair of high heels and as I set there putting them on I was sure
the man across from me could see I wasn't wearing panties. I loved how they
looked and the were rather comfortable. I walked over to the counter and said
"I would like to keep them on if you don't mind." The girl smiled and said it
wasn't a problem.

In my new heels I stepped into the mall again. The while situation really was
exciting for me and on my way out I stopped at one more store to buy myself a
nice set of see through lingerie. Back home I undressed and put on the
lingerie, I placed my phone on a chair at the end of the bed and set the self
timer of the camera app. I sat on my knees on the bed and stared sensually into
the lens of the camera. I unclasped my bra and held it up with my hands before
on the next photo I took it off. I held my breasts up with my hands and with
every shot I got more excited.

Finally I laid on my back, spread my legs and held the fabric to the side with
my finger, with two fingers of my other hand I spread my lips revealing the
pink inside. I leaned forward and stopped the app, before I continued
pleasuring myself. "Oh yes, fuck me," I moaned, "I won't tell my husband if you
don't tell your wife. Take me, make me your slut." I moaned a little harder as
I slid two fingers inside my wet pussy, rubbing my clit with the palm of my
hand. "Oh yes, fuck me in my marital bed. He will never know how hard you fuck
me or how much I come on that dick of yours. You can come any day, any time."

Almost two hours later I sat down at the kitchen table wearing my sweats. I had
cleaned up everything and made the bed again. My new outfits I had put away in
the one drawer I knew Josh would never look, my underwear drawer. I checked my
new e-mail address if I had received an answer form the site and to my
amazement they had accepted my application. I logged in and was greeted by my
new profile. _Welcome to Silvia's List, your account isn't fully active yet and
therefore still hidden from the site. Please check if there is anything you
want to change and then click Publish to make your account visible to other
users._ it read.

I checked if everything was okay and with a beating heart I clicked _Publish_.
The site opened for real this time and there was so much to do. I clicked on
my profile again and I was happy to see they hadn't used my photo anywhere. As
they had said it was just for identification purposes. My avatar was of a
little girl holding up a large flower and I kept it that way, at least for the
time being. 

I could upload photos to _My Photo Album_, see the messages I had received and
lots more. Within seconds I received notice of a chat and I clicked on it.

"Hey gorgeous, want to video chat?"

That one quickly followed by a few more and I declined them all. It all went a
bit to quick for me, so I set my status to _do not disturb_ and I continued
browsing the site. I spent a few hours looking around before I posted my first
entry on my timeline.

"Hi, MysteriousKitten here. Don't blame me for that name, it was suggested when
I registered and I thought it was funny. I'm not really sure what made me
register, but here I am. I'm also not so sure how active I will become, so
don't get mad if I'm not around that often. This is all new to me and I really
need to find out if this is really what I want to do. Well, that's it for now.
Bye"

I logged off and closed the browser. I created a storage account at one of the
cloud services and uploaded the photos from my phone. Afterwards I deleted them
from my phone and leaned backwards against the chair. I couldn't believe I
actually had done it and much less how good it made me feel. I started to
giggle when I thought back at me walking down the mall without any underwear
and I wanted to do it again. But not today, it was time to put everything away
and return to my normal life.

It was Saturday and Josh was in his office working. I sat down on the patio in
the sun with my laptop and after checking if he was near I opened the site and
logged in. I had received a couple of messages, mostly of men complementing me
or asking me if they could meet me somewhere. I deleted them all without
answering and saw that my post had gotten quite some _karma points_. I clicked
on my profile and read that karma points indicated how popular you were on the
site. Karma points could be given or taken away and if you reached a certain
level your status on the site would be elevated. The highest level possible was
_Silvia's Favorites_. The list of people with that status contained just five
accounts, one of them was of Silvia herself. If she even actually existed.

I went back to my time line and started typing.

"Just another day at home. Hubby locked in his office working. It makes me feel
so lonely sometimes. I know he's mere feet away from me, but the closed door
makes it feel a thousand miles. If I've seen him for three hours this week I'm
overestimating. And I can't believe I'm actually telling you about this, about
how I feel. You are just strangers to me, but I really need to get it off my
chest. Hope you don't mind. Bye"

My hands were shaking a little when I clicked on _Post it_ and I waited for the
page to refresh. Before I knew it I started another post.

"Me again, I am so sorry but I really need to tell someone. I really do love my
husband and I would die for him if need to, but I have my needs too. I can't
believe I am doing this. I would never have thought I would be wanting to cheat
on him. But I do. Let's just do it online first, like in chat. Maybe then
progress to video and who knows where it will end. But I have to take this
slow, I have to be sure I want to do this. I feel guilty enough for posting
this here. Anyways, thanks for reading. Bye"

Within seconds both posts got karma points and someone replied to the last one.

"Hey Kitten, I just wanted to say to take your time. Do this on your own terms.
I love my husband more than he will ever know, but I'm sure he will divorce me
if he finds out. I went all the way in the first week and now I wished I had
taken it slower. It took me quite some time to get over the guilt I felt, but
I'm still here and I'm loving it. So take it slow, grow into it and if you need
to you can always come to me for answers. LovelyLillith."

Right after that post I received a friends request from her and I checked her
profile. She had uploaded some photos of her, some even of her with other men
and I accepted her request.

I downloaded the photo of myself in lingerie from the cloud, opened it up in
Photoshop and placed a black bar over my eyes. I shrunk it down to an
acceptable size and uploaded it to use as my avatar. When the page refreshed
there was an automatic post stating I had used this photo as my avatar. I was
startled a bit and checked if Josh was around to see it, then I giggled softly
and posted.

"I've taken the first step I guess. Hope you like what you see. My husband
doesn't even know I have those. You don't know how exciting this is to me. I'm
sitting in the backyard and as soon as he walks out he can see what I'm doing.
My heart is racing right now and I'm loving it. If you want I can upload more
photos, but I will protect my identity. Hope you don't mind. Bye"

I started browsing the site and opened the forums. There were all kinds of
posts and most of the were tips and tricks on how to hide it from your spouse.
I read most of them and then opened the thread were people shared stories about
their experiences. I was amazed by how open they were talking about cheating on
their partners. There were also quite some posts where they shared they were
getting a divorce after the significant other had found out. But they all had
one thing in common: if the relationship had been so good, they wouldn't have
had to cheat.

I spent more time on the site than I would have predicted and after almost four
hours I logged off and closed the site. I had posted some more and even reacted
to some threads on their forum. My photo had gotten quite some karma points,
all in all spending time on there had made me feel good about myself.

That evening was one of the few Josh and I spent together watching a movie on
Netflix. I laid in his arms but my thoughts weren't on the movie at all, they
were at the site and I wanted to know if I had gotten any new responses. A few
hours later we went to bed and to sleep. Even though he was laying next to me I
still felt lonely.

During the next week I went shopping again. This time I wore that short new
dress I had bought earlier with the high heels. I had left my ring at home as
well as my underwear. Parading like this through the mall felt really exciting
and I noticed some men looking at me. The only thing was I was so scared of
meeting someone I knew, I really didn't want anyone I knew seeing me like this.
When I sat down for a coffee I checked on my phone how far the next big city
was, almost a four hour drive. Way too far, I couldn't possibly do that in a
day.

That evening Josh told me he had to go out of town for a week, he would leave
the following day. And although I should have been disappointed I felt excited
somehow. "That's okay honey," I said, "I will be gone for a day or two too. I'm
meeting a woman who has an idea for a shop and I'm meeting her in Portland. I
thought I might book a room for the night."

"That's wonderful. What's her name?"

"Lilith, Lilith Baker. She owns a lingerie store and she wants to open one up
here."

"How did you meet her?"

"Online, one of those sites you can get information on how to start your own
business. I went there for some legal documentation."

"Oh, you could have asked me."

"I could have, but you're a criminal lawyer. This is civil."

"Ah, glad to hear something rubbed off. Well, have fun. And it's good to see
you found something you like to do. I can see it in your face, your glowing a
little."

This was the first time I ever lied to him and as soon as he went upstairs to
pack his suitcase I felt guilty, but not enough to come clean about it. After
dinner Josh went to bed early as his flight would be at 5. I sat down at the
kitchen table and opened my laptop.

"I can't believe what I just did. For the first time I lied to my husband. He
told me he had to go out of town for business for a week and I told him I would
go somewhere to meet with a friend. I just want to leave town for a bit and be
on my own, in a town where nobody knows who I am. I should feel more guilty
than I do, but that's just the way it is. I will post some more when I get
where I'm going. Bye"

I decided to upload another photo of myself, this time the one where I am
holding up my loose bra with my hands. This time I made the bar over my eyes a
little smaller too. As soon as the page refreshed it read _MysteriousKitten has
uploaded another photo._. I giggled when I saw it up there and logged off.

The next morning Josh got up at half past three and went out the door at 4:15.
He had kissed me softly on my cheek as to not wake me up. I pretended to still
be asleep and moaned softly as he kissed me. "I love you," he whispered before
he left.

An hour or two later I got ready for work and asked my boss if I could take the
next two days off. "Oh sure," he said, "you've not taken any days off since you
started working here. As a matter of fact I guess we'll be okay for today too,
so go and do something fun. I wish I could." I loved my boss so much, he was an
elderly man but he had such a kind heart. He had started this market as a small
store downtown and slowly grown it to what it is now, a small chain of three
super markets.

Excited I got back in my car, sat down at my laptop, booked a room for two
nights, packed my bags and went on my way to Portland. The hotel I booked was
in downtown Portland and it was just beautiful there. There was an underground
parking lot and I told the man in the booth I had booked a room. He checked the
computer and let me in.

In the lobby a checked in and got the key card to my room. It was on the
seventh floor and the view was breathtaking. It wasn't the largest of rooms,
but it would do for the time I was there. I took a quick shower, put on my
tight short dress with the black jacket I had brought. Did my hair and makeup a
little and started exploring Portland. There were quite some stores and
boutiques near the hotel and I found I nice restaurant where I could eat. Just
being there, walking through the streets of Portland made me feel so free.

One of the boutiques I came across was called _Portland's Rose_. There were
some nice clothes in the window and I went inside. This wasn't your ordinary
boutique, the clothes they sold were way more sexy and provocative. The girl
behind the counter got up and said "Hi, I'm Laura. How can I help?"

"Oh I'm just browsing. I'm new in town, came here for a meeting tomorrow and
thought I might explore a little." I said.

"Oh nice, well I could give you some tips on where to go."

"That would be lovely." My eyes fell on a dress that was rather translucent and
I said "What would one wear under that?"

"Oh," Laura said, "anything you want, but it's really nice with some black
lingerie. Or if you're really feisty, nothing at all." She giggled a little and
I could help but laugh too.

I checked the price. 60 dollars it said. "Oh, that's wrong. It's the last one
and we're getting rid of this collection this week. So everything is half
price. I just have to place the signs still, but we just opened." I checked the
time and it was almost one in the afternoon. "We're open all night and my
colleague called in sick this morning." she almost apologized.

I thanked her for her information and browsed some more. I found a glorious
jacket and thought it might look great with that dress. I tried on the jacket
and it that it looked good. "That one looks really nice on you," Laura said
from behind the counter where she was working on the signs. On my way to the
checkout I grabbed on of those translucent dresses, luckily they were
one-size-fits-all and paid for the two items. "That will be 45 dollars please,"
Laura said, "and if you have the time. Please come back, as I said everything
is half price this week."

Laura had given me directions to a nice place to get some coffee and she wasn't
wrong, I sat down at a table outside overlooking the square with a large
fountain. I placed my order and took a nice photo of the fountain. On the site
they had announced their new app and I had installed it on my phone. It didn't
give you much possibilities besides updating your timeline, uploading photos or
responding to messages, but it was fine nonetheless.

"Well, here I am. I really did it. I'm in this town where nobody knows me and I
left my ring in the hotel. As far as anyone knows here I'm not married. Now I
am sitting in the sun, enjoying a latte. I can't believe how much fun I'm
having without my husband. How much I'm enjoying this. I still love him so much
and I couldn't live without him, but this is what I needed for so long. Well,
my latte is getting cold, but I will send an update soon. Bye"

I put down my phone and sipped from my latte. A woman came up to me and said
"Would you mind if I joined you? It's rather busy and there's no more places
available outside." I said I didn't mind and she sat down.

"Hi, I'm Luna," I said, "I think it's appropriate to introduce myself."

"That's so nice, I'm Sarah. Nice to meet you."

We chatted for a while and when I asked if we could take a selfie she happily
obliged. "Thank you so much," I said, "people wouldn't believe me otherwise.
I'm rather reserved normally."

When I finished my latte I wished her a good day and tried to find my way back
to the hotel. I took one wrong turn and after asking for directions I walked
through a nice park. At the end I turned left when I saw another shop that
spiked my interest: a lingerie store. I went inside and browsed the store for a
bit. My eyes fell on a bag with ten black nipple stickers, grabbed one and it
said it was for all sizes. I also got myself I nice pair of black panties. As I
was browsing the store I noticed there was a thick curtain in the back, above
it was a sign stating _Adults only_.

My curiosity was peaked and I went inside. There were masks, pads, whips,
corsets and everything you needed if you were into BDSM. I slowly walked
through the isles until I came to a rack full of dildos in all sizes. With my
heart racing a looked at a few and decided to buy two of them, one normal sized
and one really big. On my way to the checkout my eyes fell on a box with
stainless nipple clamps which also had a restraining bar. I stared at it for a
while and then just grabbed it.

At the checkout I handed the man my personal credit card, both Josh and I had a
personal account as well as a shared one. We paid for everything from the
shared account and gave ourselves a monthly allowance to spend in any way we
wanted to. Because I hadn't used it for years there was quite the balance on
mine.

Back at the hotel I sat down on the small balcony overlooking Portland. I took
a short shower, put on a nice dress and made my way over to the restaurant I
had seen earlier that day. I had a lovely dinner and when I got back in my room
I unpacked my new toys and laid down on the bed. I read the instructions that
came with the clamps and put the device together. I then placed the foot
between my breasts and clamped my nipples. A shot of pain went through my body
as I let go of the clamps. I had to take a few breaths until the pain subsided
a little. I slowly moved the bar up until both my breasts started to stretch a
little. I fastened the bar, laid down and started masturbating.

The moment I was wet enough I took hold of the smallest dildo and pushed it
inside me. The combination of pain and pleasure was so good I almost came
immediately. I moved the bar up a little more, sending shocks of pain through
my body again. I got on my knees and placed the big dildo underneath me, slowly
I went down and the silicone dick stretched me to the max, sending another
series of pain through my body. I kept on going down until I felt the fake
balls against my ass. It was inside me so deep. I gave myself some time before
I slowly started to bounce. The restrainer held my nipples tight and every time
I bounced I felt shard of pain in combination with the utter pleasure of having
that big fake dick inside me. I started bouncing faster and harder, the harder
I bounced the more pain I felt. Without warning everything went black and I had
the biggest orgasm I had ever felt in my life.

I fell down on the bed, the clamps sent another shot of pain through my body. I
took them off, which gave me another shot of pain. I massaged my nipples a
little as I recovered from my orgasm. When it all subsided I started to giggle
uncontrollably and within minutes I did it again. This time I extended the
restrainer to it's max and bounced as hard as I could. "Oh yes, fuck me" I
panted, "fuck me, come inside me. I want you to fill me up, like my husband
can't. Oh my lord, you are so big. Yes, yes, I want you in my ass. Put it in my
ass, please."

I rose up and the dildo slid out of me. I placed the tip against my ass hole
and slowly went down. The pain was excruciating but I pushed on, until
suddenly without warning slipped inside my ass. I want down as deep as it would
go. The pain was relentless, but I started to bounce nonetheless. I stopped for
a moment and reached for the other one and pushed it inside my pussy. Then I
started bouncing again. "Oh yes, the both of you. Fuck me hard. Come inside my
pussy and my ass. Fill me up." I panted, "I want you both to fuck me, to treat
me as the whore I am."

Without warning another orgasm rolled through my body and I could feel my pussy
and my ass constrict around the silicone penises inside me. My nipples were
glowing from the pain as I fell down on the bed once more. The toys slipped out
of me, but I was to tired to remove the clamps. When I was clear enough I just
removed the restrained but kept the clamps on my nipples. I laid down on my
back, fully enjoying the shots of pain the clamps send through me whenever I
moved. After about 15 minutes I did remove them and massaged my nipples to ease
the pain. Fully satisfied I crawled under the sheets and fell asleep.

The next morning my nipples were still sore and before I went into the shower I
put everything in my bag. As I showered I massaged my nipples some more and
giggled thinking back to the night before. I knew I wanted to do it again, but
at a later time. I got out of the shower with my wet hair in a towel and
another around my body when there was a knock on the door. "Room service."

"Come in" I shouted and a young Filipino woman walked in. "Oh, you can leave
towels on cart when you're ready." she said and started to change the bed. She
cleaned the furniture and when she was done I thanked her and gave her a 10
dollar tip. I got back in the bathroom blow dried my hair and did my makeup. I
checked my back on what I wanted to wear and then got the urge to take a risk.

I got back in the bathroom and opened the bag with nipple stickers. I placed
them correctly to cover my areolae, put on the new pair of panties and put on
the translucent dress together with the jacket I had bought. I placed my phone
on the table and posed for a photo. In a simple editor on my phone I cut it so
only the lower part of my face was visible. After uploading it to the site I
added the caption "What do you think of my new outfit?" and posted it.

Feeling my heart in my throat I walked out the door of my room and it was even
louder when I actually stepped outside. It was quite busy for the time of day
and I knew people were looking, but that's exactly what I wanted. It took me
almost half an hour to not care anymore and I just walked. I went into stores,
sat down at a cafe for a latte and just acted as if it was just another day.

On my way back to the hotel I went into that lingerie store again, this time I
bought an even bigger dildo, some cuffs and pad locks, another pair of nipple
clamps these were connected with a chain and a box of sterile needles. I also
grabbed a ball gag.

Back in my room I locked the door after placing the _Do not disturb_ sign
outside. I undressed and sat down at the table. I opened up the box of needles
and took a deep breath. I placed one on my nipple, held my breath and pushed it
all the way through. I bit my tongue to deal with the pain. But I repeated it
until all the needles were in my nipples, ten in each one. I started walking
around and every step was painful. I did some jumping jacks until I couldn't
take the pain anymore.

I unboxed my new friend, placed it on a chair and slowly guided it in my pussy,
I felt myself stretch even more and once it was inside of me I started to
bounce. The silicone dick was heavy enough to slide right out and I went down
again. Faster and faster, the needles sent shards of pain whilst the giant fake
dick sent pleasures. I resisted to come, I didn't want to come. I got up and in
the bathroom I removed the needles carefully. The all left small drops of blood
behind and I massaged them when they were all out. I grabbed the needles and
put them back in the box. I would throw them away on my way back home, I
thought.

I proceed to unpack the cuffs and padlocks. The later ones I opened and I
placed the keys on the nightstand next to the bed. I got the ball gag and put
it in my mouth strapping it tight at the back of my head. I put the cuffs on my
wrists and ankles. Locked my feet together with the locks, I clamped my nipples
with the new clamps. I laid down on the bed, my feet were locked and my hands
were locked behind my back. As a precaution I hadn't tightened the cuffs on my
wrists that tightly so I could slip out of them if I wanted to.

After a while I got the keys from the bedside table and unlocked my wrists.
Next time I wanted to feel really restricted but I wanted to do it at home,
where it felt a bit mode safe. I put everything away and called down to say I
would spend another night.

A few hours later I walked into the club Laura had recommended, sat down at the
bar and ordered something to drink. When I heard a nice song I stepped on the
dance floor and just let myself go. I was wearing that tight short dress
together with the high heels. I could feel my boobs sway and soon enough there
were a few men paying interest to me. One of them came up to me and started to
dance with me. I moved in a little closer until is leg was in between mine, he
put his arm around me and we moved to the music. I looked up in his eyes and
before I knew it we kissed.

I pressed my damp cunt against his leg and started grinding, I wanted him. He
took my hand and we ended up in a darker spot of the club. We kissed some more
and I placed my hand on his crutch. After those fake ones I needed a real cock.
I just couldn't stop. Carefully I took his lid out, lifted my leg and granted
him access to me. I couldn't believe what I was doing, I was actually cheating
on my husband in a nightclub. I felt his cock against my pussy and without
warning he slipped inside me. "Oh yes," I whispered in his ear, "fuck me." He
started pumping and I moaned in his ear. "Oh my god yes, fuck me." He lifted my
leg a bit more and went in deeper. "Oh yes, yes, yes" I moaned with every
thrust, "Keep going, I'm almost there. I'm gonna come all over your cock. I
want you to come too. Fill me up, come inside me." I moaned. With just a few
more thrusts he exploded inside me and I came too. "Oh yes, that's what I
wanted, that's what I needed. Give me that cum."

When he was done he straightened his clothes, thanked me and walked off. I did
the same and quickly went into the bathroom where I removed my panties, cleaned
up a little and looked at myself in the mirror. I couldn't believe what I just
had done. "You little slut" I said to myself, but what's done that's done and
there was nothing I could do to change it. I got back on the dance floor this
time without my panties on and I danced for a while until another man came
close to me, put his arm around me and we ended up in that same dark spot
again. His cock was even bigger and he fucked me hard. "Oh yes, you are so big,
you stretch me out." I whispered in his ear. "I want you to come inside me,
fill me up with your cum. Take me for the whore I am. Tell your friends I want
to be fucked by all of them." With those words he came inside me and I came
again.

I fucked about ten men that night before I returned back in my hotel room. But
I didn't return alone I had brought four guys with me. We all got undressed and
I started to suck on one cock while another one fucked me. After a few minutes
I got on top of one and guided another one in my ass. Feeling both men inside
me made me come instantly and I took a third one in my mouth. The all came
inside my pussy as I instructed them to and after about five hours they left me
laying in that bed, totally wasted, my ass and pussy throbbing from the beating
they got.

The next morning I cleaned myself up, got dressed, gathered all my belongings
and checked out of the hotel. I felt so satisfied and happy with what had
happened in Portland. Half way I made a short stop and checked if anyone could
see me. I got the clamps out of the bag and placed them on my nipples. I
started driving again, fully enjoying the shards of pain coming from my
breasts.

I came home to an empty house as it would be another couple of days before Josh
would come home. After clearing away my luggage and starting my laundry I sat
down at the computer and ordered some more bondage kit online. They would
arrive the next day and I felt a little relieved with it. I really wanted to
give myself a day off. But I was only home for an hour or so when I went
upstairs, got undressed and put the cuffs on my wrists and ankles. I placed the
ball gag in my mouth and pulled in tight. I clamped my nipples again and spent
the rest of the day like that. I cleaned the house, did the laundry and sat
down in a slave pose in the corner.

That night I placed the keys on the night stand, locked my ankles together and
my wrists behind my back. This time the cuffs were on tight and I couldn't slip
out of them. I fell asleep like that.

The first light of the sun woke me up and my jaw hurt from the gag. I 
maneuvered myself to get the keys and unlocked my wrists and ankles. My nipples
were throbbing by now and I screamed as I removed them. It was so painful I
started to cry a little. After it all subsided I went into the bathroom, placed
the stickers on my breasts and put on the see-through dress. As last I removed
the gag and massaged my jaws until the pain went away. I brushed my teeth, did
my hair and makeup. Just as I was ready the doorbell rang, I looked out the
window and it was DHL with the order I had placed.

With my heart throbbing I went downstairs and opened the door fully aware of
what I was wearing. I needed to pay the man and I asked him in for a moment so
I could get my purse. As I handed him the money I leaned in a bit and he
responded. I placed my hand on his cock and unzipped his fly. I turned my back
on him, lifted my hips and pulled up my dress. He got out his cock and as he
placed it against my pussy I spread my legs a little. He slid inside me and
started to fuck me. "Oh yes," I panted, "fuck me. Fuck me hard. I want you to
come inside me. Come inside my pussy." With those words he exploded and I came
too. He pulled out and I pulled down my dress, thanked him and opened the door.

Back in the house I picked up the package and went into our bedroom. I placed
everything on the bed and when all was laid out I placed all the keys on the
nightstand. I sat down on the bed and got the straps for my thighs. I pulled
them tight and locked them with the small pad locks that came with them. I
proceeded by closing my legs and locking the large rings with another lock. I
did the same with my ankles. I put on the leather mask and bound it tight with
the straps on the back. I then put the gag in my mouth and clicked them on the
mask. I checked where the other restraints were before I placed the blindfold
where it belonged. In the dark I wrestled to get the upper arm restraints where
they should go and pulled them tight behind my back. I had to feel around for a
while but did manage to get the metal cuffs and locked my wrists. I could move
at all, I was blinded, gagged and got really, really wet. I could feel the mix
of fluids coming out of me.

I don't know how long I was laying there, I must have fallen asleep and because
of the mask I had no idea what time it was. I suppressed a feeling of panic and
just accepted the way it was. I managed to get the keys and open the cuffs on
my wrists. After a struggle my upper arms were released to and I removed the
gag and blindfold. I kept wearing the mask, but did release my legs. With the
mask on and my nipples still clamped I went downstairs again to get myself
something to drink.

The clock on the microwave informed me it was 1AM and it was still a day or two
before Josh would come home. I removed the mask and massaged my face as it felt
the fresh air. After removing the clamps I massaged my nipples and walked
around the house. As I walked through the house I felt the desire for some
excitement. After putting on the translucent dress and my high heels, I did my
make up and got into the car. I drove out of town and stopped at a parking lot
for truckers. I parked my car and just sat there. When one of the truckers saw
me I waved and he walked up to me. "Can I help you ma'am?" he said and his eyes
went wide when he saw what I was wearing. I rolled down my window and spread my
legs a little.

I started rubbing my boobs while he was watching, then he got out his cock and
I sucked him. I opened the door and slid to the side of my chair, opened my
legs and he slid inside of my. He fucked me hard and when he was about to come
I locked my legs and hissed "No, don't pull out. Come inside me, I want you to
come inside me."
