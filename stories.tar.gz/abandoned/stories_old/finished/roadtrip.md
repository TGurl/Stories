# Roadtrip
_a tale by TransGirl_

## Disclaimer
This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as posible, forgive me any (scientific) mistakes or freedoms taken.

## Chapter 1
When we were 16 my best friend June and I had seen a movie about two women who
went on a road-trip. We were determined to do the same after high-school. It
took us almost a year to convince our parents to let us go and reluctantly they
agreed as we would be 18 then and they couldn't stop us even if they wanted to.
They warned us about all the dangers we could encounter and June's dad taught us
how to use a gun. "Just for protection" he said. As June was the oldest her
father bough her a gun and registered it in her name.

Right after graduation we prepared to go, bought all the things we needed and
were ready to leave. My parents handed me a credit card and told me to call them
as often as I could and on a sunny Saturday morning we took off. I waved to my
parents as long as I could. We weren't even out off town or I received the first
text message from my mom: _Everything Okay? Miss you already._ she ended the
message with a winky-face and I just smiled. I should never had told her how to
text, I thought.

I turned on the radio and pumped up the volume when one of our favorite songs
came on. Both of us sang along as loud as we could. Two girls, right out of high
school were driving towards freedom. We stopped to get some cold drinks and I
took over driving. We had chosen a random spot on the map and it was still a few
hours until we got there. "You know what would be fun?" June asked.

"No, what?"

"What if we tried to earn some money along the way. So we don't have to our
parents money. And we only use the cards when absolutely necessary."

"But my dad said to use the card so he always knows where I am."

"Just text it to him. Or you know what? I've brought my laptop, we could start a
blog about our adventures. You know, like "Two girls, a car and the road" or
something like that. We could post pictures too."

"That's not a bad idea, we could do that anyways."

"Nice. Yes, that's what we're going to do."

She started to sing along the song on the radio again and opened the passenger
side window. The wind blew through her hair and she smiled as she looked at me.
A few hours later we stopped at a diner and June created a free blog. We took a
selfie and posted our first post. We both posted the address to our parents and
within minutes both our mothers had left replies how much they loved and missed
us.

It almost was dark when we reached our first goal, a small town called
_Newington_. It wasn't much but at least there was a small hotel where we could
stay the night. We took some photos of the room and posted them on our blog.
After a shower, we got in bed and cheered to our first night away from home. We
had done it, we officially had started our road trip.

The next morning after we had showered and sat in the small restaurant eating
breakfast I called my parents to tell them we were okay. "Oh Laura," my mother
said, "I miss you so much, you know you can come home any time, right?"

"Yes mom," I replied, "but I really want to do this. I would have been gone to
college otherwise. Still the same thing."

"No it isn't Laura, it's not the same thing. You are just two girls out there,
if you were at college I could have had some sense of safety. Not there's
nothing and I can't protect you anymore. Call it what you will, a protective
mother or something else, but I will not stop worrying about you. I never will."

"I know mom, but we'll be alright, I promise."

After the phone call June and I decided to head north just to see what's out
there. As it got later it got hotter in the car. "We should have bought a
convertible," Julie said as she rolled her window down, "my God it's getting hot
in here. She unbuttoned her blouse a bit and from the corner of my eye I could
see she wasn't wearing a bra.

We stopped a few hours later, we were in the middle of nowhere and there wasn't
a town in sight. According to the map on our phones it was at least another
three hours before we would hit the next town. The water in our bottles was
lukewarm but at least we had some. "Come take a picture of me. The landscape is
beautiful." June shouted. I got the camera and June posed as though see
presented the mountain range behind her. She took a few other posses when
suddenly she ripped her shirt open revealing her breasts. I hesitated for a
second but still took the shot.

"Now you." she laughed and took the camera out of my hand. "No June, I can't" I
protested but June had already started taking pictures. "Come on, lift up your
shirt. Flash me." she yelled. 'I really shouldn't be doing this' I thought but
still I lifted my shirt and heard June say "Ah, you're wearing a bra."

"Of course I am." I replied

"Take it of, set yourself free. Your mom isn't here and you're 18 now. You can
do whatever you want."

"Come on June, let's just go. It's just too hot and I really could use a shower
right now. Please. Can we just go?"

"You need to lighten up, Laura. You really do. Look, you're my best friend and I
love you. But when was the last time you had fun, real fun I mean. You know
alcohol, drugs or" she waited a moment, "boys?"

"June!"

"Exactly! Never. That's exactly what I mean and we start by freeing you of that
pesky bra. Come on, take it off."

"June"

"Take it off. We're not moving until you do."

"June, let's just go."

"Take it off, Laura, take it off" she kept repeating the last three words until
I just gave in and took off my bra. She grabbed it and threw it as far as she
could. She turned to me and said "From this day forward we're going to get rid
of every bra we got. Every day we throw away one bra, today one of yours,
tomorrow one of mine. Until they are all gone."

"Let's go already."

We got in the car and June started to drive. I felt uncomfortable without my
bra, but June just had a big smile on her face. We were almost out of water when
we reached the next town and rented a room at a motel. The beds were okay and it
was clean, but it wasn't much more than that. Across from the beds was a TV that
just was too small for the size of the room. June lay on her bed, turned to me
and said "I am hungry, we should get something to eat."

I finished my post on our blog and asked "But where? We don't know this town."

"More reasons to explore."

We got most of our stuff out of the car. "You know," June said as she was
carrying one of the bags, "I should call my dad and ask if it's okay to trade
this car for a camper. Then we wouldn't have to sleep in dumps like this. Just
pull up at one of those places, park and done. First it's cheaper, second we
keep it clean."

That wasn't a bad idea at all. So we called her dad and after all the niceties
she popped the question to her dad. "Oh, wow, that's not a bad idea. It is a bit
more expensive than your car though. Maybe if Laura's parents help we could make
it work."

"Yeah," June said, "today when we stopped to switch places. Our water was
already warm. In a camper we'd have a fridge. And when we decide to stay
somewhere a bit longer we could always rent a car." My parents weren't that
easily convinced but they also agreed. The plan now was that we would head back
home and switch.

"If we drive through the night we could be there tomorrow afternoon."

"Yeah," I replied, "about that. I might be staying though."

June acted like she slammed on the breaks. "What?"

"Yeah, I've been thinking and maybe we shouldn't do it like this. Going on a
year long trip. We could do a week, two weeks, maybe even a month. It's like, I
miss my family so much, June. Going away made me realize how much I love them."

"Whoa, Laura we've been planning this since we were 16 and now you're abandoning
me? I can't believe it. I just can't believe you said that."

"It's the truth, June. I thought I could do this, I really did. But I need to go
home. Please don't be mad."

The route back was mostly quiet. June only spoke to me when needed and they were
short sentences. We drove all night and when it was my turn I drove with tears
in my eyes because I had hurt my best friend, but I was happy to. Happy to be
driving home.

When we arrived both our parents were delighted to see us and when June's father
wanted to show the camper June just said "Bring it back. Laura doesn't want to
go anymore. She's decided to stay home. This trip was the end of our
friendship." She turned to me and said "Get your stuff out of my car and go.
Leave. I don't ever want to see you again."

My dad unpacked most of it, my mother helped as I lay on my bed crying. Half an
hour later my mother sat down on the bed next to me. "What happened?"

"Oh mom. When I heard we were going home to get the camper I felt so alone. I
missed you and dad so much. Just the thought of going home made me feel so good.
I realized that if I got here I didn't want to leave anymore. I just wanted to
be honest with June, I just wanted to let her know how I felt. But she just got
angry, she got so angry with me."

"Look Laura," she lay down next to me and offered her arm, "I'm going to be
really honest here. But have you and June ever done anything that you wanted to
do. I mean, who's idea was this road trip? As far as I can remember it was
mainly June who pushed it. You just gave in after a while and then started to
believe it was your idea too. That's always been the dynamic between the both of
you. Now, finally, you've grown up and told her no. No, I don't want this. I
want to do what I want to do. And if she can't cope with that, who's problem is
it?"

"Yes, but she's my best friend. I don't have anyone else."

"That, weirdly enough, is my point. Do you remember Jayda? That girl who was new
to your class a few years back? You were all excited. You told us how nice she
was and how much fun the two of you had. You also said how much June would like
her. Do we even know why she stopped being your friend?"

"No, I don't. She just stopped, she didn't want to come around anymore, she just
walked the other way as soon as she saw me. June told me she just didn't like us
anymore and we should just ignore her too."

"Well, we could find out."

"How?"

"Just ask her, she works at the grocery store now."

The next morning I was all anxious about meeting Jayda again. My mother
encouraged me to walk in and I took a deep breath. Jayda was working at one of
the registers. I grabbed something small and took my place at the end of her
queue. The moment she saw me she asked if someone could take over. I dropped
what I had in my hand on the shelve and rushed after her. "Jayda, please. I need
to know. Please talk to me. What did I do to hurt you? Why did you stop being my
friend?"

Jayda turned around and gave me the stank eye only dark women could give and she
was good at it. "What did you do? Like you don't know. Come on, Laura, you know
darn well what you did. Little miss white privilege."

"What?! I don't understand. Jayda!"

She just stormed off. I looked around, saw the info booth and just grabbed the
mike. Over the speakers I said "Jayda. I know I am white. And I know I am
privileged and that's not okay. Why should I have more opportunities in life?
Just because my skin is lighter than yours? Then why do I spend so much time in
the sun to get darker? Jayda, I know you can hear me, but I really don't know
why you stopped being my friend."

Jayda stopped walking and slowly turned around. She looked at me and I couldn't
help but tear up. "Look Jayda, all the store can hear me. I don't care if your
black, white, yellow or whatever color there is. I look at who you are Jayda.
And you were my friend. Who was it that approached you when you were new in
class? Who told you where you could find anything? It was me. All I saw was a
girl who needed a friend, desperately. And that's what I offered you.
Friendship, nothing more nothing less. But then all of a sudden, you walked away
and I have no idea why. I really don't"

As I spoke Jayda walked nearer and then she said "Drop that microphone. You're
going to get me fired and I need this job." When her manager arrived and wanted
to scold Jayda I intervened and said. "Sorry sir, but this isn't her fault. This
was all me. Ban me from this store if you like, you can even ban my mother who's
sitting in her car outside. Hell, you can ban my whole family. But you can't put
this on Jayda. She was halfway down the store when I grabbed that mike. If
anyone should be punished it should be me."

A shopper nearby shouted "Just let them go. This was beautiful. Two people who
let the whole world know they are burying the hatchet. Let it be." Other
shoppers made clear they agreed. One man said "No call the cops. They both
should be in jail. Disturbing the peace." The moment he got flack for saying
that he just replied "ah, to hell with ya. What's this country coming to?"

"Okay, okay, but you young lady. Don't ever do that again. And you Jayda? Just
take the rest of the day off, I'll see you tomorrow, okay?"

"Thank you Dave."

When my mom saw me and Jayda leave the store together I waved to let her know it
was alright and she drove off. "So Jayda, care to tell me?"

"You really don't know do you?"

"No, I don't. It was like all of a sudden I had done something wrong. You
started ignoring me and then June said I should do the same. I don't
understand."

"Ah, June." Jayda turned to me and said, "June told me you was going to hold a
party and that you told her to invite me. I got all excited, bought a new dress
even though we couldn't afford it. My mom dropped me off and when I walked
inside I was at a bingo-night for the elderly. There I was, in my shiny new
dress, ready for a party. I made the best of it and helped announce the numbers.
They were all excited and it was fun. But when I came outside, people from
school had gathered in the parking lot. They all pointed at me and laughed.
'Look at Jayda, all dressed up for bingo night', 'ah poor little black girl has
to go to bingo night to party'. The next day I wanted to ask you what happened
and June told me how sorry she was, that she didn't know and how it all had been
your idea."

"What?"

"Yes, but now I see who did. It wasn't you, it was June. She just didn't want me
to be your friend. We did some things together, but she always pushed to do
things she wanted to do and I didn't want that. So I stopped. But I still
believed it was you who had embarrassed me and I was so sure I saw you. Were you
even there?"

"Where? At the bingo-hall? No. When was this?"

"May 3rd, two years ago."

"May 3rd? I don't quite remember, wait, two years ago? May 3rd is my parents
anniversary. We weren't even in town that day. Yeah, we went to a movie and had
dinner in Roxboro."

"Now there you have it. Oh Laura, I'm so sorry for the way I treated you. And
I'm sorry for everything I said back there."

"It's okay, I'm sorry too. I am so sorry they did that to you."

"Thanks. I've got a few hours to burn. Want to get an ice cream?"

"Sure, let's get an ice cream."

We had a lovely few hours together. Jayda told me everything that had happened
since the incident, how she got pregnant of a sweet little girl, how she had to
drop out to take care of her. Everything. We promised to stay in contact
although we both knew that wasn't going to happen. We hugged and she said "Now
we've said the things we are supposed to say, let me say something I really
mean. I am so happy we had this talk, Laura. It's like some weight has been
lifted off my shoulders. We both know this will never happen again, but at least
we can now talk and be nice to each other. And I really like that. Thanks for
doing this. Thanks for embarrassing yourself and thanks for admitting you're
privileged, more people should do that."

"Not a problem, Jayda, just as long as you know I mean it. Kiss that little girl
of yours for me. She's a pretty little thing and one day I hope to meet her."

"I know you mean it and one day you will meet her. I gotta go, it was nice
seeing you again."

After 10 minutes my mom came to pick me up and I told her everything I had just
learned and how nice Jayda was. I told her about her little girl and everything.
"We should get her some stuff for the baby," my mother said.

"No," I replied, "that's exactly what she doesn't want. Look mom, she's an
intelligent woman who just because she's black had to drop out of high school
when she had her girl. Now she works a dumb job just to take care of her kid.
What Jayda needs is the opportunity to finish high school so she can get a
better job. That's what she needs. Gifting her stuff is like giving her band
aids while she cutting herself with a knife. The solution is to make her drop
the knife."

"Wow, you're so right. I knew you were smart, but this is another level."

"Mom, what if dad interviewed her. A real interview. If she's good enough he
could give her a job. With those hours she could attend night classes, like dad
does for the other employees. Then Jayda could have the opportunity to make her
life better. But this is not a charity. If dad thinks she's not good enough he
shouldn't hire her. It has to be Jayda, all the way."

"Let's talk to your father."

After I had explained him everything he said "I could use two more hands around
here. But, and this is a real one, she has to beat the interview. Which means I
won't do the interview, Gayle will. She's black and she's mean during
interviews. If Jayda passes that she will be fine."

I jumped for joy, got in my car and drove to the store. I told the manager I
needed her address so I could return her phone. Reluctantly he told me what I
needed to know and I landed in the shadier part of town. I parked my car as
close as I could and tried to look as if I didn't care. I rang her bell and
Jayda opened the door.

"Laura? What are you doing here."

"I need to talk, can I come in?"

"Sure, but be quiet. She's sleeping."

"Okay."

We both sat down on her couch and I said "Look Jayda, when I told my mom about
you and your kid she wanted to bring you diapers and stuff. But I said no. I
said no because you don't need stuff like that."

"I sure do, diapers are expensive."

"Yes, I know. But. What you need is an opportunity. An opportunity to raise
yourself. So, my dad has a company and he needs people right now. I've spoken
with him and he is willing to give you that opportunity."

"No, I don't need you to get me a job..."

"But I didn't. I gave you an interview. Whether you get the job or not, that's
up to you. All I am doing is telling you that if you give them a call they will
schedule an interview. I just told him who you are and how convinced I am you
can do this. It would mean night classes to finish high school, it won't be
easy. But if someone can do it, you can. It's all up to you whether you pick up
that phone. You want the same opportunities I have, well this is it."

Jayda stared at me. "So you don't have a job and you didn't buy me diapers. What
kind of friend are you? Coming here empty handed like that. Expecting me to call
some stranger for a job. What's the number?"

I told her the number and they scheduled an interview for the week after. "It's
all up to you now? All I did was to tell you and my dad of an opportunity.
Nothing more, nothing less. Come get that girl and let's get you some diapers.
Just because I want to."

"Now she get's me stuff, after all that, now she's being nice." Jayda laughed.

A week later I learned from my father Jayda had aced her interview and she would
be starting a week later. He had actually spoken with her and said "That girl
has a bright future, if she works for it." He hugged me "Oh Laura, why are you
such a good girl?" "I don't know dad, it sure wasn't my parents." We both
laughed.

Another two weeks later June moved away to attend college somewhere on the other
side of the country. Somehow Jayda and her had met somewhere and Jayda had told
her all about our meeting and how she had learned it wasn't me who had organized
the embarrassment. Half a year later her parents moved away too and that was the
last I ever saw of her. I've tried to find her decades later and learned she had
passed away from a drug-overdose. Her body was found at an illegal dance party
with the needle still in her arm.

Me? I've become a human rights lawyer and I'm actively fighting against
prejudice on the work floor. My partner in all this, Jayda. She not only
finished high school, she worked and studied hard to become finish law school.
Together we opened up our practice. Her daughter is at Harvard now, she wants to
be a judge.

That road trip we were sure would change our lives, it sure changed mine.
