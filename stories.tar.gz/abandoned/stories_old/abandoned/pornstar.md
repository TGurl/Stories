# A pornstar was born
_an erotic tale by TransGirl_

## Disclaimer
This is a work of fiction and any resemblance to a real person either living or
dead is purely coincidental. The worlds I create in my stories might contain
names of real places or businesses but no resemblance to the actual places or
businesses is intended.

My worlds take place in alternate time lines and therefore might not resemble
reality as we know it. This is all just fantasy, although I try to make it as
real as possible, forgive me any (scientific) mistakes or freedoms taken.

## Chapter 1
To say I was always like this would be besides the truth. The truth is it all
went gradually, one thing let to the other and soon enough I was who I am today.
Not that I'm complaining, just setting the story straight. In the same way it
isn't true that I always wanted to this, this wasn't my dream job. It just
happened and I'm happy to be were I am today. But let me start at the very
beginning.

I was always interested in human procreation ever since I first heard about it
in school. The fact that a male and a female had to _join_, sot to say, was
fascinating to me. But in the times when I grew up and especially the family I
grew up in, this was taboo and simply not talked about. The subject was avoided
all together. So my mother didn't tell me about periods and I was in a panic
when I got my first one. My mom just said it was normal and I had to deal with
it. It was more my aunt Ashley, my mom's sister, who told me what it was and
what to do.

Ashley was the black sheep of the family, a bit of a free spirit. To say she was
accepted would have been an exaggeration, she was tolerated. It seemed I was the
only one who accepted her and for that reason alone my aunt and I were drawn to
each other. To be clear, she wasn't flaunting around. She was happily married
and as far as I know completely loyal to her husband, Bryan. Ashley just talked
about things more easily.

When I was 15 we lived in a small house with just enough rooms for all of us. My
brother's room was all the way in the top of the house, my room was next to my
parent's a level lower and on the bottom floor was the living room, the kitchen
and a pantry. We all shared the shower on the second floor and it was mandatory
to lock the door when you were using it.

I lived there until I was 19 and ready to move out. My two year older brother
still lived at home and that was something I didn't want to do. After high
school I was ready to go to college.

Now that I've painted the picture I can finally start telling you how it all
began.

While doing research for a school project I was doing in my last year of high
school I came across this website that promised good money for photos. I looked
into it and it became apparent to me that those photos were rather explicit, but
you had to subscribe to be able to see them. I was fascinated by the idea of
girls selling pictures like that and especially why.

One of those girls, Marisha, had her social media available and I tried to
contact her. I told her I was doing a school project and had come across her
profile on that site. Then I told her I would love to interview her about it,
not to judge or blame, just as a human interest story.

At the time I wrote articles for the school newspaper and I knew they would
never publish something like that. But I had started a blog and was still in the
process of figuring out what I wanted to do with it and this might be the way to
go: human interest stories of people who did jobs or other things nobody else
would ever consider doing. I took a few days for Marisha to respond.

_Hi,

I read your post and rather not take part in a piece that most likely will be
damning and judgmental.

M_

I persisted in my efforts to talk to her, told her I didn't want to be
judgmental at all. That all I wanted to know was her story: why she did what she
did. And if her family accepted what she did. I took quite a few direct messages
I and I think she finally gave in and agreed to voice chat.

"So, my name is Laura and as I told you in the posts. I will do my utmost not to
be judgmental. I'm just really interested in the how and why. And just to let
you know I will refer to you with the name you used on the site, I won't use
your real name."

"Thanks. But why are you doing this?"

"Well, I was doing research for a school project and somehow came across the
website. Yours was one of the more public profiles and I have a blog which I
might turn into something with human interest stories. So I thought this might
be a nice one. Me telling your story: how and why are you selling photos of
yourself in explicit situations."

"See, that could be judgmental and I've got enough judges already."

"Yes, I know. But I'm not interested in what you do. I'm interested in you and
how you made the choices you made."

"Hm, I don't know."

Suffice to say that first _meeting_ wasn't a great success. But she promised to
think about it and we had a few more chats. During this time we got to know each
other and I would like to think she grew fond of me, even it was just a little
bit.

During one of those chats she said "Look, we've been doing this voice chat a few
times now and I feel I'm a bit of a disadvantage."

"How?"

"Well, you know what I look like, but I have no idea what you look like. We could
video-chat, it that's alright with you."

I agreed and enabled my webcam.

"Wow, you're a pretty little thing." Marisha said when my camera was turned on.

I blushed and thanked her for the complement. "So, how did this all start for
you?" I asked when we had exchanged pleasantries.

"That's a good question. Mainly because I needed the money and didn't want to do
anything illegal. This seamed as safe as it could be and it is when you take the
necessary precautions."

"Which are?"

"Never have anything identifiable visible. Nothing with your address on it, for
example. But also, never have your curtains open. There are people online who
are able to find you based upon what they see through the window. Best practice
is to have some sort of studio, somewhere you don't live. That could be very
expensive, especially when you start. I know girls who have been swatted or even
killed. So there is a danger too it. Also you need to use a VPN when streaming
and although you might use a website, people are able to find you."

"So why, if it's so dangerous, why do you do it?"

"Primarily: the money. But it's not that bad. If you make sure you can't be
found that easily it nothing more dangerous than going to a bar. Whenever you do
that you take more risks then with what I am doing."

I thought about it and had to agree with her. I knew girls personally who had
been raped just walking back to their car. I had heard stories of people who
disappeared just yards from their home.

"So you said you started because you needed the money. How did it start?"

"Now that's a story. I got fired from my job and had a hard time finding a new
one. Bills kept coming and I struggled to pay them. Basically it came down to
maxing my credit cards and filling one hole with another one. It never seemed to
end. Then I realized I needed money fast and working the odd job just wasn't
enough. There were moments I really thought about hitting the streets and
selling myself. It would mean easy money and another few bills paid, but it also
meant I could get arrested and have be a criminal. That was a line I didn't want
to cross."

"Understandable."

"Yes, so one night I was at a bar and got to talk to this girl who said she was
into camming. When I asked what it was I realized it would be some easy money.
So I started doing that too. After a month I had earned almost 800 dollars, just
by sitting in front of that camera and showing my boobs. I also did a bit of
dancing and stuff."

"That basically meant you could pay the rent."

"And a few bills too. The people in the chat kept asking for more and just as a
test I set a goal of a 1000 dollars and I would strip naked on camera. It took
them only an hour or two to raise that goal. And that's how I got naked for the
first time."

"And you got paid how? Directly, through the site? How does that work?"

"The site I used back then had these monetary things called 'charms'. People
could by these 'charms' on the site. I believe a 1000 charms was equal to 10
dollars, or something like that. I forgot really. On my end I could then revert
those charms back to dollars and they would deposit those on my credit card.
They would pay me 8 dollars, so they made 2 dollars on every 10."

"Ah, that's how it works. They get a percentage of what you earn."

"Yes, and 5 percent isn't that bad of a deal. But there are a lot of girls on
there so it's very hard to get an audience if you get one at all. You really
need to stand out. It can be really hard, I've had weeks I didn't earn a single
dime. So I had to keep working a regular job. Camming was more like a hobby with
which I could earn some money."

"But when did that change?"

"That changed when I switched sites. I came across this site that enabled you to
set goals on every stream. If we reach goal on I go topless, goal two is naked,
goal three is, well you get the drift. At first the goals weren't that high, but
as I got better and I got some regulars I could raise them. You have to keep in
mind some of the people do not come for the sex part, that's a bonus, some of
the come because they are lonely. You need people skills to get good at
streaming. Some of those regulars came with me every time I switched. One of
those regulars became special to me and we've been married now for seven years."

"That's what I'm looking for. That's beautiful. But let's get into that another
time."

"Sure, but I need to say one thing. The only way you can ever understand is when
you try this yourself. Otherwise I can explain it to you, but do not really
understand. Now I'm not saying you, personally, should do this. I would never
say a thing like that. It's just I needed to say it."

"I understand and agree with you to a certain extend. But I can empathize and
try to imagine what it would be like."

"And still you wouldn't understand. But that doesn't matter. What matters to me
is that you don't judge what I'm doing for a living. That's just a part of me,
but the biggest part is my family. This is just my job."

I smiled and we promised to talk soon. In all those talks I had grown fond of
her and felt like we could be friends. My mom asked about her a few times and I
told her she was a source for a story I was working on. And as I always wore
headphones nobody could hear what she was talking about, all they knew was that
woman was just another woman.

My mom once asked why I talked to her so much and I just told her she was a
source for a story about woman in the workforce and what their experiences were.
My mom placed her hand on my shoulder and said "If you ever need my story, you
know where I live."

For the next few weeks I kept going back to something Marisha had said. About
how I would never understand until I tried it for myself. Every time I thought
about it I ended at the conclusion I was just too afraid. During those weeks it
went from _never_ to _maybe_ and ended in _one day I could try_. There were some
days I would look around my room and look for anything that could identify my
location. I noticed envelopes with my address on the nightstand, books from the
library and things like that.

One day I opened a webcam program and moved my laptop in such a position that it
was pointed at my bed. I set the video to full screen and checked if there was
anything compromising in frame. I then just sat there for a while pretending
that I was streaming. It took a few times getting comfortable seeing myself on
screen and to check where I could improve I started recording myself.

To make sure my family didn't think anything of it I had told them I was
pretending to be a journalist on camera. For my birthday I got a camera and I
microphone from my parents, so I could learn how to take photos too.

## Chapter 2
I got accepted into college with a journalism major. The reason I got accepted
was the story I had written about Marisha, who had given her endorsement to the
story. I graduated high-school and moved to an apartment of my own. My parents
paid the rent, water and electric bills, all the rest was up to me.

Although it was just a small apartment with just a bedroom, a living room with
an open kitchen and a small bathroom, it was all mine. Having my own space gave
me a sense of freedom and responsibility. It also had a sense of security
because I had moved only an hour away from my parents.

Ever since that story Marisha and I had kept in contact and we had even met in
real life. I had met her family and until then I had never seen her videos and
just a few pictures. One night I decided that had to change as I only knew one
part of her life, her personal one. It was time to meet her alternate: _Lady
Love_.

I went to her profile, registered an account and paid for a single video that
piqued my interest: _Lady Love needs to pay the rent_. 'Here', I though, 'I'm
donating five dollars and you will never know it was me.'

My heart was racing to see this video. It wasn't like I didn't know about these
kinds of video, but I had never watched one and this was one with someone I
knew. My heart was racing and my hand was shaking when I pressed the play
button. After the mandatory title sequence _Lady Love_ walked into frame wearing
nothing but a silky robe. The acting wasn't that bad and the character was
crying about how she was unable to pay the rent.

After a knock on the door the 'landlord' walked in and stated she needed to pay.
What ensued was a scene were _Lady Love_ agreed to pay _in other ways_. My face
turned red as I watched how she seemed to enjoy it. I had to look away when
there were close-ups of her vagina and later depicting the act of penetration.
The movie ended after about 10 minutes where the two of them agreed this was
they way she would pay rent from now on.

After seeing the video I read what she had written underneath. It had been one
of her first videos and she told about how nervous she was and how she would do
it differently now. She also told that the man playing her landlord became her
husband two weeks after filming this video.

The way she wrote the backstory showed me how open she was about that part of
her life and I started to appreciate the fact I was one of the few who was let
into the other part. Realizing those were two totally different things I
understood at least a part of it. In my mind I was able to separate the two. The
person in the video was an actress playing a part.

After that evening I watched a few more of her videos and saw the progress she
had made as an actress. In one of the latest the quality was almost the same as
any other movie I had seen: perfect lighting, shots were aligned and there was a
better story. Some were real life love stories, others were just basically about
the sex. For me the ones with the stories were most interesting, sure they all
ended with showing the act but still there was an attempt to tell a story.

On a weekend where I had nothing to do I opened up my laptop and started
writhing a story I had been chewing on for a while. Within two hours I had it
all written down. In my classes _writing for the screen 101_ I had learned how
to create a screenplay and the rest of the weekend I spent converting the story
into believable conversation. When I was done I was quite pleased with myself
and wondered what Marisha might thing about it. So I sent it to her.

Just a day later she called me. "I've read the script you sent me. It's
interesting but I don't see any love scenes in it. How could we incorporate
those?"

"Ow, never thought about that. It wasn't my intention for you to do anything
with it. I just wanted to know what you thought."

"It's a really nice story and we could cut it to about 30 minutes. But for it to
work for me it lacks something. Like in the end when she kisses the love of her
life, why not make that into a love scene. Just to amplify the journey she has
made."

I told her I would think about it and made some changes like she had
recommended. I struggled to add more explicit scenes. Most of them were just
remarks from _<LOVE SCENE> LL closes her clothes again and turns away_ to
_<LOVE SCENE> LL accepts the love and engages in the act_.

A few days later Marisha told me she loved the changes and how she knew exactly
how to fill them. Instead of just sending me the final video she invited me to
come to the recording of the video. That way I could help tell the story and
have some influence on how the story was told. She even joked about getting
credits in the video but I laughed and declined that offer.

As the weekend approached I got more anxious about actually going and I really
thought hard about it. But Marisha was right in it being my story combined with
me being curious what it would be like. With my heart racing I drove to the
location where the video would be shot. I arrived at the house around noon and
was amazed by the location. It was a huge house overlooking a valley below, it
was a magnificent house. As I walked in there were lights, camera's and the
likes. There were a few men and women walking around doing their thing. The girl
who had opened the door pointed me to where Marisha was.

The moment she saw me she yelled "Laura! Come in. People, this is Laura. She
wrote the script. Laura meet the people."

I waved my hand and watched how Marisha had her hair and makeup done. It was
heavy but she explained it had to be for the camera. She was wearing just a robe
and walked over to a rack full of clothes. She showed me an outfit and asked "I
envisioned her wearing this. Is this okay? Or should we go a bit more simple?"
The outfit was a female suit, with a nice pencil skirt. A typical outfit for a
business woman or a lawyer.

I thought about it a bit and replied "It's okay. It represents the restrictions
she has placed on herself."

"Exactly. And as she loosens up her clothes could do the same. I thought." she
said almost jumping for joy. She then grabbed my shoulders and looked me in the
eye "Now, Laura, don't be embarrassed by what you are going to see. These people
are here to do a job. It's nothing personal or degrading about it. Everyone here
knows why they are here and do it of their own free will. Okay?" I nodded and
she shouted "Okay, people, time to start. Please prepare for scene 1."

Marisha got dressed and I followed her to the living room. In the corner stood a
rather handsome man dressed in a suit holding my script. He waved as I walked by
him and took a seat that was pointed out for me. I looked my eyes out how
Marisha took control and showed everybody where to stand, which camera's should
be where and how she did the sound check. It was a proper film set. Marisha was
the lead and the director.

The scene started and after the doorbell rang she walked up to the door and
opened it "Gareth, what are you doing here? I thought we would meet at the
office?" The scene developed as I had written and Marisha blew away the advances
the man made. I had to blush when I saw how the man grabbed Marisha's breasts
and held her ass. With a close-up of her face the scene ended.

"What did you think?" she asked me. I answered I was quite pleased with it and
they shot a few other scenes. They weren't in the order I had written them, but
I knew that would all be done in editing. Marisha offered me something to drink
and eat while the crew set up the camera's in the bedroom. I knew the more
explicit takes would me shot.

From a corner of the bedroom I watched how Marisha played her thinking back to
the man grabbing her boobs. She lay on the bed and started to feel herself. She
opened her blouse and rubbed her breasts. She then took off her skirt with her
back to the camera bending over as she did it. Showing how she didn't wear
panties. On the bed she started to masturbate and I felt my face turning red to
see her spreading her legs and allowed the camera to film her vagina.

She then quickly changed to the other clothes and they filmed how she played
with some toys and moaned the name of her counterpart. Again the camera zoomed
in on her vagina, this time showing how the toy slid in and out of her. She rode
that toy with her boobs bouncing.

In another corner just out of frame I was fascinated to see one of the girls
jerking the actor while she was talking to Marisha. The girl then went down and
sucked the man until he was fully hard. The scene started with Marisha being
pushed on the bed, opening a silky robe and saying "Oh please Gareth, fuck me,
fuck me like I've never been fucked. I need you Gareth." The actor than moved in
and pulled her to the edge of the bed where the camera zoomed in to record how
he penetrated Marisha.

And although this was just a job for everybody there, seeing Marisha being taken
like that. Watching that big dick entering her wet pussy, really excited me. I
felt myself getting wet and really wanting to relieve myself. Unbeknownst to me a
seed was planted and it would, not before long, grow into a tree.

A few weeks later Marisha sent me the finished video. I was really nervous to
see it and had to smile when one of the title screen said _story written by a
good friend_. The story line was almost perfect and the love scenes even better.
It was the first time I got aroused by watching a porn video and started to
masturbate with _Lady Love_.

I wrote another script and incorporated more love scenes. I even got a bit more
explicit in the descriptions. This script was a bit more intimate and smaller.
It was about a mother who had feelings for the best friend of her son. How she
struggled with the age difference and how it all came to fruition. I clearly
described how small the house was and how intimate the scenes had to feel. It
all had to be shot with just one camera and it would be just Marisha talking
into the camera as if the one watching was that friend.

A few months later I was invited over to attend to the recording of my new
script. Marisha was happy to see me and said "This script is just beautiful. You
should write more of these. I think you might have found a new line of
storytelling for me." I blushed when she said that. After a few minutes later
her phone rang and one of the girls who had to be there called in sick. "Darn
it," Marisha shouted, "we really needed her. How are we going to do this?" The
camera man who also played the friend pointed at me and said "Maybe she can
help?"

Marisha looked at me and when I asked what was expected I was shocked she was
even thinking about it. "No, I can't do that. It's not something I do." I
protested. Marisha told me they had only rented the place for the day and in
order to shoot this video and to release it in time they had to shoot it today.
So I reluctantly agreed "Okay, okay, but I'm only doing this for you and this is
a huge favor. Just so you know it."

The cameraman got his camera, Marisha sat down on the bed and we started to
shoot. My job was to get the cameraman hard and very carefully I grabbed his
penis and started to jerk him. There were a few times I pulled my hand away too
late and we had to redo a scene, but I got the clues on where to pull away and
where to continue. I started to have fun and actually got a bit aroused by it
too.

"It looks like you are enjoying yourself." Marisha said with a smile on her
face.

"It isn't the worst job I ever had." I replied.

It was time to shoot the most important scene, the one where the mother actually
has sex with her sons friend. And the cameraman needed to get hard fast. My
jerking didn't help enough so I did the next best thing, I started to suck him.
The feeling of him getting hard in my mouth almost made me come, but I didn't
allow myself to come in front of people. I felt almost disappointed when he had
to start filming.

When all the scenes were shot and I down next to Marisha who was busy removing
her makeup, she said "Looked like you were enjoying having that cock in your
mouth. I could use a good _fluffer_." When I asked what that entailed I wished I
had never asked. But I had to admit to her that I rather liked sucking his cock.
Immediately my face turned red. I couldn't believe I was talking about sex so
openly.

"Hey," Marisha said to comfort me, "we've all been there. It's just we surround
ourselves with most if not all aspects of sexual exploration. Sometimes that's
all we see. We're used to be open about it or how else can I tell my counterpart
what I do and don't like. I can't tell him something hurts me if I can't tell
him or her what's hurting."

That night while I was thinking back to what I had done that day I again had to
masturbate and just thinking about his big dick in my mouth, how he tasted, how
I gagged on it made me come multiple times. I knew right then I wanted to do it
again. When Marisha offered me a job at her company I accepted it almost the
moment she offered. The money wasn't bad either, it was more than I made with
the job I had at that moment in time. When my parents asked where I worked I
just said I worked for a production company on film sets.

"Any movies I know?" my dad asked.

"I don't think so, they are mainly low-budget, independent movies." I replied,
which was the truth. I just didn't tell him what kind of independent movies they
were.

Suffice to say that sex got me through college and when I graduated I had worked
on numerous movies, for Marisha as well as for other productions. In that world
my name got around and by the time I graduated I had to decline offers just
because I was working somewhere else.

After graduation I started to work for Marisha's company full time, not only as
a screenwriter, but also as a set decorator and as a general manager. When
Marisha asked how I wanted to be credited in the movies I told her I would thing
about it. Two weeks later I told her "If you want to credit me, just use _Lena
Cooper_ as my name."

She tilted her head and repeated multiple times "Lena Cooper". Finally she said
"I like that name, wished I had thought of that before I chose _Lady Love_." We
both laughed and I entered the workforce of the adult industry.

## Chapter 3
After working for Marisha for a year or two I visited my aunt Ashley for a
while, I didn't feel good and needed some distance from the job. And although it
had become a bit easier for me to be surrounded by all the sex I ran into a
mental road block. Marisha told me she recognized the symptoms and basically
told me to take a few weeks off. 

I could have gone home, but I felt if I could tell someone what I did for a
living it would be Ashley. Still it appeared to be a huge roadblock for me to
open up to her. There were quite a few moments I wanted to tell her, but I just
couldn't. As a result I kept running around in the same mental circle, something
had to give but I didn't want to loose any of my family.

Then one day I decided to take the plunge. "Ashley, I need to talk." I said.

"Sure, honey, what's up?"

"First of all I need to thank you for putting up with me. But before I go home I
need to tell someone and I can't tell mom or dad. They will disown me the moment
I tell them. So this is serious and I need to know you will keep it between us,
no matter what."

"Laura, honey, always. Whatever it is you can talk to me. Then we can decide how
to handle your parents."

"That's fair. Here it goes. You know I work for a production company, right?
Okay. So we make independent movies and I work on the sets of those movies and I
dabble in some screenwriting. It pays good money, more than I would make as a
starting journalist. But I want to do more with my experiences I need an outlet
for my emotions. I wrote it all down and they are good stories. I am really
thinking about posting them on my blog."

"That's a good blog," she said, "I read all your posts on it. It's so funny what
you encounter on those sets."

"Yeah, but I'm leaving an important fact out. I don't ever talk about what kind
of videos we shoot. And I need to open up about that. It's an important aspect
of what I do. For example I can't talk about the actors and describe some silly
situations they find themselves in sometimes or how painful it can be. People
just see them as simple minded, while some of them are highly educated. They
just chose to do something they really like to do."

"I'm not quite understanding what you are getting at. You do sometimes write
about them, don't you?"

"Yes, but there is so much more I leave out. Just because I'm afraid on how
people will react. I'm can't explain without telling you. So here it is: the
movies I work on are porn."

"What? Porn movies. You have to be kidding, right? How ever did you get involved
with porn."

I told her about Marisha and how I contacted her for that story I wrote that got
me into college. How I wrote a script and how she invited me to come see how it
was shot. I told her everything, even about the _fluffing_ I now did on a
regular basis.

"You mean you get them hard?"

"Or keep them hard." I said.

"Wow, Laura. Now I understand why you couldn't go to your parents with this.
Look, I would be the last one to judge you over this, but porn? It's so
degrading to women."

"That's what I thought too. But most of them decide to do this. Sure there are
really shitty circumstances, I won't deny that. But then there are companies
like Marisha's who actually take care of their actors. Mandatory tests and
healthcare for the actors. Look I always use a condom but I only make the men
hard, people don't want to see the actors using condoms. So they are tested on a
regular basis for everything. On that level they are almost the healthiest
people on the planet."

"Is that true?"

"Yes it is. Then there is the other thing. Most of them are married and have a
family. This is just their job. A way they make a living."

"Wow, that's really something Laura. I may need some time to process all of
this."

"I understand. But I had to tell someone outside of that world. I need someone I
can talk to who knows that this is a part of my life now."

"Okay, you know what? You're right, it's just a job and it's not like you are on
camera."

"Yeah, about that."

"No Laura, you didn't, did you?"

"Not yet, I'm really thinking about it though."

"Oh no Laura, you can't. Why?"

"Because it's exciting and it's a lot more money. I could even start my own
company in time and make the movies I think would be interesting. There are a
lot of productions that's just boy meets girl and they end up in bed within the
first minute. I want to make movies from a female point of view, a bit more
story, a workup to the ultimate moment. Even make longer ones telling the story
about the struggle of a girl growing up. Sure some scenes will be more explicit,
but that's not as important for women as it is for men. Most movies are now
geared to men."

"That's true. I've seen a few and I hate it when it moves to fast."

"I'm not surprised you've seen porn. Everybody has. It's one of the biggest
industries in this country and nobody ever watches it." Ashley burst into
laughter when I said it and I chuckled too.

"Oh Laura, you know I will always love and support you. But, honey, really think
about this. If you do this you will not be able to undo it. If you do not make
it such a video will always haunt you, everywhere you go. So really think about
it, now you're just a fake name on some credits. Nobody who sees those knows
it's you. But if they see your face that all goes out the window."

"I know, but somewhere deep inside me I really want to try. It's something
that's been bugging me for a few months now."

"Okay, here's the deal. I will not tell anyone, this is between you and me. It
will be hard not to tell my sister, but not as hard as you think." She then
proceeded with telling me some secrets she keeps from the rest of the family
too. She told me the reason she wasn't married. "Laura, I trust you on this one,
I'm gay. I'm a lesbian and I've known since for ever."

I was quiet for a time and asked "And?"

"What do you mean with 'and'?"

"And what? What's the problem? So you are gay. Who cares?"

Tears sprung in Ashley's eyes "That's the best reaction I ever got and not the
one which I was expecting at all." she said. We stared into each others eyes and
kissed. With every kiss it became more passionate. I moaned softly when she
squeezed my boobs. She proceeded to unbutton my blouse and caressed my skin. 
"I wanted to do this for so long." she panted.

I held her head and said "I've got another secret for you. And I don't really
know how you'll react, but as we're being honest I have to tell you: I'm
straight." Ashley burst into laughter and kissed me again. I kissed her back and
took off my blouse. I kissed her neck and licked her hard nipples. When I bit
them slightly her moaning aroused me. I felt my pussy well up and I started
getting wet. With my tongue touching her skin I went up and pressed my mouth
against hers. Our tongues touched and I held her head in my hands.

Ashley pressed her crutch against my leg in between hers and I could feel how
wet she was through the fabric of her panties. Slowly she started grinding and
breath heavily. Then she took my hand and guided me to her bedroom. She
undressed me and I her. We pressed our naked bodies against each other and
kissed again. With our mouths connected, our breasts touching we fell on her bed
and just made out. Both our hands went all over our bodies.

I moaned loudly when I felt her hands between my legs and even louder when she
slid a finger in between the lips of my labia. I spread my legs and she slid
another finger inside me. She pushed me on my back and started to kiss me
everywhere. I held her had as she was sucking on my nipples and closed my eyes
as Ashley kissed my belly.

I groaned when she licked my clit with her tongue. And when she started to lick
my pussy I grabbed her had and pushed it against my cunt. She pushed her tongue
inside me as deep as she could and within seconds I came. Relentlessly she kept
on going pushing me further over the edge until I had an orgasm. My body spasmed
and all my muscles contracted. I had to push her off as my clit was just too
sensitive. I had to catch my breath and Ashley kissed me everywhere. Until she
reached my mouth.

We kissed for a while and I started to kiss her everywhere. When I reached her
pussy I said "Tell me what you want me to do. I've never done this before." and
with my tongue I touched her clit. It tasted a bit salty and sweet and I liked
it. I licked her labia and spread her lips with my fingers. I licked her insides
and started to suck her clit. "Oh yes, you are doing.." she panted as she spoke
"don't stop. I'm coming, I am so close, keep going."

After Ashley had come too we lay in each others arms, our legs crossed with each
other. I grabbed her leg with both hands and pulled it against my wet cunt and I
started grinding while I pressed my leg against hers. Suddenly she pushed me on
my back and pushed one leg underneath me and the other over.

I was wondering what she was doing when it suddenly became clear as she pressed
her wet cunt against mine and started grinding. Feeling her wet lips touch mine
almost send me over the edge. I thought I went crazy when she adjusted her
stance and our clits touched. "Oh Ashley, this feels so good" I panted and
started to grind faster and faster. We both were breathing heavily and almost
orgasmed together.

Out of breath we sagged on the bad and we crawled into each other arms. We
kissed for a while longer and just fell asleep.
