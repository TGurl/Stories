# How I Become Me
_an erotica tale by TransGirl_

## Crossing a boundary
Would you believe I wasn't always like this? Would you believe that in high
school I was a shy little girl? Sure I had my friends at school, but we didn't
hang out after school or anything. My mom kept pushing me to join something,
from the girl-scouts to the cheer squad. Everything came by until she just gave
up, I guess.

At college it all started in the same way, until I met Marisha. She was, and
still is I might add, a very outgoing, happy-go-lucky type of girl. Until this
day I still wonder why she spoke to me that day, but she did and we became close
friends. She almost tore my out of my comfort zone and took me to parties,
events and other things that happened around campus. It was on one of those days
I met Travis, immediately I was blown away by him. He was part of the football
team, I knew that much, but he also took part in the local Dungeons and Dragons
guild? He studied computer sciences? He was a jock and a geek, rolled into one.

He saw me looking at him, got up and walked over to me. From the corner of my
eyes I could see Marisha smiling. He introduced himself and talked about the D&D
Guild and asked if I would be interested. I just shook my head.

"Ah, might the fair lady be interested in a cup of hot brew? It's an excellent
vintage and the master of this establishment, that would be me, took the utmost
care in brewing it." he said flowed by a whispering of "it's just coffee but go
with it."

I laughed and Travis shouted "At last the lady has a smile." If I told you I
fell for him right there and then it wouldn't be that hard to believe now, would
it? In the weeks after he started with tipping his make believe hat every time
we crossed paths in the hallways. Then he started a small conversation every
time we met. Those meetings became longer and I always looked forward to our
next get together. Then one evening a letter was shoved under my door.

It was a white envelope with nice writing on the front. 'To the esteemed Lady
Laura' it read. On the back the letter was closed by a real seal of red wax. I
opened the letter:

_Dear Lady Laura,

We've been meeting in the hallways of this palace for quite some time now and I
do believe you are as I always looking forward to those random rendezvous in the
hallways.

Now, the King has decided there to be a ball in a fortnight and you would make
me the happiest knight in this real if my Lady would be so kind to accompany a
simple knight to said ball.

If my Lady agrees just light a candle and put it in your window for me to see, I
will be standing outside for your answer. If my Lady hasn't answered within the
next 10 minutes, I will know enough and I won't be a bother to the fair Lady any
longer.

Waiting in anticipation,

Travis,
Knight of the ellipsoid table
Slayer of Dragons._

I rushed to find a candle and finally found on in a drawer. I lit it, made sure
it was secure on the dish and put it in the window. Within seconds I heard
someone yelling "She said yes, She said yes. I've got a date to prom!" And I
just giggling.

During that dance he was so respectful and kind to me. We danced, drank some
wine, talked, laughed and at the end of the night he walked me home. In front of
the girls dorm we kissed for the first time. After which I turned away and ran
inside. When I looked out my window I saw Travis standing there. When he saw me
he took a bow, waved and walked away.

During the rest of our college years we grew closer and closer. He took me to a
D&D game and a few weeks after that I joined in as a guest. He immediately
started to court me and we played a very romantic scene together. Just before
the end of the game the villain was able to strike me and I died in the arms of
the noble knight who swore to take revenge. When the game master ended the
session for the week everybody applauded my performance during the game.

"You were so good, Laura," one of the said, "You've got to promise to come again
some day." I just smiled and looked down, I wasn't used to getting praise. But
it was Travis who took the crown by saying "My fair Lady, you were amazing in
this game. If I hadn't fallen for you yet I would have this evening. Thank you
so much for making my night."

"You've fallen for me?" I asked.

"Well yeah, isn't that obvious, I thought it was."

I blushed and said "I like you too."

That night was one of the most amazing nights of my life up until then. We
strolled on campus, kissed a few times and ended up in his bed. That was the
night I lost my virginity. The days after that he introduced me as his girlfriend
for the first time.

Two weeks after we graduated he invited me over to meet his family. I had never
been more nervous in my life. When we arrived at his parents house I was awe
struck, this wasn't an ordinary house: it was a mansion. "Oh yes," he said, "my
parents are filthy rich, but they are still simple folk."

"You never told me this." I replied.

"No, and that was one of the biggest reasons I started to like you. You had no
idea who I was or who my parents are. Other girls just hung out with me because
my parents are rich, you hang out with me because of me. And that's why I love
you Laura Baily." My mouth fell open when he said that. It was the first time he
told me he loved me.

"What did you say?"

"Yes, Laura, I love you. I've loved since the day we met."

"Aw, I", I stared at my lap and whispered, "love you too, Travis."

We kissed and walked up to the front door. A man in his late 40s opened the
door.

"Hey dad," Travis said, "this is Laura."

"Very nice to meet you Mr Willingham."

"Nice to meet you too, Laura and it's just Terry, please. I'm not my father and
hardly an old man." he laughed.

We walked in and to my surprise the whole family was there. Travis had
conveniently forgotten to mention that part.

"Hey everybody, a moment please." he shouted and when everyone was paying attention
to him he continued "I would like you all the meet my fiance Laura."

Again my mouth fell open. Did he just say fiance?

Travis got on one knee and looked me in the eyes "Laura Baily, would you make me
the happiest man in the world and accept my hand in marriage?" He opened a box
with the most beautiful ring I had ever seen.

I was flabbergasted, looked around at everyone. They were all anxiously waiting
for my answer. "Yes," I whispered.

"Um, what now?" Travis replied.

I spoke a little louder "Yes."

"Didn't quite get that. One more time?"

"YES!" I almost shouted and everybody in the room cheered. I jumped into his
arms and kissed him. He put the ring on my finger and all the girls gathered
around me to congratulate me. That was the way I was introduced into his family.
Half a year later we had the best wedding at his parents house, all my family
was there.

Marisha was my brides-maid and Travis had two best men, hist best friend for
years and my little brother who was as proud as he could be. It by far was the
best day of my life. At the end of the day, as per tradition, we left first.
Huge letters spelled 'JUST MARRIED' and there were cans tied to our bumper. I
got in, Travis sat next to me and we drove off: we were now officially Mr and
Mrs Willingham.

## Vibe of the Bahamas
For our honeymoon we went to the Bahamas. And we strolled the white beaches,
staring out over the very blue water. We just were so happy there. We didn't
stay at a hotel or something, Travis had rented a small house near the beach and
it was simply the best. We loved every second of it.

One day he pulled me on his lap and kissed me. When his hand went up my chest I
slapped it away "Not here" I hissed. But he kept on going and I looked around to
see if anyone was there before allowing him to touch them. He slowly unbuttoned
my blouse and started sucking on my nipples. I felt them getting hard almost
instantly. With his free hand he slowly moved up my thigh and rested just short
of my now moist slit.

Almost automatically I spread my legs a little bit and I could clearly feel him
getting hard. Somehow this turned me on, me the reserved girl from high school
and college was turned on by being fondled where everybody could have seen us. I
spread my legs a bit further and softly started moaning.

In one swoop Travis not only slid my panties to the side but he also slid one
finger inside my now wet cunt. I felt my labia spread apart as his finger slid
inside me. I moaned a little louder, although I felt a bit embarrassed by what
he was doing I didn't want him to stop. I placed my hand on his cheek and kissed
him. In the mean time I spread my legs even wider.

"Oh Laura" he moaned.

By this time he had three fingers inside me and a started to gyrate my hips, I
wanted him, right there and then. I got up, got his hard cock out and straddled
him, there I was the shy Laura Baily sitting down on her husbands thick cock
right there in the open for everybody to see. But I didn't care any more, I
wanted my husband to take me.

I rode his dick, grinding my clit against his body. By this time I was moaning
loudly. I didn't protest when he took off my blouse, exposing my triple-D
breasts to anyone who walked by. I had crossed a line and I didn't care any
more. I got up took of my skirt and sat down on him again, this time I was
totally naked.

"Oh yes, yes, fuck me. I want you to fuck me hard." I shouted. Travis had just
unleashed the tigress in me and I wanted him, all day long. I leaned forward,
put my arms around him and kissed him, grinding on his hard cock inside me. I
closed my eyes and just lost myself in the moment. When I opened my eyes I
realized we had gotten an audience. From almost 30 feet a dark man was watching
us, I looked at him and smiled. I got up, turned to him and sat back down
sliding Travis cock inside me. I spread my legs wide, thus giving the man a
clear view of my wet pussy sliding over that big cock.

My movement mad my boobs bounce and the man got a bit closer. He took step by
step until he stood next to us on the other side of the balustrade. He reached
over slowly until he touched my boobs, sending jolts of pleasure through my
body.

'I'm fucking my husband and a strange man is touching my boobs' I thought.
Normal me would have stopped and run away, but I didn't I wanted more. Slowly
the stranger went down until he touched my clit. I though I went crazy with joy,
just a few touches and I orgasmed so hard I thought I fainted.

Travis got excited to by seeing this stranger touching his wife and at the
moment I orgasmed he exploded inside me. He screamed as he came sending wads and
wads of cum inside my now cum hungry pussy. He patted my ass and I stood up, he
crawled from under me and I sat down again. This time turning towards the unknown
man. I spread my pussy lips, exposing the cum covered pink insides of my vagina.
He slit two fingers inside me and made me cum all over again. He just thanked me
and walked away.

I needed a moment or two to regain my wits, gathered my clothes and joined
Travis inside. He kissed me and told me "This was amazing. You were so good and
I just lost it when that guy started touching you."

"I don't know what came over me. I'm so sorry, I won't ever do that again."

"No, no, no, that's not what I meant. I loved it. Makes me feel so proud you are
my wife. If other men desire you like that. Oh man, I can't explain it. It's the
best feeling for me."

"So, you didn't mind when he touched me down there." with my head I nodded down.

"No, I loved it. I almost came instantly when he touched you there. And when you
showed him your, well, vagina it was even better. I loved it how he made you
cum."

I walked over to him and kissed him. "Relish this memory. It won't happen again.
Count on it." I said as I walked towards the shower. Somewhere deep inside me I
knew that was a lie. As I showered my thoughts went back to that moment when
that stranger and I were alone and he had tree fingers inside me. I remembered
wanting him to fuck me too. As I stood there thinking about I started
masturbating giving myself another orgasm. It was at that moment I knew I wanted
it to happen again, but it had to be organic, just like it was today.

The next few days we spent exploring the island, doing some sightseeing and
buying the most hideous presents for our family. On one of those trips we were
hiking a trail and ended up at a beautiful waterfall. Travis wanted to take a
picture of me in front of it. When I stood at the fence I noticed a small sign
stating 'Swimming allowed. Sharp rocks. Feet protection mandatory'. I told
Travis to hold on for a minute and walked down the small path leading to the
water.

The water wasn't that deep and I shouted "Are you ready?"

"For what?"

"To take the picture of your life time."

Travis walked up to the gate as I swam to the middle of the pond. The water was
cold, but it wasn't that bad. When I was near the waterfall I dove made my hair
wet and went under water. There I took off my bikini top and put it under my
bottoms. I tilted my had backwards and pushed as hard as I could with my legs. I
rose up so fast I breached the surface up until my waist, exposing my now naked
breasts to whoever was standing at the fence. Luckily the only one there was
Travis.

I laughed and swam pack to where my clothes were. Once there I noticed I had
lost my top and quickly put on my white shirt. As I didn't have a towel there
was nothing to it but to let myself dry in the hot climate of the Bahamas. When
I joined Travis two wet patches made my nipples clearly visible. He showed me
the pictures he took as I squeezed the water from my hair. The photos were
amazing, I looked like Bo Derek in the Blue Lagoon. Years later he would
surprise me with an enlargement of that photo which now has a prominent place
above our bed.

By the time we got back to our car I had fully dried up, except for my hair
which was still a bit damp. Who would have thought that I, Laura Baily, would
ever do a thing like that? I sure hadn't, but there was something really freeing
about that island. Something struck a cord with me and I loved feeling this
free. And I loved the man who allowed me to be free and to never restrict me to
become who I am.

## Exploring further
In the weeks following that day on the trail we started taking more pictures and
they became more explicit each time. We both enjoyed our times together and I
loved being the model. We bought nice dresses for me to wear and the heels got
higher as we went along.

It was on a Tuesday when I got the bad news the place I was working at was
closing down. Even though we didn't really need the money I was devastated, I
loved working there and felt so sorry for everybody who lost their jobs. As I
drove home I just couldn't stop crying and Travis comforted me to the best of
his abilities.

Weeks went by and I settled into being at home for the day. I spent a few hours
on cleaning the house, but as we had hired professional cleaners there wasn't
much for me to do. Soon the boredom took over and I sat behind the computer once
more just to try and eleviate the boredom. I grabbed my phone and texted my best
friend, I knew she was working but I just needed to talk to someone. I checked
the clock and Travis wouldn't be home for another few hours.

I got up and strolled through the house. All kinds of things went through my
head. 'I could go to the mall', 'Maybe a a walk? It's nice weather', but I ended
up laying on the couch and watching TV. Nothing on there could peak my interest.

Then Marisha called and told me she would get off early and asked if I liked to
meet her at our favorite coffee shop. I jumped up, got dressed and hopped in the
car. 30 minutes later we sat down at a table outside the shop and ordered our
coffee. We chatted for a while and I told her how bored I was.

"Then get another job." she said.

"Yeah, I could do that. But I would like to have some freedom too. I don't know,
I got really tired of the 9 to 5 thing. It's just I don't know what to do
anymore."

"Then find something you like to do and turn it into a business." she said, "I'm
sure there's something you like and then it wouldn't feel like work. Take me for
instance, I love working with flowers and now I've got my own shop. And I'm good
at it too."

That last part was true. Her bouquets and arrangements were the best in town,
she now owns a very exclusive store with the richest clients there are. She
caters to all kinds of events, from weddings to funerals. Her flower
arrangements are always in tip top shape.

"Yeah, maybe you're right. It's just that I've got no idea what I want to do."

"You're a smart girl, you'll figure it out somehow." she said. We kissed and
said our goodbyes. As I was near the mall I decided to go window shopping. I
checked out some nice clothes, shoes and some purses too. The sudden buzzing of
my phone startled me a bit. It was Travis telling me he had to work late and
wouldn't be home for another few hours. "I'm so sorry honey," he said, "but
there's no way out of it."

"Is she at least attractive?" I asked jokingly.

"Yes, she is," he replied, "but she's a bit on the young side. Come say hi to
aunty Laura." He handed the phone to his young niece, the daughter of his
sister. "Oh hi Susan," I said with a laugh, "are you taking good care of Uncle
Travis?" "Yes, I brought him chocolate." she said. I laughed and felt tears in
my eyes. She just was so adorable. "Now, you take care of him alright?" Travis
said goodbye and we hung up.

The house just felt so empty and I sighed as I sat down behind the computer.
'Woman looking for some fun thing to do' I typed into Google. The results
weren't exactly what I was looking for as I was bombarded by sex ads and porn
sites. But there was one link that caught my attention. _Looking for something
fun to do and make money at the same time? Send us your photos and earn money
with them._ I clicked on the link and read what they had to offer.

_We offer you the opportunity to start your own space on the internet. By
offering photos and/or videos you can make up to $50,000 dollars a week. Just
click here and see what is possible for you._

'50.000 dollars a month? That's a lot of money' I thought and I clicked the
link. There they had more good news about how much money you could make. Now I
wasn't stupid and I knew it was all just marketeering, but I was intrigued
nonetheless. I clicked on the menu option _Models_ on the top of the page and
got a page with their _best earning models_. These were all very attractive
women. I clicked on one of them and was led to her profile page. There ware all
pictures of her in nice lingerie. _Want to see more of me?_ a link described,
next to it was a dollar ammount: $150 dollars a month. And she had more than 100
thousand followers! That would mean a lot of money.

I closed the site and thought 'I could never do that.' But then I remembered how
much fun I had taking thos pictures of me. A seed was planted, I just didn't
realize it yet. I put it aside, made me some dinner and ate while I watched a
move on Netflix. When I was done I did the dishes and sat behind the computer
again. As it was the last site I visited, the browser opened up with it again.

I opened Google, read the latest news and watched some funny YouTube videos. All
this time my thoughts kept going back to that site. I got the camera and
downloaded the photos to the computer. I put them in a folder where we kept all
our pictures. I clearly marked the folder as private and browser through them
for a bit.

When Travis came home I told him where I had put them so he wouldn't accidentaly
show them to others. Travis smiled and assured me he wouldn't. We hung out for a
while, talked about his day until it was time to go to bed. In bed, when I lay
in his arms, I whispered: "Travis, are you asleep? I need to talk."

He groaned a bit and said "Sure honey, what's up?"

"Well, I've been bored lately. Very bored. And I talked to Marisha today. She
said that maybe I should find something I like to do and try to make it into a
business."

"Solid advice."

"Yeah, well, I would like to find out what it could be. I haven't got a clue and
being home all day doesn't help either. Would it be okay for me to try and find
myself? Maybe even go away for a while?"

"Where would you go?"

"I have no idea. All I know is I can't go on like this."

"Laura," he said as he got up, "I will support you in anything. If that means
you have to find yourself, then so be it. I just want to know what you are doing
and, if you go somewhere, where you are. Laura, I love you. I love you enough to
give you your freedom. Just promise me to always come back to me."

I kissed him and said "Always, you are the love of my life. But I've never been
on my own. From home to college, from college to marrying you. I don't regret
anything and I would do it all over again. But these last few days have been,
tough. I need to find out what it is I want to do and who I want to be. Hope you
understand."

"I don't really, but that isn't important. If you need to discover yourself,
then do it. Spread your wings and fly, Laura."

"I love you so much, Travis, more than you will ever know."

"I love you too."

I rest my head on his shoulders and fell asleep.

The next morning Travis had to get up early and I waved as he drove off. I felt
excited once again. I showered, gathered some clothes, packed the camera, my
phone and some small stuff like a toothbrush etc. With everything packed I wrote
a note to Travis stating how much I loved him, put my keys on top of it and
looked at my weddingring. I kissed it and placed it next to the keys.

As I drove off the place where my weddingring used to be felt empty, naked even.
And I really thought about driving back to get it, but I couldn't. My keys to
the house were next to my ring and there was no way to get into the house, but
to call Travis. I shook my head and tears welled up in my eyes. I loved my
husband so much, but this was a thing I just had to do.

After a few hours I stopped at a road side diner and ordered a burger and fries.
As I was eating I kept fiddling with the spot where my ring used to be. 'Wow,
did I really play with it that much?' I thought.

I drove for a few more hours and found a cheap hotel that looked a bit decent. I
signed in and fell on the bed. Just as I was falling asleep my phone rang. It
was Travis.

"Laura? Where are you?"

I told him where I was and how I glad I was to hear his voice.

"But, Laura, I know you need to find yourself, but why did you take off your
ring? Is there something you need to tell me?"

"No," I replied, "It's just, I can't explain it. I just needed to take it off. I
needed to feel free and that ring is a bond of some sort. I still love you and
I'm still your wife. That will never change, whether I'm wearing that ring or
not. Ah, I can't explain it. Just see at as a bond for me. I will be back to
claim my ring and to be back by your side."

"But Laura..."

"No Travis, I need this. I've got to. Please, don't make me come back. Because
you know I will when you ask me to."

"Oh Laura, just be back soon. I miss you and I love you."

"I love you too Travis. I will call you soon, okay. I just need some time and
space for a bit."

"Okay, honey, just text me where you are so I can find you when it's needed.
Okay?"

"Yes, honey, I will."

And with that we hung up. I buried my face in the pillow and cried, hard. It was
as if all the tension I felt came out. I beat myself up for leaving my ring
behind, why did I ever do that? The keys were some sort of a stick, just so I
couldn't go home that easy. But my ring?

I grabbed my phone and started browsing through the photos of Travis and me. It
almost felt like we had broken up. I went through a bit of a mourning process
and just cried a lot that night.

The next morning I gathered my stuff, payed my bill and got in the car. I
seriously considered going back, but decided against it. I drove on for a few
hours, got some gas and a few hours later I parked my car in a small town. I
walked into the local inn, rented a room and dropped on the bed. The man behind
the register had told me where I could get some food. After a short shower, I
got dressed and walked over to the _Huckleberry Saloon_, I giggled at the name
for a bit.

The saloon was your typical small town bar offering beer, whiskey and simple
meals. The big man behind the counter greeted me with a "Well, hello there
Missy. Mighty nice to see a new face around here. Billy Bob is the name and how
can I help you?"

I told him I wanted a beer and something to eat. "Alright, that is no problem,
please find yourself a table and it will be right over." I sat down at a table
near the window and looked out over the small town.  After about ten minutes
Billy Bob walked over to bring me my food and beer. He tipped his cowboy had and
walked over to the bar.

A few minutes later a young man walked in "Well hello there Slater, same as
usual?" The man nodded and walked in, saw me and greeted me. The moment he
noticed I was alone he walked over and said "Sorry to disturb you Miss, but I
noticed you are eating alone and that's a real shame. Nobody should be eating
alone and if you wouldn't mind I would be priveleged to keep you company for the
duration of this meal."

As I turned my head I noticed he was rather handsome looking, with his square
jaw, pearly white teeth and his twinkling blue eyes. I almost said no, but I
changed my mind and said "If you have to."

He sat down "Slater is the name, and who might you be?"

"Just passing through." I replied.

"Well now, just-passing-through what did you do to your parents to earn a name
like that?"

I could help but laugh. The was something disarming to the way he talked and is
good looks helped a lot too. "Okay, it's Laura" I said.

"Laura, that's a pretty name. Suits you. And why on earth are you in a god
forsaken place like this?"

"A long story."

"I got plenty of time. So I'm listening."

"Nah, not this time, cowboy. Try that tactic on another woman. I'm not
interested in what you have to sell."

"Who says I'm selling anything. I'm just offering you an ear to listen. But I
won't pressure you. Let's just eat dinner and talk about anything you want."

I smiled and was really charmed by him. Whatever he did, he was good at it.

Billy Bob brought Slater his food and we had a nice dinner together. I don't
know how he did it, but I actually enjoyed his company. He told me the history
of this small town, where I could find a job to earn some money and he asked me
if I would like to come to the saloon later that evening. There would be a band
playing and some line dancing.

"Come on, it should be fun." he said.

I thanked him for his time and walked back to the inn. I texted Travis where I
was as promised and dropped on the bed again. After laying there for a few
minutes I checked my phone for the time and sat down on the edge of the bed. I
walked over to the window and saw quite a few cars parked in front of the
saloon. Half an hour later I could hear the music. Without thinking a grabbed my
jacked and walked over.

Slater greeted me with his big smile and introduced me to some people who were
there. A nice girl named Daisy took me aside and said "Be careful with him, he's
woed other women with his charm and before you know it you might do something
you'll regret." I told her I would never let that happen and thanked her for her
warning about Slater.

The band started playing another song, we danced, drank beer and had a good
time. Not for long it was time for me to head back. Slater offered to walk me
over and I didn't object.

"Thank you for tonight" I said, "It's been a while since I had some fun."

"You're quite the mistery to me, Missy, but I like that about you."

I giggled a bit and shivered. "It's getting cold. I need to go inside." I said.

I looked into his blue eyes and before I knew it we kissed. And we kissed again
and again. Our tongues met and his hands went all over my body. His touch
electified me and I wanted more. I grabbed his hand and walked up the stairs
leading to my room. Once inside we undressed eachother and I pushed him on the
bed. On my hand and feet I crawled on top of him and pressed my mouth against
his, pressing my breasts agains his broad torso. He took me in his strong arms
and I moved my hips so that the crown of his cock pressed against my labia.

Slowly I sat down and moaned his his big cock slid inside me. I raised my body
and his cock went in deeper. Way deeper than Travis ever did. I had been with no
other man besides Travis in my life and here I was having sex with a man I had
just met today. Here I was Laura Baily cheating on her husband with a stranger.

Everyting together really turned me on and I started riding his big cock. I felt
it twitching and turning inside me as I grinded on his muscular body. He then
lifted me up and I held on to him as best I could, my arms around his neck and
my legs around his hips. He placed me on the table in the room and started
fucking me. I spread as wide as I could, wanting to feel him deeper. With just a
few thrusts of his big pole I felt my pussy tighten. "Oh god, I'm coming, I'm
coming. Right there, don't stop. Yes, yes. YES!" I pressed my body tightly
against his as the orgasm took hold of me. My pussy grabbed on to that big pole
and I felt him twitch and spasm. He was about to come too. "Oh, Slated, come
inside me, give it to me. Yes, come inside my pussy!" I shouted.

We both needed some time to catch our breath and dropped on the bed. We started
kissing and I took his cock in my hand. Slowly jerking. It didn't take long for
it to be fully erect again and Slater got on top of me. I lifted my hips and
guided that beautiful dick of his inside me one more time. This time we didn't
just fuck, we made love. We kissed, our toungues in eachothers mouth, his big
pole inside my cum hungry pussy. I had three more orgasms while he was fucking
me and after a while he exploded once more inside me, I felt his cum dripping on
my ass.

He rolled off of me and gasped for air. "Wow," he said, "Just wow." I smiled and
gave him a kiss. I rolled over towards him and just fell asleep.

The next morning when I woke up Slater was gone leavin a small note saying
'Thank you. It was the best.' Suddenly and enourmous feeling of guilt came over
me. What had I done? I had cheated on my husband with the first man who showed a
bit of interest in me. As I showered I could feel Slaters cum dripping out of me
still. I tried to clean it the best I could.

When I was dressed I gathered my stuff, payed for the room and hopped in the
car. I couldn't get out of there quickly enough. Not only had I had sex with the
first guy I met, I had let him come inside me. What if I got pregnant? Sure, I
was on birth-controll, but still there's always a chance. You can't immagine the
relieve I felt when the first drop of blood announced my period. I had always
hated this time of month, but this time I was elated.

As the weeks went by I all but stopped texting Travis. I didn't even use my
credit card. I worked the odd jobs to earn some money and drove on. I went from
town to town and after a few months I called Travis.

"Oh Laura, am I glad to hear your voice. Where are you? How are you?"

"I'm fine Travis. I'm almost ready to come home."

Travis started crying and whimpered "Really? Do you mean that?"

"Yes, babe, I still love you so much. Now even more because you allowed me to do
this. As I said I'm almost ready. I will let you know when I'm coming home,
alright? I love you so much."

"I love you too babe."

I cried after I had hung up and stared at the lake where I was parked. I was
just so beautiful over here. I got out of the car and walked towards the shore.
After a few minutes I grabbed the map I had bought a few hours earlier and
checked where I wanted to go. There was a big town just a few miles ahead and I
checked my phone for a hotel or an inn. Called to make a reservation and drove
towards my final destination of my road trip. I hadn't lied to Travis, I was
almost ready but I had to finalize my journey.

As I drove towards the town, parked my car and signed in. The hotel I stayed at
was the kind of no-questions-asked and I dropped down on the somewhat comforable
bed. In a nearby diner I ordered some food and I explored the city a bit.

Suddenly I noticed a car driving next to me. I stopped to look what this man was
doing and just as I wanted to yell at him he said "How much?" I was stunned, but
realized what he meant. "You can't afford me." I replied.

"Hah, bitch." and he drove off.

I giggled a bit as the whole situation amuzed me. 'He was willing to pay me' I
thought and started to laugh. A few more blocks over I found myself on a long
street. Most of the girls were wearing rather revealing clothes and high heels.
They were 'working girls' I realized, these were street hookers. And although I
should feel disgusted, or sorry or anything else but what I felt. My pussy
welled up and I started getting wet. 'How would it be if I.. No, don't think
like that.'

I rushed away and almost ran back to the hotel I was staying at. In my room I
just couldn't stop thinking about what I had seen and how I had felt. I opened
my suitcase and grabbed a crop top, a mini skirt, a pair of heels and a jacket.
'Just for fun, let's see how I would look' I thought.

After a few minutes I checked myself as best I could in the only mirror in the
room. Then I got out my camera and took a few picture of myself. I looked like
one of the girls I saw walking that street. As I watched the photos I felt
butterflies in my stomach and thought 'Would I dare? What if I just joined them,
to feel what it feels like? I didn't have to do it for real.'

I grabbed my purse and on my way over there I bought a box of condoms. No idea
why I did that. I wasn't getting into a car! Not for a milion bucks! When I
arrived some of the girls gave me the stank eye, but ignored me for the rest.
They made sure I wasn't encroaching on their spot so I ended up on the far side
of the street. The nerves were killing me, but the fact that I, Laura, the shy
girl from high school was 'working the street' excited me.

Soon enough a car stopped near me. A window opened and I walked up to it,
bending over clearly showing my triple-D breasts to the man behind the wheel.
"Looking for some fun?" I said.

"Depends on what you offer?"

"Well, what you looking for?"

"A good time."

"I can do that" I couldn't believe what I was doing. I actually was negotiating
a price to sell my body.

"So, how much?" He said.

"a hundret"

"One hundred dollars! You gotta be kidding."

"Take it or leave it. Your choice."

"Ah okay, get in."

With my hands shaking I actually opened the cardoor and got in. We drove to a
secluded location and he handed me a 100 dollar bill. I put it in my purse, got
out a condom and grabbed his dick to make it hard. After I had put on the condom
I straddled him and guided his cock inside my wet pussy. I moaned as he entered
me. I rode him until he came and then he dropped me off at the street again.

I had actually done it, I was officially a hooker now. And somehow I felt so
proud of myself. I walked the street for a few more hours and when I was back in
my room I had earned 1100 dollars. I had found what I loved to do and I could
make money doing it. I was I whore, a hooker, a lady of the night.

I stayed at the hotel a few more nights and worked the streets every night. My
outfit became more revealing the more I worked. I loved what I was doing and
enjoyed the interaction with my Johns. But I had to go before I was arrested and
left town with almost 7000 dollars in my purse.

In the next town I started looking for where I could work and quickly found were
I needed to be. I rented a room in a shady hotel nearby and at night I walked
the streets, having 6 or 7 clients each night.

On the eigth day I just had to call Travis and I asked him to meet me half way.
It was the nice reservation with the large lake I had been a few days earlier. I
arrived early and was really nervous about what was to come. I needed to come
clean with him. He had earned that right with spades.

My heart almost stopped when I recognized his car. I nervously got out and waved
as he parked next to me. He took me in his arms and kissed me. It was like
coming home, the love of my life and I started to cry.

"What's up?"

"We need to talk", I replied, "Well, I need to talk and you need to listen. I
have to be honest with you and I really don't know what's going to happen next.
But I've spread my bed and now I have to lie in it."

"Okay"

"Let's get somewhere a bit more private."

We walked for a while and Travis told me all the news that had been happening at
home. His sister had another child, a son Bradey, and his dad had promoted him.
I smiled and laughed, but I still needed to be open with him.

"Okay, here it is. I don't know how to tell you so I'll just start." I told him
everything, from Slater to the other men and how I had prostituted myself.
Everything came out, it was like a volcano spewing lava I needed to get it off
my chest. When I was done there was a long moment of silence.

"So, what you're saying is: you're a prostitute. You sell your body for money."

"Yes, and I make good money too. In just a few days I made almost 7000 dollars."

"But you fuck with men for that money."

"Yes"

"Sorry Laura, that's just too much for me. I really don't know what to think of
it."


