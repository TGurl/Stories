# My Dad My Pimp
_an erotic tale by TransGirl_

## The White Rose
My life had been ordinary. I was a good student at school, hardly ever got in
trouble and helped my dad on the weekends in the store. I wasn't old enough to
actually work but he let me do the odd things like making coffee for everybody,
bringing around cookies, things like that. As a 12 year old it gave me the
feeling I was actually helping.

Our life almost completely unraveled when my mother passed away due to a drunk 
driver. He ran a red light running from police and hit my mothers car on the 
drivers side. The only solace we have is that she must have died instantly. The
driver? He survived with minor injuries. At his trial the judge let me say a few
words, but as I could hardly speak my aunt spoke them for me. But I wrote the
words.

Ever since then my dad was a broken man. His business failed and because of that
we had to move to another town. Everything reminded him of mom he explained to
me. I was devastated not only had I lost my mother, now I was loosing my friends
too. I rebelled and ran away from home.

The police found me three hours later walking down the street, having no clue
where to go or what to do. The brought me home and the moment I saw my dad I
regretted what I had done. He took me in his arms, kissed me and told me he
loved me. "Please," he said, "you may yell at me, you may slam your door, you
may even slap me if you really want to. But never ever do a thing like this
again."

I promised I wouldn't and kissed him on the cheek "I love you dad and I'm sorry"
I whispered. That night was the first time I actually heard him cry. He was
talking on the phone with my aunt. "I don't know Jessie, it's all so hard.
Ashley knew exactly what to say to her. Yeah, maybe you're right. Okay. Sure, if
you would like to. Yeah. Let's see what she'll say. Yeah. Bye."

The next day when I came back from school, Jessie was sitting at the table. You
could clearly see the family resemblance between the siblings. Jessie was a
tall, voluptuous woman who didn't know how beautiful she was and how her smile
disarmed everyone she spoke with. "Oh hey Laura, nice to see you. How are you?"
she asked.

"I'm okay," I replied, "why are you here?"

"Your dad asked if I would like to talk to you for a bit and I thought it might
be a good idea, you know just us girls."

I had always liked aunt Jessie but now I had some suspicions. "Okay," I replied
clearly showing my reservation, "but why are you here? We could have talked on
the phone."

"Well, that's what I wanted to talk to you about. Come sit down with me, grab a
drink and let's talk."

I sat down and stared at her. "Now, let's see. How shall I start? I think it's
so unfair of your dad to pull you away from your friends, especially now. I
mean, you've just lost your mom for heaven's sake."

I nodded and she continued "It's just not fair, isn't it? He could at least
consider how you would feel right?"

"Yes," I replied feeling encouraged by her words.

"Now," she said as she took my hand, "There's a thing you can do. You have a
choice. One being going away with your dad, loosing all your friends and going
to a new school. But that's not what you want right? No. So, here's option two.
Your father moves away and you come live with me. You can still have your
friends, you can still got to your school and I can be your new Mommy. Who knows
you might even call me mommy after a while. So what do you think?"

I jumped up and yelled "You will never be my mommy, my mommy died. She's dead
and I'm never going to see her again. It's all so unfair, why? Why did she have
to die?" I started to cry uncontrollably and Jessie took me in her arms.

"There, there girl. Let it all out. It's good to cry. Yes, it's so unfair. I
know." she went down on her knees and looked me in the eye, "Imagine how your
daddy feels. He lost his wife, the girl he fell in love with at 13. The woman he
asked to marry him when they were 22. The mother of his daughter, his most
precious daughter. Yes, you lost your mom, but your dad lost his wife."

Her words hit me like a thunder strike. She was right, my dad had lost his wife.
Images of them together popped into my head, how happy they were and how much
they both loved me. "But, Jessie, I don't want to move. It feels like we're
abandoning mom. Like we're leaving her."

"I understand," Jessie replied, "but your mom isn't bound to this house, or this
town. She bound to you and to your dad. As long as you have her in your heart,
she will always be with you. And you can always come to visit, we can visit her
every time you want to. But you don't need to be here to feel her love. You can
be anywhere in the world."

I dove into her arms and cried for quite some time. All the emotions, all the
anxiety came out. Although I was only 13 at the time I understood what she had
done and I thanked her for it. "Your welcome girl. You can always call me, day
or night. I will be there for you." she whispered, "I love you little rascal, I
always will."

I giggled when she user her nickname for me. We walked into the garden where my
dad was eagerly waiting on the result of our talk. I ran towards him and told
him I loved him. "I'm sorry dad," I whispered, "I am so sorry you lost mom. We
both lost someone we loved. I am so sorry dad." He just burst into tears and we
both cried for a while. He held on to me tightly and whispered "I love you to,
sugar bear, I love you so much."

Jessie made dinner for us and went home when she as done. Dad and I ate dinner
and remembered the good times with mom. We actually laughed at her stupid jokes
and how she always knew how to get a smile on our faces. We started to celebrate
her life and the time she was with us.

About a month later we moved to a different town, almost 500 miles away. Dad had
found a new job and I enrolled into a new school. It was hard at first, but I
found some new friends and life became a bit easier as time went on.

It had been 3 years since we lost mom and we got our lives on track more or
less, even though my dad missed being his own boss he didn't miss a days work.
He had to work so hard to make ends meet and I really wanted to help him out in
any way I could. My dad was very grateful for me working the weekends, but I
knew it wasn't enough.

I didn't realize how dire the situation was until the day I got home seeing my
dad at the kitchen table trying his hardest to fill one gap with the other. I
sat down next to him and decided I was going to do something about it. I had no
clue what, but I was going to find something I could do.

In my room I opened my laptop and searched the internet for a solution, when I
came across this website that paid money for pictures. _Earn 500 dollars a day
or more_ the slogan was. I tried to register an account, but failed because I
needed a credit card. So I moved on and found this site asking for girls to sit
in front of a webcam. 'That shouldn't be that hard.' I thought, 'I like
chatting.' I registered and checked the box stating I was 18, well I was in
about six months.

To be sure not to arouse suspicion I went downstairs and told my dad I was going
to chat with some friends, grabbed a coke from the fridge and went back
upstairs. Before I did anything I checked my e-mail and found one from the site.

_Please confirm your identity.

To confirm you are female we're asking you to upload a picture of yourself,
holding something to prove the day and time. We are required to do this so we
can ensure the safety of all our models.

Also make sure that there is nothing in site that may reveal your location. Use
a VPN to hide your data. Click here for more information on how to set one up.
It's from the utmost importance to ensure your safety at all times.

If you need further assistance, click here.

Regards,

GirlsOnCam_

'How do I get a newspaper? I can turn my alarm-clock around for the time. But
where do I get today's paper?' I thought. The clock indicated it was almost 8PM
and my dad would never allow me to run to the store. So I had to find another
way or wait until the next day. There was no way I could do this that night, so
I gave up and watched a movie instead.

All day at school I couldn't stop thinking about the site and how I had to get
today's newspaper. The dean called me in for a talk and I noticed a stack of
newspapers on the counter. "Sorry, Miss, could I have one of those? I need one
for a project." I lied.

"Sure, they're almost old paper anyways. What kind of project are you doing?"

"I'm not sure quite yet. But I want to do something from the news. I'm thinking
about comparing news-outlets. You know, what the difference is between written
and the spoke news. I don't know, it's something that's been spinning in my head
now for a few weeks."

"But it's not an assignment, is it?"

"No, but it's a great way to get a free news-paper."

The dean started laughing "Okay, Laura, touche. You got me there. I actually
believed you for a hot minute."

I smiled and we had a good talk about my future and what I would like to do
after high school. She told me about the different possibilities for a
scholarship and I told her I would seriously think about it. At the end she
handed me a note stating I was with her as I was late for my last class that
day.

After school I rushed home and was a bit relieved when I noticed my dad wasn't
home yet. Just as I was about to go to my room he called telling me he would be
late and there was pizza in the fridge. I told him I would be fine and I would
see him later.

Once in my room I placed my phone on my desk, checked if my clock was clearly
visible, held up the news-paper and took a photo. After checking it it was all
sharp I uploaded the photo. On the site I read _Thanks for uploading. It can
take up to 48 hours for us to process the application. We will reply via e-mail
as soon as possible. This will give you time to set up your account. Your
account will not be visible until it's approved._

'Another 48 hours?' I thought. I shrugged my shoulders and clicked on my
profile. I needed a nice picture, a screen-name and a name for my account. 'God,
what shall I call myself?' I thought. To get inspiration I clicked on _Models_
and saw a few accounts, underneath a big red banner that stated _Your account
has not been approved yet, so you only get access to 'fake' accounts._ 'Nice' I
thought 'Another dead end.'

All kinds of names passed through my head, but I settled on _RebaSloan_, a name
the almost resembled my mothers maiden name. The account could then be called
_Reba's Corner_ or something. It was time for my profile picture. I brushed my
hair, did my make-up, grabbed a nice top and sat in front of my camera. I chose
the best one to upload and was rather happy with the result. I didn't really
like the name, bit hey I had another 44 hours to think of something better.

After eating my pizza and watching a movie I had the name for my account _The
Inner Sanctum_, a location of one of my favorite scary movies. I loved it. I ran
upstairs and changed the name. Before I went to bed I checked my email and to my
amazement there was one from _GirlsOnCam_. My account had been approved and once
again they talked about privacy and security.

The next day I took my laptop to school and asked the IT teacher to help me
setup a VPN, it was way easier than I thought it would be. "The only thing is,"
he said, "you need to pay for it. So maybe ask your dad for permission."
Although I was a bit bummed I knew that getting permission wasn't that big of a
problem.

That afternoon my dad was home and making dinner. "Oh hey dad, can I talk to you
for a minute?"

"Sure, what's on your mind?"

"Well, we learned about privacy on the internet today. And the teacher suggested
it might be a good idea to set up a VPN, a virtual.."

"Private Network, yes I know."

"Yeah, that's the one. Now he recommended two or three of them and they all
offer a family package for 3.99 a month. So, I thought, maybe we should get one.
You know just to be secure and safe."

"That's not a bad idea. There's only on thing though..."

"What's that?"

"We already have one. It's been on your computer for years now. At first it was
so I could see what you were doing on your laptop. But as you got older I
disabled that feature. As a matter of fact, I disabled almost all the features
but the VPN itself. You might not have known, or you simply forgot, I work with
computers, Laura." he smiled as he spoke the last words.

"But what you are really saying is that you've been spying on me?"

"No, just showing some interest."

"Okay dad," I laughed, "But I still want to check the settings you were talking
about. Just to see whether you really disabled those features."

"Help yourself, my laptop is right over there. You know the password."

I opened up his laptop and sure enough his password was my mothers birthday. I
smiled as I typed it in. The screen lit up and my heart skipped a beat when I
saw his wallpaper was a picture of me and my mom. 'Aw, cute but that has to
change at some point.' I thought, 'and you're still wearing your wedding ring.'

"Dad, can we talk for a moment? Please?"

My dad sat down next to me and said "What's up honey?"

"First of all, this." and I pointed at the screen.

"What? It's a nice picture."

"It is. But I was 5 maybe 6 years old. You really need a new wallpaper, dad."

"But, honey, it's your mother. I love her in that photo."

"Yes, dad, I know. But it's been 3 years now. You need to move on. Live again,
go on a date, meet someone new."

"I don't know, Laura. I did try, but it feels like I'm cheating. I just can't do
it."

"Mom would have wanted you to find someone new. And I do too. We will never stop
loving her. I know I won't, but we need to live dad. We can't keep living like
this, you know, in the past. I can hear mom now 'Peter Bailey, you walk up to
her and ask her out? I will if you don't'."

My father grinned as I imitated my mother. "You look and sound so much like her.
The older you get the more you do."

I smiled and said "Okay, now for these settings. Where do I click?"

My dad showed me and went back to making dinner. Just to be sure I changed the
password for the program to something he could find out with a little thought
and changed some more settings. As I surprise I changed his wallpaper to one of
me and I added a small photo of my mom in the top right corner. _In loving
memory_ I wrote below it.

During dinner he told me he had to work the next day. "But it's a Saturday,
dad." I protested, "we always do fun things on Saturday."

"I know, Laura, but we need the money. Taking overtime is what I have to do. I'm
so sorry, but there is no other way."

I veined disappointment but inside I felt elated. This gave me a few hours to
engage on the site. "Well, okay then. Maybe I'll go to Marisha for a while."

"Or ask her to come over. It's supposed to be a nice day and you girls could do
whatever it is you girls do." I giggled and said I would think about it.

The next day I woke up to my father shouting "Okay, I'm off. Will be home again
round 4. Okay, Laura? Did you hear me?"

"Yes, dad." I groaned, "have a nice day at work!"

I looked at the clock, it was 8:30 and normally I would have turned around but
this time I got up and walked to the shower. After getting dressed I opened up
my laptop, found the VPN app and logged in as the administrator. I smiled as I
saw my dad hadn't found out the changes yet. I cleaned the history and added
_GirlsOnCam_ to the _Do Not Log_ list. My father always underestimated my
computer skills.

After that I logged into the site and was welcomed by a new banner. _Welcome
RebaSloan, your profile is 68% complete. Please consider completing you profile
before proceeding._ I clicked it away and read my new messages. They were all
from the site with instructions, ideas or other worthless information. I went
through my profile, answered a bunch of questions and others I chose the _will
not reveal_ option.

Then it was time. I placed my laptop on the edge of my desk and pushed my chair
backwards a bit. Fluffed up my hair a bit and clicked on _Go Live_. A new page
appeared and in the top-left corner I saw a small window asking me permission to
access the camera. I was disappointed in the quality, but it had to do for now.
Underneath it was the chat and to the right a column where the guests would
appear. I saw three buttons: _goals_, _prices_ and _request pc_. I had no idea
what these buttons meant. Soon enough someone appeared in chat.

"Hey"

"Heya"

"U look nice"

"Thanks"

"I'm looking for some fun."

"What do you mean?"

"Show me your boobs."

I was shocked when I read those words. This random person somewhere in the world
asked me to him or her my boobs.

"No"

"Bitch"

I closed the room and have to admit I was in a bit of a shock. This wasn't quite
was I was expecting. I knew there were sites like these, but I really thought
this was something different. The site never indicated it allowed this kind of
content. I clicked on models and chose one that was life. On screen appeared a
beautiful girl in nothing but her bra.

There were lots of people in her chat and she either typed an answer or she just
spoke. I clicked on _prices_ and got a pop-up that talked about how much she asked
for pictures of her. A fully nude picture was 500 coins, more explicit pictures
were even more expensive. Then I clicked on _goals_ and got another pop-up. If she
reached _4000 coins_ she would start her show and with _request PC_ the pop-up
indicated a Private Chat would cost 1500.

I clicked on help and read a thousand coins would cost 10 dollars. So basically
she sold nude pictures for 5 dollars. I went back to my account and really
thought about deleting it. But then I realized with selling a hundred pictures
she earned 500 dollars. 'I need a better camera.' I thought.

After checking everything I found my dads old digital camera in the garage and
to my surprise it was still a bit of charge left in it. I took some selfies with
it and was very disappointed with the result. My phone took better photos than
that camera did. Then I remembered Marisha had a good camera maybe I could
borrow hers.

"Sure," she said when I asked her, "I'll bring it right over. What do you need
it for?"

If it wasn't for the fact we told each other everything I could have made
something up. "I'll tell you when you get here."

Twenty minutes later Marisha arrived with the camera. We sat down in the garden
as she explained it to me. "Now what do you need it for? I'm dying to know."

"Okay, fair is fair. Look you know how hard my dad has to work to make ends
meet. Now, I do my best to help with the job I got but that's only when they
need me. And I really want to help. So I looked on the internet and there's this
site where you can sell photos of yourself. The girls on there make a lot of
money."

"What? But Laura, that's basically selling your body for sex. It's just wrong. I
don't think I can agree to that."

"But, Marisha, ..."

"No, no buts. Especially not yours on the internet. I can't believe you are
actually thinking about this. Look I will support you in anything, I will, but
this?"

"Marisha I am going to do this. Either with your help or not. We need the money
and although he might not know, I understand we could loose the house. And then
we will have to move again. I don't want to move again. So I need to do anything
necessary to help my dad." I had seen the letters from the bank and I saw the
_Urgent_ logos on the front. I knew my dad was painting a rosier picture than it
actually was. But he had already enough to worry about.

"Is it that bad?"

"Yes, it is. I saw the mail from the bank and all."

"Did you read them?"

"No! I saw the envelopes with Urgent and such. And I do know it's not a good
thing when they put urgent on the front."

"You might be right. But I still do not agree with any of this. Just so you
know."

"I know, Marisha, I know. And if there was any other way to make money fast,
then I would do it."

"Then there is this little ting about your age. You're not 18 and it's basically
child pornography. You could get into a lot of trouble."

"Yeah, I know. I haven't posted anything yet, but my face."

"Good, because you should wait until you're 18."

"I don't know if I have the time."

"That might be true. But if they find out you're under age you will ruin your
life and I can't stand for that. If I loan you my camera, I will be guilty too.
Aiding and abetting or something like that. So, I've made up my mind, I can't
loan you my camera. Not until you're 18."

"I understand. Thanks for listening and for not judging me."

"I would never judge you. But what are friends for if not to tell you the errors
of your ways. I love you, Laura, you are my best friend. The one who knows all
my secrets. I trust you and I don't want to see you get hurt."

"Thanks, I love you too."

We spent the day doing other things and just before my dad arrived she went home
taking her camera. I had something very difficult to do. I had to talk to my dad
and I knew I would get grounded for at least a month or two. But I needed to
know the truth and I needed to tell him the same. There was no other way to it.

"Dad?"

"Oh there you are. Hey sugar."

"Hey. Sit down dad. We need to talk. I saw the letters from the bank, are we
loosing the house?"

"No, whatever gave you that idea?"

"Why else would they put _Urgent_ on the envelopes?"

"Because they are urgent? Maybe?"

"So what are they about then?"

"Laura, don't worry about it. It's nothing."

"But dad I do worry. So much so I even registered an account on a site to sell
pictures of me, you know, naked ones."

"What?! You are joking, right? You didn't actually do that?"

"Yes I did. And I was this close of actually posting them. You can earn a lot of
money with them, a lot. I just wanted to help you keep the house."

"Oh Laura, we're not going to loose the house. I am trying to get my own bar.
I'm sick and tired of this job I have. And it's almost complete, just one more
signature and I can start remodeling. _the White Rose Inn_ will be the name, as
your mother loved them."

"Oh dad, why didn't you tell me?"

"Because I wanted it to be a surprise. You were the one who told me to be my own
boss again and a few weeks ago I saw this bar was for sale. Your mom left us a
small amount of money and it was just enough as a deposit. So, now you now, I
wasn't at work today, I was at a lawyer to go over the contracts and permits."

"Oh dad, I almost made such a big mistake. If it hadn't been for Marisha those
pictures would have been up there."

"Laura, I will always support you with anything you will do. Even exposing
yourself on the internet, it it's something you really want to do. But, only
when you turn 18. Then you're an adult and I can't, legally, do anything about
that anymore."

This wasn't the reaction I thought I would get, but I took it. I went into my
room, opened my laptop and deleted the account. If they wanted me, they could
wait 6 more months.

## A manager you will be
Six months later the bar had become quite successful, it was located in a nice
neighbourhood and my dad offered decent food for a small price. On Friday nights
he had a band playing and the floor would be filled with line-dancers. There was
another room with three pool-tables which where continuously in use.

It was three weeks after my 18th birthday and I would start my very first shift
at the bar. I walked in and took my regular seat in the corner. "Hey dad, how's
things?"

"Okay, honey, we're doing okay. Herbert, this is my daughter Laura. Laura this
is Herbert, he's one of the old gang."

"You know this used to be a titty-bar. I miss those days."

"Herbert!" I veined being offended, "you old dog you."

Herbert started laughing "She's a keeper. She can take a joke."

"Okay, dad I will change now. Be right back."

I walked behind the bar, grabbed an outfit and ducked into the small closet that
now did service as the girls changing room. Then I grabbed my nameplate from the
desk and walked in the bar. My dad handed me a tray and off I went.

"Hey folks, I'm Laura, how can I help you this evening?"

"Oh hi Laura, we would like burgers and fries please."

"Coming right up, anything to drink?"

"Just two cokes please."

"Alright. I will bring it as soon as possible."

I handed my dad the order and walked towards the other table. My dad had
organized it so that all the tips went in a jar and would be split amongst all
the waitresses. You just did what was necessary at the moment. He always hated
zones when we were in other places. It could mean you had to wait for a long
time when your assigned waitress would be available.

As I completed another tables order I watched how Marjory brought the food to
the table where I had started and I watched how more of the tables were filling
up. It was going to be a crowded night.

"Hi there, I'm Laura, how can I help you tonight?"

"Well, hey there Laura, you could start by showing us your boobs."

"Sure, I could do that. But that would also mean you getting thrown out of here
and you would end up ad MacDonald's or something. You know what? Why don't you
boys get out of here. I'm sure they will love to help you at MacDonald's."

"Wow now Missy, no need to speak to us like that. We're your customers."

"Not any more you aren't."

"Okay, let me talk to your boss and we'll see how long you'll be working here.
Any idea who I am?"

"Yes, you're the mayor's son who thinks he can get away with anything. But not
here. And this is my boss. Did I mention his my father? Oh, did I forget that?
So sorry."

When my dad heard what they had said, the boys tried to deny it but the guests
at the other table confirmed my story and even aplauded as the boys were thrown
out. A few days later the mayor came into the bar and with a raised voice he
demanded to speak to the manager. As my dad wasn't there at the moment I walked
up to him.

"Someone in this bar insulted my son. And I demand to know who that was. That
person needs to be fired or I will make sure this bar closes."

"Oh, that person would be me."

"You? But you're just a waitress."

"And I am the owners daughter. Let me ask you a question, sir. Do you have a
daughter?"

"Yes, I do."

"And how would you react if two strange boys asked her to, and I quote, show her
boobs?"

"Well, I would insist they'd apologize."

"Good, then I will be waiting for an apology."

The mayor looked at me as if he saw water burning. "Are you suggesting my son
said that to you?"

"Yes, sir, I am. And there are witnesses. So, if your son feels the need to
apologize he'll know where to find me." and I walked off. Some of our patrons
did their best not to burst into laughter. The loved to see the mayor being told
off by an 18 year old and in such a polite way.

The evening went on and my dad was working the bar when the mayor and his son
walked in. My dad almost started speaking, but I waved for him to be quiet.

"Well now, miss, I think my son has something to say."

"I'm sorry if I have offended you, miss. I had too much to drink and I am sorry
for my actions."

"Mighty nice of you to apologize. But you are no longer welcome in this
establishment. Please don't let the door hit you on your way out. And, mayor,
thank you so much. You and the rest of your family are always welcome to come
through our doors. And maybe, in time, we will allow him back too."

As they walked out my father leaned on the bar and asked me what this was all
about. And before I could answer Herbert burst into laugher and said "Your
daughter told the mayor in a very polite way to hit the road and make his son
apologize. That's what happened. I told ya, she's a keeper."

My father and I burst into laughter too and I handed Herbert a fresh beer, he
had earned it. Two weeks after that my dad held a staff meeting and said "There
are moment I can't be here like today. And we need someone who's officially the
manager. But I don't want to appoint someone without your consent. So..."

"Um, that's an easy one." Marjory interrupted and she pointed at me, "Laura."
All the rest of the staff agreed "I mean," Marjory continued, "the way she
handled the mayors son and the mayor. That was classy." I blushed as they all
agreed to make me the manager.

"Okay, then. Dad as I now seem to be the manager, can I make my first executive
decision?" My dad nodded. "Okay, first of all, these outfits? Who thought of
these? They're uncomfortable and really sweaty. We need other outfits and I will
make sure to get some nice ones. Secondly, the tips. We put them in a jar and
divide them equally amongst the waitresses. But Jonah has worked his but off
in the kitchen. He gets nothing. I don't think that's fair. So show of hands, 
who agrees to include Jonah in the tips?"

Everybody raised their hands and Jonah almost started crying "Thanks Laura." was
all he said. I just nodded, it was something I wanted to talk about with my dad
anyways.

"So there it is. I promise you I will listen to your input, but ultimately it is
my or and ultimately my dads decision. Now, let's get ready for tonight. It's 
Friday and it looks like it will get busy."

I settled in my role as the manager quite nicely and the staff knew they could
come to me with anything. There were certain things my dad didn't have to know
and other things he should. Jonah became a lot more motivated now he was
included in the tips. After a while I even let him order everything for the
kitchen, I thought it was unnecessary for him to create a list. My dad would
then order and if something was missing my dad had to run and get it.

"Why not let Jonah order and give you a list of what he has ordered. And if he
misses something he can get it himself." I said, "If it doesn't work out we can
always turn it back." But it worked out better than I had expected, the extra
responsibility made Jonah even more engaged in his job. One day he experienced
the other side of the coin, I told him off when he hadn't ordered enough. He
never made that mistake again.

It was Sunday night and the bar was closed. My dad and I enjoyed the one evening
we didn't have to work. I crawled against him and he put his arm around me. It
all felt so peaceful. At the end of the garden the white roses were in bloom and
I smiled. 'Thanks mom, thank you for being with us.' I thought.

## The spur of the moment.
Two years later my dad suffered a heart attack and passed away in the hospital.
I did my best to keep the bar running, but it just wasn't the same anymore and I
was forced to sell it. I was heartbroken. Marisha did her best to cheer me up a
bit but nothing worked. Now I had lost everything, my mom, my dad and the bar.

As the house was too big for me alone I had to sell that too. Marisha was
helping me pack and I cried almost the whole time. After a few days of packing
and storing the boxes, we sat on the window sill of a now empty house. "Marisha,
I need to go for a while. I need to clear my head, to find what I want to do. I
think I'm going on a road trip and I have no idea when I will be back."

"Oh, Laura, do you have to? You can crash on my couch for a while. Until you
have your own place."

"Thanks, but I really need to get out of here. I really need to be on my own for
a while. Just seeing the country, you know."

"Oh, I'll miss you so much. You will need to call me as often as you can. And
you must let me know where you are. Oh, Laura, I miss you already."

We hugged and when the realtor came I handed him the keys. I took one more look
inside and whispered "Goodbye house, you've been good to us. Thank you so much."
and closed the door behind me. I got in my packed car and drove off, into the
sunset.

Before I left town I stopped at a mall and bought a camera and a tripod. I also
bought a sun panel which I could use to charge my electronics. On my way out I
had bought a nice dress and got in the car. The sun was charging the camera in
the backseat and I just drove to somewhere. As it was getting dark a looked for
a place to stay and parked at a small hotel.

As I dropped myself on the bed I thought 'Well, here I am. All alone and nothing
but freedom ahead. Whatever will I do, momma? Hope you and dad are happy up
there. I'm trying, but I just don't know where to go or what to do.' I turned
around, put my head on the pillow and softly cried.

The next morning I got in the car and just drove as far as I could. At the
suggestion of Marisha I had started a blog and wrote: Here I am. In the middle
of nowhere, on a long road leading to somewhere. I don't know what I am doing
here, why did I do this? I'm feeling so lonely, but something tells me I have to
do this. I have to explore and find who I am. My bet it's my mom, looking out
for me, guiding me. I just have to follow her lead. Sometimes I feel her
presence and I almost feel happy, but then it subsides and I'm still in the same
mess as a few seconds before. I have to get going. Talk to you in the next
post."

After a few hours more I arrived in a small city, somehow I recognized the name
but I just couldn't place it. My phone guided me to another small hotel and I
signed in. The lady was very friendly and as we walked up the stairs it was like
my heart stopped beating. There on the wall was a picture of my mom! She looked
around 6 years old, but she clearly was my mom.

"Hey dear, it's like you've seen a ghost."

"I might have. Who is that?" and I pointed to the picture of my mom.

"Oh, that's Bridget. She disappeared almost 20 years ago. Or was it even longer
than that? I don't quite remember. But her parents stayed here for one night. By
the morning her bed was empty. We've searched for her for days and couldn't find
her. Why are you asking?"

"She looks like my mom. I am sure that girl in the picture is my mother."

"Are you sure? She's awfully young in that picture."

"Yes, I'm almost sure." I put my bag down and grabbed my laptop. In a folder I
found what I was looking for and showed it to the lady. "Look."

"Well, I'll be darned. They almost are identical."

"Yes, but this is me when I was 6. We could have been sisters if we had been the
same age."

"Darn, this is just unbelievable. We need to talk to Brady, he's the local
sheriff. He'll know what to do."

Half an hour later I sat at a table downstairs and was talking to Brady. "Yes, I
have to agree, the resemblance is almost undeniable. As far as I know the mother
is still alive and she's still searching. In her own way that is."

"Where does she live? Can I meet her? I just have to know."

"I'll see what I can do. Now you just stay here and wait. I could make that an
order, but somehow I know you won't comply anyways." He tipped his hat and
smiled. I laughed a bit and Beth brought me some soup. "Here now, dear. You'll
have to eat. When you're done, bring everything out of that car of yours. I've
cleared some space in the back. I guess you'll stay for a while."

"Beth? Can you please sit with me? I hate eating alone and I could use the
company."

"Alright, let me get some soup."

A few minutes later we both enjoyed the soup and I asked "You called her
Bridget, but my moms name was Rebecca. I don't understand."

"I don't either, but Rebecca is a nice name. How was she, your mother?"

"She was the best. She always smiled and made jokes. Everywhere she went the sun
shined. She loved white roses, and one day..."

"Did you say white roses?"

"Yes, why?"

"Because, I used to put white roses on the night stands. I stopped when they got
too expensive."

"Oh, yes, she never knew why she loved them. We did if off as just being a thing
you can't explain."

"That could be it."

The next day I received a call from Brady telling me where I could find
Bridget's mother. I still held on to the idea it all being a coincidence, but
somewhere deep inside I knew it couldn't be. My mom had guided me here, to bring
closure to an old wound.

As I walked up the path of the small house with the white picket fence I felt
really nervous. I rang the doorbell and an old woman with long white hair in a
bun opened the door. When the woman saw me she almost fainted, but was able to
keep standing "Bridget? Bridget? Is that you?"

"No, my name is Laura. But my mom might be."

"You look so much like her. How? What? Oh, do come in, come in."

We walked to the back of the house and sat down on a patio overlooking a small
garden. I almost cried when I saw the white roses.

"Want a lemonade, my dear?"

"That would be lovely, thank you."

The woman came back with two lemonades and I was amazed by how quick she was.
She had to be at least 70 or something. The woman sat down and said "Oh it's so
nice to see you. I don't get many visitors anymore."

I smiled and said "Pardon me, but we've not introduced ourselves. I'm Laura,
Laura Bailey."

"Oh, you can call me Olivia, Olivia Thompson. But please call me Olivia, or
Olive like the used to do."

"Alright Olive, thank you for the lemonade. I'm staying at the hotel in town and
I saw a picture of Bridget. It was like I was struck by lightening, she looked
so much like my mom. I just have to know."

"Oh, yes. Dreadful day that was. We didn't live here back then, we were on our
way to go somewhere else. My husband, Joe, had found a job and we needed to move
close by. But as it was getting dark we stayed at the hotel for a night. When we
woke up Bridget was gone. Nowhere to be found. They searched for days, the
police, my husband and all the other men in town. But she was just gone."

"Now, I want to show you something." I opened my laptop and showed her a picture
of my mother holding me as a baby. "This is two days after I was born. It's the
oldest picture I have of her. She told me she lost everything in a house fire,
but I don't know whether that's true anymore."

Olivia almost screamed "That's her. That's Bridget. That's my daughter, oh
please tell me I can see her."

I had tears in my eyes when I told her my mother had passed away. I told her
everything I knew about that night I lost my mother. Olivia cried and I felt so
sorry for her. In front of me was a woman who had lost all hope of ever seeing
her daughter again. I knelt in front of her and put my arms on hers.

Olivia opened her arms and held me. "Oh, at least I've found you. My
granddaughter, at least I finally found you."

Olivia insisted I stayed for dinner and I gladly accepted the invitation. Olivia
talked about her live, about her son and daughter who were born after Bridget.
About how good her live had been despite the loss of her daughter. I just sat
there an listened.

"Olivia, thanks for everything. And I will be back soon so we can take that DNA
test, as I said, it's just to make sure. Definite proof we are related.
Goodnight, grandma."

"Good night, grand daughter."

A few days later I returned to take the DNA test and was surprised to the door
being opened my a woman in her late 30s. "You must be Laura, come in. My name is
Jennifer, come in." I walked in and the woman asked me to sit. "I need to talk to
you." she said.

"When my mother told me about your visit I was livid. I was sure you ware taking
advantage of her and I even called the police about it. But then Brady told me
how white you were after you had seen that picture. And now that I see you, you
do look a lot like Bridget in that picture." she said.

"Look, I'm sorry. But when I saw that photo I just had to find out. And although
your mother might be convinced, I still have my doubts. That's why I want to do
this test. If we are not related, I still need to know why they looked so much
alike. Bridget and my mother I mean. It can't be a coincidence. The fact they
both liked white roses, the dimples in their cheeks, there's just too much."

"Yeah, you're right. But remember, if you take advantage of my mother I will
come after you like a ton of bricks. I am a lawyer and I will destroy you."

"Then I'm a warned woman and I will proof that I don't have any ill intentions."

"You should be a lawyer or a politician. You are a smooth talker and I don't
trust smooth talkers, I am one and I hardly trust myself." she started to giggle
and the ice was broken.

It took two weeks for the results to come back. Olivia and her children were
sitting in the living room staring at me. "Now", I said, "I haven't looked
either. So this will be news for all of us." I opened the envelope and took out
the letter.

_Dear Miss Bailey,

We tested the swabs for maternal DNA. This DNA sequence is passed on from mother
to daughter and gives us a 94+ percentage of certainty. After testing the two
swabs you sent us we are certain to a degree of 98.6% that the two swabs contain
familiar DNA.

If you have any questions..._


"What does that mean?" Olivia asked.

"That means Laura is your grand-daughter, mamma. Laura is my niece." Jennifer
answered and started crying "She's Bridget's daughter." I looked at Logan who
just sat in the corner, he hadn't said a word yet. "Hey, uncle Logan. I'm Laura,
your niece." I walked over to him and held out my hand. He jumped up and took me
in his arms, I could feel him crying. It was the best welcome to the family I
had ever had.

After we all had our hugs we started talking and soon it became dark. We
exchanged numbers and I drove back to the hotel. When I walked in I told Beth
the results and she was elated. "You don't have to pay me anything. You can stay
here as long as you want. I am so happy, for you and for Olivia. This calls for
soup."

I knew better than to decline and we sat down at a table. "So what are you going
to do now?" Beth asked.

"I'm going to find answers. What happened that night? Where did my mother go? Do
you still have the books from back then?"

"I've kept them all. From the day we opened."

"Would it be okay if I looked at them?"

"Go right ahead."

As Beth was cleaning the table, I looked behind the counter and found the book
of that year. I checked the data and copied all the names and room-numbers. With
my index-finger I went over the entry _Bridget, 6_.

After a restless night I went to the library and looked through old newspapers.
After a long search I found a huge article dedicated to the disappearance and
the search that ensued. My heart skipped a beat when I saw that same photo
again. But the article gave me no new clues.

It was infuriating and it was time to call my best friend. When I was finished
Marisha was very quiet for a while. Then she said "I might have an idea."

"What?"

"No, I can't through the phone. They might be listening."

"Who?"

"The illuminati! The ones that control everything."

"Marisha!"

She started laughing. "I just had to. It's such an unbelievable story, Laura.
Not that I don't believe you, but someone had to make you smile."

I started to giggle. She always knew how to make me giggle.

"Look on a serious note. Are you really going to pursue this?"

"Yes, I have to. I need to know. I owe it to Olivia and her children. Oh, I my
grandma I should say. It's so unreal still. And I owe it to my mother."

"Okay, just be careful, you don't know what's been going on."

"I will, thanks."

For the next weeks I chased every name from the ledger, only to find out all but
one had passed away. The only one living was a man called Hank, Hank Williamson.
He should be around 60 now and although he was just a young boy back then, maybe
he'll remember something.

After a phone-call he agreed to meet me in a public park. I got up early and
drove 200 miles. On the bench underneath the statue of Lincoln sat a rather
handsome man for his age. His black hair had silver linings and was combed over
backwards. This was a man who took great care of his looks.

I walked over and said "Mr. Williamson?"

"Yes, who's asking?"

"I'm Laura, we talked on the phone."

"Ah, Laura, very pleased to meet you. Please take a seat. You asked about the
disappearance of that little girl, didn't you?"

"Yes I did" and I sat down next to him.

"I was very young back then. I don't know if I can be of much help. But we could
try, come let's take a walk."

He got up and started to walk. I quickly followed him and he told me everything
he could remember of that night. "I remember there was this woman, she took
special interest in that girl. I don't know her name, but she used to work at
that hotel, that I do remember."

"Do you know what she did at the hotel?"

"Oh no, I'm sorry. Chambermaid, maybe?"

"The chambermaid."

"I could be wrong, you know. Now, Laura, you've driven all this way and I
couldn't bare to let you go without offering you a cup of coffee. Would you care
to join me?"

"That would be nice, thank you?"

We entered a beautiful restaurant and Mr. Williamson sat down at a table in the
back. It was quite dark and the only place I could sit was next to him. He
ordered two coffee and I felt his hand touch my knee. I should have gotten up
and just walked away. But something kept me sitting there. Something inside me
wanted him to touch me.

His hand was on my inner thigh when the waitress brought us our order. And just
as she placed down the cups he touched my clit through the fabric of my panties.
I felt myself getting wet instantly. He started rubbing my clit and whispered
"If you want me to continue, drink your coffee. If you don't get up, thank me
and walk away."

I lifted up my cup and as I took a sip I spread my legs a little wider. With a
finger he pushed my pantie to aside and slid his finger along my vagina. I had
to bite my tongue not to moan. I lifted my hips as he slid one finger inside me,
my hard nipples were clearly visible through my tight shirt. I finished my
coffee and he sipped his calmly as he slid his finger in and out of me. I was
sure everybody could hear me sopping.

"Now," he whispered, "take off your panties and hand them over to me."

I looked around to check if nobody was looking and I removed my panties as quick
as I could. Underneath the table I handed them to him. He lifted them to his
nose and sniffed. "These are mine now." he whispered. I just nodded.

"Lean back, lift up your dress and spread your legs open wide. Let them see what
a slut you are." he whispered, "show them what a whore you are."

I slowly leaned back and lifted up my skirt. When it was over my hips I spread
my legs wide. "Wider" he whispered, "as wide as you can go." I lifted my legs a
bit and put one over his lap, I spread my legs wide and I felt myself getting so
wet. "Nice, now sit back and straighten your clothes. If you want to go further
follow me to the bathroom in a minute or two. Otherwise, just go."

He got up and for the next minute or two I was totally confused. What was I
doing? This man had me spread my legs in a restaurant! I should just go. I got
up, took a few steps to the exit and then followed him.

He stood there with his dick out and I locked the door behind me. I walked up to
him, he lifted me on the sink and thrust his pole inside my very wet pussy. Inch
after inch I felt his pole go deeper. I moaned and whispered "Oh, yes, fuck me,
fuck this slut." He pumped a few times and I came all over this strangers cock,
the orgasm made me shiver all over and he kept on pumping. In and out, harder
and harder. I wanted him, I needed him. "Oh yes, come inside me. Come inside
this cum-slut. Oh yes, yes, yes, give it to me." He exploded inside me and I
could feel every wad of cum enter my cum-hungry pussy.

He slid out of me, straightened his clothes and said "Now get out of here. I
told you everything I know." I pulled down my dress, straightened my hair and
walked out the restaurant. In my car I started to cry, what had I just done? I
had just fucked with a stranger. I could feel his cum drip out of me. Halfway
back I stopped at a diner and asked if I could use the restroom. I cleaned
myself as best I could, but could not deny the whole situation had turned me on
and I started to rub my clit. I bit my lip as I came again and cleaned myself
one more time. Then I straitened my dress, sat down and ordered a coke.

As I sat there I felt the cum dripping out of me. It felt so exciting. I started
to smile. 'Maybe I liked it a bit too much' I thought.


