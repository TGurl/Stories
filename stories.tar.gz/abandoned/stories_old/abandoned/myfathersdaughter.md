# My fathers daughter
_an erotic tale by TransGirl_

## A hot summer
We were living in _Wolf Point_ at the time this all took place, it's a small
town and my dad was the local Sheriff. As the cops kid I had it easy, boys
didn't dare to approach me. Which when I got interested in them became a source
of discomfort too.

Wolf Point was a nice place to grow up, but as I got older living in a small
town became confining, there was just one bar, a school and a hairdresser. That
was it. For our groceries we had to go to _Walkerton_ 50 miles down the road. I
used to love it when we had to go to _Walkerton_, they actually had a
drive-through there. To the 10-year old me _Walkerton_ was the big city and
really had a field-day when my mom took me shopping at the mall over there.

When I was 15 I went swimming with my best friend Sophie and when we arrived a
few of the local boys were already there. We went to the other side of the pond
and watched the boys as they swing on the tire hanging from an old tree only to
release when they were halfway the pond.

When one of them landed in the water he almost lost his trunks, Sophie and I
giggled and eagerly awaited him getting out of the water. To our disappointment
he had managed to pull it up again. After about 20 minutes the boys wanted to
get something to drink and asked us if we wanted to join them. We declined and
watched as they walked off.

Sophie and I got in the water, swam for a little bit and then lay in the sun
chatting about the boys, the latest album of our favorite artist and much more.
As we were the only ones there I looked around if I saw anyone and then took off
my top. "Laura!!" Sophie whispered, "what if anyone sees you?"

I might have been 15 at the time, but my body had already developed rather
nicely. The top of my bra was already on the small side and the fabric just
about covered enough. The next day the plan was to go to _Walkerton_ to buy a
new bikini and maybe even a swimsuit. We would see.

"Ah, there's nobody here but us."

I lay down closed my eyes and just enjoyed the sun. When I got too hot I dipped
in the water and just as I was under Colin, who I had a big crush on, came
towards the pond. "Oh, hey girls." he shouted. I was paralyzed, what was I going
to do. There I was in the water topless and now Colin was here. Why him? With
panic in my eyes I looked at Sophie who immediately understood my predicament.
"Um, Colin? Would you mind turning your back? Laura has lost her top in the pond
and she needs to get out and put a shirt on." If looks could kill my father
would have arrested me.

"What? Oh. Need some help there Laura?"

"Um, no, I'm okay, just getting a bit cold in here." I replied and looked at
Sophie with a look on my face 'I don't know'.

"So, basically, if I don't turn I get to see you topless Laura. Is that it? Is
that the deal here?"

"Just to it." I shouted.

"Now, Laura. I know you a little bit. We could both be winners here: you get out
the water and I get to see something special. No. You wouldn't do it anyways,
you would stay in the water until hell froze over. Nah, Laura, I bet you 5
dollars you do not dare walk out with me looking at you."

'Oo, I hate you Colin' I thought. Everybody knew I did not back off from bets,
especially ones which were about me not doing something. Someone bet me once
I wouldn't take a bite from a worm-sandwich. The easiest dollar I had ever won,
I had even swallowed it.

I swam up to him and said "Let's make it 10."

"Laura!" Sophie protested from the other side of the pond.

"Deal."

I began to swim to the other side again and then changed my mind. Right in front
of Colin a placed my feet on the sandy floor and stood up. Exposing my topless
body, the look on his face was priceless. I held out my hand and said "Pay up."
Colin was too flabbergasted to react and couldn't take his eyes off me. I
started laughing and walked towards Sophie, put on my shirt and walked towards
Colin again. He still couldn't believe it. "Now, Colin, cat got your tongue? You
owe me 10 dollars. Pay up."

Colin stumbled on his words "I don't have it on me."

"Okay," I replied, "tomorrow then. Or else, nah I'll think of something." I
burst into laughter and together with Sophie we walked back to her house.

"I can't believe you just did that? You know it's okay to loose bet now and
again, don't you? You don't have to win them all."

"But what's the fun in that? Did you see his face? And I won 10 dollars."

"Laura, sometimes I don't know why I put up with you."

"Ah, you love me Sophie. You can deny it all you want, but you love me."

Sophie started laughing and we hooked arms as we went along the path to her
house. After a refreshing lemonade and some more chatting about nothing in
particular it was time for me to go home. I decided to take the shortcut and
take the path crossing the pond. There was nobody there as it was almost 
dinnertime. As it was still rather warm I decide to take another dip in the
water. I checked if nobody was around and undressed. Totally naked I jumped in
the water and swam for a bit.

When I got out I spread my towel and laid down to let myself dry. It was so calm
and all I could hear were the birds chirping. I almost fell asleep and then
realized where I was. I quickly put my clothes back on, leaving of my bikini
which I dipped in the water to make them wet. Wrapped them in my towel and
walked home.

My dad sat at the kitchen table in his uniform, he had the late shift that night
and already was having his dinner. I kissed him on the cheek and told him I was
going to take a shower. "You've been at the pond?" he asked.

"Yes, why?"

"According to someone they saw a naked girl there. She was sunbathing just 10
minutes ago. That wouldn't have been you, now would it?" My face turned white.
I knew better than to lie to my dad and looked at my feet. "Laura. You can't do
things like that. I told Miss Abrams I would talk to you and although she found
it funny, I don't. I'm the sheriff, Laura, you just can't do stuff like that.
What if one of the boys had seen you?"

I had to admit I was relieved when he told me it was Miss Abrams who had seen
me. She was an old spinster who ran a small animal shelter. She was an old
hippie who had lived in a commune all her life until most of them had passed
away, then she moved to _Wolf Point_, just because of the name. Enough to say
Miss Abrams was a free spirit.

"I know, daddy, I won't do it again. Or at least I will be more careful next
time." I winked and he did his best to conceal his smile, but he failed
miserably. Somewhere deep inside the hardened shell lived that cheeky boy who
unleashed tens of frogs in his school. He hugged me and said "No go shower, you
smell like the pond."

The next day my mother took me shopping and we had a good time. I got a new
bikini, a dress, a nice pair of small heeled shoes and a new purse. My mom had
collected a few bags of herself. On our way back it was time for the traditional
stop at _Chipotle_ and as we sat at the table my mother said "So dad told me
about the little incident at the pond yesterday." I wasn't surprised she knew
about it, mom and dad never had any secrets from each other.

"Yeah, I was happy it was only Miss Abrams."

"Oh, I didn't mean that. I meant something about a bet?" she said not looking up
from her burrito.

"How did you hear about that?"

"Oh, let's say a certain boy got into my practice all excited wanting to talk to
Robert, you know my boss's son? And when I asked him what it was about he
blurted it out. I told him if he ever told anyone about it I would tell his mom
about some things I know about him. And asked him how that would feel?"

"Oh, and?"

"And nothing. He just told Robert he had a new video-game and if he wanted to
play."

"Thanks mom."

"You're welcome. Did he pay up already? If so, then this dinner is on you."

"No, mom, he didn't."

"Darn, well, looks like I'm paying again."

My mom was the coolest and although she in some words told me off, she did it in
the nicest way. And she proved she always had my back. "Just one thing, Laura, I
was your age once and just be careful, okay hon?"

"Yes mom, I'll be careful."

Sometimes it was nice when your dad is the local Sheriff and your mom a local
lawyer. And although they both represented the law now, that hadn't always been
the case and my grandparents have told me stories about the problems the both of
them would get into, especially when they were together. The whole town knew
better than to lie to either of them, they both had a sixth sense for it.

That evening I went over to _The Upper House_, the local bar. They also had a
small ice cream parlor in the back. When I arrived I saw Colin sitting there,
his face turned red when I saw him and I felt a bit sorry for him. Sitting next
to him I said "Okay Colin I'm sorry for yesterday. I shouldn't have taken that
bet. Please don't be mad at me."

"Mad? Why should I be mad? You won fair and square. I was about to tell Robert
but your mom stopped me. Maybe for the better, Robert would have told everyone
about it. And that's the last thing I want."

"Thanks. What are you having? Looks good."

I walked to the counter and rung the bell. With my cone in my hand I walked back
to Colin. We started talking and then walked down the _Old Trail_, a hiking path
that ultimately ended in _Walkerton_. At a bench we sat down again.

"This is nice." I said.

"Yes, it is. Laura, can I ask you something?"

"Sure. What?"

"Yesterday, at the pond, why did you take that bet?"

"I don't know. I really don't. I don't like loosing, I guess."

"Yes, maybe. But the thing is, Laura, I like you. A lot." Colin looked at his
feet as he said it. My heart started beating faster and butterflies rose up in
my stomach. Did he really just say he liked me? He did.

I stared at him and at the moment he looked at me I kissed him. He was startled
at first but then kissed me back. His hands gripped the bench firmly and I
turned away giggling. He also didn't know how to act. We looked at each other,
kissed again. He raised his left hand a bit and my heart was racing. He touched
my cheek and said "Wow, Laura, I would never have believed."

I smiled and said "Yup, ever since we got the same classes. Hadn't you noticed?"

"No, I hadn't"

"Yup, Laura likes a boy." I giggled.

We got up and skittishly our hands touched as we walked back down the trail.
Just before the clearing we let go and walked the rest of the way as normal as
possible. When I got home my mother knew something was up and came into my
bedroom. "Laura, something has happened. Tell me everything."

"Oh mom, it was so nice. Collin and I walked down _the old trail_, then we sat
on a bench and talked. The we kissed mom, we kissed. I've kissed a boy, mom. It
was so nice."

My mom laughed and hugged me. "I'm so happy for you, Laura. I remember my first
kiss. Nothing like that though, we played spin-the-bottle and it was Louis, the
fat kid, really nice but he had an weight-issue back than. Now he owns a gym, as
far as I know. Funny how that works." We laughed and chatted for a while.

Before I went to sleep my dad popped his head around the door and said "Want me
to arrest him?" I laughed and fell asleep.

For the rest of summer Sophie visited her grandparents, Colin and I spent more
and more time together. One day we went up to the old Millers house, an
abandoned house deep into the woods. We looked through the windows at the dusty
furniture that was still inside. Colin tried the door and was surprised when it
opened.

We walked through the house a bit and looked at the picture of _old man Miller_
that still stood on the fireplace. The house was abandoned when the old man
passed away almost 20 years earlier. We walked out and carefully closed the
door. Slowly we took the path leading back only to down on the grass on top of
the hill overlooking _Wolf Point_. The town had gotten his name from this hill,
if you squinted your eyes it resembled a wolf's head.

We were quiet for a while and we kissed. Colin didn't know where to put his
hands, so I took one and placed it on my right breast. A shock went through my
body feeling a different hand there. I pressed my mouth against his and for the
first time our tongues touched. As we went along we got more passionate and we
both started to breathe heavily.

His fingers were on the buttons of my dress and was looking at me. I nodded
slightly and one by one he opened my dress. Feeling his hands on my skin sent
shivers down my spine and he squeezed my boobs a bit. Trying not to hurt me he
touched them carefully. We kept on making out and I felt his hand going down by
belly in between my legs. My whole body reacted and shrugged away from this
sudden very intimate touching.

Colin pulled away and stared at me. "No, keep going. It's just, well, it's my
first time." I explained. He slowly put his hand back and I inhaled deeply when
he touched my clit. A wave of pleasure went through my body and I spread my legs
a little. It was like my hand had a will of it's own and I touched the outside
of his trunks. The moment I felt it I shrugged back and moaned loudly as Colin
slid a finger inside me.

I grabbed his hand and said "Not here, what if anybody sees us. I can't do this
here." I got up straightened and buttoned my dress. I felt so embarrassed by all
of this. Colin held me from behind and whispered "I don't mind. When you are
ready it will happen. Until then I'll wait, Laura, I'll wait." I turned to him
and we kissed. I ran home after pushing him away, tears in my eyes. I was
certain this was it for Colin and me.

When I got home I stormed into my room, closely followed by my dad. "Laura,
what's up? What happened?" I just buried my head in my pillow and cried. My dad
put his hand on my shoulder and I shrugged away. This made him even more
worried. "I'll call your mother," he said, "maybe it's better if you talk to
her." He left my room and I started to cry uncontrollably.

I have no idea how much time went by but suddenly my mother sat on my bed and
put her hand on my shoulder. "Laura? Are you awake? Laura?" she whispered. I
turned over and put my head on her lap, she played with my hair. "Oh Laura, what
happened? You know you can tell me anything, anything at all. Please Laura, you
are worrying me."

"It's just," I tried but I could not get myself to sharing, "Nothing"

"No, Laura, there is something. It's not like you to be so upset. Did anything
happen with Colin?" I shrugged and she continued, "That's it, isn't it? Did he
do something you didn't want to? Did he go against your wishes?"

"No, mom, he didn't. I wanted it too, but not there. Not on top of the hill. I
pushed him away mom and ran. I am sure he doesn't like me anymore, just because
I couldn't do those things."

"Oh, Laura," my mom said, "it's so hard for a girl, for most girls at least. And
then to even do it out in the open. No, Laura, I understand and you did good.
You didn't give in and stood your ground. If he really likes you that will be
okay. Maybe he even likes you more now. Come, scoot over." My mom lay on the bed
and took me in her arms.

"First of all, we don't tell dad any about this. You're still his little girl,
but I've been a little girl too and I understand. You want to explore, you want
to try things out and that's good, you're learning. What you want, don't want,
what you like and don't like. And to always listen to yourself, never give in to
what the other wants."

"Secondly, I will call our doctor. We are going to get you on birth-control.
That doesn't mean you can't get pregnant, but the chances go down drastically.
Um, no buts. That's going to happen and I will talk to dad about it. Don't
worry, this is going to happen. Believe me."

Her hands going through my hair felt good, I calmed down. "But mom, aren't you
angry?"

"Why should I be? You're growing up, you are becoming a woman and this is part
of it. You don't think I had it easy, now do you?"

"I don't know."

"That's true, you don't. Well, let me tell you. His name was Steven, Steven
Donowitz, and I had the biggest crush on him. The day he asked me to prom was
the best day in my life, up until then at least. I've had two best days, the
first one was the day I married your father and the other was the day I held you
in my arms for the first time. I had never known how deep love can be until I
had you in my arms. Now back to the story." She told about how nice her prom was
and how they kissed. How she though she was ready, but wasn't and how she caved
in because she wanted to please him. How she struggled the days after until a
teacher told her, that everybody has bad dates and that it's normal to have
regrets. "Mind you I didn't tell her about the s.e.x. part."

I giggled when she spelled sex and my mother smiled "There she is, there my
daughter. Oh Laura, don't you ever tell your father about this and I will keep
this between us, okay? Pinky promise."

"Pinky promise."

"No, go freshen up. Dad has dinner almost ready and you know how he gets when
we're late. Hop, bunny, hop into the shower and I'll see you downstairs."

During dinner my mother said "Oh, I've made an appointment for Laura to see Dr 
Michaels tomorrow. Don't worry, nothing is wrong, we're just getting Laura the
pill." My dad almost choked and mom burst into laughter when she saw his red face.
She looked at me and winked "Couldn't resist." I just giggled and when dad caught
his breath he said "You could have coached me a little bit. But, yes sure. I guess
it's time. My little girl is growing up."

The next day I ran into Colin at school and he apologized for what happened.
"It's okay I said, I'm just not ready I guess. So please forgive me if I hurt
you, I didn't mean to." I replied.

"It is me who needs to say sorry. I pushed you to far and I shouldn't have done
that. So, are we good?"

"Yes, we are."

"Good, because I really need some help with Math."

I laughed and we sat down at one of the tables in the courtyard and I helped him
study. When it was time to go to our next classes I had agreed to come over some
day and tutor him. The rest of the day flew by and we went to the bar to buy an
ice cream. Sophie had returned and joined us. At dinner I told mom the good news
ad she was so happy for me.

Nervously I knocked on the door of Colin's house, I had promised to come over
and tutor him. His father opened the door and said "Ah you must be Laura, come
in. Colin is upstairs in his room, first door on the left. You'll find it."

"Hello Mr Marcaeu."

"Oh please, call me Tom. I'm not my father." he laughed. He must have been in
his late thirties, but to me he looked old. He wasn't bad looking, in fact he
was quite handsome. His pale blue eyes contrasted his sun-burned skin. His hands
showed clearly him being used to rough work and his smile was disarming. He
walked by him and went up the stairs. The first door on the left was clearly
marked by a sign: Colin's Room - Stay out!

I knocked and Colin opened. He invited me in. His rooms showed signs he had done
his best to clean it, but it was still a mess. At his desk there were two chairs
and his books were opened. On his computer a game was on pause, so clearly he
had found other priorities. "Sorry for the mess. I did clean up." he said.

"We should start." I said and sat down on one of the chairs. We spent the better
part of an hour doing our homework and I helped him with Math as he helped me
with other things. Then we both became quiet and looked at each other. Our lips
met and then our tongues. He moved in closer and placed his hands on my legs. I
felt a slight panic coming over me, but I remembered the words my mom had said:
_Only do things if you want them too_. And I wanted this.

He took my hand and took me to the bed. I lay down and he came down next to me.
His hands touched me and I shivered. Then he lifted the seem of my shirt and
placed his hand on my belly. I stared into his eyes as he slowly moved upwards
to my breasts. "What about your parents?" I whispered.

"They don't care, relax, it's okay. If you want me to stop I will, okay?" he
answered. With his finger he lifted my bra and slid under it. When he cupped my
breast I gasped for air. It felt strange and really good at the same time. Sure
my mom or my doctor had touched my breasts, but this was different. This was a
boy touching me there.

Colin moved in closer and kissed me again. I turned my upper body towards him
and kissed him back. My hand touched his groin, but instead of pulling it away I
kept it there. He proceeded with taking off my shirt and I felt a bit embarrassed
to be in his bed wearing only my bra. He caressed my skin with his hands sending
pleasure signals through my body. I started to enjoy his attention. When his
hand was on my belly again he turned is so his fingers were pointing down to my
private area.

He made his way down and slid under the seems of my summer pants. The elastic in
my waist-band didn't give much resistance and he kept on going. He wriggled his
fingers a bit when he reached my panties. Soon enough his fingers touch my clit
and I moaned loudly the moment he did. Automatically I spread my legs and he
slipped one finger in between my labia. The moment he slid one finger inside me
I pressed my mouth firmly against his pushing my tongue deep inside his mouth.

With ever move of his finger I got more and more wet. He added another finger
and pressed the palm against my clit and began to shake his hand. I thought I
went crazy and started to move my hips. I didn't want him to stop I placed my
head next to his and softly bit his shoulder only to fall back on the bad as my
whole body started to spasm and shake. There were tingles all over my body and I
pulled his hand away from me. I groaned, moaned as the orgasm rolled over my
body. Colin got up and undressed me. I didn't care anymore, I wanted more of
this.

But all he did was undress. I couldn't stop staring at the pole between his
legs. I had never seen one in real life before. How could boys even walk? I
turned on my side and with one finger I carefully touched it. I felt soft and
warm. "You can grab it," he whispered, "it won't hurt me." I looked at him and
then back to that pole. Nervously I placed my hand around it and just squeezed
it a bit, constantly checking if I wasn't hurting him. "Now just move your hand
up and down." he whispered.

I followed his instructions and looked at him while I was doing it. "You can
hold it a bit firmer and go a bit faster" he said. The feeling of holding a
stiff penis and making him feel good was very pleasurable for me, so I
discovered. He started to moan and then suddenly pushed me on my back rolling on
top of me. My heart started racing as I felt his penis head push against my
labia. As I was dripping wet the tip went in a bit. I spread my legs and
whispered "I am ready, but please be gentle."

Colin pushed forward a bit and I felt my labia separate. As he went in deeper I
bit my hand to suppress my screams of pain. "Is it okay?" he asked. I nodded, I
wanted him to continue. It went on for what seemed aged, but finally he rested,
his penis was now all the way in me. No longer was I a virgin and I started to
cry. "Am I hurting you?" he asked and started to pull out. I placed my hands on
his hips and pulled him back in. I shook my head and said "No, but please don't
move for a while."

As the walls of my vagina stretched the pain subsided and it started to feel
good. Really good. I loved the feeling of a penis inside me and slowly I started
to move my hips. Colin took this as a sign he could move to sending pain signals
through my body, but with every thrust those subsided and what remained was the
feeling of his penis sliding in and out. With every thrust it started to feel
better and my fluids started to flow. "O god," I whispered, "you are fucking me,
Colin, you are fucking me."

After just a few minutes Colin pulled out and ejaculated all over my belly. The
feeling of his warm seamen on my skin send different vibes through my body. I
had never seen a boy come before and I was mesmerized. With my finger I started
to play with the white fluids on my belly. I got a glimpse of the clock and
realized I had to go home.

We quickly cleaned up, I got dressed, grabbed my stuff and ran out the door.
"Bye Tom, I got to go home." I shouted and Tom just waved. When I rushed home I
was sure everybody could see what I had just done and I felt somewhat proud of
it too. I greeted my dad and went straight to my bedroom. Put my stuff away,
grabbed a towel and took a shower. So far it wasn't out of the ordinary, I did
that more often especially during the summer. During dinner on the other hand my
mother kept looking at me and she had a bit of a smile on her face.

After dinner I was in my room reading a book for school. My mother came in,
closed the door and sat on my bed next to me. "Laura, you know you can't lie to
me, so just tell the truth. You had sex, didn't you?"

"Oh mom, it was so nice."

"Wow, a 16 year old boy who is nice during sex. That's a new one. But I am happy
for you. Want to tell me about it?"

"Mom!" I said firmly, "I don't ask about you and dad, do I?"

"Touche, but you were careful, weren't you?"

"Yes mom. And I'm on the pill now, remember?"

"Yes, but as I said, that's not a 100% guarantee. So you still need to be
careful."

"Yes mom."

"Oh, Laura. You are becoming a woman, so happy for you. But let's keep this a
secret for dad too. Let's let him believe you're a virgin for a while longer."
She hugged and kissed me. I couldn't concentrate on my book anymore my thoughts
kept going back to Colin, that bed and what had occurred in there. This afternoon
I had left my house a girl and returned a woman.

## Revelations
During the next months and all through summer break Colin and I enjoyed each
other almost every day. At first only in his or my bedroom, but after a while he
started to suggest we should make it a bit more exciting and he would cup my
breasts in more public settings. But I clearly stated I didn't want that so he
stopped. He did tease me, but that led only to a more passionate session behind
closed doors.

As I came over on a more regular basis his mother told me to just walk in the
backdoor. As was appropriate around where I lived I always announced my arrival
and so I did the same on this day. "Hello, Laura here." I shouted. Nobody
replied. The kitchen, the living room were empty and there was nobody outside
either.

As I walked up the stairs I could hear someone showering. When I reached the top
I saw the door being ajar and through the slit I caught a glimpse of Colin's
father. It was if I was nailed to the floor, I couldn't move and couldn't stop
looking either. I saw the outline of his body through the steamed up glass and
heard him turning off the water. When he stepped outside I clearly saw his penis
and how large it was. For what must have been seconds, but seemed like minutes
to me he just stood there drying himself with a towel.

I turned away my head and rushed down the stairs as quietly but quickly as I
could. I rushed to the kitchen and once there I shouted again that I was there.
"Oh hey Laura, just a moment I'm in the shower. Be right there." it sounded from
upstairs. Anxiously I sat down on one of the stools by the bar separating the
kitchen from the living room. My heart was racing and it seemed to take for ever
before Tom appeared. "I'm so sorry, Laura, but Colin isn't home. He and his mom
went off to see his grandmother in hospital. As a matter off fact I am going
over there right now. You can come too if you want to. It's up to you."

All I wanted was to get out of there so I thanked him for the offer and told
him I wished her all the best. On my way home I couldn't believe what I had just
seen and I felt myself getting wet a bit. Luckily Colin's grandmother was
released a few days later, but I felt a bit anxious every time I went over
there. Something had changed and I couldn't look at Tom in the same way any
longer. But as time went on that subsided a bit but never left me, there were
still moments when I looked at him differently.

Colin and I had the typical on-and-off-again high school relationship. There was
always something pulling us back together again. In the off periods I would get
these urges and would feel myself getting wet whenever I would see Colin. The
moments together were like fireworks: fast, passionate and explosive.

When I turned 17 my body hadn't stopped growing and I knew the boys were looking
at me, it made me feel uncomfortable and flattered at the same time. My dad
understood I wasn't a virgin anymore and he had a tough time accepting it, but
finally he did. It was the last year of high-school and I concentrated on finals
and choosing a college. Colin and I didn't see each other on a regular basis
anymore, but still remained friends. This time with benefits, as they say.

My dad needed some help around the police station and I started answering the
phone. It was just for a few hours a day and I earned a few dollars with it. But
still I felt so proud when he handed me my first pay-check. Together with Sophie
we went to the mall in _Walkerton_ and spend it on clothes.

"So, got an idea which college?" she asked.

"I'm not sure yet, you?"

"Oh, community college I guess."

"I've enrolled in Duke and Harvard. But I'm also thinking about M.I.T."

"Wow, look at you miss prestigious university." she said with a wink.

"It was more the dean's idea than mine. I will probably join you in community
collage. I'm not that smart."

"Yes you are. Why else would they recommend it for you?"

"But it's so expensive. I couldn't do that."

"Yes you could and you should. But please, keep on being my friend."

"Oh, you'll never get rid of me. No matter how you try." I laughed.

On our way back we passed my dad, I waved until I noticed he was directing
traffic pass a big accident. A truck had rolled over and luckily driver sat near
an ambulance holding his head. The road was littered with produce and Sophie had
to steer carefully around it. "What a mess," I said, "I'm glad he's okay."
Sophie nodded and kept her eyes on the road.

The next thing I remember is waking up in the hospital. My mother sat beside my
bed holding my head. The beeping of the machines sounded so loud to me and I
groaned. "Laura?" I heard my mother from far away. "Laura? Are you awake?" With
my hand I touched my face and felt a tube in my mouth. I started to panic and
cough. I wanted to pull that thing out of me.

Before I knew it I was surrounded by nurses telling me to calm down and one off
them removed the tube. I coughed loudly as my airway was freed of the tube and
spat in a bowl the held in front of me. I took a few deep breaths. "Where am I?"
I panted, "What happened? Where is Sophie?"

My mom pushed me down in the bed again "You're in the hospital, Laura. Sophie is
in here too. There was an accident. Relax. You're going to be okay."

"And Sophie? I want to see her. I want to see Sophie."

"In time, Laura, you need to get stronger first. You need to get better."

One of the nurses turned a valve and everything went black again.

When I opened my eyes I saw my dad sitting in the chair. "Hey dad" I whispered.

"Laura! You're awake again."

"What happened dad? How's Sophie? I want to see her."

"In time, Laura. You need to get well."

"No dad, I want to know. Tell me. Tell me the truth, dad."

"Okay, okay, do you remember that truck? When you waved at me?"

"Yes, nothing much after that but that I do remember."

"Well, as you were passing that truck a car came from the other side. He was
driving way too fast and," he looked down and it was clear he had seen
everything, "he hit you." There were tears rolling down his cheeks. "We were
able to get you out, but Sophie got the brunt of it. She was stuck and it took
us a while, but we got her out too."

"So she's not dead?"

"No, but we don't know if she will ever walk again. Her legs have too much
damage, they were able to safe them, but she's still in critical condition."

Tears rolled down my cheeks. "I want to see her, dad, now. I need to be with
her, she's my best friend and I need to be with her. Please dad."

"I will ask the doctors. I'll do my best, but we have to wait until mom comes
back, she went home to take a shower. She should be back any minute."

The doctors cleared me to visit Sophie and I don't know why or how, but she woke
up for the first time when I held her hand. Her mother started crying and her
father just looked at me and whispered "thank you." Sophie had to recover for
quite some time in the hospital and then went on to learn how to walk again. She
surprised me when at one of my visits she got up out her wheelchair and made a
few steps on her own. Just before she lost balance I caught her and hugged her.
I knew then she would be alright.

The man in the other car was convicted of reckless driving and driving under the
influence and my mothers office sued him for everything he had. But there was
nothing to get, my mother just needed her form of revenge.

Me? I had severe migraines for months after the accident and I couldn't
concentrate for long periods of time anymore. Going to a prestigious college was
out of the question as I had to do my finals all over again. When my dad caught
me drinking my pain away he scolded me and pushed me to do better. I just had
such a hard time coping with what had happened. As quickly as Sophie had given
it a place, so hard was it for me.

The migraines eventually went away, but the concentration problems didn't. I
just had to get used to it. My parents tried their best to cheer me up and
gifted me a subscription to audio books. But it just wasn't the same. When you
read your imagination fills in everything, from the surroundings, to the clothes
and also to the voices. Hearing an actor doing those voices just wasn't the
same to me.

One day in school something triggered an enormous migraine attack. I fell out of
my chair and a very startled teacher called the school nurse. I was laid down on
a bed and she covered my eyes with a towel. I took almost 30 minutes for the
pain to go away and I just felt nauseous. The nurse advised me to go home and
rest. One of the other teachers dropped me off and asked if you would be
alright. "Yes, thanks. I will see you tomorrow." I said.

As I walked in I was a bit surprised to see my mothers car. But didn't think
much of it have been a coincidence. She sometimes had to pick up stuff for work
that she really needed. Fully expecting to see her rushing through the house it
was eerily quiet. I checked the living room, glanced in the dining room and the
study. When I reached the stairs I heard noises that I couldn't place. As I
walked up the noises became louder. It was almost like someone was having sex. I
took off my shoes and sneaked the last bit. The sounds were clearly coming from
my parents bedroom.

The door was ajar and through the gap I saw my mother on her hands and knees,
she moaned "yes, yes, oh go on, don't stop, make me come." I moved my head so I
could see the one behind her, fully expecting to see my dad. But he wasn't my
dad, my mother was having sex with her boss on her marital bed. I was shocked to
see how my mother was cheating on my father with her boss. I pushed the door
open and shouted "Mom! What are you doing?"

In total shock my mother looked at me, I stared at her and at the man who had
his hands on her hips. I turned around and stormed into my bedroom. I jumped on
my bed and I really wanted to cry, but I couldn't. The image of my mom having
sex both revolted and excited me. Her face filled with pure pleasure turned me
on, but still she was cheating on my dad.

A few minutes later I heard her say "so sorry, yes, go, go, just go" and she
then knocked on my door and came in. "Laura?" she said, "Laura, honey?" I turned
my back to her. I didn't want to see or hear her. "Go away." I shouted. "Laura,
please. Let me explain." she said.

"What's to explain? You are cheating on dad. And with that old man? God, mom, I
think I know exactly what's going on."

"Okay. That's not what it is, honey. You may turn your back on me, but I'm going
to say what I need to say. When I'm done I will leave you and you do with it
what you want to do. All I want is for you to listen. Just listen. Can you do
that for me?"

"I guess I don't have a choice. You're going to talk anyways."

"Yes I am. Now. Two years before you were born your father and I went through a
bad patch. We were married for a year and almost got divorced. Your father was a
rookie cop and I a young lawyer. We lived in _Walkerton_ in a very small
apartment."

"Yes I know, you showed me. Come to the point already, so I can think about what
to do."

My mother ignored my protest and continued "During one of our fights we told
each other the truth. I didn't feel satisfied and thought I was too closed
minded. Anyways, that fight made us talk, really talk. Your dad told me how he
fantasized about me being with another man and I told him he was crazy, ready
for another fight. But then he took me in his arms and said that it wouldn't be
cheating, he would give me permission to sleep around. Just as long as I told
him everything or if he could watch. The first time your father held my hand,
the second time he sat in a chair next to the bed. He pulled away farther every
time until it became normal for us. Sometimes he would watch a football game
while I prepared to go out with another man. I would kiss your father and he
then wished me fun. Ultimately I didn't come home during the weekend. I would be
in a hotel room attending a party."

"I crossed many boundaries and started having unprotected sex. I even stopped
taking the pill. Then I got pregnant and I had no idea who the father could be.
Right after you were born we took a paternity test, I just had to know. And
although he would have loved you all the same, so did your father. To our
relieve the test came back positive, my husband was and is your father. There's
no doubt, a 99.8% score is the best result possible."

"That whole situation shook us to the core. I stopped for a few years, but
couldn't stop thinking about other men even if I was with your father. So we
decided to pick it up again, but this time we recorded it. Just so your father
could watch it afterwards. I can't say anything else but I love your father very
much and he loves me so much he gave me the freedom to fulfill my needs. Needs
he alone could never fill. So, technically I am cheating, but your dad knows and
even encourages it. Do with this what you want. I'm telling you the truth and I
wished you hadn't found out this way, but that can't be changed."

She got up and walked to the door "I'll be downstairs if you want to talk about
it. If not? Then we'll see. I love you, honey, I love you so much." She closed
the door behind her and her words echoed through my mind. I just couldn't stop
thinking about it. 'Dad was okay with this?' I turned on my back and stared at
the ceiling. Her story sure explained why I felt these urges, why I just
couldn't stop thinking about sex.

My mom sat on the couch with a blanket around her and a glass of wine in her
hand. I crawled up to her and she opened her arms. She put the warm blanket over
my shoulders and said "hey little sunshine."

I listened to hear heart beat for a minute which calmed me down a lot. "So dad
is okay with this? Why?"

"He just likes to see me with another man, I guess."

"But why?"

"You would have to ask him. I don't understand, really. All I know is how I
feel. That's what I tried to explain."

"Yeah." I was quiet for a while. "Mom? Could it be I'm like you. I sometimes
can't stop thinking about it until I've done it. Until that need has been met.
Do you feel the same way?"

"That's it, darling, that's how I feel. Sometimes I had been with your father
and I just wanted, no needed, more. We tried to do it more than once or to make
it more exciting in other ways. We even tried role-play, but the only thing that
worked was this. After we started this your father and I never fought again, we
both are happy. Your father trusts me enough to let me go, because he knows that
at the end of it all I always return to him."

She looked at me and continued "Your father is the love of my life, he gave me
the most precious he could ever five: you. He made me a wife and a mother. He's
the one for me. The others are just sex, lust, nothing more or less. They don't
mean a thing to me. I might kiss them, hold them or even have sex with them. But
they are the ones I leave every time. But your father? He is the one who I
return to, he is my rock, my home, my everything. There might be a quite a few
men I've had sex with, there is only one who make love to. That's your father."

"I think I understand." I whispered.

"Oh, Laura, I wanted to tell you for so long. I just didn't know how or where to
begin. I'm sorry about the way it went, not about the fact it happened. You
needed to know, for a long time. At least now I can be open and honest about
this and that makes me happy."

"Mom?"

"Yes"

"Is it strange for me to feel a bit aroused by seeing you, you know, having
sex?"

I could feel she was a bit shocked by my question, "Where you?"

"A little bit. If it had been dad I don't know what I would have done, but until
that moment I just, ah I don't know. Forget it."

"To answer your question. Maybe it were more the sounds, the smells of sex. Not
that it was me. Sometimes when I smell something, let's say in the mall, that
reminds me of sex I feel a bit aroused too. Other times it's hearing a woman
pant as she us running on the machine next to me at the gym. I think it's
something like that."

"That could be true. Mom? I love you, mom. And I think I understand now."

"I love you too, pumpkin. I love you so much you will never know. Maybe when you
have a kid of your own someday. In the far, far future. I don't want to be a
grandma yet, you hear?"

I laughed at the idea and didn't want to think about being a mom. My mom held me
a bit tighter and we just laid like that for a long time.

## Mistakes were made
It had been a year since the day I learned the truth. My mother had shown me the
paternity test when I asked her to and I had finally finished high-school a year
later than planned. Colin and I had finally broken all bonds and he had moved to
another city to attend college.

My concentration problems were still there but they had gotten better, at least
I could read a book again. Maybe not as quick as I could before the accident,
but I could read them again.

Both my parents were more open about what was going on and as time got by it
became easier for me too. It was nice to see her come home with a glow and a big
smile on her face. The only thing I heard was "it was just the best, he was so
good" or "man, I'm exhausted. He wore me out". The details she kept for my
father. And I was perfectly happy with it.

I enrolled college in _Walkerton_ to with Communications as my major and because
of my injuries they allowed me to take it a bit slower. It was hard for me to
read a chapter at a time or to remember what I had read. I did the best I could
and my grades weren't that bad.

I had tried to live in the dorms, but I couldn't study there at all and I didn't
want to move back but there was no other way for me. As soon as a small house
across the street came available my parents bought it and surprised me with the
keys. We took our time redecorating and it was in dire need of some repairs.
Eventually I could move in and make it my own.

When they finally connected _Wolf Point_ to broadband internet I was one of the
first to subscribe as I needed it for college. Finally I had access to the same
resources as my fellow students and my grades improved a bit. It was on a Friday
night and I was browsing the internet as I was bored. I wanted to know more
about a site I had heard about.
