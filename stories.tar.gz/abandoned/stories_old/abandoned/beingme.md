# Being Me
_an erotic story by TransGirl_

## Instructions
As is often the case how it all started is unknown to me.  But that it happened
is a fact of life. Do I regret this fact? Not really. It's a way of life for us
and we fully agree to it. If at any time someone indicates they do not agree
they are free to stop. Some might leave but most of them stay as we do provide a
meaningful way of life.

At the age of six I learned of the special status of my father. I knew already
he was important, but I didn't know he was that important. Sure he was leading
prayer every Sunday, but I just thought it was something he liked to do.

It was just after 7PM when my mother entered my bedroom. It had to be because I
had to be in bed at 7PM sharp. Not a minute later. She sat down next to me and
combed my hair with her fingers.

"Laura," she said, "what I've got to say is important. You must listen to me and
you will have to listen carefully. Do you understand?"

"Yes mother."

"Now, again this is important, you're almost seven now and that's an important
age for a girl. It means you are becoming a woman. To indicate you are you will
have to follow some rules. Those rules are very important. Those rules come from
the holy messiah who now rules our lives. He, hallow be his name, may not be
named as that is blaspheme and will be punished severely. Do you understand?"

"Yes mother."

"What this means from the day you turn seven is that you can only refer to him
who gave life to you as _his holiness_. You may not look at him or touch him if
his holiness has given you permission to do so. Do you understand?"

"Yes mother."

"On the day you turn seven you will not receive physical presents anymore. Those
are signs of the devil inside us. We need to do everything in our power to
squash that longing for material wealth. If we don't succeed in this battle
inside us, there will be no place for us in heaven. Do you understand?"

"Yes mother."

"On the day you turn seven you will be asked a very important question. The
reason I'm telling you this is to give you time to think about this. You will be
asked whether you enter this way of life of your own free will. His holiness
will tell you you can leave at anytime, at any moment in your life. But you
won't be allowed to enter heaven if you do. You are allowed to keep living with
us, you can even attend church, but you are not allowed to sit next to us
anymore. Do you understand?"

"Yes mother."

"Well I will be back every night and tell you these rules until you know them by
heart. Until you really understand what it means to become a woman and I will
guide you through this process. Do you understand and agree to me guiding you?"

"Yes mother."

"Now then, my dearest daughter, sleep well. Did you say your prayers?"

"Yes mother."

"I will be back tomorrow and start you education. Sleep well, dearest daughter."

"Sleep well, mother"

As you might understand it was difficult for me to catch my sleep that night. My
father was the messiah they all spoke about? What did that mean for me? Was I
important too? What did this all mean for me?

The next morning I got up at 6 to start my morning prayers and to wash myself in
the water bowl which stood at the other side of my room. I was just about to
start when my mother walked in.

"Oh, daughter, please stop. You have to learn how things are done when you are a
woman. Your morning routine will change and you must learn the proper ways for a
woman to prepare herself for the day. I am here to show them to you as I still
need to do them. Just watch me and try to copy them as best you can. I will
correct you when needed. Do you understand?"

"Yes mother."

My mother placed the box she was carrying on the table. She opened the box and
took out two strange looking objects. I had never seen anything like that before
in my life. My mother sat down on the bed and looked at them as if she was
holding sacred objects.

"Daughter, these are phalluses, they represent the bringer of life. All men have
them on their body. Us women don't, but our bodies are destined to receive the
holy bringer of life and to bear and protect the fruits of that most sacred
interaction. Do you understand?"

I didn't understand really but I said "Yes mother."

"Now it is very important to keep the bringer of life clean. And it is our duty
to see to it that it is. Every morning we need to make sure we clean them with
our mouths. It is our duty to see to it that every man who is eligible receives
this cleaning. As you are becoming a woman in two weeks time, you will have to
attend to these cleanings too. If you are good enough you might even be chosen
to clean his holiness. Which would be a great honor. Do you understand?"

"Yes mother."

"Now these phalluses are for you to learn how to clean them. Every woman has to
study cleaning every morning for 30 minutes, until you are provisioned enough to
clean his holiness. An honor I've had for 4 times now. Now let me show you how
it is done."

My mother stood up and undressed herself. It was the first time I ever saw her
body, her curves and her full breasts. She reached for the box and got out a
hammer and nails. With firm and concise hits she nailed these phalluses against
the foot of my bed.

"Now you are not allowed to remove these ever. As you grow we will adjust their
height, but for now this will do. Do you understand?"

"Yes mother."

"As they are a bit low for me I have brought another one and I have gotten
permission from his holiness to do my training in your room with a temporary
replacement of my phalluses. You do not have to worry."

"I don't worry mother"

"Laura!" my mother only used my name when I did something very wrong, "you are
not allowed to abbreviate. God and the messiah have given us words and we shall
use them as they are intended. Do you understand?"

"Yes mother. My apologies mother, it was not my intention to insult you."

She looked at me with her fierce eyes for a while and then softened again. "Do
not do it again. Do you understand?"

"Yes mother."

"To the training. To clean the bringer of life you first need to clean it with
your tongue, like this."

She started to lick the phallus she had attached to the foot of my bed. She
licked it from top to bottom and back again until she had touched every inch of
it. She then proceeded to lick the strange thing that hung under it.

"These are very important. These are sacks that contain the balls that bring
life. They need to be cleaned thoroughly."

She licked them with the utmost care. She even started to moan softly as if she
enjoyed it. When she was done licking those balls she licked the rest of it one
more time, every inch, paying special attention to the top.

"When this is done you can proceed with the deep cleanse. And that is done like
this."

My mother opened her mouth and took the phallus in. Deeper every time she
retracted and went forward again. I could see a bulge in her throat as the
phallus went in deep. She didn't even gag, but the longer she had it in there
the redder her face got. After what looked like an eternity she pulled back,
took a deep breath and repeated what she did.

"Now you try. Start with the smaller one. The other one is for another day."
she said as she was gasping for air.

I leaned forward and held my tongue out.

"No, daughter, you forgot an important thing. What do you think it is?"

"I do not know, mother."

"You are still wearing your bed attire. You will have to take that off otherwise
you could insult his holiness."

"Oh, sorry mother" and I took off my nightgown and panties.

"That is better, now you may proceed."

The phallus tasted strange, rubbery and I didn't particularly like it. After
licking the phallus all over I proceeded to the strange sack underneath and
licked those too, then I licked the rest again paying special attention to the
top. After opening my mouth I struggled to fit it in and wanted to grab it with
my hands.

"Oh no, daughter, never touch it with your hand during cleansing. If you do you
have to start all over again. Just do your best. You will learn."

I struggled for a while but did manage to take it in and gagged as soon as the
phallus went in too deep. My mother held her hands on my head and pushed me
forward until it went in all the way. I thought I was dying and tears sprung in
my eyes, but despite my clear signs she kept me there.

"Just relax, daughter, relax. Don't fight it." she said.

After a few seconds she released me and I moved back as quick as I could gasping
for air. When I had regained my breath my mother said "Again." and she pushed my
head forward. I opened my mouth and the phallus went in deep again. This time I
tried to relax and it did get a bit easier.

"It will get easier, you will and must study every day. Do you understand?"

"Yes mother." I gasped.

"Now we will both train for the fully allotted time. As we did not start our
training officially we will start from the beginning." She reached for the box
and got out a clock. "When the large one is over there, we have completed our
training for the day. Do you understand?"

"Yes mother."

She started the timer and we both licked our phalluses. All through the training
I did my best to copy my mother and although I still had problems I felt I was
getting better at it. When the training was over my mother turned to me and said
"You did well, daughter, very well indeed. Now when I come here tomorrow morning
you have to have started your training for that day. Do you understand?"

"Yes mother."

"Now it is time to clean our bodies. When you are done, please wear the clothes
I have laid out for you and then you can come for breakfast. Miss Jessica will
then teach you for the morning. In the afternoon you will go back to your room
and train for another 30 minutes. When that training is done you are not allowed
to leave your room unless you are called for. When the clock chimes 5 you are to
do another 30 minutes of training, then you can come for dinner. After dinner
you will do the dishes and return to your room. Pray and go to bed. I will join
you at 6 every night from now on. We will not be wearing bed attire anymore as
we need to be ready to receive the bringer of life at any time. Do you
understand?"

"Yes mother."

I started to wash, put on what my mother had laid out and went down for
breakfast. Miss Jessica taught us the alphabet and how to read the holy books of
God and the messiah. When school was over I went back to my room, undressed and
trained with the phalluses. Several ladies checked whether I was training so
there was no way I could not be. At the end of the 30 minutes it was again
easier for me to keep it down my throat. The rest of the time I just lay on my
bed and contemplated what was happening to me. When the clock chimed 5 I went
downstairs, had dinner, did the dishes and went up to my room again.

At 6 my mother joined me. We both undressed and went to bed. She turned over to
me and started caressing me with her soft hands. "As I have told you we always
need to be ready and willing to receive the bringer of life. I will now show you
what that means." With her hand she went down and in between my legs.

"When you become a woman the bringer of life will enter your hole there." with
her index finger she pushed against it. When she touched a certain spot I felt
jolts running through my body. "Yes," she said, "that's the spot. The bringer of
life is also a bringer of pleasure. It's our job to enjoy the interaction,
that is very important. Do feel it? That wetness? That's important. The wetter
you are the more pleasure it will give both you and the bringer of life. Do you
understand?"

"Yes mother."

She softly rubbed that special place some more. I felt it getting wet and then
she pushed her finger inside. Not just the tip, she pushed it all the way. It
hurt and I yelped. "Shh, my daughter, relax and it will start to feel better. I
promise." She started to slide her finger in and out. It kept hurting and it was
impossible for me to relax. "This, my daughter is another part of your training.
Your hole needs to stretch until in can accept the phalluses and I promise you
you will learn to enjoy this."

"I will help you every night. And I will teach you how you can train yourself.
It's what we women do, we are always ready and willing to accept the bringer of
life at any time at any moment."

She kept her finger inside me and even tried to add another one, but it just
wouldn't fit. After what felt like a lifetime she pulled out and kissed me.
"Shh, you did so well. This was good. Even better than me, when I was taught.
You should be proud of yourself."

It took a while for the pain to subside and a crawled against my mothers naked
body. "Do you want to train me?" she asked and she took my hand and guided it
down her body. "Feel that little knot? That's it, yes. If you rub that you will
make me feel so good. Oh yes, keep going. Yes. Feel that? I am getting wet too.
See it's normal for us women. Now just slide one finger in. Yes. Just like that.
Make me ready to receive the bringer of life. You can ad another finger if you
want to. Oh yes." She started to moan. "Just push all your fingers inside. It's
nice and warm, oh yes, I feel your hand inside me. Now make a little fist. Yes.
And slide it in and out as fast and hard as you can. Yes, just like that. Keep
going, right there. Oh yes, you are doing so good. Oh yes."

My mother started moving her hips and she closed her eyes. It did feel nice and
warm in there and just as I started to enjoy it a bit the door swung open. In
the doorway stood my oldest brother. He said nothing and just walked up to the
bed, looked at my mother and dropped his pants. For the first time I saw a real
life penis. It was hard and stood up like a flag pole. He grabbed my arm and
pulled it out and then got on top of her.

My mother spread her legs wide and he pushed his rod deep inside my mother. "Oh
yes," she moaned, "give me that bringer of life, my son, give me the holiest of
holy fluids." He moved his body so his penis slid in and out of her. He went
fast and hard, with every thrust my mother moaned deeply. "Oh yes, yes, my son,
give it to me. Treat me like the whore of Satan that I am." I watched in
amazement how my brother treated my mother. 'Whore of Satan?' what did she mean
by that?

After a few minutes my brother groaned, stayed still for a moment, got up, put
on his pants and just left. Never saying a word. My mother lay still for a
second and the proceeded to put three pillows under her hips. "We cannot waste a
single drop of the holy fluids" she said, "It would be such an honor to bare and
protect the fruits of his labor. I am blessed once more."

"Mother, may I ask a question?"

"Yes, my daughter, you may."

"At one moment you said 'whore of Satan'. What did you mean by that?"

"Oh that. If a woman hasn't received a blessing for a while and the only thing
she does is train then Satan has a way in. As a punishment I had to fundraise
for three weeks. When I had raised enough I was allowed to return and take my
place within the ranks. This blessing I just received means I am accepted again
and may sit with the blessed."

For the next two weeks every day was the same: training, school, training,
dinner, more training and at night my mother taught me the ways of the woman.
And she was right it became easier, even pleasurable and at the last night I was
not only able to take the largest phallus down my throat, I could even fit it in
my hole. And it did feel good, it felt so good I didn't want to stop.

It was the night before I turned seven and my mother walked in my bedroom again.
This time she had brought another box. On the front I read my name and I
wondered what was inside. My mother took of her clothes and complemented me on
my training and how good I had done. Then she opened the box.

"This is very special. This is medicine for women and as you almost turn seven I
will show you how to administer it. But we have to wait until the clock chimes
twelve. You are not quite seven yet. When the clock chimes 12 we will both take
our medicine and then I will show you how we women perform the holy rituals. Do
you understand?"

"Yes mother."

"Now then. Have you done your training?"

"Yes mother."

"And did you enjoy your training?"

"Yes mother."

"Good. Now tomorrow you will stay in your room and train until you are called
upon. Then you will wear your Sunday dress and come downstairs. His holiness
will be seated and you will present yourself to him. You will bow, but never
look at him. Then when the matron has spoken the words 'she will perform her
first cleansing now.' you will proceed and do the cleansing on his holiness. Do
you understand?"

"Yes mother."

"Good. When his holiness accepts the cleansing he will give you his blessing and
you will accept it. Do you understand?"

"Yes mother."

"Very well. Now just lay besides me and we will wait for the time to take our
medicine. Come."

I crawled against my mother and just started sucking on her nipples. "Oh, my
daughter, yes. That feels nice. Soon yours will grow and when they do I will
return the favor."

I almost fell asleep, when my mother shook me and said "The clock is chiming
time for our medicine." She reached for the box and in it was a small bottle and
two syringes with needles. She took out one syringe and placed a needle on it.
Then she took out the small bottle and pushed the needle through the cap. She
pulled the lever a bit and I saw some of the liquid fill the syringe.

She then reached in the box again and took out a strip of rubber. "Now give me
your arm." I did as I was told and she wrapped the band around my arm tightly.
My veins popped out a bit. She tapped one of them with her finger and then
placed the needle against it. "My dearest daughter, welcome to womanhood." and
she pushed the needle in my arm. She then pushed the lever and thus the liquid
in my arm. She pulled the needle out and rubbed the spot with her finger. When
she released the rubber band a rush came over me. I felt so strange, it felt
warm and cold at the same time. The world started to spin.

"Relax" I heard my mother say, "Accept it. It is the holy spirit that is
entering you now. Accept him." I fell on my pillow and closed my eyes. I have no
idea whatever happened that night. All I know is that the next morning my mother
praised me on how well I performed.

"It is time to get ready now," she said, "start your training. Make yourself
ready for the ritual."

"Yes mother." I got up and started my training. I have no idea how long I spent
training, but it was quite some time. Then I heard my name being called. I got
up, put on my Sunday dress and made my way down the stairs.

All of the congregation were there. On one side the women, all were naked, on
the other side the men. The matron gestured for me to come closer and I walked
towards her, being careful not to look at his holiness.

"Gentlemen," she said, "his holiness has the honor to welcome another woman in
the congregation. This is Laura and she turned seven today. As is tradition she
will enter her place in womanhood at the lowest rank. She will have to proof
herself and show us that she is willing and ready to take her role. She will now
perform her first cleansing."

I took a few steps forward, took off my dress and kneeled in front of his
holiness. My hands were shaking as I unzipped his pants and took out the bringer
of life. Carefully I started licking, it tasted way different that the phalluses
I had been training on: a bit salty but it didn't taste bad at all. I cleaned
every inch of his pole and the proceeded to clean the sack. I took the balls of
life in my mouth as instructed by my mother. When all was clean I took the pole
in my mouth and pushed my head forward. The pole went in all the way and I kept
it there for quite some time. Then his holiness placed his hands on my head and
started moving his hips, making his pole slide in and out my throat.

His holiness then lifted my head and said "this one is worthy". He pulled me on
his lap so both my legs were on either side of him. The bringer of life rested
against my hole. "With this I accept this woman in our circle." The next thing I
felt was his pole sliding inside me. Automatically I moaned and started moving
my hips. My mother had instructed me to bounce up and down and so I did. His
holiness slid in and out of me. It felt so good and I moaned as load as I could.
"Yes, yes, his holiness, give me the fluids of life. Accept this girl in your
circle and make her a woman that is worthy of your blessing." I spoke.

I bounced on him for quite some time and then I felt his pole twitch and turn.
His holiness groaned and I felt his fluids enter me. "Oh yes, his holiness,
thank you for blessing me with the fluids of life. Thank you. Thank you."

His holiness pushed me off and I kneeled before him, my head on the ground.
"This girl now is a woman. She is willing and ready to take her place. Now,
young woman, stand up and sit with the women. From this day forward you are not
allowed to wear clothes, you are not allowed to look at or talk to men until
given permission to do so. You are required to take your medicine every day and
you will be ready to receive at any moment at any time. Do you understand?"

"Yes his holiness."

"Do you accept this role at your own free will and will you respect the rules I
have just stated."

"Yes his holiness."

"Then rise and take your place amongst the women."

I got up and walked over. The matron pointed where I should sit. I kept looking
at the floor as all the women did. I felt the fluids of life slowly drip out of
me. His holiness spoke for a while and then said "Now it is time to celebrate.
We have accepted a new woman in our midst." The men cheered and the women just
stared at the floor. "But first it is time for us men to retreat. The harvest
needs to be finished and the women need to prepare. Let's start our day."

The men rose and walked out the door. When the last one had left and closed the
door I could clearly hear a key being turned. It was the first time I realized
we were locked in this house. My mother came over to me and said how proud she
was of me. The matron said it was time for our medicine and told to fetch our
boxes. After about ten minutes we all gathered and administered our medicine.
Miss Jessica helped me and again the world started to spin, but this time it
didn't last as long and I sort of got what was happening. Everybody started to
kiss and caress each other. Miss Jessica kissed me and she slit two fingers
inside me. At the same time my mother slid her hand inside Miss Jessica.

The room filled with moans of pleasure. At a certain point the matron opened the
door of the large cabinet, revealing a pentagram and upside down crosses. She
lit all the candles in front of them and chanted "Oh Satan, our guide, our lord,
we have a new bride for you. She still has to receive her name, will you accept
her blood and reveal her name to us."

The matron grabbed my arm and with a sharp knife she cut my wrist. I watched as
my blood dripped in a bowl. She swung around, uttering words I did not
understand. She then took a feather out of a drawer, dipped it in my blood and
drew a pentagram on my belly. "Oh Satan, honor us with your presence and give
this new bride a name." She held the bowl with my blood up and placed it against
my mouth. "Drink this, new bride of Satan and show the Lord you are willing to
become his bride." I took a sip and tasted my blood. It tasted metallic and
salty. The matron tipped the bowl and I felt my blood streaming down my chin.
"Oh Satan, our Lord and saviour, let her proof herself to you."

My mother and Miss Jessica rolled in a tub filled with blood. "Let her bathe in
the blood of the hornet creature." My mother took my hand and told me to step in
the tub. I did and it still felt warm. I was instructed to lay down and dip my
whole body in the blood. When I lay down, Jessica pushed my head under and held
me there for a while. The warm blood felt strange and siropy but somehow it felt
welcoming and natural. As I was held under I felt the urge to breath and I
opened my mouth. At the same time Jessica pulled me up and I spat out the blood
I had taken in.

"Oh, thank you Satan for accepting Luella as your bride. Thank you for honoring
us with your presence. Now let Luella wash herself in the cleansing blood of the
hornet creature that gave us this blessed fluid."

I started to wash myself with the blood and when it was time I got out. "Luella,
you are blessed. Now let the blood dry as we, whores of Satan, drink." All the
women reached for cups and dipped them into the blood I had just been in. All of
them drank until the tub was almost empty. The matron took my hand and said
"Welcome to the Brides of Satan, Luella. We will teach you our ways and you will
have to study hard. Learn our prayers and follow our guidance."

Every Saturday one of us had the privilege to bath in the blood of the hornet
beast and I learned how to administer my medicine. Some days we had to take it
multiple times. I learned how to accept the bringer of life and was blessed at
an average of three times a day. I had accepted my place as the lowest ranked
amongst the women.

As the years went on my body started to grow into that of a voluptuous woman, my
triple-D breasts were the envy of almost all of them except my mother who had
almost the same size. When I was 14 I bore my first fruit and was blessed to
guard a male. At 16 I bore a female who I named Marisha, although I knew that
would only be temporary. When I was 18 I became the guardian of twins, two girls
and named them Ashley and Scarlet.

At 19 I received my first punishment. Although I took great care of the fruit
inside me, it wasn't to be. I lost the child and was sent to fundraise. I was
sent out to the banished ones and was greeted by Jessica, who had given in to
the words of a false prophet.

That night I wore high heels and a very revealing black dress. Men would stop
and I would show them 'the merchandise'. They would then pay me and I would let
them have their way with me. For an additional donation they were allowed to
give me their fluids of life. It took me six weeks to raise enough money and I
was allowed to return. A few weeks after I had returned we learned I was with
fruit again. This was the holiest blessing I could have received. I was bringing
in the fruit from outside our congregation. They took extra special care of me
and I gave birth to a holy male.

All in all I brought 34 lives into our congregation. As I am getting too old to
bear fruit it is time for me to leave, just like my mother did a few years ago
and Jessica after her.

"Oh Satan, thank you for making me your bride. It is time for me to join you in
the depth of hell. I am looking forward to becoming your whore and spawn your
children. Oh Satan, my Lord and saviour, accept this my final offer."

I took the sharp knife in my hand and placed it firmly against my throat. I
looked at my fellow brides one last time and slit my throat. My warm blood
started gushing over my body and as life left this mortal body I felt one last
orgasm. 
