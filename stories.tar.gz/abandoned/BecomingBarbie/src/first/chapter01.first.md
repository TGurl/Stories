# Chapter 1
Bent over my books my thoughts went to the sounds of the party going on just
below my window. I could hear people having fun and the music sounded really
inviting. How ever much I wanted to go there I couldn't, I had to prep for
exams the next week and I really wanted to pass so I could go home for the
summer break.

If I didn't pass I had to stay for summer classes in order to move on to the
second year and I was not looking forward to that. I hadn't seen my family in
months and I really missed them, a lot. Sure nowadays you can Skype or Zoom,
but it just doesn't feel the same to me. My parents had hated it when I told
them I wanted to go here and being a thousand miles away from home wasn't easy
at first, but I struggled through it and as time went on it got a little bit
easier.

"Mom, I need to be independent," I had said, "I need to be somewhere where it
isn't easy for me to lean on you. I just have to do this."

My mother had sighed and given in "But I still don't like it." My moving here
had broken her heart, I could see it. Just the other day she called and told me
she understood why I had to go and that she still loved me. Hearing that made
it easier for me to cope with the homesickness, from which I still was
suffering.

I got up and closed the window in order to muffle the sounds coming from the
party downstairs, not that it helped but it felt more like a symbolic win and I
returned to my books. A couple of hours later the party was over and it didn't
take long for my room mate Marisha to return. "Wow, that was so much fun!" she
said as she walked in.

I looked over my shoulder and sighed, saying nothing I returned to my books and
tried to get through this last chapter. Marisha was the total opposite of me,
where I was reserved she was outgoing, where I dressed modestly she, well you
get the picture. She was an English major and I did my best to work my way
to a law degree. Had I realized how dry most of the stuff was that I had to
learn I might have chosen something different, although I had no clue what that
would have been. My father was a lawyer and it had always been my dream to take
over his practice when the time came.

You should have seen my father's face when I told them I wanted to study law
and I even applied to some of the big colleges only to be rejected. Not that it
mattered much, my dad hadn't gone to an ivy league school either. Their mood
changed however when I told them _where_ I wanted to go. Being an only child
had been great, this was one of the drawbacks however.

My mother had a hard time with me being gone as she had hoped I would go to a
college nearby so I could stay home for a few more years. But I felt it was
time to go and move out, I was 18, almost 19 and I didn't want to live at home
until I was 23.

"Hey, it's almost midnight. Why don't you stop for today? You need some rest."
Marisha said waking me from my thoughts. To be honest I hadn't read a letter
for the past three quarters of an hour, all I had done was drift away in my
thoughts and think about anything but what was in front of me. I looked at her
and said "Maybe you're right. It's just so hard. I never thought it would be
like this."

"Why don't you change majors, you could take English. At least you get to read
some great books in the process instead of those dry law books." Marisha
smiled. We both knew it was way to late for that to happen and I was committed
to see this through. I had spoken with some second and third year students,
they all said the first year was the hardest and I held on to that idea. All I
had to do was pass the next round of exams.

I turned to Marisha and said "I'm so tired. My head hurts and I really do want
to go to sleep. But I really need to study, I simply don't have the time."

"If you go on like this you will fall asleep at that desk, I promise you that.
Just lay down for a few hours, rest and start fresh in the morning. My father
always said 'You learn more if your mind is fresh.' and he was right. Don't you
ever tell him that I said so, he will gloat for weeks if not months and I will
never hear the end of it." Marisha chuckled. She got up, laid her hands on my
shoulders and said "Come on, go to bed and sleep. I promise I will be quiet."

I slowly rose up from my chair, my back was hurting for sitting for all these
hours and I stretched my back. I walked over to my bed and noticed how inviting
those sheets felt. I turned around and said "I will rest for a few." I fell
onto my bed and before I knew it the warm rays of the sun on my face woke me up
again. Clearly I had fallen asleep as soon as my head touched my pillow. I got
out of bed and noticed I wasn't wearing my clothes anymore. Marisha had
undressed me and put me to bed, there was no other explanation. I chuckled when
I pictured her struggling with my sleeping body and smiled when I watched her
sleep in her bed.

Although we mostly were polar opposites, she had a big heart and I felt so
happy that I met her. That chance meeting had changed the both of us, I had
become somewhat more open and she had become a little more reserved. After a
week or two we asked my then room mate if she wanted to switch and she to our
relief said yes. I didn't really get along with her that well and she didn't
really care who she roomed with. When the move was approved by the school it
was done in just a few hours.

Marisha felt like the sister I never had and she felt the same way. All she had
was a couple of brothers and as I said I was an only child. I shook my head to
get back into the present, grabbed a clean towel, my bag with toiletries and
walked towards the bathrooms. There were three of them, one for the girls, one
for the boys and as a pilot they had opened a mixed one too. Not that it was
used much and when it was we mostly put a pink or a blue sock on the doorknob
to indicate who was in there.

One morning as I passed the mixed bathroom I was sure I had heard some moaning
coming from in there. I was sure people were having sex in the shower and I had
chuckled thinking "Well, at least it's good for something." I never got to know
who it were in there and I didn't really care either. As I opened the door to
the girls bathroom I was greeted by Amber, a fellow law student of mine.

"Good morning," she said, "ready for the exams? I really need to study hard for
these. I think I will be studying all weekend."

"Me too. Good morning, by the way. Hey, I've got an idea, why don't we study
together? It might go a little faster."

"Sure, why don't we meet at the library this afternoon, let's say around noon?
We could grab a lunch before we start."

"Great, noon it is." I smiled and stepped into one of the booths. As I was
getting ready Amber said "See you at noon then." and I heard her walking out
the room. As far as I knew I was on my own in there and just a few minutes
later I stepped in to the hot water coming from the shower.

Half an hour later I returned to our room and Marisha was sitting up in her
bed. "Good morning," she yawned, "You're up early."

"Did you put me to bed last night?"

"Yes, I did. I couldn't let you sleep in your clothes, now could I? I should
have become a nurse, I was rather good at it. I had you in there in no time at
all."

"Thanks for not taking off my underwear. I would have been embarrassed if you
had done that."

"Why? It's not that I haven's seen a female body before. Last time I checked I
still had one of my own."

I started laughing and realized she was right, but still I would have been
embarrassed. It's just the way I'm wired, I guess. "Oh, good news. Amber was in
the bathroom and we agreed to study together this afternoon. We will grab a
lunch at noon and then go to the library. So I will be out of your hair for
most of the day."

"As if you are a bother to me," Marisha replied, "but nice to see you getting
to know other people. I hate to see you alone all the time. And be honest know
who asked who?"

"Oh, I asked her. I really did."

"Wow, big step." Marisha chuckled, "First you ask me to become your room mate
and now you're asking Amber to study with you? You _are_ making progress, my
dear."

I really was and I was proud of it too. In middle and high school I had been
bullied a lot and that had made me the way I am, reserved and protective of
myself. The bullying had become so much that my parents even pulled me from
school and started to home-school me. They even went out of their way to
organize a prom for me and it was just magical. One of the neighborhood boys
had asked me to go and I felt really pretty in that dress that night. My mother
had tears in her eyes when she saw how happy I had been that night.

Maybe that was a contributing factor for me to choose to go to a college far
away from home. It was here where I learned to co-exist with other students and
that not everybody wanted to put me down. It was quite the opposite to be
honest. People here seemed to like me and didn't really mind a conservative
Christian girl in their midst. Some of them even were those _evil_ atheists
they had always warned me about, but when I got to know them they weren't that
bad. They respected my believes even though they didn't agree with them. Some
of them even said they just didn't care.

Now I have to explain that my parents were not very strict Christians, the were
more progressive than every body else at home. One of the reasons I got bullied
was the fact my mother as pro-choice, as a medical doctor she always tried to
inform people with the scientific truth around that matter. The moment she
spoke out was when I became the _baby-killers child_. I had never told her why
it was I got bullied so much until it all just came out. She held me in her
arms and said she was sorry, but she also said she couldn't keep silent about
it. "It's just too important to me," she said, "and we still live in a country
where there's free speech. That doesn't give anybody the right to do what they
did to you and for that I am so sorry."

A few minutes before noon I met up with Amber and we got some lunch together at
the small diner on campus. Afterwards we went to the library and studied for a
few hours until we realized it was way passed six in the evening. We decided to
get something to eat and returned to our studies until the library closed at
ten. We had gotten a lot of work done and we both felt good about our chances
of passing the upcoming exams.

"Let's do this again tomorrow," Amber said, "just one more day and I think
we're ready."

I just nodded and said "Thanks for doing this. I had a really hard time
understanding some of it and you explained a lot, so thank you."

"You're so welcome," she smiled, "you did the same for me, you know? We should
have done this earlier, see you tomorrow." And with that she walked off.

"At noon again?" I shouted after her and she just waved.

I chuckled and made my way back to our room. Even though we had worked all day
I didn't feel as tired as I had done the other days after cramming for hours.
It had been fun studying with Amber and we had laughed a lot too. As I entered
our room Marisha immediately sat up straight and her face turned red. "Oh, I
didn't expect you to be back so soon," she stuttered. From behind her a boy
rose up saying "Hi, I'm Matt. Pleased to meet you." I shook his hand and threw
an angry look at Marisha.

"Maybe you better go," Marisha told Matt, "this might not have been such a good
idea after all." Matt got up, straightened his shirt and said "It was very nice
to finally meet you." before leaving the room.

"What were you thinking?" I hissed at Marisha, "What if I had come in a little
later? Would you both have been naked? Oh, I can't think about that. What if --
Oh God no --"

Marisha showed me her sad face and uttered "Well, maybe you would have liked
it. Maybe somewhere deep inside you you would like to see it." She touted her
lip again and somehow it always made me snicker. Somehow she always knew which
buttons to press to brighten my spirit. Looking back at that time I really
think she knew something about me that I didn't even know yet. Maybe she saw
right through me and knew what was hidden deep inside me, a part of me so well
hidden and walled off that I didn't even know it was there.

The next day Amber and I met up again in the library and studied together for
almost six hours, I simply couldn't believe how much we got done. "Maybe we
should study together more often," Amber said as she leaned a little forward,
"I like spending time with you." There was something in the way she looked that
made me uncomfortable and when she laid her hand on my knee in a jerk reaction
I jumped up and said "What are you doing?"

Amber's face turned red and she immediately started collecting her books, by
the time she was done she threw her backpack over her shoulder, with tears in
her eyes she said "Maybe we shouldn't do this again..." and she walked off.
With my eyes I followed her not knowing what to say or do, I was totally
stunned, not only by her touching my knee or by the way she reacted, it was
more what it did to me. Feeling her hand touch my knee had send jolts of
pleasure through my body, something totally unexpected and according to how I
was raised totally wrong.

After a few minutes I returned the books we had borrowed, collected my things
and slowly made my way back to my room. Marisha was sitting at her desk, she
was studying for once and the moment she saw me she knew something was up. She
kept pressuring me and I told her what had happened. "Didn't you know she's
gay?" Marisha said, "Amber is a lesbian and she's quite open about it too."

"No," I replied, "I didn't know. But that's not what startled me."

"What was it then?" Marisha inquired.

"I don't know," I whispered.

"Wait! What?! Are you telling me you _liked_ it?" Marisha asked with
enthusiasm, "Now did you? Did you like her touching you?"

"Maybe," I whispered and with a normal voice I added "But it's _so_ wrong, I
shouldn't. That sort of thing is reserved for a man and a woman **after** they 
are married, not before. Before is a sin."

"Why?" Marisha replied, "Why is it a sin? Matt is a Christian and he sure as
heck doesn't think it's a sin. So why is he wrong and why are you right in
this? What's so different? You both believe in the same God, the same Jesus and
stuff."

"You shouldn't say things like that," I replied with a stern voice, "You should
never doubt the word of the Bible." At that moment I realized the influence the
church had had on me, even though my parents weren't that strict I had become a
lot stricter. All my live I had to adhere to the rules set by the church and
the community. If I stepped out of line there was always someone commenting on
it. That moment made me realize I wasn't in that environment any more and maybe
it was time to _lighten up_ a little.

"Wow," I said, "I would never have thought I would say something like that."

"Yeah," Marisha uttered, "That church of yours is looking more and more like a
cult to me. And maybe your parents weren't that strict, but everybody else
was."

"Yeah, I realize that now." I looked up at Marisha and said "I should
apologize to Amber." I got up and walked out the door. A few minutes later I
stood in front of her door and hesitated for a moment before I knocked.

"Oh, it's you..." was all Amber said.

"Amber?" I quickly said before she closed the door, "Please listen to me. I was
wrong and I apologize. I shouldn't have reacted the way I did, it's just --" I
looked down the hallway and continued "Please, can I come in for a moment?"

Amber just stared at me for a few seconds and then turned around, leaving the
door open. I stepped inside and stood in her room for a few seconds. "Do you
have this room for yourself?" I asked when I realized she didn't have a room
mate.

"Yeah, and don't say I'm lucky. I would love to have a room mate, but nobody
wants to share a room with a lesbian, I guess." she replied with anger in her
voice.

I looked down at my feet and said I was sorry before I said "Look, about what
happened. I'm a Christian girl and, well this is _so_ hard for me, it wasn't
what you did that startled me, it was how it made me feel." I looked up at her
and said "I was always told love was between a man and a woman and everything
else is a sin. When you touched me --"

"You don't have to say it, I know. It disgusted you and you think I'm going to
hell. But I can't change who I am, this is me and I like girls."

"No, that isn't it. It was quite the opposite, really."

Amber sat up straight and said "What? You liked it?"

With a red face I whispered "Maybe. I don't know. I'm so confused. I was raised
in a Christian community and we never talked about things like this. It was
just am given you saving yourself for marriage and now? Now I'm not so sure
anymore, being here changed me I guess. Or at least it's starting to."

"So -- you like girls too?" Amber said with a curiosity in her voice.

"Not in that way," I replied, "or at least I don't think I do. I don't know, as
I said I'm so confused."

Amber stood up with a smile and said "Apology accepted and I will not push any
harder. Maybe we can both untangle those feelings you have and believe me I've
struggled with them for years before I came out. I know you have to find out
for yourself first. And no matter what I will be there for you, even if you
turn out straight." I burst into laughter and we hugged, I knew I had made
another friend that day.

Two weeks later Amber and I walked to where the results of the exams where
posted, my heart was throbbing in my throat. I simply had to pass if I was to
go home for the summer break. Amber went first and she turned around with a
huge smile on her face "We both passed! We passed!" she shouted. I couldn't
believe her and had to see for myself: a B+, I had never scored anything that
high before. I turned to Amber and we jumped into each others arms. This meant
I could go home and see my parents for the summer.

During the last weeks before the summer break Marisha, Amber and I spent a lot
of time together and one beautiful day we sat on the grass on the central
square of campus. Without warning Amber bumped me and said "Oh, I wouldn't mind
having breakfast with her." She nodded in the direction of a girl walking down
the path. She was wearing a short skirt and a very tight shirt, her large
breasts were clearly visible and she wore a lot of makeup.

"You mean Barbie over there?" Marisha whispered, "She looks like a Barbie
doll." Amber punched her shoulder and said "I like Barbie dolls, so what?" I
just stared at her and didn't believe someone would want to look like that, buy
somehow I couldn't stop staring at her. Her lips were clearly filled and her
boobs couldn't be all natural, somewhere deep inside me I was intrigued by how
she looked, she was just oozing sexuality and she wasn't afraid to show it.

"I could never do a thing like that," I said almost as if I had to convince
myself.

"Why not?" Marisha said, "I wouldn't be against something more up there." and
she looked down at herself. "Just a few cups bigger maybe," she continued.

"Can you do that?" I asked.

"Oh sure, if you have the money you can do anything." Amber replied, "You could
make yourself look anyway you want. Take the human Ken for example, he spent
lots of money making himself look like the doll and now he has become a she and
she is a spitting image of Barbie now. The best thing is she couldn't be
happier now, she finally looks the way she feels."

"But he --" I started.

"_SHE_" Amber interjected, "_She_ is a woman now, like she has always been deep
down her hart. And now finally she has come out for who she really is and
that's wonderful. Everybody should be who they really are, not how society
wants them to be. Straight, gay, trans, dark, light, whatever. It shouldn't
matter, not a bit."

I felt a little embarrassed by her sudden tirade, but deep inside I knew she
was right. It shouldn't matter, people should be who they are. That realization
was the first doubt I had about what I was taught as a child and maybe even
bigger, it was a seed that had been planted doubting my religious beliefs. If
God created humans and humans were wired this way, what could be so wrong?
Didn't God love unconditionally? Who were we to place those conditions?

When I returned home I was still confused about everything and maybe spending
some time at home would place everything in perspective again. After an eight
hour flight I landed on the airport nearby our town. My parents were there to
pick me up and my mother couldn't let go of me. She was so happy to see me
again. "You look good," she said, "You look happy and if you are happy so am I,
but it's so nice to have you back."

We arrived at their apartment and I unpacked my suitcase in my room. Although
they had dedicated it to me, it still felt like I was just visiting. My father
was making dinner and I sat down on the couch next to my mother.

"Tell me everything," she said, "how's school? Made any other friends besides
Marisha? Come on talk to me girl. How are your grades? Do you eat well? You
look like you're eating well. Why aren't you saying anything? You used to talk
to me all the time --"

"If you just take a breath for a moment," I interjected, "maybe I can get a
word in?" I chuckled as my mother looked a little stunned.

"Wow, look who's getting assertive," she said with sarcasm in her voice, "I
_like_ it."

I told her all about school and how I met Amber. How we studied together and
about the B+ I got for the last exams. "I had never gotten grades that high
before, I mean a B+? Me?"

"I always knew you had it in you," my mother replied, "but I'm a little
biased."

"A _little biased_? Mom?" I said.

"Okay, okay, I am a lot biased, but that's a mothers' prerogative, isn't it?"

"_Sure_" now it was my time to be sarcastic.

We were quiet for a moment and then I said "Mom? Can I ask you a serious
question? I mean just between us girls, or women if you want to."

My mother turned towards me and said "I've been waiting for this since you were
born. Shoot."

"Well," I played with my fingers as I spoke, "look Amber is gay and she's quite
open about it too. But in church they always said it was a sin, but if you see
her she's so happy and open about it. How can it be so wrong if God made her
that way?"

"Okay," my mother scraped her throat, "I didn't quite expect it to go that way.
But never mind. Look Laura, there's nothing wrong with her being gay. She's
just who she is and if that is what makes her happy go for it, I say. And I'm
sure dad will say the same. So if there's something you need to tell us --"

"No, no," I quickly answered, "it's not that. I'm not gay. It's just if they
are wrong about that, what else are they wrong about?"

My mother couldn't suppress a sigh of relief and then said "Look, we have
always told you to think for yourself, to always ask questions. We've raised
you to become an independent woman who doesn't need to rely on anything or
anyone. It's okay to have those questions and to find the answers you seek.
Just hear me as I say this. No matter what the outcome, you will always be our
child and we will always love you."

I looked at her with a tear in my eye and said "Thanks mom. But don't tell dad,
not just yet. I don't want to disappoint him."

"Oh honey, you could never disappoint that man. You're his sugar doll, no
matter how old you get you will always be his little girl. Don't you ever
forget that."

That evening during dinner my father scraped his throat and said "Laura, we
need to tell you something. I had a job offer, one I couldn't possibly refuse.
Your mother and I have spoken about this and we've decided to accept it."

I stared at my father and said "Does this mean --"

He nodded and said "Yes, we're moving again. This time to Rotherfield, almost
600 miles from here. Your mother already has quit her job and is looking for
something over there. What do you think?"

"Wow," I replied, "that's really something. Is this really what you want to do?
I mean, you grew up here dad."

"I know," he replied, "but someone I know moved away and it surely seemed to go
well for her. So I thought we might follow her example and take a chance."

I blushed because I understood he was talking about me. "Really dad?" I said
with a slight smile, "you're following my example?"

My father smiled and said "Always pumpkin, always." I looked at my mother who
smiled and nodded. "Maybe it's time we leave this place. My opinions aren't
that wanted over here and I'm more isolated than I ever was. This feels like a
new opportunity for me and to be honest when I resigned I felt like I could
breath again. Maybe we could look for a place to live in Rotherfield tomorrow,
heck why don't we get a hotel room and explore that town for a few days."

And so we did. Rotherfield was a beautiful town, totally different from where
we were from. Rotherfield had an old city center with old colonial buildings
and it breathed history. My father showed me were he was going to work, to me
it was just another office building. We spent a day or two looking at potential
houses where they could live, but no decisions was made while we were there.

Three weeks later I returned to college and spent a few days alone there. Amber
and Marisha would return the following week and it was nice to have some time
on my own. Although it had been nice to spent some time with my parents, being
in that town again, in that community had made me realize how much people were
guarding their words, hiding their opinions and the few times I went back to
that church I notices how much the man in the counsel pushed his agenda on to
the people who were listening.

Being back at college had made me feel like I could breath again, how I could
be myself and nobody seemed to care. I walked across campus feeling happy, for
the first time I knew I was happy to be far away from home, from that
restrictive feeling that town gave me. For the first time I was really happy my
parents were moving out of there too and besides that, I didn't live with them
anymore so I had no say in the matter anyway.

On the second night I was alone in our room I felt a little bored and started
browsing the internet. Out of nowhere I started searching for breast
enlargements. I found out there were a lot of risks to those procedures,
especially with the silicone versions. Although most sites said the latter ones
gave a more _natural feel_, the thought of being able to make them larger if I
wanted to was rather appealing to me. As my search went on I came across a site
with pictures of women having over 1000cc in them and I marveled at their
bodies. The more I looked at them the more I wanted to be like them and I kept
on browsing that site.

At some point I got up, locked the door and sat down again. For the first time
I let myself marvel at those girls and the more I browsed the more excited I
got. At some point there was a post with links to other sited, I opened them
all and watched some videos of those women showing off their breasts and when I
came across a video of one woman being with a man, a dark man I couldn't stop
watching. I saw how she marveled at his penis, how she licked it and took it in
her mouth. How a bit later she climbed on top of him and guided him inside her.
Automatically I looked over my shoulder if anyone could see me, which was silly
because I had locked the door.

Slowly I spread my legs and started to play with myself, within seconds I was
so wet and my fingers slipped inside me. I pulled up my shirt and rubbed my
breasts while I was staring at that video. At that moment I wished I was in her
place, feeling that big black cock inside me. Suddenly I realized what I was
doing, closed the browser and straightened my clothes. I felt so ashamed of
myself and knelt down at my bed to ask for forgiveness, I had been weak. When I
left my room half an hour later to clean myself up, I was sure everybody could
see what I had been doing.

As I stood in the shower the images of that woman returned to my head, I did my
best to shake it off but I just couldn't. I had to pleasure myself, I just had
to. So I lifted my leg a little and rubbed my little clit. Within seconds I was
fully wet again, biting my lip not to moan out loud. I slipped two fingers
inside me and masturbated until I came. The orgasm made my knees buckle, I had
to lean against the wall not the fall down. After catching my breath, I
listened carefully if there had been anyone there to hear me. To my relief it
was all quiet and I finished showering.

As I returned to my room I felt elated and embarrassed at the same time. I felt
elated because I had the courage to do what I just had done, embarrassed
because I had done what I thought I would never do. All I am trying to say is
that I had mixed feelings and was more confused about myself than I had ever
been. Back in my room I put on a night gown and went to bed, I wanted to forget
all about it as soon as possible.

The next morning I knew the thoughts hadn't left my mind, not even for a little
bit. I did my normal morning routine and thirty minutes later I drove to the
nearest mall. I walked into _Forever 21_ and browsed their wares for a bit when
I came across a rack with mini-skirts for sale. I had never owned anything that
short before and I grabbed three of them: one black, one red and a pink one. On
another rack they had crop tops for sale, I also grabbed three of those
matching the skirts I had gotten earlier. In the dressing rooms my heart was
pounding as I checked myself in the mirror.

It looked strange at first, but I didn't hate it at all. As a matter of fact if
I had bigger breasts it would look even better. In my head I pictured myself
with a pair of giant boobs like the women from the videos I had seen. In a
different section I got myself a pair of Converse sneakers, another thing I had
never owned and walked over to the register. A few minutes later I walked
outside with my new purchases.

At a bookstore I got myself a brightly pink notebook, some very girly pens with
tassels and some other things I needed for the upcoming school year. On my way
out of the store my eyes fell on the shoe store near the entrance/exit. Before
I knew it I was inside looking at shoes. I chuckled when I saw the shoes I
would normally go for, but this time I wanted something else, I wanted heels.
On a table in the middle of the store they had the outgoing collection and a
sign said _Up to 70% off_. The pair that got my attention had 6 inch heels and 
they were black. For half price they were a steal and I just had to have them.

At the register the girl said "Oh, these are so nice. These are 70% off too."

"Oh, I thought the green label meant half price?" I uttered.

"Well, somebody must have relabeled them. Some people try to do that, but the
prices are in the computer already and relabeling doesn't help one bit. It's
always funny to seen them try."

"I can imagine," I replied.

She handed me the bag with my new shoes and feeling utterly satisfied with my
purchases I went home, but not before I got myself some donuts and bagels. Once
back on campus I got myself a nice latte from the coffee shop and went back to
my room. I placed everything on my desk and changed into a new outfit. I chose
the bright pink skirt with matching top. I sat down on my bed and put on the
heels. As I stood up I almost stumbled, this was the very first time I wore
heels at all let alone 6 inch ones. I carefully took a few steps with my hands
out wide to support myself if I fell.

I took a few steps more until I reached the other side and sat down on
Marisha's bed. Determined to learn how to walk in shoes like this I got up
again and stumbled across the room back to my bed. I repeated this a few times
and the more I did the more secure I became. After going up and down a few
times I didn't need to hold out my arms anymore. Feeling proud of myself I sat
down again, my feet were hurting but I didn't want to take them off.

I went over to my desk and sat down to drink my latte and eat a bagel. I felt
proud of myself. I turned towards the desk, got one of my girly pens and the
notebook I had bought. On the cover I wrote _My Barbiefication Diary_ and
stared at it for a moment, before I openend the first page and wrote:

> 08/24/2010
> Yesterday was the first day back on campus after spending some time with my
> parents. Before I left I felt confused about who I am and what I want to be.
> Do I still want to do law? Well, during the past few weeks I know the answer
> to that one: yes. But there are more important things I am confused about.
> Like do I still believe in God? If so, what do I think about people like
> Amber? About people who are gay? And what about sex before marriage? I see a
> lot of people now who do not have an issue with that. Not even the Christians
> I meet here. At the moment I don't have an answer to that question.
> But there is something else, something I simply have to write down and I am a
> little scared to do so. Writing it down makes it real somehow, but I can't
> deny it any longer. It's a part of me and I need to explore it. I need to
> know where it leads me.
> Before I write it down I have to remind myself of how it all started. Before
> summerbreak I saw this girl walking across the central square of campus. She
> clearly had _things_ done. Marisha even called her a _Barbie girl_. I must
> admit her boobs cleary weren't _all natural_. During the break I couldn't
> stop thinking about her and whenever I saw myself in the mirror I imagined
> how it would look on me. The more I did the more I wanted to have bigger
> boobs, a smaller nose, wider hips.
> I arrived a week early at campus and I have a few days on my own. I started
> exploring the internet about breast enlargements. One thing lead to another
> and I came across several sites referring to them as _Bimbos_. I prefer
> Barbie, but what can you do? Last night I watched some _adult_ videos of
> women like that and it arroused me to the core. The more I watched the more I
> wanted to be in their place, so much even that I pleasured myself in the
> bathroom last night.
> Today I made the first steps into my _Barbiefication_, I got myself some mini
> skirts, crop tops and even a pair of 6 inch heels. I am wearing them right
> now as I'm writing this. I might even take some pictures of myself later.
> This booklet will be filled with my experiences becoming a Barbie girl, my
> adventures while doing so and I will collect all kinds of information I need
> to know and remember.
> This is the first step, the next one is telling Marisha. I am _not_ looking
> forward to that.
> Kisses, Laura.

I read what I had written one more time and smiled as I looked out the window
across from my desk. My feet were hurting a lot by now and I quickly took off
my heels and sighed a breath of relief when my feet were in a natural position
again. I rubbed them a little and looked outside again. I ate another bagel and
finished my latte. The sun was shining fiercely outside and I felt the urge to
go outside to enjoy the weather. I changed into my black mini-skirt, grey top
and grabbed a jacket from my closet. I checked myself in the mirror and smiled,
the sneakers matched really well with my outfit.

As I held the doorknob in my hand I took a deep breath and stepped outside. On
my way out I bumped into some people I knew and waved as they said hello. One
of the said "nice outfit." and smiled. Hearing her say so did me good. A few
minutes later I walked across the square towards the on-campus Wallmart. It
wasn just a small version, but they still had almost everything a student ever
needed. I was in dire need of some femaile hygiene products, toothpaste and
also got myself some showergel.

I stopped at the isle with makeup, but had no clue on what to buy so I just
kept it to mascara, eyeliner and lipstick. I had never ever bought anything
like that before and was a little nervous as I stood at the register. A few
minutes later I left the store, as I was still beautiful outside I decided to
just take a little stroll through the park outside of campus. I walked for
nearly an hour before I returned. Nobody had looked strangely at me wearing
what I was wearing, quite the opposite people didn't seem to care.

This was rather a revelation to me, in my old town I would have been called all
kind of names and none of them would have been nice. It took me nearly half an
hour before I forgot I was even wearing a mini-skirt. This all felt so
liberating.

The next day I repeated the walk through the park, this time I wore my brightly
pink outfit and I had gotten myself a nice big pair of sunglasses from 
Wallmart. I sat down on a bench overlooking the pond and watched the ducks swim
in the water. It all felt so calming and the more time I spent outside the less
I cared about what people thought of me wearing clothes like these.

Every day I practiced walking in my heels and the more I did the better I got,
the more time it took for my feet to start hurting. On the morning before
Marisha would arrive I could wear them for almost four hours before the pain
became unbearable. It was around 1 PM when Marisha texted me she was almost
there. "Just another hour or so," she texted. And I stared at myself in the
mirror. Would I dare? No. Quickly I changed into something more like the old me
and put everything away in my closet. My _Barbiefication Diary_ I put in my
backpack, together with all the pens.

By the time I was done nothing about that part of me was visible anymore, not
even the makeup I had bought myself. I sat down at my computer and tried to
think of something to do. In the end I just opened YouTube and watched some
videos until Marisha walked in the door.

"Hi," she said and put down all the bags she had been carrying. "I've missed
you," she continued, "I would never have thought I would, but I did." I got up
and hugged her.

"I've missed you too," I said, "Boy, have I got a lot to tell you."

"Me too," she replied, "but you go first. I am too tired from driving here. 18
hours! But finally I got my car here." I remembered her telling me she had
flown here last year, as her parents thought it was too far for her to drive
alone.

"I thought your parents were agains it," I said.

"I changed their minds," Marisha said with a smile, "and my brother came with
me. He's in the coffee shop getting us a drink. A latte for you and a
Mocchacino for me. And whatever he drinks."

"Thanks, but how will he get home again?" I asked.

"We will drop him off at the airport tomorrow," Marisha said, "until then he's
booked a hotel room." There was no other way, guests staying overnight wasn't
allowed in the dorms.

"Okay," I said thinking I couldn't tell her the most important thing I had to
tell her now. I just couldn't risk her brother walking in on it. So I sat down
and said "My parents are moving to Rotherfield. My dad got an offer he
couldn't refuse, to quote a movie. It's a big step for them, my father is
leaving is hometown. The place where he grew up."

"How do you feel about that?" she asked.

"To be honest, I am happy for them. Being back there reminded me off how
restrictive it is to be there. I had never realized how much until I returned
there. I believe I've changed ever since I came here and now I'm back here I
don't think I want to go back there again. So I am happy my parents are moving
away."

"Wow, that's a big change."

"Yeah," and I thought 'You don't know half of it'. At that moment there was a
knock on the door and Marisha opened the door. In the doorway I saw a very
handsome young man, with a tray of coffee in his hand. The resemblance was
clear and with a deep voice he said "Hi, I'm Travis, Marisha's brother." As he
stepped in he pushed her away and said "She told me you wanted a latte, so this
one is for you." I stared into his deep blue eyes and felt myself drift away in
them.

"L -- Laura," I stuttered.

"Yeah, I know. She couldn't stop talking about you. She talked so much about
you I just had to meet you." he laughed. Marisha pulled his arm and grabbed her
coffee. "You could have handed me mine too," she said with sarcasm in her
voice, "and don't be a dork. This is Laura, she's my friend and I will hurt you
if you do NOT give me my Mocha chino!"

Travis laughed and said "Don't mind her. She's just being my little irritating
sister, like she is all her life. But I do love her." He wrestled her arm a
little before giving in and handing her her coffee. "Dork!" Marisha shouted.
"Goober," Travis replied. They clearly were brother and sister and I smiled
seeing them interact that way.

"Boy, am I glad you're going home tomorrow. Aren't there any flights tonight?
I've spent 18 hours listening to you rambling about football and whatever
sports you're into. I've had enough, go home!" Marisha said with fake anger in
her voice.

"I love you too," Travis replied.

I laughed and we had a few pleasant hours together, ending in the three of us
getting a pizza at the on-campus pizza place. We sat outside as we enjoyed our
late dinner. Before we realized it was time for Travis to go to his hotel and
we made plans to meet up early in the morning.

When we returned to our room Marisha told me all about her weeks at home and
how she had decided to drive home this time. "The first time I stepped into my
little car I knew how much I had missed her. I just couldn't leave her at home.
So Travis offered to go with me on a small road trip, we had loads of fun. He
isn't as bad as he looks, he might look like a sports dude but he's a real geek
inside. He's totally into something called _Dungeons and Dragons_, what the
heck that is. He's what I call a football geek. He loves football, but comics
too and stuff like that."

I snickered and couldn't imagine what that would be like, but one thing I knew
for sure I liked him a little too much. "What does his girlfriend think about
it?" I asked hoping for an answer.

"Oh, he hasn't got one. He's single and has been for a few years now. He's
looking for the right girl, he says. Don't worry, you're not his type. His type
is monster tits and lots of makeup. Like that girl we saw before summer break."

I blushed a little when Marisha brought her up and did my best to hide it.
There was just something in her look that told me I hadn't been successful in
it. She stared at me with a look of 'you're hiding something from me', a look I
knew all to well from my mother.

I took a deep breath, now was as good a time as ever and I said "Marisha, can
we talk? I mean really talk? I need to tell you something and I can't wait any
longer. If I don't do it now I'm afraid I never will." I said with my heart
beating so fast I thought it would explode.

Marisha sat up and said "Sure, what is it?"

I looked down at my hands and said "Well, this isn't easy or simple for me so
please hear me out. I don't know how to tell you this so I will just say it,
okay? I told you how restrictive going home had felt to me, didn't I? Well,
it's a bit more than that. Remember what Amber said that day before summer
break? How people should be who they are and how it could be against the will
of God if he was the one that made them that way? Well, I've been thinking
about that a lot since that day, and I mean a lot. Almost all day, every day. I
even talked to my mother about it. Not everything, but a lot of it."

"Okay, what are you saying? I don't quite understand where you are going with
this." Marisha replied.

I took a deep breath and said "I might be doubting God and maybe even me being
a Christian. The more I think about it, the more I look for answers the more
questions I come across. I don't know, but I haven't been praying for weeks
now and it doesn't feel any different from when I did every night. I've noticed
nothing different at least. Before I would think about what God or other people
might think of me and now I don't anymore. Not that I don't care, I just don't
think about it with every move I make, or with every word I say."

"And how does that make you feel?"

"I feel liberated, free. Those are the words that best describe how it makes me
feel."

"Then I don't see anything wrong. If it had made you feel guilty or bad in
whatever way I would have said go back to church and do whatever it is you need
to do to ask for forgiveness. But, if it makes you feel good or if you are okay
with it -- well, explore it some more and I will support you."

"Thanks, I'm still a little confused about it but it does feel good not the be
thinking about it all day long. Not to worry about what other people might
think. I've still got a long way to go, but I'm getting there."

"I am so happy for you. I think it's a good thing you are doing. And who knows
maybe you will return to being a Christian again some day. You will never again
become _that_ Christian again, that's for sure. So enjoy this journey, explore
it and see where it goes."

"I will, but there is something else I need to tell you. Something that might
be even worse than that."

"Oh, which is?"

"Well, that girl you mentioned? _Barbie girl_ you called her?"

"Yes, what about her?"

"Well, I've been thinking about her too. Maybe that's what led me to doubting
everything. During summer break every time I looked at myself in the mirror I
imagined myself dressed like her, have a body like hers and I realized --"

"You realized what?" Marisha said after I was quiet for a while.

I looked up at her and said "I want a body like hers. I want a smaller nose and
wider hips. My lips filled like hers. I want to be a Barbie girl too. I want to
express my femininity and my sexuality. I even bought mini-skirts the other day
and I have worn them outside too! It was so liberating to see that nobody cared
about what I was wearing. I want to learn how to do makeup, I want my hair to
grow long and I want to dye it. Marisha, I want to be a girly girl! One with
very big boobs."

Marisha eyes lit up and she burst into laughter. When she calmed down she said
"Is that it? I thought something really heavy or dark would come, but you
wanting to be a girly girl? I never saw that one coming. And right after you
told me about doubting God? I really thought you were going to tell me you
murdered someone or something. What else could be darker than loosing your
religion?"

Hearing those words made me laugh too as I realized how right she was. Compared
to me doubting God, the last part wasn't that dark. I felt a sense of relief
she didn't get angry or something like that. On the contrary she didn't seem to
find it strange in any way or form.

When she stopped snickering she said "You really do want to be like that girl?
You really mean that?"

I nodded and said "Yes, I've even searched for information online the past
couple of days. I came here early so I could be on my own for a while, just to
get my thoughts straight, you know? And I saw a lot of pictures of women who
had _things_ done. Did you know you can get adjustable breast implants? They
will place a little port underneath your skin and with a needle you can fill
them up with saline. Which is a lot safer than silicone implants. If a saline
one deflates your body will just get rid of the saline. Imagine having those
and you want a cup larger, you just go to the doctor and he will inject saline
into them. All under local anesthetic."

"Wow, you've been studying up on this," Marisha said.

"Yes, the more I looked for information the more I knew I want to do this. I
want my nose smaller too, I've always hated it. Then I saw a picture of a girl
who had made herself look like Barbie and she's so beautiful. The moment I saw
her I knew I wanted it too."

"But isn't it all very expensive?"

"Yes, but I thought I could get a job and safe up some money." I replied.

"Good luck with that one," Marisha replied, "the moment you start working they
will cut your scholarship, won't they?"

"I don't know, I don't think so but I'm not sure. They will revoke it the
moment I tell them about the other thing though, so please keep that between
us. I just need to pretend I'm still that girl for three more years."

"Wow, that's a long time but I will tell nobody. These are our little secrets,
okay? And I'm happy you decided you can trust me with this. Can I tell you a
secret too?"

"Sure," I replied.

Marisha got up from her bed and sat down next to me on the floor. She looked at
me and said "The past few weeks I've felt something wasn't quite right with me,
every time I looked at myself I thought I was missing something. I just could
tell what, until just now. When you told me about wanting to become a Barbie
girl, it was at that moment it clicked for me. I think I want to join you, I
think I want to be one too."

"What? You really mean that?"

Marisha nodded and said "Yes, think about how much fun it will be? I can teach
you everything about makeup and stuff. We can both explore the possibilities
and whatever, we can share this with each other. I am so eager to see where
this goes."

"Me too," I said, "Wait, I need to show you something." I got up and took my
new outfits from the closet and showed them to Marisha. "And that's not all," I
said as I grabbed the pair of heels I had purchased.

"Wow, those are really high," Marisha uttered.

"I've been practicing," I laughed, "This morning I was able to wear them for
four hours!"

"Wow!" Marisha said, "What size are these? Do I fit them? No, they're too small
for me. Darn it, I so wanted to try them on."

"They were 70% off, can you believe that?" I blurted out.

"What? 70%? You lucky girl you. And these are just beautiful, these I can wear.
Maybe I can borrow them one day." Marisha smiled.

It was so much fun talking with her about this and later on I showed her the
different websites I had found on my quest during the past few days. We
marveled at some photos of women who had their breasts enlarged and the both of
us were in awe of some of the 1000cc and more breasts we saw. The more I looked
at those women the more I wanted breasts like that. All in all it was so nice
to share this with Marisha and during those hours we grew closer than we had
ever been before. That night we became _Barbie sisters_.
