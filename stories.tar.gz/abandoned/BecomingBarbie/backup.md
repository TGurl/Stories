# Chapter 1
Bent over my books my thoughts went to the sounds of the party going on just
below my window. I could hear people having fun and the music sounded really
inviting. How ever much I wanted to go there I couldn't, I had to prep for
exams the next week and I really wanted to pass so I could go home for the
summer break.

If I didn't pass I had to stay for summer classes in order to move on to the
second year and I was not looking forward to that. I hadn't seen my family in
months and I really missed them, a lot. Sure nowadays you can Skype or Zoom,
but it just doesn't feel the same to me. My parents had hated it when I told
them I wanted to go here and being a thousand miles away from home wasn't easy
at first, but I struggled through it and as time went on it got a little bit
easier.

"Mom, I need to be independent," I had said, "I need to be somewhere where it
isn't easy for me to lean on you. I just have to do this."

My mother had sighed and given in "But I still don't like it." My moving here
had broken her heart, I could see it. Just the other day she called and told me
she understood why I had to go and that she still loved me. Hearing that made
it easier for me to cope with the homesickness, from which I still was
suffering.

I got up and closed the window in order to muffle the sounds coming from the
party downstairs, not that it helped but it felt more like a symbolic win and I
returned to my books. A couple of hours later the party was over and it didn't
take long for my room mate Marisha to return. "Wow, that was so much fun!" she
said as she walked in.

I looked over my shoulder and sighed, saying nothing I returned to my books and
tried to get through this last chapter. Marisha was the total opposite of me,
where I was reserved she was outgoing, where I dressed modestly she, well you
get the picture. She was an English major and I did my best to work my way
to a law degree. Had I realized how dry most of the stuff was that I had to
learn I might have chosen something different, although I had no clue what that
would have been. My father was a lawyer and it had always been my dream to take
over his practice when the time came.

You should have seen my father's face when I told them I wanted to study law
and I even applied to some of the big colleges only to be rejected. Not that it
mattered much, my dad hadn't gone to an ivy league school either. Their mood
changed however when I told them _where_ I wanted to go. Being an only child
had been great, this was one of the drawbacks however.

My mother had a hard time with me being gone as she had hoped I would go to a
college nearby so I could stay home for a few more years. But I felt it was
time to go and move out, I was 18, almost 19 and I didn't want to live at home
until I was 23.

"Hey, it's almost midnight. Why don't you stop for today? You need some rest."
Marisha said waking me from my thoughts. To be honest I hadn't read a letter
for the past three quarters of an hour, all I had done was drift away in my
thoughts and think about anything but what was in front of me. I looked at her
and said "Maybe you're right. It's just so hard. I never thought it would be
like this."

"Why don't you change majors, you could take English. At least you get to read
some great books in the process instead of those dry law books." Marisha
smiled. We both knew it was way to late for that to happen and I was committed
to see this through. I had spoken with some second and third year students,
they all said the first year was the hardest and I held on to that idea. All I
had to do was pass the next round of exams.

I turned to Marisha and said "I'm so tired. My head hurts and I really do want
to go to sleep. But I really need to study, I simply don't have the time."

"If you go on like this you will fall asleep at that desk, I promise you that.
Just lay down for a few hours, rest and start fresh in the morning. My father
always said 'You learn more if your mind is fresh.' and he was right. Don't you
ever tell him that I said so, he will gloat for weeks if not months and I will
never hear the end of it." Marisha chuckled. She got up, laid her hands on my
shoulders and said "Come on, go to bed and sleep. I promise I will be quiet."

I slowly rose up from my chair, my back was hurting for sitting for all these
hours and I stretched my back. I walked over to my bed and noticed how inviting
those sheets felt. I turned around and said "I will rest for a few." I fell
onto my bed and before I knew it the warm rays of the sun on my face woke me up
again. Clearly I had fallen asleep as soon as my head touched my pillow. I got
out of bed and noticed I wasn't wearing my clothes anymore. Marisha had
undressed me and put me to bed, there was no other explanation. I chuckled when
I pictured her struggling with my sleeping body and smiled when I watched her
sleep in her bed.

Although we mostly were polar opposites, she had a big heart and I felt so
happy that I met her. That chance meeting had changed the both of us, I had
become somewhat more open and she had become a little more reserved. After a
week or two we asked my then room mate if she wanted to switch and she to our
relief said yes. I didn't really get along with her that well and she didn't
really care who she roomed with. When the move was approved by the school it
was done in just a few hours.

Marisha felt like the sister I never had and she felt the same way. All she had
was a couple of brothers and as I said I was an only child. I shook my head to
get back into the present, grabbed a clean towel, my bag with toiletries and
walked towards the bathrooms. There were three of them, one for the girls, one
for the boys and as a pilot they had opened a mixed one too. Not that it was
used much and when it was we mostly put a pink or a blue sock on the doorknob
to indicate who was in there.

One morning as I passed the mixed bathroom I was sure I had heard some moaning
coming from in there. I was sure people were having sex in the shower and I had
chuckled thinking "Well, at least it's good for something." I never got to know
who it were in there and I didn't really care either. As I opened the door to
the girls bathroom I was greeted by Amber, a fellow law student of mine.

"Good morning," she said, "ready for the exams? I really need to study hard for
these. I think I will be studying all weekend."

"Me too. Good morning, by the way. Hey, I've got an idea, why don't we study
together? It might go a little faster."

"Sure, why don't we meet at the library this afternoon, let's say around noon?
We could grab a lunch before we start."

"Great, noon it is." I smiled and stepped into one of the booths. As I was
getting ready Amber said "See you at noon then." and I heard her walking out
the room. As far as I knew I was on my own in there and just a few minutes
later I stepped in to the hot water coming from the shower.

Half an hour later I returned to our room and Marisha was sitting up in her
bed. "Good morning," she yawned, "You're up early."

"Did you put me to bed last night?"

"Yes, I did. I couldn't let you sleep in your clothes, now could I? I should
have become a nurse, I was rather good at it. I had you in there in no time at
all."

"Thanks for not taking off my underwear. I would have been embarrassed if you
had done that."

"Why? It's not that I haven's seen a female body before. Last time I checked I
still had one of my own."

I started laughing and realized she was right, but still I would have been
embarrassed. It's just the way I'm wired, I guess. "Oh, good news. Amber was in
the bathroom and we agreed to study together this afternoon. We will grab a
lunch at noon and then go to the library. So I will be out of your hair for
most of the day."

"As if you are a bother to me," Marisha replied, "but nice to see you getting
to know other people. I hate to see you alone all the time. And be honest know
who asked who?"

"Oh, I asked her. I really did."

"Wow, big step." Marisha chuckled, "First you ask me to become your room mate
and now you're asking Amber to study with you? You _are_ making progress, my
dear."

I really was and I was proud of it too. In middle and high school I had been
bullied a lot and that had made me the way I am, reserved and protective of
myself. The bullying had become so much that my parents even pulled me from
school and started to home-school me. They even went out of their way to
organize a prom for me and it was just magical. One of the neighborhood boys
had asked me to go and I felt really pretty in that dress that night. My mother
had tears in her eyes when she saw how happy I had been that night.

Maybe that was a contributing factor for me to choose to go to a college far
away from home. It was here where I learned to co-exist with other students and
that not everybody wanted to put me down. It was quite the opposite to be
honest. People here seemed to like me and didn't really mind a conservative
Christian girl in their midst. Some of them even were those _evil_ atheists
they had always warned me about, but when I got to know them they weren't that
bad. They respected my believes even though they didn't agree with them. Some
of them even said they just didn't care.

Now I have to explain that my parents were not very strict Christians, the were
more progressive than every body else at home. One of the reasons I got bullied
was the fact my mother as pro-choice, as a medical doctor she always tried to
inform people with the scientific truth around that matter. The moment she
spoke out was when I became the _baby-killers child_. I had never told her why
it was I got bullied so much until it all just came out. She held me in her
arms and said she was sorry, but she also said she couldn't keep silent about
it. "It's just too important to me," she said, "and we still live in a country
where there's free speech. That doesn't give anybody the right to do what they
did to you and for that I am so sorry."

A few minutes before noon I met up with Amber and we got some lunch together at
the small diner on campus. Afterwards we went to the library and studied for a
few hours until we realized it was way passed six in the evening. We decided to
get something to eat and returned to our studies until the library closed at
ten. We had gotten a lot of work done and we both felt good about our chances
of passing the upcoming exams.

"Let's do this again tomorrow," Amber said, "just one more day and I think
we're ready."

I just nodded and said "Thanks for doing this. I had a really hard time
understanding some of it and you explained a lot, so thank you."

"You're so welcome," she smiled, "you did the same for me, you know? We should
have done this earlier, see you tomorrow." And with that she walked off.

"At noon again?" I shouted after her and she just waved.

I chuckled and made my way back to our room. Even though we had worked all day
I didn't feel as tired as I had done the other days after cramming for hours.
It had been fun studying with Amber and we had laughed a lot too. As I entered
our room Marisha immediately sat up straight and her face turned red. "Oh, I
didn't expect you to be back so soon," she stuttered. From behind her a boy
rose up saying "Hi, I'm Matt. Pleased to meet you." I shook his hand and threw
an angry look at Marisha.

"Maybe you better go," Marisha told Matt, "this might not have been such a good
idea after all." Matt got up, straightened his shirt and said "It was very nice
to finally meet you." before leaving the room.

"What were you thinking?" I hissed at Marisha, "What if I had come in a little
later? Would you both have been naked? Oh, I can't think about that. What if --
Oh God no --"


