# One Hot Summer 
_an erotic tale by TransGirl_

## Chapter One
So far the year had been good for me. I got my drivers license and during the
summer break I would finally visit my uncle Dave again. I hadn't been there in
almost three years and couldn't wait to go. My mother had called her brother
crazy when he bought the farm of some old couple, but now he had expanded it
and she was so proud of him.

It was just a few weeks until summer break and classes were basically nothing
more than completing the curriculum. There were no more tests and the seniors
were preparing their prom. After the last bell I walked out the school and
waved to my mother who was waiting for me. "How was your day?" she asked as I
got in. "The same as yesterday," I replied, "rather boring. I wish it was break
already."

My mother smiled and started the car. "Just a few more weeks honey," she said,
"just a few more weeks." I stared out the window as we made our way home.
Suddenly I realized we weren't going home, I turned to my mother and asked
"Where are we going?"

All my mother said was "You'll see." and she smiled.

My mother was a lawyer at a rather large firm and she looked real smart in her
suit, clearly she had come straight from work. We turned left to the strip mall
and I rose a little when I saw my father standing on the parking lot. He owned
a shop here and I thought it strange he would be waiting for us. "What is going
on?" I asked my mom. She just was quiet and parked the car. We got out and
walked towards my dad.

"Hey," he said and they kissed. "ugh," I uttered, "get a room." My mother
chuckled and said "Your father has something to say to you." I turned to my
father and he said "Luna, we are so proud of you. Not only did you get straight
A's at school, you also got your license. You've been working hard at our store
and we thought we should reward that. So, what do you think?"

My father stepped to the side and I had no clue what he meant. "About what?" I
asked. Then finally the penny dropped, we were standing in front of a car.
"What? Is this real? You are joking --" I shouted.

"No," my father said, "this is yours." and he handed me the keys of the red 
Toyota Camry. I pressed the button and the car unlocked. "No, this isn't real."
I shouted. Many times I had told my father how I loved the Camry and he always
said "When you get enough money, then maybe." But they actually had bought me
my favorite car. I jumped for joy and got behind the wheel.

I squealed as I sat down on the soft chair and touched the dashboard. Then I
quickly got out and jumped into my fathers arms. "Thank you so much," I yelled,
"This is the best." After thanking my father I repeated it with my mother and
couldn't stop cheering. As I sat down in the car again my father leaned over
and said "Now, the car is registered to us and also insured on our name. But,
there is a catch. You will have to pay for gas yourself. So, you will need to
get a job. But that will start after summer break, okay?"

"Okay, Okay, can I show Melissa? Please?" Melissa was my best friend ever since
kindergarten. We used to live next to each other, but over two years ago she
moved to the other side of town when her mother remarried after her father had
passed away. At first Melissa hated her step-father, but that had changed over
the years. Having my own car meant I could visit her more often and it was the
best feeling ever.

"Sure," my father said, "but be home for dinner, okay?"

I squealed again when I started the car, it was so quiet. The dash showed me I
had a full tank of gas and carefully I backed out of the parking spot. I waved
to my parents as I drove off. Driving my own car for the first time felt like
freedom and I felt like a real adult as I made my way over to Melissa.

I parked the car just out of sight and walked over to the front door. I rang
the bell and when Melissa saw me she jumped to me to hug me. "What are you
doing here?" she asked and then she shouted "Mom, it's Luna!" She opened the
door further and then asked "But wait... Where's your mom? How did you get
here?"

"Well, that's actually why I'm here." Melissa's mother walked into the hallway
and I said "Oh hello Mrs Miller. Maybe the both of you should come with me."
Melissa and her mother followed me outside. When we reached my car I shouted
"Tada!" and acted like a TV show assistant. "What?!" Melissa shouted, "this is
yours?" I nodded and said "Yeah, my parents gave it to me earlier. Don't you
love it?" Melissa turned to her mother and asked "Can we take it for a spin
mom? Please?" Her mother laughed and said "Sure, but just around the block
okay? Dinner is almost ready. Will you be staying Luna?"

I shook my head and said "No, my parents are waiting on me. I just couldn't
bare not to shoe Mel." The both of us got in the car and I drove around the
block a few times, Melissa was busy getting her license and said "I hope I will
get the same one. Different color of course, but this is nice."

After a few laps around the block I dropped Melissa off and waved to her when I
went home. During the whole trip I couldn't stop smiling. When I got home I
carefully parked the car on our driveway and walked in the house. "It's just
magical," I said to my mother who was preparing dinner, "Thank you so much, I
can't wait to show it off at school tomorrow."

The next day there were some jealous class mates and I was so proud of my car.
It felt really good to drive to school myself. After school I dropped Melissa
off again. Somehow going to school the last days of the year wasn't such a bore
anymore. During those last weeks I tried to convince my parents to let me drive
to uncle Dave. "No Luna, you're just 16 years old," my father said sternly,
"You are _not_ driving 600 miles on your own. No way, never." I thought he was
was being too strict and stormed into my room slamming the door behind me.

The last weeks went by slowly but finally summer break had arrived. I drove
home that Friday afternoon and parked my car on the driveway. As I walked in
the house I found my mother sitting at the kitchen table. It was clear she had
been crying, a lot. I put down my backpack and asked her what was wrong. "It's
your grandmother," she said, "she fell this morning and is in the hospital.
According to the doctor it's not looking good. Dad is on his way home, I need
to go there." She started crying again, her parents moved to Florida a few
years ago and hadn't seen them in almost two years.

My mother was just a wreck and I tried to comfort her the best I could. When my
father came home he took over and the two of them went into the living room.
After a few minutes my father called for me. Slowly I walked in and sat down on
the chair near my mother. "Okay," my father said, "here it is. We are flying to
Florida tonight. I already booked the tickets. You can stay over at Melissa's,
her parents already agreed to it."

"Or I could go to uncle Dave," I said, "If I drive all day I can get there in
about 10 hours or so." My father looked at me "No, not that again. Not now."
But my mother touched his arm and said "Just let her go. She's a good driver
and she's responsible. When did she ever broken our trust? Never." My father
sighed and said "No, it's just too dangerous. A sixteen year old girl on her
own? No. It's not that I don't trust you Luna, I just don't trust the rest of
the world."

"But we need to let her go someday," my mother said, "she's growing up,
becoming her own independent woman. Just one more year and she's going to
college or do you want to keep her in a golden cage then too? Just let her do,
Tom. It's the right thing to do."

My father sighed and said "Okay, but text us as often as possible and no
stopping at any things along the road. Only stop in towns if you need a rest.
And no deviating from the shortest route either, get there as quickly as
possible." He turned his head away saying "I can't believe I am actually
agreeing to this."

My mother smiled at me and together we started packing everything I needed for
the next couple of weeks. "Just be very careful," she said while we were
packing my clothes, "Don't make us fly back."

"Mom, why is dad being so difficult about this?" I asked her. My mother looked
up and said "You will always be his little girl, even when you're older. That
will never change, he's just worried about you. That's all." She sat down on
the bed and continued "Look, you are our miracle child. We tried for several
years to get pregnant, IVF and everything, nothing worked and then one day I
felt sick and discovered that I was pregnant with you. That's why we are so
protective of you, we love you so much Luna. Your father just wants to protect
you." I sat down next to her and said "It will be okay with grandma, mom. I'm
sure of it." My mother started crying again and hugged me "I hope so Luna, I
hope so."

We just finished packing as my father came into my room. He walked towards me
and handed me a credit card. "It's a prepaid card," he said, "There's enough on
it for the next couple of weeks. You can use it for gas and anything else you
might need. If you need more just call us." He then showed me how I could check
the balance on my phone. I was amazed when I saw there was actually 2000
dollars on it. "That should last you a while," he said, "Don't spend it all in
one place. As I said, it's for gas and stuff." I noticed a tear in his eye, I
hugged him and said "I will be okay dad. Thank you so much and I will text or
call as often as I can."

Together we packed my car and I drove over to Melissa's to spend the night
there. A few hours later my father called to tell me they had landed safely and
were on their way to the hospital. Another hour later he texted grandma was
getting better, he ended the text with _Florida is still too humid._, that's
when I knew for real everything was okay. Later that evening my mother called
and we talked for almost an hour. "Grandma is okay honey," she said, "It was
touch and go for a while, but for now it looks like she can go home in a few
days. We will be staying to help them out. We will try and get them some help
before we go home." I told her I loved her and went to sleep.

The alarm sounded real early and Melissa's mother made breakfast for me. "Oh
Luna, do you really want to drive to your uncle all alone? You are welcome to
stay here, you know that right?" I nodded and said "I know, but this is
something I want, no I need to do. I know it can be dangerous so I will be
careful, but I need to know whether I can do this. I promise to come back as
soon as I get to scared, okay?" Melissa's mother hugged me and said "Okay. It's
not on me to stop you from going. Just text us, please. Melissa is worried
too."  An hour later I got in the car and drove off. My adventure had started.

## Chapter Two
At first the drive over to my uncle had been exciting, but soon the monotone
driving on a straight highway got boring. I sang along to the radio to try to
break the boredom, but nothing seemed to really work. All I saw around me was
large fields of crops, it all was just more of the same. After two hours I left
our state and the landscape slowly changed. Luscious fields changed into sandy
desert, in the distance mountains were visible. The colors changed from greens
to reds as I drove on.

I was getting tired and stopped in a small town for some rest. I sat down in a
booth of a diner and ordered a burger with fries. The waitress asked me where
my parents were and I told her I was on my own to go to my uncle. "Oh," she
said, "but you're so young. Aren't you scared?" "Until now," I replied, "no,
not really." I texted my parents where I was and enjoyed my roadside food.
After sending my mother a photo of myself she replied with a smiley.

Half an hour later I was on the road again, in stead of being straight as an
arrow the road was more bendy, going around red stone mountains. I was just in
awe of the landscape, somehow it was just beautiful to me. At some point the
view was just mesmerizing and I couldn't help but stop to take a picture with
my phone. The road was empty, there wasn't a car in sight and I took a few
minutes to enjoy the view before I got back in the car.

My navigation told me there was still 5 hours to go and my dashboard told me I
had enough fuel for another six, so that should be plenty. Again the landscape
changed slowly, the reds changed into mauve and then sandy colors, in the
distance I saw my first cacti and once more I stopped to take a photo. During
the last few hours I had seen just about ten cars and a few trucks on the road.

Just one more hour and I would arrive at my uncle's farm. I was just so tired
of driving and I really wanted it to end. I really needed to take another rest,
but I was in the middle of nowhere and the sky showed all kinds of colors as
the sun slowly set. There was just nowhere I could park but along the road and
my father had warned me not to do that. So I decided to drive on as tired as I
was I had no other choice.

The miles counted down slowly and time was slowing down, finally my navigation
told me to take a left turn. Just a few more miles until I arrived. The sandy
desert changed into fields of corn announcing my uncle's farm. The moment I
saw the entrance to his driveway I felt elated. I had made it, finally. I
turned left and after a few more minutes I parked the car near my uncle's
house.

The front door flew open and my uncle came storming out. "LUNA!" he shouted
while he ran towards me. He opened the door and nearly pulled me out. "You've
made it, you're finally here. I was so worried all day. Oh am I happy to see
you. How was it? Oh my God, am I happy to see you." I smiled and hugged my
uncle. "How's grandma?" I asked him. "Oh, she's okay. Your mother told me they
will get her home the day after tomorrow. Come in, come in. You must be tired.
I will get your stuff out the car later."

We walked into his house and I was so happy to lay down on his couch. It had
been a long nine hours and almost fell asleep. "Here you are," my uncle said as
he placed a glass of lemonade on the table next to the couch, "You rest. I will
unpack your car, which is beautiful by the way. You just lay here, okay?" I
nodded, took a sip of my lemonade and just fell asleep.

"Luna? Luna!, wake up," my uncle whispered while he softly shook me, "Dinner is
ready. Wake up girl." I opened my eyes and for a moment didn't know where I
was. But then I saw my uncle and smiled. "How long was I asleep for?" I asked
him. "Oh just a few hours. I let you sleep because you really looked like you
needed it." I thanked him and got up from the couch.

"It's a nice couch," I said with a slight smile. "I know," my uncle responded,
"believe me, I know." We sat down at the kitchen table to have dinner together
and I told him about the drive over. "At first it was exciting, but then it got
boring. But I did seen my first cactus and the red desert was just beautiful, I
had never seen it for real." My uncle listened to me patiently and when we were
clearing the table he said "I've put all your bags in your room. All you have
to do is unpack. The bed is made and I think _Ariel_ knows you're here, she's
been restless ever since you arrived."

Ariel was my horse, she was born on the farm and I helped my uncle with her
birth. The both of us were relieved to see her standing up and my uncle asked
me for a name, afterwards he said "Ariel is your horse, when she's big enough
you can ride her. And when you are here you can take care of her." That summer
I spent almost all my time with the mother and Ariel. Somehow the mother knew
too and I was the only one she allowed to get near her child. The summers after
I saw Ariel grow and every time I was there Ariel ran to me, she really knew
who I was.

When I was finished unpacking I walked over to the stables and there was just
one horse who looked outside and it was Ariel who whinnied the moment she saw
me. I opened the door and petted her. "Hey there Ariel, yes it's me." I
whispered as I patted the white spot on her forehead. Ariel bopped her head and
whinnied again. I got her some more hay and started to brush her. I loved this
horse so much and wished I could live more close to her. After spending a few
hours with Ariel I walked back to the house, showered and got into bed. I was
spent, I really needed to sleep.

The next morning the rays of the sun coming through my window woke me up. I got
up, took a shower, got dressed and walked down the stairs. On the kitchen table
was a note from my uncle. _I'm working the fields today. Breakfast is in the
fridge. Help yourself._ I smiled and checked the cupboards for some serial and
a bowl, in the fridge I found a bottle of milk and sat down at the kitchen
table. After having breakfast I cleared the table and walked outside. The sun
warmed my face and in the distance I could see the clouds of dust behind the
machine my uncle was operating.

My body was still a bit stiff from driving all day the day before and I thought
a short walk would be good for me. I explored the farm a little bit before I
sat down on the patio. The farm sounds really relaxed me and I just enjoyed
being there. After a while I decided to get some sun, changed into a bikini and
got one of the lawn chairs from the shed. I rubbed sun block over my body and
laid down. The sun felt warm and comforting enough to make me sleepy again.

"Ah, I see how it is," I heard my uncle say some time later, "me working hard
on the fields and you just laying here." He chuckled as he went into the house
"Want some lemonade?" he said. "Sure," I replied, "the sun is getting to hot
anyways." I walked in and sat down at the kitchen table. When my uncle sat down
across from me I couldn't help to notice him looking at my chest. Although it
was inappropriate for him to do so I didn't really mind. For my age I had grown
into a full female body and there were no signs that the growth was stopping
soon. My girls were getting bigger the older I got.

"Is it okay if I got riding this afternoon?" I asked my uncle. He smiled and
said "You know where the saddles are, don't you?" I nodded and smiled. I
stretched my body, not only to get rid of the soreness but also to tease my
uncle a little bit. I finished my drink and got up. "I guess I'll change into
some other clothes then." I said and walked towards the stairs. I knew he was
watching my back and I smiled a little.

After changing I walked into the stables, got a blanket and a saddle. Ariel
whinnied again as if she knew what was about to happen. I saddled her and
walked her out. Ariel stood perfectly still as I got on top of her and we
slowly rode towards the road. On the other side a trail started and we rode
along it for a while until we were in the middle of nowhere. I slowed Ariel
down and she whinnied a little.

After a short while we came across a pond and we stopped for a little rest.
Ariel drank from the water and started grazing. I laid down next to the water
and felt like it couldn't get any better than this. I just listened to the
sounds of nature and smelled the air filled with the sweet smell of the
flowers. It was all just so peaceful.

After a few hours I returned to the farm, brushed Ariel and thanked her for a
lovely day. When I walked into the house I found my uncle grilling steaks
outside and I set the table for us. I got myself a soda and a beer for my
uncle. He gratefully accepted the beer and I said "Maybe I change before
dinner." I put on a dress and my flipflops, when I got back to the patio the
steaks were ready and we had a nice dinner.

During dinner my mother called to tell us grandma was home and we chatted for a
while. I told her about the day I drove there and how I rode Ariel that day. I
even spoke with my grandmother for a while before handing the phone to my
uncle. My uncle talked to my mother for quite a while and they acted like the
typical siblings, arguing a lot but it was mostly teasing.

My uncle handed me the phone and said "Your father wants to talk to you." I was
a bit anxious as I took the phone. "Hey sugar," my father said, "I am so glad
to hear everything went okay. You know what? As a reward get yourself something
nice, like that camera you are talking about for so long. Just promise me to
take a lot of pictures, okay?" I cheered softly and said "Thanks dad, and I am
so happy grandma is okay. -- What? No, it's all fine. -- I love you too dad.
Bye."  We finished dinner and after clearing the table we sat down on the patio
enjoying the sunset.

The next day my uncle got up early again to work the fields and I got in my car
to drive over to town. In my purse was a shopping list for groceries and some
other things my uncle needed. After getting all that I stopped at the mall to
look for that camera. As I walked to the store I came across racks with
beautiful dresses on sale. They were 30% off and couldn't let them hang there.
I got three of them, all one-size-fits-all, before proceeding to the
electronics store.

The camera I wanted was on sale too, so I not only got the camera but I also
got tripods, one large one and a small one with those bendy legs so you could
place it anywhere. I also got a backpack for the camera and an extra battery.
Back at the house I unpacked the car, put away the groceries and put the
batteries in the charger and sat down on the patio to thumb through the manual.
After a while my uncle came to the house to get something to drink, his face
was all dirtied up from working the fields.

"You know you aren't meant to actually read those, don't you?" he said as he
passed me by. "You know the field actually doesn't belong on your face, don't
you?" I replied with a chuckle. "Touche," he replied and went into the house.
When he got out he said "Looks like it will take a while for me. Could you take
care of the horses? And the chickens need water and feed too." I nodded and was
happy to have something to do. We chatted for a bit before he got up to go back
to work. A short while after I changed into jeans and a simple shirt, then I
walked over to the chickens to refresh their water and feed them. I also
collected the eggs before I went over to the stables to look after the horses.
I brushed them all, fed them and payed some special attention to Ariel.

After the work I walked back to the house and just as I turned the corner I saw
my uncle standing near his tractor. He had taken off his shirt and I marveled
at his muscular torso. I took a few steps back and just stood there watching
him work the machine. Without thinking I placed my hand on my left breast and
softy squeezed it. "No," I thought, "I can't think of him this way." I shook my
head and continued into the house. From my bedroom I looked out the window and
still could see him bent over the tractor. I clearly could see his muscles move
and again I carressed my breasts. I felt my nipples harden the longer I watched
him work his muscles.

I took off my dress, got a towel and bound it around my body. I stepped into
tha bathroom and started the shower. When the water was warm enough, I dropped
the towel and stepped in. The water falling on my body felt so good, I bent my
head backwards to wet my hair. I poured some shampoo on my hands and started to
wash my hair. At some point I felt like I was being watched and glanced over to
the door. To my surprise I saw it was ajar and I was sure I had closed it. But
instead of feeling freaked out, I felt good about it. I continued washing my
hair and then started to wash my body, making sure I was turned towards the
door as I cleaned my breasts. "If he's really watching me shower, let's give
him a bit of a show." I thought.

When I finished showering, I bound my towel around my body and another one on
my head. As I walked out I was sure to see my uncle, but ther was nobody there.
In my bedroom I looked outside again I saw him still at work with the tractor.
Feeling confused a litte I decided it hat to be me who left the door of the
bathroom open. I giggled thinking I had gotten it all wrong. I put on a dress,
but decided not to wear a bra. 

In the kitchen I checked the bateries and was glad the were fully loaded so I
could play with my new camera for a while. I took some test photo's and then
decided to take one of my uncle working the tractor. I tiptoed outside, pointed
my camera at him and just as he rose I snapped a photo. Clearly he heard the
shutter sound coming from the camera as he turned around and took a few stupid
poses. "Ah, I see the camera works." he shouted with a big smile on his face.

He walked over to me and said "You know, there's a beautiful nature reserve
just a few miles from here. Why don't you got there tomorrow to take some
photo's. It's just beautiful down there, I really need to finish sowing the
fields tomorrow and I will be at it all day."

"That's a great idea," I answered him, "Is it okay to get the horses in the
pasture? It's really warm in the stables and I think it would be good for
them." My uncle laughed and said "I thought you'd never ask." I got up, placed
the camera on the table in the kitchen and walked over to the stables. Opened
the gate to the pasture and led the horses out one by one. The all whinnied as
the took off into the pasture, the last I walked out was Ariel and she whinnied
all the way over. When I let her go she started a gallop and bucked as she
entered the field.

As quick as I could I hurried back to the house to get my camera. Once back at
the pasture I took lots of pictures of the horses, but especially from Ariel.
She looked so magical in the field as she was grazing the fresh grass. I leaned
on the fenct and just watched them as they were playing. After a few moments my
uncle joined me and said "So majestic, right? I love horses." We just stayed
there for a while watching them roam the pasture. "I think it's nice having you
here," my uncle said, "It's been a long time since there was someone here
besides me." I bumped him and asked "Why don't you have a girlfriend?"

My uncle turned to me "That's a very personal question. You're just like your
mother, straight to the point. I like that." He looked back at the horses and
said "The farm takes so much time of my hands, I really don't have the time to
date someone. At first I had to get everything started and had to repair a lot
of things. Like these stabled for instance, they almost collapsed. Then there
was the house, the machines. Work on a farm is never done." I looked at him and
felt like he was a little sad.

"Maybe we could go into town this weekend," I said, "I heard something about a
dance?" My uncle chuckled and said "You know there is a dance. There's one
every year and every year you beg for us to go. Well, okay I think you're old
enough now. Yes, we can go. Happy?"

"Very," I replied, "I am very happy." I bumped him again and we looked into
each others eyes and I felt an urge to kiss him. He just turned back to the
horses and said "Maybe Summer will be there. You know, I've had a crush on her
for quite some time now and I can't believe I just told you that."

"Summer hey?", I said with a chuckle, "Does she have some good _assets_?" He
bumped me and said "Hey, you're sixteen. You aren't allowed to think that way."
We walked back to the house and he told me all about Summer. She worked as a
teacher in the local school, had long blonde hair and the best blue eyes he had
ever seen. At that moment I knew he was in love with her, this wasn't just a
crush.

The next day I told my uncle I was going to the nature reserve to take some
photo's and I was going to do that, but first I stopped in town and asked in
the local supermarket where I could find Summer. I wanted to make sure she was
going to the dance. The woman behind the counter told me where I could find her
and I walked over to the police office across the street. That's where Summer
worked when she wasn't teaching the kids. A small bell rung as I opened the
door, a woman with long blonde hair and very blue eyes came out of the office
and said "Hi, how can I help you?"

"Are you Summer? The teacher?" I asked.

"Yes, and who are you?"

"I'm Luna, Dave's niece. Pleased to meet you." I said.

"Ah, you're the niece he can't stop talking about. Very nice to finally meet
you." Summer laughed with a radient smile. I understood why my uncle loved her
so much.

"Well, this is a bit awkward but I really need to ask you. Are you going to the
dance this weekend? My uncle and I are going and he really would like to see
you there."

"Oh does he now?" Summer laughed, "Does he really?"

I nodded and said "He realy does. And it would be nice if you were there too."

"Wow, sending his niece over to ask me for a date." she chuckeld.

"Oh no, he doesn't know I'm doing this. I just wanted to make sure you would
come. This is all my idea and I'm sure he would ground me if he knew."

"It's all fine," Summer replied, "I would love to meet him there. Thank you for
asking. Wait a moment, please, I will be right back." Summer went into the
office and I could hear her say "Russel, I'm taking my break. I will be back in
half an hour or so." She came out again and said to me "Let's get something to
drink so you can tell me all about that uncle of yours."

We sat down in the diner down the street and talked. "Now," she said, "tell me
the truth here. Does he have a crush on me?"

"No," I said, "I think it's a little more than just a crush."

"Ah," Summer smiled, "I thought so. Well, I like him too. But he never asked me
on a date, ever. Why is that?"

"Well, it's not my place to tell but something happened a long time ago. My
mother told me it happened when I was very little. He sold everything and moved
to the farm. But you need to hear this from him. Let's just say he's very
protective and doesn't want to get hurt again."

"I thought as much," Summer said, "Well, let's work him together this weekend.
Let's show him what us girls can do." She bumped me and I knew she loved him
too. As we got up I said "It was such a pleasure to meet you. But this weekend
we both have to act like we meet for the first time. He can't know I did this."

Summer walked back to the office and I got into my car, as soon as I started it
there was a ping indicating I needed to get some gas. I stopped the petrol
station a few blocks over and asked for help as it would be the first time for
me. The attendant showed me how it worked and a few minutes later I was on my
way to the reserve.

Afer I had parked the car, I put on my sneakers, got my backpack and looked at
the sign. There were different trails and I chose to take the shortest one
first. I loved hiking, but it was hot already and didn't want to take too long.
The trail was simply breathtaking. My uncle had been right about this, there
were streams, waterfalls and the trail made it's way up a mountain slowly. I
stopped often to take pictures and halfway I sat down just to enjoy the
scenery.

The sun was warm, the breeze felt cool and I just felt peaceful. I looked
around and noticed I was all alone there. It felt like I was the only one on
the whole planet. On an urge I took off my shirt, the cool air felt lovely on
my skin. Again I checked if I really was alone and then proceeded to take off
my bra too. Moments later I took of my shoes, pants and finally my panties. It
felt great being naked in nature. I got up and after checking again I took a
few steps away from my clothes. I spread my arms and spun around, it felt so
good just standing there on top of a mountain totally naked.

Then I got an idea, walked back to my stuff and placed the tripod on the
ground. I set my camera to take pictures on the timer and when the countdown
started I stepped in to frame. I posed looking out into the distance. When I
head the shutter sound I giggled and walked over to the camera. This time I set
it to take five pictures on a 20 second interval. I took several poses with
every picture the camera took of me. Then I quickly got dressed again,
collected all my stuff and finished the trial.

Back at the car I checked the photo's on the small screen at the back of my
camera. I chuckled when I saw the photo's I took off myself naked on that
mountain. The clock told me it was just two in the afternoon and I looked
around to see if anyone else was there. I put my arms to my back, unclasped my
bra and took it off. After I put my bra in my backpack I drove off. It felt
nice not wearing a bra as a drove another few miles, before I turned to go back
to the farm.

When I arrived my uncle was sitting on the patio and he waved as he saw me
drive up. I parked the car and he asked "How was it? Isn't it beautiful out
there."

"It surely is," I replied, "Maybe I got back tomorrow to take the longer trail.
I took the short one today."

"Yes, the long trail is very nice. Don't forget to take some water with you.
You will need it. Take some food too." he said. I walked inside and went to my
room. I got my laptop from my bag and downloaded the pictures from my phone. I
took some time deleting the photo's of me from the camera before I went down
again. I put the batteries in the charger and sat down next to my uncle.

"Took some nice photo's?" he asked. I nodded and said that I would show them
when I was happy with them. "I'm still learning how to work the camera, they
aren't sharp so I deleted them when I checked them on my laptop."

"Ah, another trait you got from your mother. Never satisfied with the result.
Well, tomorrow you'll show them and I will judge if they are good or not." he
laughed. We had some dinner and spent the rest of the evening on the patio, he
was reading a book and I read some more in the manual of my camera.

At some point he got up and said "I think I'll take a shower and then call it a
day. I need to get up early tomorrow, need to get some feed for the chickens.
So I will be gone most of the day. You will need to take care of the animals
before you go." I nodded and said "Don't worry. I will."

The next morning I watched my uncle drive off and a few minutes later I fed the
chickens, took care of the horses and let them out to the pasture once more.
After a few hours everything was done and I sat down with a lemonade. Except
for the noices from the animals everything was quiet. When I was about to leave
I saw a car coming up to the house, it was Summer.

"Is Dave around?" she asked.

"No, he's getting stuff for the farm, we're almost out of chickenfeed."

"Ah, darn it." she said, "well, see you at the dance then I suppose."

"Why don't you stay for while?" I asked her, "I've made some lemonade."

"That would be nice," she said, "I don't have to work today, so I guess I have
some time. Maybe you could show me the farm."

We sat down after I got us some lemonade and we chatted. She was a really nice
person and I liked being around her. "I was just about to go back to the
reserve to walk the long trail. I really love it out there." Summer chuckled
and said she liked it too. Some time passed and I took her over to the stables
and introduced her to Ariel. "I love riding," Summer said, "It really feels
like you're free."

"Me too," I replied, "maybe we could go riding sometime." Summer said she would
love to and we strolled on. "You love horses, you love hiking the trails, what
else do you like to do?" she asked.

"Well, I got a camera from my parents the other day. I like taking photo's, not
that I'm any good at it yet, but I'm learning."

"Oh," Summer replied, "that's nice. Let me know if you need a model sometime.
They tell me I look great in photo's."

"Do you?", I cheered, " I would love to take some photo's of you. But I need to
learn how to work the camera some more." Summer chuckled and said "Just let me
know. I really need to go now, it was fun. Thank you so much."

I waved her goodbye as she drove off and I sat down on the patio again. It
would be a few more hours before my uncle would arrive and it was too late to
go to the trails. I decided to take some photo's of the farm and as I was doing
so I placed the camera on an old drum, set the timer and lifted my shirt. It
was so exciting that I walked back into the house, put on a dress, grabbed the
tripod and walked back to where my camera was.

I placed the tripod in front of the house and pointed the camera at the patio.
I had placed the chair so it was in frame, set the timer to take unlimited
pictures on an interval. After staring the timer I sat down on the chair and
with every picture taken I undid a button of my dress. After a few photo's my
dress was loose in front and it was so exciting because at any moment my uncle
could be driving up.

I stood up and leaned against the post of the patio, arcing my back. Then I
took off my dress and threw it on the chair. I posed totally naked in front of
my uncle's house. My nipples hardened not only from the breeze caressing them,
but also because it all excited me so much. After a few more pictures I sat
down on the chair, spread my legs and exposed my vagina to the camera. After
the shutter sounded, I spread my lips with my fingers showing the pink inside
me as the shutter sounded once more. I felt like I had used up all my luck and
put my dress back on. I stopped the timer and went back into the house.

After downloading the photo's to my laptop I checked them and felt really
satisfied with the results. I giggled when I looked at the photo's where I
showed my vagina. They were really sharp and I felt myself getting arroused by
it. When I heard a car pulling up, I shutdown my laptop, straightened my dress
and walked downstairs.

My uncle had parked near a shed and was busy unloading the chicken feed. When
he saw me he said "Ah, had a good day?"

"Yes, it was fine. Summer came by today. She was looking for you."

"What? Summer came by? What did she want?"

"I don't know. But we had a lemonade together and she's really nice."

My uncle chuckled and said "Yes, she really is."

He finished unloading and walked into the house. He got himself something to
drink and went upstairs. A few minutes later I could hear the shower and I
quietly went up the stairs. I was happy to see the door was ajar and sneaked
over. My heart was beating in my throat as I peeked in. My uncle was turned and
I could see his back as the water fell down on him. I gasped softly as he
turned around and my eyes fell on what was hanging between his legs. I had seen
one before but his was way bigger than the ones I had seen. I couldn't stop
watching and felt the urge to touch it. But I resisted the urge and sneaked
into my room, where I leaned against the closed door. It was at that moment I
decided to seduce my uncle.

I quickly went out my room and rushed downstairs. I sat down in the living room
and turned on the TV. When my uncle came down I acted as casual as possible and
said I wanted to take a shower before dinner. In my room I took off my dress
and walked naked towards the shower. I left the door ajar and stepped in the
shower. I washed my hair and body hoping my uncle was watching. I blow dried my
hair and brushed it. Then I bound a towel around me and walked into my room,
where I put on one of those new dresses I had bought, completing it with my
sneakers. I checked myself in the mirror and was happy with what I saw.

When I walked into the living room my uncle whistled and said "Are you going
out? You look nice." I thanked him and said "No, I just felt like it." As I sat
down I made sure he could see me. I arced my back to make my breasts more
pronounce and moved as gracefully as I could. I could see it had an effect on
my uncle as he changed his position a little. I got up and walked over to him,
I took the book from his hands and sat down on his lap.

He was stunned by my actions and I took his hands and placed them on my hips. I
looked into his eyes as I pulled down the straps from my shoulders and pulled
my dress down. He gasped as my breasts popped out and I leaned forward holding
them up so my nipples touched his mouth. He looked up and said "Are you sure?"
I nodded and he started sucking them. I moaned as he did so and said "Oh yes, I
wanted this for a few days. Ever since I saw you working on that tractor. And
whe I watched you in the shower I knew for sure. This is what I want."

My uncle softly bit my nipples and pulled me closer. I could feel the bump in
his pants pressing against my crutch. His hands went all over my body and when
we looke into each others eyes we kissed. Our mouths opened and our tongues met
for the first time. After kissing for a minute or two I got up and took off my
dress, except for my sneakers I was naked and I sat down on his lap.

Unbuckling his belt took me a while, I unzipped his pants and got up to pull
them down together with his boxers. I gasped when I saw his penis plop out, now
it was harder it was even bigger than I expected. I sat down on his lap again
and took it in my hands. I stared into his eyes and as we kissed I started to
jerk his penis a little, the more I did the harder it got and finally I pressed
it against my now fulle wet slit. I moved my hips along his shaft, rose up a
litte, pointed the tip towards my hole and slowly sat down.

With every inch I felt of him sliding into me I moaned and stared straight into
his eyes. I looked like it would go on for ever, but finally I felt his balls
against my ass cheeks. I rested to let myself adjust to the enourmaty of his
lide inside me. "Oh yes," I moaned, "this is what I wanted uncle. This is what
I needed. You inside of me. Oh yes, you are so big. My lord you have a nice
cock." Slowly I started moving my hips and with our mouths pressed against each
other I started riding him. His cock felt so good, so nice. After a few moments
I rose up and started bouncing, my uncle squeezed my boobs and I screamed "Oh
yes, yes, yes fuck me uncle. Fuck this slutty niece of yours, make me come all
over that cock. Yes, yes, oh yes."

My uncle then lifted me up and placed me on my back on the couch, I spread my
legs and he pushed his cock inside me again. He started fucking me hard and
fast, with every thrust it felt like he was getting deeper. "Oh God, yes. Fuck
me. Fuck me hard, oh God, I'm coming, keep going, oh yes, almost, right there,
yes, I'm almost there, yes yes YEESSSSS!' I screamed when the orgasm took hold
of me. Every muscle contracted and I felt my vagina clamp on to this beautiful
cock deep inside of me. I could feel him twist and throb and I knew he was
ready to come too. "Oh yes, uncle. Give it to me, come inside me. Give me all
that cum, come deep inside my pussy!" But he didn't want to come inside of me
and huffed "No, I can't." I clamped my legs around him, and with my hands I
pulled him close to me. "Come inside me, uncle, come for me. I want you to fill
me up, uncle. Yes, yes, do it! DO IT!" My uncle groaned and did his best to
slide out, but with my legs I prevented him from doin so. "Oh my God I'm
comming," he shouted and exploded inside my pussy. "Oh yes, yes, yes. Give it
to me, uncle," I shouted, "Yes, put that cum inside me. Oh yes. I love it, I am
your whore now, uncle. You can fuck me at any time you want, I am your little
slut now."

My uncle sagged down on me and I could feel his penis getting flacid inside of
me. He rose a little and said "Why did you make me do this?" I looked into his
eyes, kissed him and said "Because it's meant to be. I want to have your baby
one day. But for now I'm on the pill and I love the feeling of a man coming
inside me. I can't explain it, but that's what really satisfies me."

We kissed some more and as he pulled out of me I could feel his cum dripping
out. He took me in his arms and we made out some more. I took his cock in my
hand and as I played with it I could feel it getting hard again. So I squeezed
it some more and when it was hard enough I got on top of him once more, guiding
his cock inside my cock hungry pussy. This time I rode him until the both of us
came again, taking his cum deep inside me once more.

That night I slept in his bed for the first time and in the morning I woke him
up by sucking his cock, we had the best morning sex and he took me doggy style.
This time he did pull out sending his cum all over my back. We showered
together and he got dressed to go work the fields. I stayed in the house and
cleaned the kitchen, the living room and the rest of the house. During lunch he
came rushing in, lifted my skirt and plunged his cock deep inside my pussy, he
took me quick and hard sending his cum inside me when he came.

It was time for the dance and we both got dressed up to go. My uncle looked
really spiffy and he complemented me on my looks. We got in his car and drove
over to the dance. As soon as we entered Summer walked up and welcomed us. We
sat down at one of the tables and my uncle got us something to drink. A wine
for Summer, a beer for him and a soda for me. We enjoyed the evening and as the
music started my uncle asked Summer to dance. A few moments later a nice boy
walked over to me. "Hi, I'm Fisher, would you like to dance?" He took my hand
and led me to the dance floor.

He was really handsome and fun to be with. We both laughed and after a few
dances we sat down at a table. It wasn't long before we kissed and then talked
some more. When I noticed I couldn't see Summer or my uncle I excused myself
and went looking for them. I found them behind the stands as they were kissing
and I could see Summer was touching my uncle's crutch. I slowly made my way
over to them and startled them as soon as I shouted "Boo!"

Summer burst into laughter and said "Looks like you caught us." I nodded and
said "I sure did." I looked around to see if anyone could see us, then I knelt
down, opened my uncle's zipper and took out his cock. "What are you doing?"
Summer hissed. I ignored her and started to suck his cock. "Oh my," I heard
Summer say, "this is rather unusual. But also very, very arousing." She started
kissing my uncle again. I pressed my body against Summer and said "Maybe we
should go somewhere else." Summer agreed and all of us straightened our
clothes.

Summer went out first after she said "Wait for 10 minutes and then come to my
house." We did as asked and when we arrived Summer opened the door and ushered
us in. We entered her living room and as soon as Summer had closed the door the
two of them started kissing again. My uncle pulled down the zipper of her dress
and I watched it fall on the ground, revealing her naked body underneath.

Summer got down on her knees and took out my uncle's penis and started sucking
it. Then a door opened and the boy who I had danced with entered the room.
"Looks like my mother is having fun." He walked over to me and pulled out his
cock too. I took it in my mouth and from the corner of my eye I noticed Summer
was watching us.

After a while we all were naked and Summer sat next to me, we both had spread
our legs as the me were licking and sucking us. I leaned over and started
sucking on her breasts. I watched as my uncle plunged his cock deep inside
Summer pussy. She moaned loudly as my uncle was plowing her. Then Fisher got on
top of me and pushed his cock inside of me too. Seeing my uncle fuck his
girlfriend while I was being fucked really excited me.

"Oh god yes," I heard Summer say, "fuck me, fuck me hard." I looked into
Summers' eyes and we kissed. Her soft lips tasted like strawberries and when
our tongues met a thrill went down my spine. It felt so good kissing a woman
while a boy plunged his hard cock inside my wide, wet pussy.

Then Summer pushed my uncle to the side and stood up on the couch we were
laying on, she pushed her wet cunt against my mouth and I started licking her,
she started moaning loudly and said "Oh yes, lick me, suck on that clit. Oh
yes, yes." After a while she sat down next to me and started kissing her son,
she stuck her tongue deep down his mouth. Fisher pulled out of me and got on
top of his mother, plunging his cock deep inside her. "Oh yes, my son fuck your
mother like the whore she is."

I walked over to the chair my uncle was sitting in, his cock still hard from
watching Summer fucking her son. I straddled him and guided his cock deep
inside my cunt. I rode him hard, making my breasts bounce as I went up and
down. Summer looked over and smiled when she saw us fucking and encouraged her
son to come inside of her. "Oh yes, Fisher my son, come inside your mother.
Give her all your cum, oh yes come inside of me." Fisher groaned and I watched
him contract his body as he came inside his own mother. It didn't take my uncle
long to do the same to me, I felt his cock throb and twitch as he unloaded deep
inside of me.

When they were done, Summer walked over to me took my hand and guided me to the
middle of the room. She pushed me down on the soft rug, placed one leg
underneath me and then just pressed her wet cum filled pussy against mine. She
slowly moved her hips and as soon as our clits touched I moaned loudly, she
slid faster and faster over my wet, cum filled pussy. I felt so good, feeling
her juices mix with mine, knowing full well it was also mixed with the fluids
of the men watching us.

I looked over and saw them siting next to each other on the couch jerking of to
the show we gave them. Then I saw Fisher going down on my uncle to suck his
cock. To my surprise my uncle didn't resist. This sent me over the edge once
more and a huge orgasm rolled over my body, for the first time ever I squirted
a little. Right after that Summer came and she squirted a lot, spreading it all
over my body. She bent over to kiss me and we made out for while, when I
suddenly became aware of moaning noises coming from the couch. I looked over
and saw Fisher riding my uncle's cock, I saw how it slid in and out of Fisher's
asshole.

"Yes, my son is bisexual," I heard Summer say, "and so am I." Summer and I
started to kiss again and just caressed each others body. Later that evening I
watched how Summer sat on my uncle's cock once more and then winking her son to
come over. He placed his cock against her ass and slowly pushed it in. I spread
my legs and rubbed my clit as I watched Summer fuck both my uncle and her son
at the same time.

It was almost midnight when we said our goodbyes and Summer promised to come
over to the farm the following day. In the car I bent over my uncles lap and
sucked his cock all the way back to the farm.

## Chapter Three

