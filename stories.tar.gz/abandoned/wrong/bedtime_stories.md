# Bedtime Stories
_an erotic tale by TransGirl_

## Chapter one
The house was empty when I got home from work, which was strange because I was
sure Josh would have been home from school by now. A bit worried I checked
where he could be, but no Josh. The moment I stepped onto the stairs I heard
someone was there and as quiet as possible I made my way up. The door to his
room was open and I could see him laying on his bed masturbating. I just
couldn't stop watching and slowly moved in to have a closer look. His penis was
big and hard as he was jerking with his eyes closed. I could hear him pant a
little and felt my nipples getting hard as I stood there watching him. With a
groan he came, ejecting wads of cum over his hands.

As quietly as I could I hurried down the stairs and sat down, a little out of
breath, at the dining room table. When I heard him coming down I went into the
kitchen to make myself a cup of tea. As normal as possible I said "Oh hey, you
were home? I thought you were at your friends place, what's his name? David?"

I could see he was a bit startled to see me and didn't quite know how to pose
himself. "What's wrong honey?" I said as if I didn't know what he had been
doing, "Did I say something wrong?"

"No, no," he stumbled, "I just didn't know you were home, that's all."

For the rest of the day I couldn't stop thinking about what I had seen. I
couldn't believe how it had made me feel, let alone how I was looking at him. I
didn't see just my son anymore, I saw someone I was attracted to. "Come on
Christy, you can't feel this way about him. He's your son, for God's sake", I
thought, but the feelings were there and I couldn't deny them. All I could do
was suppress and ignore them.

As the days went by suppressing them got harder and one evening when I was home
alone I gave in. I lay on my bed thinking about that day and started to
masturbate. "Oh yes Josh, fuck you mother," I whispered, "Slide your big cock
inside your mother. Make her come all over your cock." I rubbed my clit harder
and harder until I came so hard I just had to scream. I clasped my mouth with
my hand and listened if anyone had heard me and breathed a sigh of relief when
everything was quiet.

"Oh Christy", I thought, "how could you think about him this way. He's your son
and you just fantasized about fucking him. Oh, but it did make me feel really
good." I laid down once more and started masturbating again. This time I bit my
pillow as I came. I masturbated to that fantasy for the next couple of months
and my fantasy got more and more explicit.

One Saturday my husband had to work and Josh was home. It was a beautiful day
and I was making our bed when I heard Josh jump into the pool. I peeked out the
window and could see him in the water. When he got out I saw his muscular,
young body and I lifted up my skirt. As Josh laid down on one of the long
chairs in the backyard, I had one hand on my breast, the other in my panties
rubbing my clit. "Take off those trunks son," I whispered, "Show your mother
what you have in there. Show her that giant cock of yours."

I stopped when he looked up and saw me. I raised my hand and waved as if I had
just seen him. After finishing making the bed I walked to the closet and
grabbed a shirt and skirt. I changed into them and checked myself in the
mirror. With a slight smile I took off my panties and threw them in the
laundry basket. I felt really excited when I walked down the stairs and stepped
into the back yard.

"Mind if you mother joins you?" I said.

We laid there for a while and I was fully aware he could see underneath my
skirt at any moment. I arced my back a little more, but it was like he just
didn't care. He just didn't look or wasn't interested. Doing this really was
exciting to me and I hadn't felt like this for a long time.

During the following weeks I _accidentally_ bumped into him or bent over
wearing something loose so he could look down my blouse. Every time we were
home alone my clothes got tighter, my skirts shorter. Until the day, the day he
noticed.

I was laying on a chair in the back yard. I was wearing a mini skirt without
any underwear. Just as he looked I did a Sharon Stone and his reaction made it
clear he had seen it. A few minutes later I did it again and this time I took a
little more time before crossing my legs again. Now I was sure he had seen it.

He stared at me and I just looked at him like nothing had happened. Slowly he
rose up and came closer to me. I just laid there and said nothing, my heart was
in my throat and I was so excited. He slowly bent over me and placed his left
hand on my hip. Instinctively I raised it and wet my lips with my tongue.

He came close to me and whispered in my ear "You don't know how long I've been
dreaming about this." He kissed me on the lips and said "Take it out!" His
voice sounded stern and my hands were shaking as I reached for his trunks. I
undid the knot and pulled them down. His hard dick popped out and I held my
breath as I took it in my hands.

He placed it near my mouth and commanded "Now suck it."

I opened my mouth and placed it around his big hard cock. "Oh my Lord, I'm
sucking my sons cock," I thought and opened my legs slightly. His left hand
went up my thighs until they reached my ever more wet pussy. He slipped one
finger inside me and I spread my legs some more. "Oh yes mom, suck my cock!" he
commanded with a stern voice.

After a few minutes he got close again and whispered "Do you want me to fuck
you, mom? Huh, do you?" All I could do was nod and he got on top of me. When
his cock touched my cunt I moaned and whispered "Oh yes son. I want you to fuck
me. I want you to fuck your mother. Fill her up with all that cum. Oh yes, take
me. Make me your whore, your slut."

With one push he came inside me and I moaned. "Oh my God, I'm fucking my own
son!" I thought. It felt so good having him inside me, it was so wrong what we
did but it felt so right. I placed my hands on his as and pulled him closer. I
wanted him deep inside me. I contracted the walls of my vagina and could feel
every inch of my sons cock inside me. Slowly he started pumping and with every
thrust I moaned "Oh yes son, fuck me hard. Fuck your mother as hard as you
can." He started plowing me and I almost shouted "Oh yes, yes, Keep going Josh,
I'm coming all over your cock. I'm almost there, yes, yes, yes I'm COMING!"
Every muscle contracted, I placed my hand on his stomach so he stopped moving,
I just had to have a little time.

After a minute or so he started pumping again and I spread my legs as wide as I
could, this time I wanted him to come. I wanted him to come deep inside my
pussy, I wanted to kiss my husband while his sons cum was dripping out of me. I
wanted it so bad I hissed it to my son. I demanded him to fill me up and when
he did I had another orgasm.

We had sex a couple of times that day. Once in the kitchen where he just bent
me over, lifted up my skirt and pushed his cock inside me. Once in his bed
where I rode him until he came and once in my marital bed where I had my legs
behind my shoulders as he came deep inside me. "We can't tell dad about this or
anyone else" I said after that last time, "this has to be a secret." He nodded
and said "Okay mom, our secret."

When my husband of 18 years came home later that day, my sons cum was dripping
down my leg and I kissed him with the mouth his son had put a load in just
minutes before. I placed my hand on his crutch and we discretely went upstairs
"What has come over you?" he asked. "I just missed you," I replied as he pushed
hist cock inside the pussy already containing loads of his sons cum. "Oh yes,
honey," I moaned, "I wanted you so much today. Come inside me, please" A few
minutes later he mixed his cum with his sons inside my pussy and I orgasmed
again.

I was 23 when I married Todd, a year later Josh was born. That was 18 years ago
now and if it hadn't been for that cancer we would have had a few more kids.
Josh was four when they told me I had ovarian cancer and the had to take them
out. I had chemo after the surgery and luckily enough I was determined cured
half a year later. I had a very rough period after that, coming to terms I
couldn't have any more children. I went through early menopause and it was so
hard to feel like a woman again after that. No more periods, no more sex. At
least that's how I felt at the time.

If it hadn't been for a heartfelt letter from Todd in which he declared his
undying love for me and how he still was attracted to me I wouldn't know what
would have happened. But he made sure I knew he still loved me and during a
long weekend away he showed me. I felt sexy again, wanted and most of all I
felt like a woman again.

Now here I was laying in bed with four or five loads of my son's and one load
of my husband's cum inside me. I lifted up my legs, I wanted it to slide
deeper inside me. Todd looked at me as I did so and asked "What are you doing?"

I looked at him and said "Oh, sometimes I like to pretend I still can get
pregnant. This is what I did the night we conceived Josh, remember?" Todd
chuckled and said "Yeah, that was one night to remember."

A few hours later Todd was snoring next to me as I slipped out of bed and
snuck into Josh's room. With my finger across my lips I told him to be quiet
and pulled down his pants. I started to suck his cock and when it was hard I
sat down on it, quietly moaning as I felt him sliding inside me. I started to
ride him and whispered "Be quiet! Don't wake your father." It didn't take Josh
long to put another load of his cum inside me. I got off of him and said
"Goodnight my son, sleep tight."

Quietly I snuck back into bed, feeling my sons cum dripping out of me. I fell
asleep with a huge smile on my face.

The days and weeks after that day Josh and I got more brazen having quickies
while Todd was home. One day he almost caught us when I was on my knees sucking
his cock. It was Josh who heard him, helped me up saying "Don't be so clumsy
mom! You know that tile is uneven." I giggled like a schoolgirl and said "Yes,
I've told your father to take care of it."

Then there was that day Todd was working in the backyard, finally taking care
of that tile and other things when I straddled Josh guiding his cock inside my
pussy and rode him. With my breasts out of my blouse I hopped up and down on my
sons cock while my husband was mere feet from us. Josh sent another load inside
my cum hungry pussy and I had just straightened my clothes when Todd walked in
"Oh here you both are," he said, "come take a look." We admired his work and I
kissed him once more with his sons cum dripping down along my legs.

It was a Thursday evening, Josh was doing his homework when Todd called he had
to work late. "Okay honey," I said, "I will make sure there's something for you
in the fridge when you get home." After dinner Josh finished his homework and I
slipped into something sexy. It didn't take long for the both of us being
totally naked and I was on top of him hopping on his cock. "Oh yes son, fuck
your mother," I said out loud, "This feels so good, son. I love having your
dick inside me."

Then suddenly the door to our bedroom swung open. In the doorway Todd was
visible and he didn't say a word. I got off Josh and covered myself with the
sheets. Todd just looked at me and took a few steps forward, before he or I
could say anything Josh pulled away the sheets and said "He already knows mom,
since the first day we had sex he knows." Josh pulled my arms away and started
sucking my breasts, I watched as Todd got undressed and offered me his cock.
"Oh yes honey," Todd said, "I know how you let him come inside you. I even
watched as you fucked him on the couch thinking I was working in the backyard.
I love to see how our son fucks his mother."

I moaned as I had his cock in my mouth, let Josh spread my legs and gagged on
my husbands cock as my son slid his cock inside my wet pussy. Not long after
Todd laid down on the bed and I got on top of him, I rode him hard as Josh was
laying next to us. I couldn't believe what was happening. Josh got up, placed
his hand on my hip and his cock against my ass hole. Slowly he pushed in and
the both of us were surprised by how easy it did. It didn't hurt me at all, I
moaned loudly as I felt the cocks of the most important men in my life inside
me, one in my pussy the other in my ass.

The both started to pump and I had the biggest orgasm I had ever felt. The were
relentless and kept on going through it and one orgasm rolled over into the
other until they both came sending their cum inside my pussy and ass. We had
sex a couple of times that night until the three of us were exhausted. That was
the first time we slept in the same bed, me in between the two men I loved with
all of my heart.

It became normal for us to have sex. Sometimes Todd walked in on me sucking
Josh's cock, sometimes it was the other way around. Sometimes I was fucking my
husband after dinner, the other times I fucked my son. At least once a week
they I had both of their cocks inside me, but it was almost every day I had sex
with at least one of them.

I became a true whore when Josh brought home one of his best friends, Duane. He
was a beautiful young black man and star running back for the high school
football team. I was in the kitchen preparing dinner when Duane walked in and
without warning he placed his hand on my hip and pressed his cock against my
ass. "I saw you looking," he said. I started to breath heavily as his hands
went to my breasts. He squeezed them and hissed "You want this, bitch?" I
nodded and he pulled up my skirt. I pulled down his pants and with one push he
slid inside me. He was fucking me hard as I had one leg held up high by him
when Josh walked in, sat down and watched how Duane was fucking his mother.

Seeing my son watch me getting fucked by his best friend excited me so much, I
said to him "Oh you like seeing your mother get fucked? I like seeing that big
black cock sliding in and out of me? Huh, do you? Come one Duane, show him how
a real man fucks a woman. Show him, fuck me so hard my pussy hurts for days."

I moaned loud and when he slid out of he I got onto the counter spread my legs
wide and said "Give me that big black cock! Come on! Fuck this bitch!" Duane
slammed his cock inside me and I yelped "Oh my god, it's so big. Oh Josh, he
has such a nice cock. I want him to fuck me every day! Oh yes Duane, I'm your
slut now. You can fuck any of my holes whenever you want."

Duane looked at me, pulled out and slowly entered my ass. I moaned as I felt my
ass relax and accept the intruder. "Oh yes, Fuck my ass. Fuck it hard." I
shouted, "Josh I want you to bring all your friends, they can all fuck me. I
want to fuck them all at the same time. I want a cock in my ass, one in my
pussy and one or more in my mouth and I want them all to come inside me. Oh,
I'm such a whore, such a slot. Oh yes Duane, give it to me. Fill that ass with
your cum. I want it, I need it. Oh yes, yes, almost there. I'm coming! I'M
COMING ALL OVER THAT BIG BLACK COCK OF YOURS! OH YESSSSSSSS!" As I had my
orgasm, Duane groaned sending his cum up my ass.

Just as he pulled out, Josh pushed his cock inside it again. He fucked my ass
right after Duane and I pressed my upper body against his. "Oh yes, yes, fuck
me son. Fuck that ass." Within seconds Josh came too. Almost twenty minutes
later I slowly sat down on Duane's cock and moaned as I entered my ass. I
spread my legs and Josh entered my pussy. They both fucked me until I had an
orgasm, the kept on fucking me sending two more loads up my body.


