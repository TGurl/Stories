# Chapter Two
My pregnancy didn't have much complications other then school. I rolled into
the special program for teenage mothers, which also included how to take care
of a baby and everything related to being a parent. They prepared me as much as
possible to parenthood.

Together with either my mother or my father I went to every doctors appointment
and every time they said how well I was doing. As soon as it was possible we
did an echo, revealing I was carrying a baby boy. A silver lining for me was I
didn't have to follow PE for a few months, a dark cloud was some of my friend
abandoning me. Even my best friend since kindergarten didn't want anything to
do with me anymore.

Nine months later Sean was born, a healthy 7 pounds baby boy. My mother was
with me during the birth, my father was pacing around in the hallway. The
moment he heard Sean cry he stormed in. The moment he laid his eyes on my boy I
could see instant love. My mother was crying, I was crying and my father did
his utmost not to cry. After a few minutes the nurse laid him in my arms and I
whispered "Hi Sean, I am so pleased to meet you finally."

My fathers ears perked up and he uttered "What did you call him?"

I looked up and said "Sean, dad, his name is Sean. After your father."

That was the moment my father broke. He started balling and my mother hugged
him. My grandfather had passed away a few years earlier and he was my best
friend. I was heartbroken when he passed away and couldn't think of a better
name for my son. If the echos had been wrong I also had a name in mind: Cassy,
after my grandmother on my mothers side.

After a few minutes I handed Sean to my father, who whispered "Hi Sean, I'm
your grandfather. One day I will tell you all about the man you were named
after but for now it's your birthday and it's all about you. This is your
grandmother and she will protest me calling her that, but she is. I love you
Sean and I will always be there for you."

He handed him to my mother who cradled and rocked him. She sang him his first
lullaby which also made me fall asleep. A few hours later Sean woke me when he
cried and a nurse helped me up so I could feed him. "You are doing such a good
job," she said, "You are going to be a wonderful mom. I can see that." I
thanked her for the compliment and she left us alone while I fed my son.

"Oh Sean," I whispered, "I am so happy you are here. I am never going to leave
you. Now I understand what unconditional love means, now I understand my own
mother. I love you so much, you will never understand."

A few days later I was dismissed and for the first few weeks I attended classes
via the internet. After that I returned to regular school and my classes were
only intermittent by me pumping breast milk for my son. As soon as classes were
over I returned home as quickly as I could and took over caring after Sean from
my mother, so she could finish her work.

My mother taught me how to cook and soon I took over cooking dinner from her, I
loved cooking dinner for all of us. I could see how proud my parent were when I
started to take more responsibility around the house. One Saturday morning
after I had fed and changed my son, my mother was amazed to see me vacuuming
the living room.

By the time I was 18 I helped my mother with all the chores and took over most
of the washing my sons clothes. Sure combining school with taking care of Sean
was hard and sometimes frustrating. But I had no choice but to grow up fast and
take responsibility. To me it was a normal thing, others were amazed.

Some girls asked why I wanted to be with Sean more than I wanted to go out and
party. It was something I couldn't explain, Sean was my happy place and I loved
being with him, seeing him grow. I wanted to enjoy every moment of him being a
baby for as long as I could.

My mother was amazed how quickly he slept through the night and how good of a
mother I turned out to be. Most nights when he cried she really wanted to check
on him only to find me already there. Whenever possible I would hand him to her
and she would sing to him. I always stayed and watched. Later in life my mother
would tell me how much she had appreciated the fact I hadn't shut her out. I
wanted to involve them as much as possible and I still do. Just as long as they
understood he was *my* son.

When I graduated I was so proud to see them in the stands, my son in a pram
next to them. The sun was shining and I walked on the stage when they called my
name. Despite the pregnancy I had ended up top of my class and I graduated with
honors.

I had been accepted to a college on a scholarship in the next town over and was
ready to go. Because I had a son I couldn't live in the dorms, so we had to
rent a small apartment nearby. My parents would pay the rent as long as I got a
job to pay for the rest, including childcare.

Slowly the day of us moving out arrived and my mother had a really hard time
with it. But she knew she had to accept it, that didn't deter her from trying
to keep me in the house.

The first few months living on my own felt strange, suddenly it was all up to
me. Previously my mother would take care of Sean during the day, now I had to
drop him off and pick him up. Next to going to school I had a job at a local
coffee shop where they allowed me to bring him now and then. If I couldn't
bring him my mother would watch him, she drove over especially for that. She
never complained about it. I was very lucky that way.

The first year I was able to just get by with what I earned, but I started to
dislike my parents paying my rent. I wanted to do it all myself, I didn't want
to be dependent on my parents anymore. So I started to look around for a better
job, but either me going to college got in the way or the fact that I had a
son. It was so hard to find a better job.

One evening after I had put Sean to bed I was browsing the internet searching
for a way to boost my income when I came across an add asking for women to
become models. All you had to do was sit in front of a camera while streaming
on the internet. "That's something I could do," I thought and clicked the ad.
The moment the site opened up I clasped my mouth with my hand: they were asking
for girls to undress and pleasure men through the internet. I was in total
shock and clicked the site away as fast as possible. I wasn't going to do such
a thing, even if they paid me a million dollars.

I kept on going and searching for a better job, I had to stretch every dollar
for almost two years and I was getting really tired of it. I couldn't afford
anything extra, I hadn't been able to buy something new for me or my son.
College was going great, I got good marks and was in the top of my class,
everything else was just a struggle. I kept on fighting, I knew a better life
was on the horizon if I just kept on going.

In my last year of college it was like everything was collapsing. The rent of
my apartment was raised out of the blue and became to much for my parents. I
had to move out to something cheaper, my son got really sick and hospital bills
kept stacking up. It all just got too much. On top of it all I had a paper to
write in order to graduate. I needed a break from it all, I needed help. In a
desperate measure to rescue it all I moved back in with my parents. That way we
all could save the money and my parents could take care of Sean while I was in
school.

It felt so strange being back in my room. "I'm doing this for Sean," was what I
kept telling myself. The commute to college every day was hard and long, mostly
spent listening to the classes I had taped. As soon as I got home I hit the
books, right after I had spent some time with Sean. Luckily he got better and
was back to being his bundle of joy. My parents made it possible for me to
concentrate on my paper and at the end of the year I graduated with honors.

The day I stepped on that stage was one of the best days of my life. Seeing my
parents so proud of me when I received that diploma, my son in my mothers lap
waving gave me tears in my eyes. I had graduated, against all odds. I was so
proud of myself.

Just weeks after graduating I got a job in a big company and as all people I
started low. At first I was so happy to be there, that soon changed. I was
nothing more than just another employee, a number. I applied for several
courses offered but was always denied: I hadn't put the years in was one of the
excuses. The expected me to work long hours and even work overtime which was
unpaid. I just hit a road block and called in sick one day, I couldn't take it
anymore. I needed a day off.

Not long after that day I was fired, reason I hadn't shown any loyalty to the
company. I had worked 12 to 14 hour days, 6 days a week. Sometimes I even
worked at home on my day off, just to get the assignment done in time. Not even
once did they give me a compliment, always there was the question why I hadn't
finished sooner. Although I was sad to get fired, I was so happy to leave that
place.

Now I was an unemployed 26 year old mother who lived with her parents. I felt
like a total failure. The only thing giving me comfort was watching my son grow
and be his happy little self. Somehow he was always able to cheer me up. The
time had arrived to take matters in my own hand, to do anything for my son. As
long as he was happy, I didn't care about anything else anymore.

With my heart beating in my throat I applied for a job in a strip club and just
a few nights later it was time for my first performance. I had never been so
nervous for anything in my life before. The music started and I danced, taking
of clothes one by one, the only thing we had to keep on were our panties. The
moment supreme came quicker than I expected, the music welled up and it was
time for me to remove my bra. Topless I danced some more, crawling towards the
perverts sitting at the stage. I shook my breasts for them and acted like I
loved it. I winked at them, squeezed my boobs for them and even spread my legs
a little to give them a peek.

I got off the stage and my panties were filled with bills, we mainly worked for
tips and I got a lot. I worked there for 6 nights a week, telling my parents I
was working night shifts. As soon as they found out the truth I got the biggest
scolding I had ever received from them. "How can you be selling your body like
that?" asked my mother. The only thing I could say was "I'm doing it for Sean,
mom. I tried getting a decent job, trust me I did. At least now I can go hunt
for something else during the day. I don't want to do this for the rest of my
life, but it's a job and it pays the bills."

After working in the club for almost six months I noticed I started to enjoy
it. I don't know whether it was the illusion I created on stage or the
attention I got, or maybe a combination of the two. The result was the same, I
enjoyed being on stage. Being the center of attention made me feel good. The
club where I worked was strictly no touch, but we knew allowing the johns to
touch us resulted in bigger tips. So we created *accidents*, always acting
angry afterwards. But all parties knew it was a rouse.

Feeling those strange hands on my body always sent shivers down my spine, not
of disgust, of pleasure. I loved creating those *accidental* moments when a
john touched me. The other girls always were disgusted afterwards and I acted
like I was too. I didn't want to be the only one that actually liked it.

One evening my parents had a dinner appointment and I couldn't work that night.
Sean was asleep and I thought back to that site I had visited months ago. I
opened it again and started reading the terms of service, the frequently asked
questions and everything else. 

> Your guests can tip you with the tokens they buy on our site. You can convert
> those into real money and at payout we only take a 20% cut. So if you make a
> 1000 dollars we will pay you 800. This could be the easiest money you have
> made in your life and all from the comforts of your own home.

It all sounded so tempting and I really didn't know what I wanted to do. On the
one hand I had a job giving me a rather steady income, on the other hand this
would allow me to work from home at the times that suited me. And what was the
difference, I already took off my clothes in front of strangers. Above it all
this felt saver than going to the club. On more than one occasion I had to run
to get into my car, just to escape the creeps waiting for the girls leaving the
club.

I registered an account and minutes later I was able to start streaming. I
didn't have a decent camera, just the one in my laptop and the video was
horrible. I switched on some lights in my room, but it didn't get much better.
But still I clicked on *Go Live*, just to see how it would feel. It took quite
some time for someone to show up in my chat.

"Hey there," I typed.

"Show me your boobs," was all I got.

"Now I could do that, but what's in it for me?" I replied

"Show me your boobs."

"Can't you ask nicely? I am not your servant."

"No, you're just another whore showing her body for money."

Right after that comment I banned him from my chat. I wasn't there to get
insulted, if I wanted that I could just go to the club. There I just had to
take it and smile, otherwise I would get a tip. On the site I was my own boss
and I determined what the rules were. Somehow it felt lethargic banning this
dweeb, it was so satisfying.

A few minutes later a new one entered my chat. I greeted him and he was rather
nice, still had the same goals but he was nice. He offered 200 tokens to see my
boobs, which came to 10 dollars. I knew I was new to the site and that I had to
build an audience.

"Only 200 tokens?" I replied.

"Okay, 300" he replied.

I smiled and lifted up my shirt. His reaction was of simple awe when he saw my
triple-D breasts. "All natural," I typed ending with a smiley face. Suddenly a
video appeared in the top right corner, he had activated his camera showing his
lower body and he held his massive cock. It was so big and hard.

"Oh wow," I typed, "you are so big."

"Want to suck it?"

"Oh yes," I replied acting like it aroused me, "oh my god, yes."

"Then suck it bitch."

I typed "I slowly bend over, holding your dick in my hand. With my tongue I
carefully touch it. Then I lick it for a while. I open up my mouth and take in
the tip of your cock. It feels warm and wet for you, with my tongue I circle
your crown."

"Oh yes, suck it," he typed while he was jerking.

"I take it in deeper and deeper until I gag." I typed, "I can feel your cock
throb deep in my throat."

"Oh my god, yes. Suck my cock, mom. Suck it hard."

I was shocked when he typed it, but I played along. "Oh my god, I never knew
how good it felt to suck my own sons cock." I typed. I leaned back and squeezed
my boobs watching him jerk his cock. I leaned forward and said "Now fuck me,
son. Fuck your mother."

I leaned back, moved my laptop a little and spread my legs. I pulled my panties
to the side and showed him my pussy. With my fingers I spread my lips showing
him the pink inside. A few more entered the chat and donations started rolling
in. I rubbed my clit and got really wet. I pushed a finger inside me and
started masturbating to 5 camera views of random men jerking their cocks.
Seeing all those dicks hard for me aroused me more than I wanted to admit.
Seeing them come was even a bigger turn on for me. When I stopped streaming a
few hours later I had received almost 1,000 tokens. More than I had made in the
club ever.

I closed the site and straightened my clothes and the bed as soon as I heard my
parents getting home. I quickly placed my laptop on my desk and jumped on the
bed pretending to read a book. My mother peeked in saying she wanted to check
up on Sean, I nodded and she went away.

A few weeks later I got my own apartment again, this time I paid for everything
myself. In the evenings I danced in the club and during the day, while Sean was
at school, I streamed. This all gave me a rather steady income and the longer I
streamed the bigger my audience got. I started using toys on my streams, always
making sure they were all tucked away when Sean was home.

At some point the site far exceeded what I could earn at the club, so I quit
the job and went full time streaming myself. Streaming in the evening and at
night opened a while new demographic for me: European viewers. I got a good
camera, a better computer, sexy clothes and more if not bigger toys.

All my streams had one central theme. I was a mother who was stripping and
masturbating to her son. I started to talk instead of type, I panted, moaned
and acted like I had orgasms multiple times a stream. With the camera I started
making short videos for them to watch if I wasn't online. Those started to get
some traction and earned me more than I got from streaming.

Slowly I moved away from streaming and created videos instead. Those I could do
in my own time, whenever it was possible for me. I edited them, added titles
and made up a name: MissUnderstood. I thought it was a nice pun.

My videos started making real revenue and I learned what people liked to see.
It was on a short trip I made with my parents I hit the jackpot. On a whim I
recorded myself getting naked and masturbate in public. I placed the camera in
between my legs to get some closeups of my fingers sliding in and out of me.
After a fake orgasm I got dressed and filmed myself walking through nature. I
shot some short clips of me lifting up my shirt and rubbing my crutch.

When I got home I edited the video to create somewhat of a story line and was
really nervous when I finally uploaded it. Within days it broke all my previous
records and in a week it was viewed over 100,000 times. That one video made me
more money than I had ever done before. 

I started making more videos of me masturbating in public, with every video it
got more daring. I have to admit the risk of getting caught excited me more
than the recording itself. Changing rooms in department stores, in my car on a
parking lot, a quiet spot in the library, every video the risk got higher and I
loved doing it.

One day I was recording myself in my car when suddenly out of nowhere someone
stood next to me, watching me masturbate. He took out his cock and I looked
into the camera. With one finger I pressed the button to lower the window and
he proceeded to tough my breasts. I moaned the moment he did and started
rubbing my clit harder. He placed his hand on my head and pulled me closer.
Automatically I opened my mouth and took his cock in. I sucked him until he
came all over my face. He closed his pants and walked away. I stared into the
camera, my face covered with his cum. I giggled as I cleaned myself and
whispered into the camera "Well that as unexpected."

Right after I uploaded the video it went viral. "Unexpected" I had titled it
and within a day it had reached 200,000 views. 
