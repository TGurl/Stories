# Summer Camp
_an erotic tale by Transgirl_

## Arrival
"Luna? Are you ready? We need to go. Now!" my mother stood at the bottom of the
stairs yelling at me. I was still packing the last things I wanted to bring
"Almost ready, mom!" I yelled back. "No Luna, we need to go now! Come one,
let's go!" she yelled back.

I grabbed my last things and ran down the stairs. "Always the same with you,"
my mom complained,"Didn't I say to pack your things last night? Now we've got
to hurry or we will be late. Come on, dad is waiting in the car." I smiled and
ran towards the car which was already started by my father who patiently sat
waiting for us playing with the radio. I threw my last bag in the backseat and
got in after it and after I put my stuff in it I buckled up and said "It's
always the same, always waiting on mom." My father looked over his shoulder and
raised his eyebrows. "What? I'm buckled in." I said with a smile.

My father chuckled and after locking the house my mom got in the car too. "She
was still packing," my mom said as she stepped in. My father chuckled and said
nothing but "Okay girls, let's get this party on the road." The drive over
would take approximately three hours and my mother had it all planned out like
she always did. On the way over we would stop at some sights and a diner for
some rest. All I wanted to do was drive on until we got there, but I knew my
mother wouldn't like that so I said nothing.

Finally after three hours we arrived at our destination: Camp Fuller, summer
camp for teens. It was my first time and I was so excited. My parents had
agreed after I kept on asking to go for almost two years, now finally they
thought I was old enough to go. I was 14 and thought I was totally independent.

As we drove through the gate a girl came to my mother's side of the car and
said "Hi, I'm Linda and I'm a camp leader. And who might this be?" I said "I'm
Luna, it's my first time." "Oh, you're going to have a wonderful time here at
Camp Fuller. Let me check, ah yes, Luna Davis, pink barrack. Please drive on
and you can park near the main office. Pink Barrack is the fourth on your left.
Pack leader is Silvia and she can answer any questions you might have. Now
Luna, I will see you at the opening ceremony. Have fun!"

My father slowly drove to the parking space and we got out of the car. I
grabbed my bag and my father got the other one out of the trunk. Together we
walked over to where I would be staying and a red head girl was standing in the
door. Her name tag said "Hi, my name is Silvia." and I walked up to her.

"Hi Silvia, I'm Luna." I said with a smile on my face.

"Ah Luna! Yes, welcome to the pink barrack. The first thing we're going to do
is think of a better name, what do you think? Now you can choose a bunk bed and
put your bags in one of the trunks next to it. You're one of the first so you
have some choice. Go on in and I will talk with your parents, okay?"

I went in and there were a few girls already busy making their beds. I chose on
of the bottom bunks available and put my bags in the trunk next to my bed. One
of the girls came up to me and said "Hello, I'm Dana. And you are?"

"Luna, pleased to meet you." I replied.

"First time? I don't think I've seen you before."

I nodded "Yes, I can't wait."

"You're going to have a lot of fun. I promise. Well, this are Liza, Marjorie,
Taylor and Marisha. We were all here last year too." I greeted them all and we
talked about where we were from and how old we were. Marisha said "Oh, I really
want to win this year. I hope we get a good group together."

"What is there to win?" I asked.

"Oh, nothing special. But the barrack that is most active, most fun and most
reliable get's a nice trophy and you get to go the following year for free."

"Ah, yes that would be nice," I replied.

My mother walked in and hugged me. "Have a good time, you hear? I love you and
miss you already. Well, we're going. They have our number and they know
everything they need to know, okay? Well, that's it. Have fun girls!" I knew
she was holding back her tears as she walked out, my father just hugged me and
said "Have some fun kiddo." And with that I was alone at camp, totally excited.

Almost an hour later all the girls of our barrack had arrived and we sat down
in a circle outside to think of a better name than pink barrack. The name we
landed on was "The Pink Magnolias" and three of us painted a new sign for our
place. Silvia told us to follow her and we walked to the back of the main
building. The man standing there pressed new shirts for us all. The were pink
with the camp logo in front and on the back he pressed "The Pink Magnolias".
Silvia said "Tomorrow you will get some more shirts, so we will have fresh ones
for every day. Next Saturday we will wash them for the last week, okay?"

We cheered, went back into our barrack and put our new shirts on. It was a
little too tight for my taste, but there was nothing I could do about it.
Silvia walked in and said "Okay, you can explore camp now. We have two hours
until the opening ceremony. Just go to the central area and let's sit together,
okay? Now what you're waiting for? Go explore!"

I went exploring camp with Marisha, she seemed nice and as she was here last
year she could show me around. We walked passed the barracks and she pointed
out some of the buildings and what they were for. "Now, over there is the
central area where the opening will be. And there we can get food and drinks,
over there is the doctor's office. Let's hope we don't need to go in there."
she laughed, "But I want to show you something really special, come."

I followed her along a path with went deeper into the woods. We ended up at a
small lake. "This is Lake Pendleton, named after the woman who started this
camp. She passed away a few years back and her daughter now runs this place. We
can swim here or just lay in the sun. Come." She took my hand and we walked
along the shore of the lake. She pushed away some branches and we arrived at a
more secluded area. It was a beautiful area with some large boulders and a
picnic table. "Most of the time when we go here we try to get this spot."

After a few minutes we returned to camp and she showed me around some more,
until we ended up in the cafeteria to get something to drink. We chatted for a
while until we finished our drinks and went to the other buildings to check
them out. Along the way we greeted some of the leaders, played some volleyball
and just had some fun until the opening ceremony started.

We all sat down together on the stands and Linda, the girl who had first
greeted us at the gate, walked on stage. "Welcome, welcome to this years Camp
Fuller!" The crowd cheered and Linda continued "I honor of my mother we will
be having a moment of silence, please." We all were quiet and you could hear
the birds in forest. After almost a minute Linda said "Thank you. This year we
have on the girls side: The Pink Magnolias!" Silvia urged us to stand and we
did. The rest of the crowd cheered and we sat down when Linda shouted "The
Cupcakes!" she announced all the teams and we cheered.

"On the boys side we have The Iron men! The Heavy Haulers!" This went on until
all the teams were announced. "Now and this is important," Linda continued, "As
with every year the best team will get the trophy and get to go for free next
year. But, we need the trophy first. Please welcome last years winners: the
Dark Maidens!" Everybody stood up as last years winners walked on stage. They
handed Linda the trophy and one of the shouted "And we will win again this
year!" The crowd booed and then cheered. The Dark Maidens sat down on the front
row with their leader and Linda continued "I hear dinner is ready, so I will
keep it short. Listen to your leaders, don't make me talk to you and above all
HAVE SOME FUN!"

A fanfare sounded through the speakers and we all cheered. Silvia got up and
said "Follow me! Let's get something to eat." We walked towards the cafeteria
and after we got our food we sat down at a table together. Camp had officially
started.

## First Day
The next morning we all got up early, showered and got ready for the day. We
had breakfast together and decided what we wanted to do. To be able to win we
had to participate in activities and the more of us joined in the more points
we would gather. We decided to fill the day with sports. So we played
volleyball, softball and entered the badminton competition. We gained some good
points and as we won the softball competition we were leading the Dark Maidens
with just one point.

During lunch break I went to the bathrooms when I saw one of the Dark Maidens
duck behind the building. Curious as I was I followed her on a distance. I duck
behind some bushes and could see how she met up with one of the boys. They
kissed and I clamped my mouth with my hand not to make any noise. I watched how
she went down on her knees and took out his penis. She started to lick and suck
on it and after a few moments she stood up, turned her back to him and lifted
up her skirt. He pulled her panties down and pushed his penis inside her. I
couldn't believe what I was seeing: one of the Dark Maidens was having sex with
one of the boys! He kept slamming into her until he suddenly pulled out and
came all over her ass.

The kissed once more and he snuck away. She cleaned herself, pulled her skirt
down and snuck away to the other side. I was flabbergasted by what I had seen
and quickly went into the bathrooms to do what I had to do. As I walked out I
saw another girl sneak behind the building. From my previous spot I saw her
having sex with someone too. While I was watching them I saw Marisha sneak in
there too, she held hands with some boy and pulled down her pants. The boy
stood behind her and I gasped softly as I watched two couples having sex.

Marisha lifted up her shirt and I could see how her boobs swayed to the motions
of her having sex. The other girl bent over and started to suck on the naked
breasts, I could hear Marisha moan and without thinking I pushed my hand down
my pants and started to rub my clit.

Suddenly there was a hand on my shoulder. A boy had seen me and told me to be
quiet. He pulled me to the other couples and pulled down my pants. He bent me
over and before I knew it I felt him enter me. With my face turned red I looked
at Marisha who just smiled. After a few thrusts of him I started to get wet and
moaned. "Oh yes," Marisha whispered, "this is the best part of camp. We can
fuck any time we want, with anyone we want." Not long after I felt someone
standing next to me, it was Linda and she held the hand of a boy not older than
thirteen. She lifted up her skirt and guided him inside her. "Oh yes," she
said, "fuck me, fuck me good with that young cock of yours."


