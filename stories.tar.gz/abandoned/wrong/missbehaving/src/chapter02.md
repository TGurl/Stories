# Chapter Two
As I suddenly had some time I decided to redecorate my office. I removed some
posters, replaced some plants and moved some furniture. I created more space
and changed the setup of my computer. I had placed the new camera on a tripod
next to me and together with the original webcam now could see myself from two
angles. The new camera came with a small remote enabling me to change the angle
and zoom in or out.

I was so nervous when I walked into my *new* office space to sit down at my
computer. It was the first day *at my new job* and I didn't want to disappoint
anybody. I logged in on the site and checked if everything was working okay,
before I went live.

It took some time of me just sitting there smiling into the camera with my
freshly made up face. My full red lips and dark eye shadow really popped as the
first people appeared in chat.

"Hey honey," I said with a sexy voice, "how are you today?" The chatter
responded with "I'm a little depressed with this whole Covid thing. Hope you
can make it a little better."

"Ahw, I'm so sorry to hear that honey," I replied, "what can I do for you?"

"You could show me your boobs..." he responded.

I smiled and lifted up the way to small tank top I was wearing. "Here you are
sugar," I replied, "Do you like them? Wouldn't you want to touch them? Suck on
them? Oh thank you for the 100 tokens, I really appreciate it." I straightened
my top again and greeted the newcomers to the chat.

"Now remember," I said, "for 2000 tokens you can go private with me and I will
show you a good time. It will even be better if you have a cam of your own."

In an act of desperation I had joined a sex cam site. After lots of research I
had found one that promised a steady payout and I had chatted with some of the
models before I started streaming myself. The pandemic had made it almost
impossible to get a new job and streaming on the other site didn't earn me
enough to pay the bills. On top of that, the original site had banned all
streamers who also streamed on The Void and I was one of the first ones to be
banned.

The sound of money falling indicated someone had paid 2000 tokens to go private
and I got really nervous. I hadn't done anything like this before in my life.
"Thank you MrBig, I hope you life up to that name. Let me get ready for you,
one moment." I clicked on his name and chose *Go Private*, switched to the
other camera and pointed it at the couch. As soon as I clicked on *READY* my
couch appeared in the top left corner and *MrBig* appeared in the main screen,
or his torso and legs at least.

I sat down on the couch and said "Well, at least you weren't lying." I smiled
and asked him what he wanted me to do. He asked for me to strip and I did as he
asked. When I was fully naked I sat down again.

"Show me your pussy," he said as he was jerking his big dick.

I slowly opened my legs and with the remote I adjusted the camera and zoomed in
a little. With my fingers I spread my lips and showed him the inside. "Oh my
god," I said, "you are making me so wet. Yes, keep jerking that big dick. Oh
yes, yes, I wish you could be here with me and shove that big dig in my wet
pussy." I slid two fingers inside me and moaned.

"Yes, finger that pussy!" he typed.

"Oh yes, yes," I slid three fingers inside myself and squeezed my full breast
with the other hand. "Oh my god, I love it. Fuck me, fuck me hard." I panted. I
watched him stroke his big cock and just as he was about to come I moaned "oh
yes, come for me. Come deep inside my pussy, I want it. Oh yes, yes, come for
me." He exploded and I acted like I was licking his cum. "Oh it tastes so good.
Wow, that was nice." I made air kisses and thanked him for joining me. Within
seconds after his orgasm he disconnected. I put my clothes back on and returned
to the regular stream.

I sat there for quite some hours and went private a couple of times. At the end
of the day I had collected short if 12,000 tokens. People could buy 100 tokens
for 10 dollars and on payout they would give me 8. I had earned almost 1000
dollars that day, which was way more than I had ever earned in my life.

By this time I was in my final year of college and as far as I knew nobody knew
I was a webcam girl. I graduated with honors and received my diploma in a solo
session at school. Restrictions were still in full effect and it wasn't the
graduation I had hoped for, but at least my parents were there to watch it.

I did my best to find a *normal* job but nothing came from it. There had been a
few interests but nothing seemed to stick. I started streaming every day while
my son was either in daycare or in kindergarten. After paying the bills I spent
some money on sexy clothes, high heels and sex toys. I was now streaming on the
cam site full time and some of my Void audience had found me on there.

I performed on camera with my toys and showed them how the dildos penetrated my
pussy. Not only was I having fun, I started to like doing it too. Streams
lasted as long as I needed them to be and every time I had reached my goals I
stopped streaming.

During one of the streams I was challenged to go to a public library and stream
from there. "Oh no, I can't do that. What if they catch me?" I replied.
