# The Challenge
_an erotic tale by Transgirl_

## Chapter 1
If you would ask me how it all started I couldn't tell you. It sort of just
happened and there were times I wished it never had happened, but most of the
time I'm glad it did. If you would have asked me a couple of years ago what I
thought about this subject I would have said "It's disgusting, people like that
should be arrested and punished.", but in secret I have always been curious
about it.

We had tried to get pregnant for years and when it finally happened it was one
of the happiest days of my life. The moment I got to meet him right after he
was born was another happy day. I couldn't believe how much I was able to love
another human, I loved him from the moment they showed him to me, all covered
in fluids, the umbilical cord still connected to him.

I spent hours with him, rocking him, watching him sleep in my arms. I loved
breastfeeding him and my husband had to pry him from my arms some days. I
didn't quite like it when he grew out of it, but there wasn't anything I could
do about it and to this day I am nostalgic about the days he was a baby.

Because of medical issues I couldn't get pregnant anymore, which only made him
more special to me. Now, I wasn't a helicopter mom, quite the opposite. I
wanted him to be independent and I encouraged him to think for himself. When he
learned to ride a bike I was harder on him than his father, but he got back on
that bike and within hours he learned how to ride. He was so proud of himself.

The first year he went to college I suffered from empty-nest-syndrome. The
house was so quiet and every time I past his room I felt the urge to cry.
Seriously, I had to grieve the loss of him living with us. My husband didn't
understand and we had some huge fights over this. One fight was so big I just
had to get out of the house.

Without thinking I drove over to my son, when I realized where I was I almost
turned around. But I really needed to see him. I called my husband to apologize
and told him where I was. He told me he was glad to hear from me and to say hi
to our son. I parked the car and walked to the entrance of the dorms.

The security guard called upstairs and a few minutes later Todd came out of the
elevator. "Mom? What are you doing here?" he said, "Come on in, come on in."
The guard took my personal information and together with my son we walked into
the elevator.

"Is something wrong?" he said, "You look so, so worried."

"It's all okay," I replied, "just had a fight with your father."

"About what?"

"Never mind. It's stupid."

"No mom," Todd said, "I want to know. What did you guys fight about?"

Tears welled up in my eyes as I said "It's just that I miss you so much. It
feels like you died or something. I can't walk by your room without looking in
and when I see your empty bed... I don't know. I looked online and some call it
_empty nest syndrome_ and I guess I have it hard."

"Oh mom," he said and he hugged me, "Next time just call or text me, okay? I
might not be living home anymore, but I'm still here."

"I know," I replied, "I know, but I can't shake this feeling."

"Okay," he said, "now you're here. Let's get something to eat." He opened the
door to his room and I peeked inside fully expecting it to be a mess, but it
wasn't. His room was just as neat and clean as his room at home.

"Please," I said, "can we just spend some time alone? Just like we did at
home? Just talk for a while?"

He stared at me and said "Sure. Come in."

I sat down on his bed and we talked for a while. I asked him about school,
whether he had met a nice girl, just the things a mom asks when she visits her
son. We laughed, teased and just a nice time together. When we returned from
having a dinner at a local restaurant we talked some more. After a few hours it
was time for me to go home again, but not before I had promised to come by
again some day.

A couple of months later my husband had to go on a business trip and I didn't
want to stay in the empty house for that weekend. I had called Todd to tell him
I wanted to visit for the weekend and he said "Stay in a hotel? Why? Dylan has
an air mattress and I'm sure I can borrow it. You can sleep in my bed and I
will sleep on the mattress. It's not a problem mom, Dylan's dad stayed over for
a night a few weeks ago." Dylan had become one of Todd's best friends and his
father was a widower.

I protested that I could book a hotel room, but Todd wouldn't hear of it so I
just gave in and said "Okay, okay, I will sleep in your bed. It will be
exciting to shower in a dorm again." I had lived in the dorms when I went to
college. During college I met my husband and we started dating in the second
year. It was like I could live my dormitory days again and I felt excited about
it.

That Saturday I got up early and finished packing my bag. As a woman I was sure
I was bringing way to much, but better to much than too little. I was excited
when I got in the car and drove to the town where my son went to college. I was
wearing my favorite skirt and a rather tight t-shirt. I didn't know why I had
chosen this outfit as I hadn't worn it for quite some time, but it felt good to
wear it again.

After a two hour drive I parked the car near the dorms and announced myself
with security. They called Todd to tell him I had arrived and a few minutes
later Todd appeared from the elevator. "Hey mom," he said when he saw me,
"everything okay?" I nodded and thanked the guard.

Once we were in his room I saw the air mattress on his bed and said "Ah, I see
Dylan doesn't expect guests." Todd laughed and said "No, he went home for the
weekend." I was a bit disappointed as I had hoped to meet him, but there wasn't
a lot I could change about that so I shrugged it off.

"Did you bring your good shoes? I found a beautiful trail the other day and I
thought we might go hiking later." Todd said.

I opened my bag and pulled them out. "Tada," I said triumphantly, "I was
hoping you would say that." When he was a teenager he loved going on hikes and
I had learned to like it too. During those hikes Todd had taken some beautiful
photos and three of them were on our walls at home. We sat down in one of the
shared spaces to get some coffee and we just chatted. I wanted to know how
school was going, if he met a nice girl already, just the things a mother asks
her son. Todd showed me around campus and introduced me to some of his friends.

A nice blonde girl said "Hi Mrs Davis, I'm Charlotte, but please call me
Charlie."

"Only if you call me Laura," I replied with a smile.

"Okay Laura, that's a deal," she smiled. She was really pretty and with my eyes
I told Todd to snatch her before somebody else did. "Mom!" was all Todd could
utter and he blushed. Charlie and I giggled as she knew what I meant with my
glance at him. "Sorry Laura," she said, "but I don't think my boyfriend would
like it."

"Darn," I replied, "always the same." I laughed and Charlie blushed. I loved
teasing my son and he never disappointed with his reactions. "No worries," I
said to Charlie, "I just love teasing my son. I don't mean anything by it."

Still laughing I took my sons arm as we went on with our stroll around campus.
"You really need to stop doing that, mom," Todd said, "You're embarrassing me."

"Ah, grow up," I said, "I'm just teasing."

We had lunch at a bistro just outside of campus, went back to get our shoes and
go in his car to go hiking. "I always loved the mountains," I said as we were
walking the trail. The trail went up and down until we finally reached the
summit of a mountain. The view was just magnificent and I was in awe as I
looked out over the valley below. "There's my dorm," Todd said pointing to the
building, "and that's the town hall." He pointed at some other buildings before
he got out his camera to take some photos.

I just stared at the view until Todd called me, as I looked over he took a
photo of me. I laughed and posed for some more pictures. "Wait," I said as I
took off my jacket. I posed for some more and arced my back a little.

Back in his room we checked the photos on his laptop and my face turned white
when I saw how much I had arced my back. I acted like nothing was wrong but I
felt really embarrassed when I saw the photos. I couldn't believe I had done
that. Todd ordered some food and as we waited for it to arrive we chatted and
Todd opened a bottle of wine.

It felt like we were home again, we always spent some time together after he
got back from school. Just chatting about everything and nothing. When dinner
arrived I was on my third glass and felt the alcohol. Not that I was drunk or
anything, but there certainly was a buzz. We had dinner and I helped him do the
dishes in the central kitchen. Todd made us some coffee when we returned to his
room and we talked some more.

"Do you still have those cards?" I asked him at a certain moment.

"Sure, want to play a game?"

"Yeah," I replied, "I haven't played cards since you left home." My husband
didn't like to play games and it had become something special between Todd and
me.

Todd got up to get the cards and a box of poker chips. He divided the chips and
started shuffling the cards. "Texas Hold'em," he said and dealt us both two
cards. I never had been good at poker and it didn't take long for him to have
won most of my chips. When I went bust with one last game he said "I thought
you would be better by now." and handed me my fifth glass of wine.

I was feeling the buzz quite good at that time and said "Oh no, I shouldn't.
I've had enough." But Todd wouldn't hear of it and said "Mom, you're in a dorm
at college. It's expected."

"Okay," I said, "but I really want to change and take a shower first." I
gathered my sweatshirt, yoga pants and Todd handed me a towel. He pointed me to
the girls bathrooms and a few minutes later I was showering. The water felt
really good on my face and when I bent my head backwards I could feel the world
spin a little. I giggled because I hadn't been this tipsy in a long time. I had
always been on my guard not to get drunk and I didn't want to this time either.

As I dried myself I heard another girl come into the bathroom and when I got
out of the shower she greeted me with a smile. "You must be Todd's mom" she
said, "I'm Marisha. Nice to meet you Mrs Davis."

"Oh, please call me Laura," I replied.

Marisha smiled as she started to brush her long red hair. "Okay Laura. Do you
like the dorms?"

"Yes, it's like I'm back in college." I laughed.

"You could fit in easily," Marisha replied, "You don't look your age."

"Oh, thank you," I replied, "I will take that as a compliment."

"It was one," Marisha laughed and saw how uncomfortable I was at that moment. I
was standing there with just the towel around my body and I really wanted to
get dressed. "Oh, don't be embarrassed," Marisha said, "I've seen a female body
before." I chuckled and realized she was right.

"It's just been so long since I was in a bathroom like this," I said, "I guess
I'm not used to it anymore." I turned to the mirror and removed some rundown
eyeliner with my finger. Marisha handed me her toilet bag and said "There's
some makeup in it if you want to use it."

I looked at her and said "Thank you. I seemed to have forgotten mine. I will
get some tomorrow." I looked in her bag and got some eyeliner, eye shadow and
lipstick. I brushed my hair and just as Marisha was about to step into a shower
I took off my towel. "Wow," Marisha said, "I hope I will have a body like yours
when I'm your age." I blushed and Marisha closed the door. As she turned on the
shower I got dressed and thanked her before I left the room. "You're welcome
Laura," Marisha said loudly.

The buzz had worn off a little, or so I thought and we played another round of
poker. When again I was low on chips Todd said "Why not make it a little more
exciting?"

I just stared at him and couldn't believe what he was suggesting. Todd smiled
and he handed me another glass of wine. My heart started beating faster and I
stuttered "What -- do you mean? -- Um -- No."

Todd dealt another hand and I thought I had beaten him as I said "Read them and
weep. Three of a kind." And I laid my cards on the table: three nines."

"Guess, you lost again." Todd said with a smile and laid his cards on the
table: four tens. "Oh no!" I thought and looked at my chips. I had just two
left and Tod said "Just take off your socks and next round we will play for our
shirts."

It was my time to deal and this time I was lucky. My straight beat his
two-of-a-kind and Todd took off his shirt. I don't know whether it was the
alcohol or just the moment but I felt excited about the game and watched Todd
deal another hand. I took another sip of my wine and checked my cards. They
weren't good and I lost again. With a red face I took off my sweatshirt and
thought "I am glad I decided to wear a bra."

Just a few rounds later I was down to my panties and bra. Todd still wore his
pants and boxers. We both just had two more pieces of clothing and I said
"Well, that was fun but I think we have to stop here." And I reached for my
sweatshirt.

Todd started dealing another hand and said "Well mom, I've never known you to
back away from a challenge." I turned my head to him and I could see the smirk
on his face. He knew I couldn't turn down a challenge, I had never turned down
a challenge. Not ever since I was a little girl.

"Oh, you little rat," I said, "you know I am with challenges. Are you really
challenging me right now? Really?"

"Yes mom," Todd said as he rested his head on his head, "chickening out?" He
made chicken noises and I felt something rise inside. "Oh, I will show you," I
thought and took up my cards.

I stared at him and after there new cards I had a really good hand. "Okay," I
said with a cold voice, "are you ready?" Todd nodded and I said "My panties for
your pants."

Todd was quiet for a while and said "Call. Show me what you got."

I laid my cards on the table and said "Straight flush of Queens."

Todd stared at me and I couldn't see what he was thinking. He always had a
real poker face. One by one he laid his cards down and with every card I got
more and more nervous. When he placed down the last card he said "Straight
flush."

I gasped as I looked at the cards. My face turned white and just stared at
them. I had such a good hand and still he beat me. I couldn't believe it and
when I looked up at my son he just gestured he wanted his price. "Oh why can't
I turn down a challenge," I thought and downed the last of my wine. Feeling
embarrassed I took of my panties and showed them to him.

"Throw them on the bed," he said, "I want to be sure you can't just put them on
again." He laughed as he watched me throw them. "Your time to deal." he said
and I just said "Oh no, no, no. I won't. Please turn around as I get dressed
again. I can't be doing this."

But Todd insisted and said "But mom, we've got to finish the game. Just two
more hands and I could be naked. Come on!"

I just stared at him and said "Where's the bottle?" Todd handed it to me and I
poured myself the last bit of wine in it. I downed all of it and dealt the next
hand. The flop wasn't good for me but somehow I got the upper hand and won that
hand. Todd took of his pants and now we both were down to the last piece of
clothing, my bra against his boxers.

Todd opened another bottle and by this time I was feeling a bit drunk. I hadn't
been drunk since I left college and I giggled thinking it took me to get back
to college to be drunk again. "What?" Todd asked as I giggled.

"Nothing," I said, "I just thought I hadn't had this much wine since I was in
college. I can't tell you what happened that night, it's not appropriate." Todd
just chuckled and said "I think I can fill in the blanks."

After Todd dealt the last hand, the flop could go either way. It wasn't
particularly good and when it was time to show our hand he said "This is it
mom. The last hand. Feeling lucky?"

I smiled and said "Oh, you don't know how much. I call. Show me your hand."

Slowly he went down with his hands "Three of a kind." he said.

I just stared at them, looked up at him and sighed. I placed my cards on the
table face down and slowly unclasped my bra. I stared straight at him and said
"Happy now? Your mother is getting naked." I slowly pulled the straps down and
held up my bra with my arms. "Is this enough? I've lost."

Todd got a smirk on his face and said "No, bra on the bed too. I want to see
you standing naked in the middle of the room."

I felt the blood drawing from my face and finally stood up. I stood in the
middle of the room, with my back to Todd. I threw my bra on the bed next to my
panties. As I turned around I raised my arms and said "Here, happy now." Tears
were closer than laughter at that moment.

Todd stood up saying "Oh mom, please don't cry. It was just a game. And it
isn't like I've never seen you naked before."

"Yeah, but those were accidents. This is different. I shouldn't have done this,
this is just so wrong. I'm your mother, for gods sake."

Todd got closer and before I realized what he was doing he pulled down his
boxers, revealing his hard penis to me. We just stared at each other and he
took another step towards me. It must have been the wine but suddenly I felt
his penis in my hand and he put his arms around me.

He kissed my neck and I moaned softly whispering "Oh Todd, we shouldn't do
this. This is so wrong." But it just felt too good.

"Oh mom," he said, "I wanted this for so long. Those times I got to see you
naked, they weren't accidents. I made sure I got to see you."

"What?"

"Yes mom," Todd said, "I've dreamed of this for so long."

He kissed my neck again and pulled me closer. His hands went all over my body
and it felt so good. He looked into my eyes and we kissed, not like mother and
son but as lovers. I opened my mouth and felt his tongue inside mine. Our
kissing became more passionate and I started to jerk his cock. I sat down on
the bed and started to lick his cock. I hadn't licked another mans cock since I
started dating my husband.

I looked up in my sons face as I opened my mouth to take in his penis. "What am
I doing?" I thought, "I'm sucking my sons cock." It tasted so good and it felt
so right. I took it in deeper and started sucking him harder. "Oh mom," he
said, "this feels so good." He placed his hands on my head as I sucked his
cock.

"Wait," he said suddenly and got out his camera. He changed some settings and
pointed it at me. "I've got to record this." He stepped in front of me again
and I stared into the lens as I started sucking his cock again. After a few
minutes he grabbed the camera and pushed me on my back. He spread my legs and
pointed the camera at my pussy which was really wet by now.

He slipped a finger inside me and I groaned as I felt him entering me. He
placed the camera on the desk again and as I laid there he checked if I was in
frame. Then he got on top of me and I felt his cock against my slit. "Oh Todd,
this is so wrong. So wrong." and groaned deeply as I felt his cock slide inside
me. I placed my hands on his back and then just said "Oh yes, Todd. Fuck me my
son. Fuck your mother." The combination of having sex with my own son and being
on camera while doing it really excited me.

I spread my legs wider and panted "Oh yes, yes, you feel so good inside me son.
Fuck me hard. This feels better than your father, you're bigger than him. Oh my
god, I can't believe it. I love fucking you Todd, I love fucking my own son."

He plowed me hard and I came multiple times. When I felt him twitch I almost
shouted "Come inside me son. Come inside your mother. I want you to come deep
inside my pussy!" With a deep groan Todd exploded inside me and after a few
minutes he filmed my cum filled pussy. With his fingers he squeezed some of his
cum out of my pussy. I placed my hand on my head, I couldn't believe what we
had just done.

Todd put away the camera and laid down next to me. I took him in my arms and
whispered "This was so wrong, we can't do this again. It just isn't right." We
laid there silently until Todd started sucking my breast, immediately my
thoughts went back to the days he was a baby. Within minutes I got on top of
him guiding his cock inside me again. I rode him until the both of us came,
filling my pussy once more with his cum.


