# Starting over Again
_an erotic tale by Transgirl_

## The divorce
My mother had warned me, but I just was to stubborn and in love to listen. But
she had been right all along, we were too young to get married. The marriage
had lasted for four years and now it was over. The only thing left to do was to
hand him the papers. I knew it would devastate him, but I just couldn't go on
like this and he had broken his promises far to often by now.

I just wasn't the arm candy he wanted. I didn't want to stay at home and go to
the country club like the other trophy wives. My ultimate limit was reached
when he, out-of-the-blue suggested I should get something done. When I asked
him what he meant he said "Well, your nose had always been a little crooked." I
blew up, I was so angry. When we started dating he told me he loved those
little imperfections and now he wanted me to have it fixed? The moment he left
for work I called a lawyer and now there I was, standing in front of his
office, the paperwork in my bag. It was time to confront him.

I knocked on the door and heard a short "Come in". As I opened the door he said
"Laura! I wasn't expecting you. Why didn't they call me I would have picked you
up in the lobby." I hated doing this at his work, but I needed it to be
somewhere I felt at least a little protected.

"We need to talk," I said, "and you need to get a lawyer." I handed him the
papers and his face turned white. He couldn't say anything, for him this came
out of nowhere and I understood that so I gave him some time. He started
stuttering "What? Why? How?"

"That's a long story," I said, "It's just that my mother was right, we were too
young when we got married. You were going to college and I didn't know what I
wanted. And when you proposed I was so in love with you that I just said yes,
but things have changed. I have changed and I know now that I can't be the wife
you want or need. I'm not the girl who is satisfied with going to the
country club or the spa. I need more and I can't do that when I'm married to
you. I need to start over again, like I thought I started over by marrying
you."

He just stared at me and said "What do you want? Half of what we own? I don't
know how we could resolve that without a fight. I won't leave the house."

"Read the papers," I replied, "and read the good. I don't want anything else
than what belongs to me. My clothes and my car. Everything else you can keep
the jewelry, the photos everything. I already have rented an apartment and when
I leave here I will be going there. I will stay here until everything is
arranged and then I will move to the other side of the country. I won't be
staying here much longer if you are willing. I won't fight you, I just want
those papers signed and go to court to have it ratified. That's all."

"No," he said, "that's not fair. We've been together for four years, we've
shared our up and downs. But I agree it isn't what it used to me anymore, I
can't deny that. So take the jewelry, sell it if you have to and I will also
give you what you deserve. That's what's fair, isn't it?"

"It is, but don't use that against me. I want it to be clear that I didn't ask
for this, this is your offer and I will accept it."

"What? Are you recording this?"

"Yes, just for protection. Lindsey was promised a lot, when push came to shove
she got railroaded and I just want some assurance."

"Understandable. The let the records show that you asked for this divorce, not
me."

"It's on the record now." I replied, got up and said "Look, I still care for
you, a lot. I just don't love you anymore, I'm sorry."

A month later we sat in front of the judge, who read our papers before she
asked "Mrs Peters, it says here that you agree with a third of the total assets.
Is that correct?"

"Yes, your honor."

"Why? You know you have a right to much more, don't you?"

"Yes your honer, I know. I just want this to be over. I want to move away from
here as fast and as soon as I can."

"Understandable. It also says here that you will assume your maiden name. Is
that correct?"

"Yes your honor. That was actually my idea."

"Ah, okay. And you Mr Peters, you agree with all of this?"

"Yes your honor. Splitting our assets was my idea. Laura didn't want anything
at first, but that didn't seem fair to me. She has been my wife for four years
and she has made it possible for me to go to college and now we, or I, reap the
benefits it just didn't seem right to leave her empty handed."

"That's quite noble of you, Mr Davis. This might be one of the easiest divorces
I had in front of me or the two of you are really good liars. I will assume the
first and ratify this paperwork. Well, Mrs Peters looks like you've got your
old name back. Mr Peters, Miss Davis, please stand. By the power of this court
I declare this marriage dissolved. Next case."

As we walked outside I said "Promise me to take care of yourself. And thank you
for making this as easy as possible, I owe you one for that."

He replied with "Don't worry. Deep in my heart I knew it was over before you
showed up in my office. Thank you for not staying at the house that night, I
don't know how I had felt if you still had been there. Take care Laura Davis,
it was nice knowing you." He walked away and I just looked at him one last
time, then turned around got in my car and went home single again.

## A new town
It took me a couple of weeks before I had found an apartment I liked, but
finally it was time to move. My best friend was there with me and together we
would fly to the town I would call home. The truck with my furniture was on
it's way and I wanted to make sure I was there when it arrived the next day.

"I'm still sorry to see you go," Lindsey said, "You were the only one who kept
being my friend after my divorce. It must have been hard on you with our ex's
being best friends and all." We hadn't know each other that well before her
divorce, but when I saw everybody dropping her like she simply didn't exist
anymore I reached out to her. We got to talking and she was actually the first
I told I was thinking about a divorce. We had grown close in a very short
period of time and now I was moving away.

"You're always welcome," I said, "my door is always open for you, you know
that."

"Yeah, but now I need to get a ticket, get on a plane, get a cab to knock on
your door unannounced. Just too much work, me moving there might be easier."

I turned around and said "Now, that's a good idea. There are hospitals there
too, maybe they are looking for a good nurse."

"Hey!" Lindsey shouted, "I'm a nurse practitioner, thank you very much. And I
can't I still have to do my residency here. So I'm stuck for another two
years."

"Okay," I said, "we really need to go if we want to catch that plane." I looked
around the empty apartment one last time and handed the keys to the super when
we left the building for the last time. I had sold my car so we went to the
airport in Lindsey's. We got to the airport in time and spent some time looking
at the stores while we waited to board the plane.

The flight went smoothly and we landed on time. We found a place where I could
rent a car for a couple of days and two hours later we arrived at my new
apartment. "Well," Lindsey said, "I hope you learn you're route soon, because
we were on totally the wrong end of town." We burst into laughter.

My apartment was in the fifth floor and when Lindsey walked in she said "This
is really nice. You did well. I like the colors on the wall, when did you do
that."

"Oh that was still here from the previous renters, I liked them so I told the
landlord it could stay."

"You're renting this? I thought you bought it."

"No, I don't know if I'm staying here or not. In this part of town I meant, I
might look for an apartment downtown somewhere. This was available and I could
move in immediately."

"Well, we need to get an air-mattress or something. I'm not sleeping on the
floor. Let's go find a mall."

At the mall we got a mattress, a simple table and two lawn chairs. Lindsey also
bought a small TV and said "You can put it in your bedroom when I leave." On
our way back we ordered some take-out and spent the night in a very empty
apartment besides the mattress in the corner of the living room, a small table,
two lawn chairs and a TV on it's box.

When everything was unpacked I said "Well, decorating is done. What do you
think?"

"I love the minimalist tough, but didn't you overdo it just a tad?"

I laughed and said "Let's eat. I'm starving."

The next morning when I woke up I had to thing where I was for a moment and
when Lindsey mumbled something I realized where I was again. I got up, took a
short shower and put on something comfortable. A few minutes later Lindsey also
got up and when she came out of the bathroom she said "I should have given you
an coffee machine, I would die for one right now."

"Oh, there's a coffee shop just around the corner. One of the reasons I chose
this place. I want to stay in, just in case the truck arrives early."

Lindsey went out to get a coffee and I cleared everything away, except for the
table and the two chairs. They had said they would arrive between noon and
three, but you'd never know. Twenty minutes later Lindsey arrived with two
latte's and cinnamon buns. I opened the doors to the balcony to let some air in
and we sat down at our glorious table.

Around 10 my phone rang, it was the driver of the truck "Yeah, looks like we're
going to make it a little earlier then expected. Is that okay? We can wait for
a few hours if needed."

"No, it's okay. I'm there now so just come on over, I'm actually waiting for
you."

"Good to hear, according to my GPS we should be there in about an hour or so."

My heart jumped when I saw the truck turn into hour parking lot and two burly
men got out. The super of the apartment complex talked with them for a short
while and one of them got back in. The buzzer sounded and I pressed the button
on the intercom "Hello, you've arrived I see."

"Yeah, we need to unload in the back. They've got a special place for us to
unload. If you could buzz me in, I would appreciate that." Almost 15 minutes
later I heard a voice say "Miss Davis?" It took them almost 4 hours to unload
everything and bring it up to my apartment. They had put everything in the
rooms where it needed to go and I thanked them by giving them a nice tip "Just
don't spend it all in one place," I said. "Well, thank you ma'am and thanks for
using Rover's. Have a nice evening now and you to Miss." Lindsey shouted "Thank
you, have a good trip back!" from the kitchen.

My apartment was filled with boxes and the furniture just stood where ever it
was easiest. The process of unpacking it all, putting the furniture where I
wanted them to be and in some cases, like my bed, assembling could start.

"Oh, please let's start with your bed. My back still hurts from that air
thing." After an hour my bed was assembled and Lindsey rummaged through some
boxes to make the bed. "You just find your coffee machine and make us some."
she said, "I'm dying for a cup."

Another 4 hours later, we had hardly made a dent but at least the kitchen was
almost done, my bed existed again and a wardrobe was almost assembled. It took
us another two days to get it all done. "I'm so happy you were here," I said,
"I don't think I could have done it without you." Lindsey just waved her arm
and said "I'm too tired to raise my arm, but thanks."

The next morning Lindsey had to go back and we hugged for a while as I dropped
her off at the airport. On my way back to my apartment I realized I was on my
own for the first time in my life. Really on my own, in a town where I didn't
know anybody thousands of miles from the people I did know. It was frightening
and exciting at the same time and I was looking forward to what was to come.

## A new job
For the first few weeks I was okay with just staying in my apartment by myself
trying to get the know my new surroundings, just settling down so to say. I
found my way to the nearest supermarket and mall. During that time I didn't
need much, it all was just so exciting to me. The novelty wore off a little and
I started looking for a job, just so I could get out of the house.

After a few weeks I got one at the very supermarket I frequented and although
it wasn't what I wanted to do for the rest of my live at least I had something
to do. It was hard work and I had to get used to it, but the hours I had to
work were great and I was home at 3 in the afternoon, giving me plenty of time
to pursue other things for the rest of the day.

Having a job didn't mean I stopped looking for one, but the ones I really liked
asked for some kind of college degree and that was one of the many broken
promises during my marriage, he always had an excuse for me not having to go
and now it bit me in the ass, so to say.

Having a mediocre job that I didn't particularly like and being in a town where
I hardly knew anybody, made me feel lonely and I started to really think about
moving back. One evening it felt like the walls were collapsing on to me and I
had to step out on the balcony just so I could breath. I had a full on anxiety
attack and after a few minutes I calmed down enough to go back inside. The
whole ordeal was very frightening to me and I didn't have anyone I could talk
to at that moment.

I sat down behind my laptop and started searching on the internet for some kind
of support. I came across a site stating they were aiming at people who felt
alone or lonely for some reason or another. I didn't feel particularly lonely,
at least that was what I thought, but I clicked on the link anyways.

"Are you feeling lonely? Do you thing you are alone? There are many ways you
can feel this way, maybe you are feeling lonely too and you don't even realize
it. Well, this site offers a community so you don't have to feel that way
anymore. We offer support, chats, forums, games and even a dating-service.
There is always someone here to talk to, so why don't you join us? It's free!"

'What the heck,' I thought, 'at least it's something to do.' I joined the site
and a few minutes later I logged in for the first time. I browsed the site for
a while, clicking on all the links, posted something in the introduction thread
and basically just lurked. The chat room they offered was basically the most
fun. It had different topics, or _chambers_ as they called them, so you could
talk about anything you wanted to or about something really specific like
_having dark thoughts_. I kept away from the latter one and just joined the
chat with the lighter topics. Before I knew it I had spent over three hours on
the site and really had to go to bed.

The next day I logged in again after dinner, replied to some responses on my
introduction post and went into the chat room again. People were so happy to
see me again that it made me smile. I couldn't believe something like this
could make me happy, but it did. They were real human beings sitting on the
other side who were responding to me and some of them became important to me,
but at that time I didn't know that yet. At that moment I was just having some
fun.

Some would say I got addicted, but to me I was just talking to people like
others go to a bar or something. This was way cheaper and I was in the safety
of my own home. But the fact is I started chatting with the community every
evening and during my days off sometimes even at night. There were people in
there from all over the world and it was really nice to see how other cultures
looked at things.

My parents were rather conservative and they had raised my accordingly, but I
always doubted their believes. I never had the courage to say anything about it
though and when I after I got married everybody I knew thought the same, so I
kept it to myself the whole time. Now on this site I had befriended a European
woman who opened up a whole new world to me, a world that made way more sense
to me. She basically introduced met to feminism and woman's rights issues.

"But why? What does a man need to work? You could have gone college while he
could get a job in a factory, couldn't he? So why did you choose to let him
go?" was one of her many questions to me. The more we talked the more I got to
see her point of view and with some I agreed, but to most of them I still had
that inner voice saying 'what will other people think of you?'

Then one day she said "But why do you have to conform? Why do you have to
please others? Isn't it your life? Who cares what other people think? Everybody
has on opinion, so just do what it is you want to do. Have some fun at the same
time. That's what I do, I'm just having some fun and I don't care what anybody
thinks of me."

I knew she was right and somewhere deep in my heart I wanted not to care, but
it was such a hard mountain to climb. The woman I talked to was called
_MissChief109_, which I thought was a nice pun and we befriended through the
site, which made it possible for us to sent direct messages. Because I didn't
want to get bombarded with messages I only befriended a few people on the site.
Other people could just send me a normal message or post something.

At some point I had gathered enough so called karma points that new options
came available to me. Now I could upload photos, start private chats in the
chat room or join the _Let's meet in Real Life_ section of the site. The latter
wasn't meant to be a dating thing, but it had become one anyway. Most posts in
there were just to meet up in a bar or to come together for dinner with a group
of people.

There was one that peeked my interest, it was called _The Dungeon_ and the
topic was _Let's play Dungeons an Dragons and have an adventure._ I opened the
thread and read how it worked. The group would come together on the site every
Thursday and play in a special chamber. The campaigns would last for several
weeks and everybody could join. _We are beginner friendly, we're just having
fun._ it read.

I send the _Game Master_ a message and asked it I could join one time, just to
see what it was like because I had heard of the game but I never had played and
thus had no clue what to expect.

He replied within a few hours saying "Hi, our campaign is almost over and I am
willing to do a one-shot so you could just join in. The one-shots are meant to
be introductions to the game and everybody there knows there is a beginner in
our midst so they are patient and willing to explain everything. I will let you
know when there will be one. We do use voice chat though, is that okay with
you? Do you have a headset with a microphone?"

I replied it would be okay and I bought a headset the following day. I tried it
on some of the voice channels and chatting like this gave an extra dimension to
the chat, now it wasn't just sentences anymore, they were voices and the people
became real.
