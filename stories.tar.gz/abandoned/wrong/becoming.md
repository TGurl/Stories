# Becoming
_an erotic tale by Transgirl_

## Introduction
If you would ask me how it came this far I couldn't really tell you. All I know
is that I'm happy with the way things are right now. Our marriage has never
been stronger and we are truly open and honest with each other. In no way will
I ever imply that this will work for everybody, because it doesn't. I've seen
relationships end, marriages becoming wars and even worse than that. All I can
say it worked wonders for us and if we hadn't found this, our marriage would
have stranded years ago.

Sure it's easier for us because we don't have children (yet), but that doesn't
make a difference whatsoever. For this to work you really need to trust each
other, for the full 100 percent. There are no shades of gray, no excuses. You
either commit or you don't. If either one has doubts this isn't for you. Keep
that in mind as I tell you the story of how we got here.

## How we met
I was in my second year of college and wasn't quite the party animal like the
others. I was there to study and get a degree, nothing else mattered to me.
Sure I went out on dates, had things to do besides college but getting my
degree was the most important thing to me. I even skipped holidays because I
had a test coming up.

During one of those rare moments I did something else than reading books I saw
him, standing by the entrance of the gymnasium looking bored as hell.
Butterflies rose up the moment my eyes fell on him. I had never felt something
like it before in my life. From that moment I knew what it meant to fall in
love at first sight. But I was simply too shy to act upon it and when I saw him
walk away with another girl in his arms it was like the earth swallowed me
right there and then.

A few days later I saw him again, this time in the mess hall getting lunch. It
was very busy at that time and one of the few places available was right there
next to me. I watched him as he was looking for a place to sit down, his eyes
lit up and he sat down a few tables across from me. A bit disappointed I
continued my lunch and with my heart pounding I walked right past him when I
was done. This time I was sure he had seen me.

We had a staring competition for some weeks before he sat down across from me
in the library. I couldn't believe he sat there as there were enough free
spaces available at the time and I didn't dare to look up as I was sure he
could see how red my face was.

"Hi," he said, "I've seen you around. I'm Todd. I wanted to talk to you for a
couple of weeks now, but I didn't dare to. Hope you don't mind."

"Laura," I whispered.

"What? I didn't quite understand."

"My name," I said, "Laura is my name."

"Oh, hi Laura," he said with a laugh, "Want to go and get a coffee or
something?"

"No, I've got to study," I said still staring at my book, "there's a test
coming up."

"Those are in three weeks," he said, "I'm sure you could spare half an hour."

I lowered my head even more. I couldn't believe he was actually asking me to go
for a coffee. He had walked away with one of the most popular girls in school
that day I saw him for the first time. Why would he even bother with a girl
like me?

"Come on," he said, "one coffee. If you don't like it, I will never bother you
again."

"But you have a girlfriend," I stumbled over my words as I spoke.

"What? No! Whatever gave you that idea?"

"I saw you walk away with that blonde girl after the game the other night.
What's her name? Oh yes, Natalie."

"Nat?" he burst into laughter, "Natalie is my sister. I was there to pick her
up. We were going to our parents, but she wanted to see her boyfriend play."

For the first time I looked up and he smiled "Finally! There is that pretty
face." I blushed again and lowered my head. "Aw, okay. No more compliments,"
Todd said, "What if I don't compliment you ever again, will you then get that
coffee with me?"

I giggled and he almost shouted "By Jove, she can laugh. It's a miracle."

I looked up and said "Okay then, one coffee and no compliments."

After collecting my stuff we walked out the library, across the square to the
coffee shop on campus. We sat down on the patio with our orders and we talked.
After half an hour it was like I had know him all my life.

"So, you aren't a _jock_?" I asked.

"Hell no, I'm not into sports whatsoever. My sister is, she's a cheerleader
now. But me? No. I tried baseball but I sucked at it. As I did in basketball,
football, soccer you name it, I sucked at it. Then I got a computer from my
dad and I knew what I was good at. I'm the proverbial geek or nerd, whatever
you want to call me. I just don't dress like one." He laughed and asked "And
you? What do you like?"

"I like to get my degree and get away from all of this. Besides that I love to
read, mainly fantasy. You know about elves, orcs or dwarvers. Like Lord of the
Rings and such. I love to loose myself in those worlds."

He turned to me and leaned a bit forward. "Is that so? Did you ever play
_Dungeons and Dragons_?"

"No, but I always wanted to. But there weren't any games where I'm from."

"Oh, I know something we could do for our second date --"

"Date?" I interrupted him, "who said this was a date? We're just getting
coffee."

"Oh sorry," Todd said, "I know where we could go on our first date. That is if
you want to go on a date with me. Do you?"

"Do I what?"

"Do you want to go on a date with me?"

"When?"

"That's not a no."

"And that isn't an answer."

He laughed and said "Touche, but do you? This Thursday at 7?"

"This Thursday at 7?" I acted like I had to think about it and then said "Why
not? Yes, I would love to go on a date with you. But rest assured I will go
home if I don't like it."

"And I will bring you. But I think you'll love it."

That Thursday I was anxious all day. I couldn't quite concentrate on classes,
all I could think about was what was about to happen at 7 that evening. When
the clock turned 6 I got ready for my date and had put on a nice dress for the
occasion. When there was a knock on the door my heart skipped a beat, I grabbed
my jacket and purse before I opened the door.

Todd stood there in a simple t-shirt and jeans, but he looked smashing in my
eyes. "Come," he said, "we're late already. I forgot we started a bit early
tonight."

"What? Where are we going?"

"You'll see." We went down to the lobby where he greeted the security guard who
said "Is it Thursday already?" Todd nodded and we went down a flight of stairs
to the basement of the dorms. We passed a few doors before he stopped and said
"Now we are entering the _Realms of Imagination_." He opened the door and I saw
a long table. Around it a few people were seated and on the head I saw a woman
sitting. She said "Ah Todd, right on time. We were about to start. And who is
this?"

The woman got up and reached out her hand to me. I shook it and said "Laura, my
name is Laura."

The woman smiled and said "Welcome Laura, I'm Darla and I'm what they call the
_Dungeon Master_. Here to play or watch?"

"Oh, I'm just watching. You are playing _D&D_?"

"We sure are. Please sit down, you are free to interact, but don't meta game.
If someone forgets they have a potion for example and you know where it is,
don't say anything. But you are allowed to laugh, cry and lose your self in the
story."

"I understand."

"Good, then let us begin."

Everybody got quiet and Darla lowered the lights a bit. She sat down and said
"Well, a small recap. The group of adventurers had just met in a tavern on the
outskirts of _Dalamere_, a farmers town on the borders of _Marquette_ and the
_Dwendalian Empire_. While they were enjoying there ales a woman came in
screaming someone had stolen her child. You had a short discussion on whether
you should help her as there wasn't any coin to be made. But you did and after
a short battle you returned her daughter to her. Satisfied and feeling good
about the deed you had done you returned to the tavern, only to find all your
belongings stolen. What are you going to do?"

Todd spoke up with a deep voice "I think we should ask the keeper if he saw
anything. Maybe a swift knock of my hammer will help him remember."

A girl across from him shouted "Darius! You can't solve everything with
violence. We need to be tactful."

The story went on as the group investigated and in the end ended up in the
sewers of _Dalamere_, where the learned a group of thieves had their base. A
fight ensued and Todd, being the half-orc he was swayed his hammer. As the
story unfolded I got swept up in it and cheered with them when they finally
defeated the boss and came up from the sewers victorious once more.

Before I knew it three hours had passed and I felt sad when the DM said they
would continue the story next week. One of the girls came up to me and asked
"How did you like it?"

"I loved it," I replied, "what a story."

"Yes, she's a really good DM. We're so lucky to have her."

"Who is she?"

"She is the psychology professor," Darla laughed and continued with "and if I
don't see your papers on my desk on Monday, I will fail you." She winked at me
and whispered "Always keep them on a short leash." I giggled and when Todd
asked me I answered "Yes Todd, I loved it."

I watched them play for a couple of weeks before I actually started playing
too. I had made a plan with Darla how she could introduce me. I would just be
in the story for one time at first, but that changed soon.

"Our group of misfits sat down in the tavern, bloody and covered in mud. Darius
ordered a round when his eyes fell on a dark shadow in the corner. He could
barely make out what he saw. When the person sitting there lit a candle and.
Please Laura, tell them what he sees?"

"I'm an elf woman. My face if covered by the hood of the cloak, but my hands
show I'm an elf. I heard of this group on my travels through this part of the
lands. I slowly turn my face to him and smile."

The group cheered as I told them who I was. Todd lowered his voice again "You
there. In the corner, what are you looking at?"

"At a group that could use my help." I answered.

The girl who played a dwarf said "We don't need any help."

"Ah," I replied, "then you know everything there is to know about Veius. I see,
well, then it is best I go."

"Wait!" one of the others shouted, "What do you know about Veius? Are you a
follower?"

"No," I answered, "he was one of mine once." and I told them how I made a move
towards the door. "I turn around and say 'But if you want to hear? Come and see
me in the _Deliverance_.' and I walk out the door."

The group begins to talk amongst each other and come to the conclusion the have
to meet me again. With my help and knowledge of the arcane we finally get to
defeat Veius and the DM tells about how I held him in my arms. As she spoke
tears rolled down my cheeks and when it was time for me to speak I said "Oh
Veius, my son. Why did you forsake me? Why had it to come so far? All I wanted
was the best for you, but you just couldn't wait. You always were so impatient,
my son. But I am here, your mother is here and I have never stopped loving you.
But this had to end, it just had to. Rest my son, be with your father and tell
him I love him."

The group was quiet for a long time. Darla scraped her throat and said "This is
where we till pick up next time. Thank you for this wonderful story."

Everybody looked at me and one of them said "What a game! What a game! You were
so good, Laura. You simply have to come back next time. I need to know where
this goes. Who are you really? My God, what a game."

I played three more games as the elven woman before it was time for her to
leave the group and go to wherever she was needed. The goodbye was sorrowful
and every player dug deep into their emotions. But there was a happy element to
this, I had taught some spells to one of the group and they all leveled up.

"Rexalia, please use these spells whenever one of your friends needs it. They
are powerful but will drain you. Whenever you need to you can message me and I
will answer. Now go and be with your friends. Have a good life Rex and always
be there for your friends."

The players had tears in their eyes as the watched me fly off into the sunset.

The group continued the campaign without me and I watched them play a couple of
times. I just wanted to return to my books and concentrate on school.

In the third year I agreed to join a new campaign and I played a cleric
tiefling, red skinned with black horns. We had many adventures and I double
classed as a rogue. Quite some times I had to decide whether to save a friend
or to attack the monster. That's what D&D is all about, making decisions in the
heat of battle, talking about what to do with the other players and to create a
story with all of us.

During that time all the players became my friends and something blossomed
between Todd and me, in the game as well as in real life. We kissed for the
first time in the game and that evening when he dropped me off we kissed in
real life too.

After we graduated we lived on our own for a while before we took the plunge to
move in together, a year later we got married.

## How we almost split up
We were married for almost 4 years and the shine of being married had gone.
Todd worked long hours and sometimes during the weekends. I had my own job and
slowly we grew apart, we just didn't know it yet.

It happened during one of those weekends Todd had to work and like he usually
did he locked himself in his office all day. All I saw was him getting up, take
a shower and getting dressed. He didn't even check if I was awake. He just
walked to his office and started to work. He didn't even apologize for not
remembering we had made plans. The anger grew inside me but I knew him too well
to talk to him if he was like this. Whenever he had a problem to solve his mind
just couldn't cope with anything else.

A few hours later he came into the kitchen. I was clearing out the dish washer
and he just "What? No coffee?" grabbing a soda from the fridge. I just exploded
and told him I wasn't his secretary nor his coffee lady. "If you want coffee
make it yourself! I'm your wife!" I shouted and ran out the kitchen.

He didn't say a word, he just locked himself up in his office again and the
first time I saw him after was when he crawled into bed next to me. Twenty
minutes later I just said "I will sleep in the other room."

This went on for a few weeks, we spoke less and less and most nights I slept in
the guest bedroom. My best friend, Marisha, knew something was wrong and when
she pushed for an answer I just burst into tears and everything came out.

"I'm so sorry," she said when I stopped talking, "maybe I can talk to him and
tell him you two really need to sit down and talk."

I just stared at her and said "And make everything worse?"

"What can be worse than this?" she asked.

That answer dumbfounded me, but she was right. Things were as bad as they could
get. "Maybe," I said after a while, "maybe it's for the best. Maybe our
marriage isn't to be."

"What no? Remember when we were playing D&D? I've never seen two people more in
love than back then. You two were made for each other. You need to fight for
this, be _Ophelia_ again, that feisty tiefling. Ask yourself what would she do?
She wouldn't just give up, now would she?"

I chuckled when I remembered Ophelia. She was a feisty character when I played
her. Ophelia did things I would never dare to do in real life, it was my way to
explore being like that. "You're right," I said after a while, "she would fight
for her relationship. And so will I. But I have to do this on my own. Thanks
for the offer, but I really need to do this by myself."

"Okay," Marisha said, "then just do it. Remember even splitting up is better
than this."

I nodded and thanked her, I had set my mind to talking that evening. No
excuses, no interruptions. When Todd called he would be late I told him I
needed him home for once. "Please come home," I said, "we need to talk.
Seriously, if you don't come home at six I will be gone at seven."

Todd was home at six sharp and I could see he was really nervous about what I
had to say. I hugged him and said "Thank you for being here. We need to talk."

We sat down in the living room, I took his hands in mine and said "You know I
love you. You have to know that it hurts me we have to have this talk, but I
can't go on like this. I feel like you take me for granted. You come home late,
don't talk to me or thank me for dinner anymore. You just sit down watch TV, go
to bed and do it all over the next day. During the weekends when you work I
feel like you treat me as a co-worker, not your wife. It hurts me, it hurts me
a lot."

"I love you too. And I never take you for granted."

"Maybe not on purpose, but your actions speak a thousand words. Like that time
I got angry, you never talked to me about it. You just crawled into bed, not
even checking if I was still awake. After that we hardly said a word."

"But you --"

"No," I interrupted, "you needed to talk first. I had made clear how I felt, it
was your turn to make a move and I waited for it. Until today. Today I talked
to Marisha about all of this. She knew something was up and she pried it out of
me. She made it clear we had to talk. And now here we are. What do you want? Do
you still love me? Do you even want to be with me?"

Todd's face turned white and he almost shouted "I love you more than anything
in the world. I thought you were okay with me working this hard. I am doing
this for us, so when we have children they will have a good life."

"But you are losing me this way." I said, "and what children will come if we
split up? I need you Todd, I need the boy who I fell in love with. Where is he?
The boy that made me laugh, the boy who told me stories that made me cry. I
miss that boy. I miss him so much."

Todd stared at me and it was like the penny dropped, he was quiet for a while
and finally said "I'm so sorry. I really didn't realize what was happening. I
thought you were okay with this."

"I'm not. We need to make some changes."

"Okay, like what?"

"Like," I thought for a while and said, "Remember in college how we blocked
Thursdays because of the game? We could do that again, just not for the game.
Thursdays are for us, to spend time together. To be husband and wife again."

"But what if I --"

"No buts, Thursdays are blocked no matter what. Only family can override, not
work, not friends. Sure, if we both want to visit someone we can. Because we
will visit them together. Do you understand what I mean?"

"Yes, I think so. But what if I really have a deadline?"

"Then I won't complain if you are in your office all weekend. Thursday is for
us."

Todd thought for a while and finally said "Okay, let's do it. Thursdays are for
us. I will tell them tomorrow I won't be available on Thursdays anymore as my
wife needs me and you always come first."

Tears welled up and I said "You don't know how much I needed to hear you say
that."

Todd kept his word and informed his boss about the new arrangement. It took
them some time but after a few months they knew Todd wasn't available on
Thursdays. Every date-night he was home at four and even shut off his
work-phone for the night. Slowly but surely we found each other again and more
often he told his boss he couldn't work on a Saturday as he had made plans with
me, but only when they called him and he really wasn't that needed.

Our sex life flourished too and it didn't take long for us to start exploring
things that could add to it. At first it was just with toys, some mild bondage
or just having sex somewhere we could get caught. We discovered we both liked
exploring our sexuality and both came up with things we wanted to try.

Opening up this side of our personalities made us closer then we had ever been,
through the mild bondage I learned I could trust him more than I already knew.
He never crossed the lines I had drawn and always had my well being in mind.

One Thursday I told him about a fantasy I had for a long time. "Please don't
laugh," I said, "but I always wanted to know how it would feel to be tied up,
blindfolded and gagged. How it would be to feel totally helpless. I want you to
do that to me and I don't want to know when. I just want you to do it someday
when I least expect it. To leave me helpless, not knowing when it will end."

He nodded and promised me he would keep it in mind. It was a few months later
and I had almost forgotten all about it. It was a Monday when he knew I was
home from work all day. Around 11 in the morning he suddenly came home, I
hadn't heard his car. He just stood there in our bedroom. He grabbed me, tore
my clothes of off me and bound me real tight. He then blindfolded and gagged
me. When I lay there in the guest bedroom, bound, naked and not able to talk or
see I heard him whisper "Have fun, I will be back late. Enjoy!"

I felt totally helpless and lost all track of time. I yelped when I felt his
touch on my skin "Goodmorning," he whispered, "having fun?" I shook my head and
really wanted to be set free. "Just a few more hours," he said, "I will be back
from work soon." I heard him close the door and drive off.

Before I knew it I felt a hand on my skin. I didn't know who it was and I was
so scared. My gag was removed and I felt fingers on my lips as I stretched my
mouth to relieve the pain. Two fingers squeezed my nipples and the thought of
this random person touching me like that excited me. I felt myself getting wet.
Whoever it was unbound my legs and laid me on my back. My arms were still tied
behind me and it was really uncomfortable for me.

I felt my legs being spread apart and something touched my pussy. "No," I
cried, "please no." I yelped as I felt something entering me. It took me a few
seconds to realize it was somebodies penis. The thought of being penetrated by
a stranger made me wetter than I already was. I moaned softly and said "Oh my
god, what are you doing? I can't do this. Oh my god, oh yes. No!" I shook my
head when I heard a voice whisper "Who do you think this is? Somebody else?
Huh, do you?" My blindfold was lifted and when my eyes were adjusted to the
light I saw it was Todd on top of me.

"But you just left," I uttered, "I heard the car."

"Oh that was Marisha," he said, "she needed the car and I told her she could
come fetch it at 11. I just went outside to give her the keys so she wouldn't
ring the doorbell. But tell me, who did you think was touching you this way? I
know you got excited the moment you thought it wasn't me. And don't lie, tell
me the truth. Do you get excited thinking about being fucked by someone else?"

I looked at him and felt him slowly slide in and out of me. Again he insisted
to tell him and after a few thrusts of him I said "Yes, it excites me. Oh yes,
it really does. I love you so much and I would never give in, but I do
fantasize sometimes."

"Ah, there is the truth," Todd smiled and pulled out of me. Turned me over and
freed my arms. My shoulders hurt from being in the same position for all those
hours.

"I never want to do that again," I said as I rubbed my shoulders. Todd just
smiled and said "I knew you wouldn't. But you asked for it."

"I know, I know." I replied.

"Now tell me about that fantasy."

"You really want to know?", I asked, "promise me you won't get mad."

"I promise, because I know you will never act upon it. I trust you more than
anything in the world. Now, please tell me."

"Well, it all started in freshmen year in college. My room mate was a girl,
Elsa. She went out every night and came back late, I just knew she had sex with
a lot of them. One night when she was out again I started to fantasize I was
her and how I would go to a bar, dressed all sexy like her and how I would go
dancing. I would let them touch me, touch the naked parts of my body. I thought
how it would be if we then ended up somewhere, how I would go down on him and
take his cock in my mouth. How he would lift me up and penetrate me, how he
would lay me down on the bed and get on top of me. The longer I thought about
this the more I needed to satisfy myself and I started to rub my clit. I never
came so hard before."

Todd seemingly enjoyed my story and I turned to him. "You like hearing that?
How your wife was dreaming of having sex with a random guy she picked up in
a bar? Even though it was all just a fantasy? You like it don't you? And don't
lie, your dick is all hard."

Todd just nodded and said "Tell me more."

"Oh," I smiled, "one thinks he likes it. Well, there was this one night. Mind
you this was all in my head but I will tell you like it really happened okay?"

Todd nodded and I continued "Now, it was a Saturday night and everybody had
gone home for Thanksgiving. I needed to study so I stayed behind. There were
just a few of us on campus and I was in my bed when I felt this urge deep
inside me. I got up and dressed real sexy. As I was walking the halls I stopped
a few times to rub my clit and just as I stood there a boy came out of the
elevator and saw me. I didn't stop and lifted my leg to show him exactly what I
was doing. He just walked up to me, ripped open my shirt exposing my breasts to
him. In the same moment I felt him entering me, all I could do was moan and
scream 'Yes, fuck me." Right there in the hallway across from the elevator, he
fucked me so hard I came multiple times over his cock. When he was about to
come I urged him to come inside me and I felt him twitch and throb as he was
about to come. He came so hard his cum dripped out of me. All my muscles
contracted as I had a deep orgasm."

While I was talking Todd was jerking his cock and just as I said the man in my
fantasy exploded I knew he was ready to come too. I placed my mouth over his
cock and sucked him until he unloaded in my mouth. I had never seen him come so
much as at that moment. I had to swallow a few times there was so much cum. I
licked his cock clean and when he had regained his wits he turned me on my
back, spread my legs and licked me until I came too.

After that day I told him more stories about what a slut I was all made up on
the spot. "Oh yes, then I sit down and feel his cock against my wet cunt. Just
like this and as I sit down I moan deeply. His cock stretches me and I just
can't get enough of him. He goes in so deep, so deep. I have to just sit for a
moment and adjust to his thick cock inside my wet pussy." We didn't have sex
anymore without me fantasizing about being with another man. Sometimes even
two, for me the need to explore this in real life became bigger and bigger.
Until we both agreed to see what would happen if the opportunity arose.

"Laura," Todd said after another story, "if you ever feel like you want to
explore this for real, I won't get mad. I just want you to tell me about it, I
want you to be honest with me. Maybe I could even watch. I just wanted you to
know it's okay if you really do it one day."

I just looked at him if he was crazy and said "Don't worry, fantasizing about
it is enough for me."

## The trip
Todd surprised me with a trip to Barbados. He had booked a small cottage near
White Caps and the photos just looked mesmerizing with the view over the ocean
and a white beach just outside the door. "We're going for two weeks," he said,
"the honeymoon we always wanted." I hugged him, thanked him and just couldn't
wait to go.

We landed on Grantley Adams International Airport around noon, hired a car, got
some groceries and made our way to the cottage. On our way over we stopped at a
small office to get the keys and the woman wished us a pleasant stay. With the
help of Google Maps we found the cottage and still managed to go the wrong way
a few times.

The cottage was beautiful and inside there was a photo how it was just after
the last hurricane a few years back. It told the story about the family living
there and how they couldn't afford to restore it. They had sold it to the
company we had rented it from and now they lived on the other side of the
island. "Don't be alarmed of one of them comes to visit. They just want to know
everything is okay. They are very welcoming and mean you no harm." the plaque
read.

"Wow," I said, "Don't know how I would feel if it had been me. I think I would
never come back here."

We unpacked and put the groceries away. I opened the door to the back patio and
took a deep breath. You could almost taste the salty air coming from the ocean.
It was so beautiful. Todd got out his camera and took a few photos of the
cottage and the view. "It will never be the same on a photo," he sighed. I
jumped into his arms and said "This is the best gift ever, thank you."

A few moments later Todd checked the grill outside and shouted "It uses wood.
We need to check where we can get some. And I saw some poles in the shed. Maybe
I could go fishing and we could have fresh fish."

"You? Going fishing? I have to see that to believe it." I laughed.

"Why not?" he said, "I loved fishing when I was little."

"Really? You never told me." I replied.

"Wait and see, young lady. You just wait and see."

The next day Todd wanted to explore the island a little and I just wanted to
lay in the sun. I was still a bit tired from the trip over and we decided to go
our own way for the morning. He would be back at noon and we would then see
what we were going to do for the rest of the day.

Todd got his camera, tripod and whatever else he wanted to bring and I waved as
he drove off to explore the island. He would also get some more groceries on
his way back. As soon as he left I changed into a bikini, grabbed a towel and
sunscreen and made my way over to the white sands of the beach.

I had been laying there for almost an hour when I heard a voice say "Excuse me.
Miss?" I looked up and a dark tall man was standing next to me. "Are you
allowed to be here? This is a private beach."

"Oh," I said, "we're renting that cottage over there. We were told we could use
the beach too." The man asked if I could proof it and after I did he apologized
and said "I'm just doing my job, Ma'am".

"It's okay," I replied, "we'll be here for the next two weeks. Just so you
know."

He tipped his hat and went on his way. I laid down on my towel again to soak in
the sun. The warmth of the sun, the sounds from the ocean and the birds almost
made me fall asleep. It all felt so peaceful and I really relaxed. After
turning over a couple of times I heard Todd say "So here you are. You really
need to come inside honey. Your skin is turning red."

For the next couple of days I had the most terrible sun burn and a woman a few
houses down the street handed me some local ointment that really helped. "Oh,
that's not okay, dear." is what she said when she saw me sitting in the
shadows. Her name was Madelaine, or Maddie to her friends. We just called her
Miss Maddie for the time we were there.

One evening we got a little too excited and I rode Todd right there on the
patio. If anyone walked by they could see us having sex. The fact that the
thrill of it would excite me that much surprised me and we did it a few times
more. Every time a little bit more in view and me being a little more naked.

During our last week we were sitting on the patio, the sun was high up in the
sky and it was just to warm to leave the shadows. The ceiling fan was blowing
on it's highest level and we both were wearing the bare minimum of clothing. I
went for a dip in the ocean a couple of times just to cool off a little.

The moment I got up to go for another dip Todd challenged me. "I bet you would
dare to go naked." he said with a smile. "What do I get if I did?" I replied.
Todd smiled and said "That necklace you saw the other day. The expensive one."

I thought for a moment, I really liked that necklace. As I turned towards him I
took of my top and pulled the strings of my panties. The moment the dropped to
the floor I ran towards the ocean. I breathed a sigh from relieve the moment I
hit the water, not only because it felt nice but also because nobody had seen
me. "Now I have to go back," I thought to myself and I felt a slight panic.

After a few waves had pulled me under I came up and looked at the cottage, I
checked if anybody was close enough to see me and as quick as I could I ran
towards the cottage. Once inside I grabbed my bikini, locked myself in the
bathroom and put it back on. With a huge smile I sat down next to Todd and said
"When are we going to get my necklace?"

Todd laughed and said "If I hadn't seen it with my own eyes, I would never have
believed you. We will get it tomorrow, okay?"

"Or just before we leave," I said and kissed him. As I was kissing him I got on
top of him, got out his cock and sat down on it. "Oh Todd, I love you so much."
I said as I slid over him. I was moving my hips when I felt someone was
watching us. I looked over my shoulders and sure enough there was a dark man
standing on the beach looking at us.

"Someone's enjoying what he sees," I whispered and rose up moving my hips.
Slowly I took off my top and stood up. I turned towards the stranger and sat
down on Todd again. This time the stranger slowly got closer and I pulled the
strings of my panties again. Throwing them to the side the moment they were
loose. I spread my legs a little wider and the man came a little closer. He now
could clearly see Todd's cock sliding in and out of me.

I stared into the stranger's eyes and kept on hopping on Todd's cock. The man
placed his hand on his crutch and I just kept staring at him. My breasts were
flapping as I went up and down. The man took another few steps towards us and
when he touched my breasts I couldn't help but moan. He squeezed them and
before I knew it I was pulling down his pants.

His giant cock popped up and I couldn't believe how big it was. I held it in my
hand and carefully started to jerk him. He moved in closer and I hesitantly
licked it a few times. I could hear Todd moan below me and I opened my mouth.
Todd lifted me up and got out from under me. I stood up and stared this
stranger in the eyes. I held his cock as I slowly moved towards the couch. Todd
sat down in a chair, jerking his cock. I looked at him and saw a huge smile on
his face.

I laid down on the couch, spread my legs and guided this strange big black cock
inside me. I moaned so hard as he entered me, he stretched me so far. I placed
my hands on his as and pulled him closer. "Oh yes," I moaned, "Fuck me. Give me
that cock. You're so big, yes." The man slowly pushed his dick inside me and I
felt him go inside me, deep inside me. It was like it would never end until I
felt his balls against my ass.

"Oh my god Todd, he is so deep inside me." I panted, "He's so big. Oh my god,
I'm coming already! I'm coming all over his dick." The man waited for me to
regain my wits before he started pumping. Slow at first, but harder and faster
as he went along. "Oh yes, fuck me. Fuck me hard. Make me come all over that
dick of yours. Please make me come." I shouted. Everything disappeared, the
only thing that existed for me was me and that man with his ginormous cock. He
slammed it inside me, he took no mercy any more. He kept on fucking me as I had
orgasm after orgasm. The only words he spoke was "I'm coming, almost there." I
urged him to come inside me, I wanted him to fill me up. Now I was realizing my
fantasy I wanted it all the way. Just as he wanted to pull out, I locked my
legs and with my hands I pulled him back in "No, come inside me. Come inside my
pussy!" I shouted. And as he exploded I couldn't help but scream "Oh Todd, he's
coming inside my pussy! Oh yes, he's filling my pussy with his cum." Another
orgasm rolled through my body and when I came to my senses again the man was
dressed, fist bumped Todd and walked away.

Todd walked over to me and planted his cock inside my cum filled pussy. The
moment I felt him inside me I had another orgasm. Just a few thrusts and Todd
added his cum to the strangers cum inside me. I had to rest for a few minutes
before I was able to move. I took a shower and cleaned myself. As I stood there
in the shower I could feel the cum drip out of me and I started to rub my clit.
I had another orgasm and decided to leave my pussy for what it was. I wanted to
feel that cum drip out of me for as long as possible.

When I returned to the living room Todd was grilling steaks and had set the
table. He smiled when he saw me and said "How do you feel now you've realized a
fantasy?" I just smiled and said "It was just wonderful. I mean it wasn't
organized, it just happened. That was the best part." I kissed him while I felt
the cum of both men drip down my leg.

A few days later we returned home from Barbados and told everybody how
beautiful and wonderful the island had been. We told them everything but what
had happened that day, that day was our little secret. I wouldn't be telling
the truth if I said I wasn't relieved when I got my period after that trip,
because I was. I was very relieved. But still that moment, that day is my best
memory about the trip.

## Becoming a hot wife
In the weeks and months after that trip my desire to repeat that day kept on
getting stronger. But I didn't know how to scratch that itch. I had to satisfy
myself with toys, but it just wasn't the same. As we both had promised to be
open and honest I told Todd how I felt and he smiled saying "I know honey, I
can see it."

One evening he got home and said "We're having a guest for diner tonight."
Behind him Marius entered the kitchen, a strong big African American man with a
very deep voice.

"Pleased to meet you, Ma'am. The name is Marius." he said.

"Oh," I blushed, "Please excuse me, I didn't expect guests. Laura, I'm Laura.
Welcome."

Marius talked with Todd for a while as I changed into something different. I
was wearing sweats when they came home and as I stood there in front of my
wardrobe I decided to wear something sexy. I did my makeup and hair before I
put on some nice heels. My full breasts were clearly visible and on a whim I
took of the panties I wore.

We had a wonderful dinner and sat down in the living room afterwards. I sat
down on the couch and Marius sat down next to me. I flirted with him a little
just to see how responsive he was. He checked Todd a few times and when he
didn't respond I leaned over a little making it possible for him to look down
my dress. Again he looked at Todd and I leaned forward a little more.

Just as we were about to kiss Todd got up and reached for his camera. I could
see the red light turn on and knew he was filming us. I leaned forward a little
more and kissed Marius. As soon as our lips touched I could feel him grab my
boobs and squeeze them. I stood up, took of my dress revealing my naked body. I
knelt down, undid his buckle and opened up his pants. Todd sat down next to us
and I stared into the camera as I went down on this big black cock. My mouth
hardly went open far enough but I managed to get it inside. I started sucking
that delicious cock and Marius started to moan a little. I felt myself getting
so wet, not only because I was sucking a cock in front of my husband but also
because he was filming me as I did it.

After a few minutes I couldn't take it anymore. I got up, straddled Marius and
guided his big fat cock inside me. His cock stretched me even more than that
stranger in Barbados and I moaned loudly. "Oh my god, it's so big!" and as soon
as I felt his balls I had to just sit there for a moment. "Oh my god!" I
shouted.

Slowly I started moving and stared Marius in his eyes. I leaned forward and
said "Promise me to come inside me. I want you to come deep inside my pussy."
When he nodded I kissed him pushing my tongue inside his mouth. "Now fuck me,
fuck me as hard as you can. I want to come all over that cock of yours. Fuck
this slut, this whore." We started moving together and as soon as he started
pumping I had an orgasm, one of many that evening.

After a few minutes he lifted me up and placed me on the diningroom table. I
spread my legs as wide as they would go and Marius started slamming my pussy,
with every thrust in looked like he went in deeper. "Oh yes," I screamed as
loud as I could, "Fuck me Marius, fuck me hard. Oh yes, I'm coming again. Oh my
god, this feels so good. Oh yes, fuck me with that big black cock!"

We fucked for almost half an hour before he groaned he was about to come. "oh
yes, give it to me! Come inside me. Give me that cum!" I shouted. I dug my
nails in his back when I felt him explode inside my pussy.

We had sex a few more times before it was time for Marius to go to his hotel. I
kissed him, put my dress back on, grabbed my purse and told Todd I would be
home in the morning. In the hotel Marius fucked my brains out, in the bed, on
the table, on the balcony and in the shower just before I went home. As I got
into the taxi I felt his cum drip down my leg and I smiled.

When I got home Todd had left for work and I called Marius. He was there half
an hour later and without saying a word he fucked me in the kitchen, the dining
room and in my marital bed. I just couldn't get enough of him, but above all I
knew I loved big black cocks.

That afternoon when Todd came home I was on top of Marius one last time before
he had to catch his flight home. Todd took out his cock and I sucked him while
Marius was slamming my pussy. For the millionth time he unloaded his cum inside
my cum hungry pussy.

Just a few days later I met a nice man in the supermarket and knew he was
checking me out. I walked up to him and whispered "Meet me at the back." I went
through the checkout and walked over to my car in the back of the store. A few
minutes later the man walked over. I gestured to get in and we drove to a
secluded area. I leaned forward, got his cock out and started sucking. After a
few minutes I got on top of him, got my breasts out and guided his cock inside
my wet pussy. I rode him until he unloaded, he really wanted to pull out but I
sat down on him and whispered "No, come inside me. I want that black cum. I am
a black cock whore and I need that cum inside me." Just as he exploded I felt
my orgasm coming up and kept on moving until I came too.

Almost a year later I called my husband. "Honey, don't wait up for me," I said,
"I've met a few guys and we're going to a motel. They offered 2000 dollars if I
had sex with them on camera. I agreed. It will take all weekend."

On camera the man behind it said "Look at who we met in the store today. She
didn't even hesitate to say yes. What's your name honey?"

"Laura," I replied, "Laura Davis and I'm doing this because I love black cock."

"Does your husband know you are here?"

"Yes, he does."

A large man placed his cock near my mouth and I looked into the camera as I
said "Honey, this is for you." I started sucking it and another man started
rubbing my clit. I spread my legs and felt his fingers slide inside me. It
didn't take long for me to be naked and the first cock to enter me. "Oh, she
likes it bareback." the cameraman said and I just giggled as I took out the
cock from my mouth. "Not only bareback," I said, "I want them all to come
inside me. I'm not on the pill anymore, I haven't been for months."

"Oh you want that black baby?"

I nodded "Yes, I want that black baby. I want it so much."

Just as I was being fucked and was sucking another cock, twelve more men
entered the motel room. I thought I went crazy after a few hours, I had come
some many times and now a big black cock was pushing against my asshole. It was
all lubed up and as soon as I relaxed it just slid inside me. "Oh my god," I
yelled, "It's so big." I started hopping up and down, the big dick slid in and
out of my ass. Before I realized what was happening another man came on op of
me and slid his cock in my pussy. I was being double penetrated and the camera
was still rolling. Both men came simultaneously and filled my ass and pussy
with cum.

A knock on the door announced take out being delivered and as a tip I sucked
the boys cock as I was getting fucked by one of the men there. We sat down for
dinner and I got a chance to catch my breath. Right after dinner I straddled
the cameraman and rode him until he came too. One of the men lifted me up right
after my pussy was filled once more, laid me on the table and took what was his
for the night.

Later that night I fell asleep with one cock in my pussy and another one in my
ass. The following morning I woke up being fucked by one of them and I just
spread my legs and encouraged him to fuck me. The camera started rolling again
and I had a huge orgasm, for the first time in my life I squirted.

We went to get some groceries a few hours later and as soon as the camera
started recording I knelt down and started sucking a cock right there in the
store. I leaned forward and the man lifted my dress. I bit my lips as soon as
he entered my pussy. I was being fucked right there in public and I just didn't
care.

Later that afternoon we arrived back in the motel room. There was a new bunch
of men waiting for me. "But we have a little surprise, don't we Laura?" I
nodded and took of my dress. Right there on my belly was a tattoo. "Only for
blacks!" it said and there was an arrow pointing to my pussy.

"I've made it official," I said into the camera, "I'm a black cock whore. And I
will only fuck black cock. Not even my husband gets to fuck me anymore. Only
black cock and I will never take the pill again. Every black man who wants to
fuck me, can. No questions asked, no introduction required. I'm a whore now and
I love it."

One of the men walked up to me, got his cock out and I spread my legs. Without
saying a word he slipped inside me and I just groaned "Oh yes, fuck me with
that big black dick. Oh yes, yes, I just can't get fucked enough."

Days later I gathered my clothes and left Todd forever. I didn't even leave a
note. I moved in with the cameraman and became one of his whores. On my back
there was a new tattoo "Property of TenCents." I got pregnant 5 times of men
who I don't know and gave birth to three of them. I never took the pill again
and loved to have sex while I was high on crystal meth. 
