# Chapter One
Growing up as a single child my parents worked hard to give me everything I
needed. My mother was a cleaner in the local hospital, my father did
construction. We lived in a small house and although they did their best not to
show me I knew they were struggling. At a very young age I decided that would
never happen to me. From the age of 16 I was expected to work too and I got a
job at the local groceries store. Every day I worked for four hours at that
store and all during the weekend.

Me starting to work gave my parents some relieve. I felt proud I finally was
able to help them out. Due to the store going bankrupt I lost my job and it was
hard finding a new one. It took me some weeks to start working in a small
clothes store at the strip mall a few blocks from our house. The store was
specialized in female fashion and I felt happy working there.

One Saturday I was walking to work as it was a beautiful day and my father's
truck had broken down. It was still early as I made my way over to the strip
mall. A few blocks from my house I saw some girls parading the street, they
were wearing very tight tank tops and the shortest skirts I had ever seen. As I
passed by them I wondered how they could walk on those high heels.

The street was still long and there were no side streets for several hundreds
of yards. I looked down, paying no attention to the girls standing there. A car
pulled over to my right and kept the same pace as me. The man rolled down his
window and whistled to me. "Hey girl," he shouted, "you new here? How much?" I
kept on walking, my eyes glued to the pavement. "Hey? You deaf?" he shouted
above the beats coming from his car, "I asked you a question. You can at least
pay me the courtesy of answering it. How much?" he shouted again.

"Leave me alone," I said, "I'm on my way to work."

"Oh, she can speak," he replied, "on your way to work, are you? Well, how much
do you make an hour? Six dollars? Seven maybe? I will give you 50 dollars if
you suck my dick." I was shocked by what he said and started walking faster.
Just another hundred yards to go before I could turn left into the strip mall
into safety. The man adjusted the speed of the car and said "What you say? 50
dollars for a blow job. Easiest money you'll ever make."

A panic slowly took hold of me and I picked up the pace a little more. Waiting
for the moment I could turn left. The man sped up too. From the corner of my
eyes I could see him switching from looking in front of him to me. As he was
driving on the wrong side of the road he had to be careful nobody was coming
towards him. With a short "Bitch!" he returned to the right side of the road
and I was relieved to see a police car driving towards us. I sped up some more
and almost ran when I could turn left. The moment I entered the store I had to
catch my breath.

"What happened?" Miss Joyce asked me. I told her what had happened and she
replied "Next time call me and I will pick you up. Tonight I will bring you
home and never, ever are you going to walk through that street on your own
again. You hear me?" I just nodded and said "It was just such a beautiful
morning, Miss Joyce. I didn't know about that street, I never was there that
early in the morning."

The rest of the day was rather uneventful and when it was time to close Miss
Joyce dropped me off. I thanked her for doing so as it was way out of her way.
My mother waved when she saw me get out of the car, my dad was underneath his
car doing something to repair his car. I kicked his feet and said "Hey dad." He
crawled from underneath the car "Oh hey kitten. How was work today?"

"It was okay, rather quiet." I replied. I handed him the check Miss Joyce had
given me. "For the groceries this week," I said as I handed it to him. He
looked at it, got up and said "No, not this one. You worked hard for it, do
something nice for a change. This one is yours to keep."

"Are you sure?" I asked him, he just nodded. I jumped for joy as I had seen a
nice dress in the store I really liked. I looked at my mother who was watching
through the window, she was smiling and nodded. I ran inside and hugged her.
"Mom, now I can buy that dress I wanted. Is it okay to go buy it tomorrow?" My
mother smiled and said it was okay.

"You've earned it," she replied, "You've been such a good girl and we thought
you deserved something in return." She dried her hands and hugged me. Being so
happy with the surprise I had totally forgotten about the incident from that
morning. I ran upstairs and placed the check somewhere safe.

The next morning I got up early to go running as I did almost every Sunday
morning before we went to church. Normally I would turn right to jog through
the park, this time I went left. I just wanted to change it up a little, I
thought. Ten minutes later I was near that street again. In the distance I saw
those girls again, in their tight clothes and very short skirts. From a
distance I watched them bending over to talk to the men in the cars stopping in
front of them.

I was wondering what it would be like doing that. Wearing those clothes in high
heels, getting into a strangers car to go do whatever they were going to do.
All kinds of fantasies went through my head and I couldn't stop watching them.
After almost ten minutes I shook my head and slipped away. I ran as fast as I
could back home, all the time thinking about what I had seen and imagining
myself standing there.

That afternoon my mother and I went to the store to get that dress I wanted. We
went to get some ice-cream afterwards and had a wonderful time. "We should do
this more often," my mother said, "I love this mother-daughter time." I nodded
as I drank my coke that I had ordered with the ice-cream. We chatted about
nothing in particular. When a boy entered the parlor my mother noticed I was
checking him out and asked "What grade would you give him?" I was stunned by
her question.

"Mom!" I whispered. My mother laughed and said "No seriously, I would like to
know what kind of boys you like. I would grade boys on a scale to 10 when I was
your age. So why not?" she whispered back. I just stared at her and softly
replied with "An 8?"

My mother burst into laughter and said "An eight? That high? Wow!" I started
laughing too and from that point we started grading more boys. "What would dad
say if he knew you were looking at other men?" I asked her. My mother looked at
me and replied "Oh, he doesn't have a problem as long as it stays at looking.
And he has eyes too, you know? As long as we don't act upon it, it's all okay.
I can't ask of him to close his eyes when he's not at home, now can I?"

I laughed again "I suppose you're right. Can we do this again someday? I like
this a lot and we don't get many opportunities to do this." My mother nodded
"Yes, I would like that very much. But sometimes I just need to work, you know
we need the money. This time we could afford it because dad got a bonus at
work." She went through my hair with her hand and said "We wished we could give
you more than we can. I feel so guilty at times, I hope you understand."

I told her I did and we went back home. My father was mowing the front lawn and
waved as we drove up. A few minutes later I showed him my new dress and skipped
back inside. My mother had made some fresh lemonade that morning and was
pouring three glasses. We sat down in the back yard enjoying the rest of the
day.

A few weeks later my parents told me they had to go away for a weekend. "Now we
are going to trust you," they said, "No party, no strangers in the house. We
will inform the neighbors that you're home alone so they can keep an eye on
you. If you do anything to break our trust we will come back as fast as we can.
You understand?" I nodded and although I felt a little anxious to be alone for
a weekend I also was looking forward to it.

"We will be back on Sunday," my mother said as they got ready to get in the
car. She hugged me while she said "There's enough food in the fridge and you
could invite Melissa over if you want to. Remember to call the neighbors if you
need anything." I kissed her saying "I will be okay mom. Thank you for trusting
me." A few minutes later I waved as they drove off. The silence off the house
felt strange at first so I turned on the TV.

To make it easier for me my parents had arranged for me to borrow one of the
neighbors cars for the weekend. But as a 16 year old being home alone for the
first time and having a car available to me made me feel like an adult. As I
sat there on the couch I felt a little bored and decided to go to the mall
instead. Half an hour later I parked near the entrance and went inside. I had
no intention on buying anything, I just wanted to be out of the house for a
while.

On the first floor of the mall I passed by a large clothing store and couldn't
help to go inside. I looked at dresses, jeans and all kinds of shirts. After
browsing for a while I came across some short mini skirts that were on sale.
Immediately my thoughts went back to those girls and my heart started beating
faster. I grabbed two of them, one bright pink and a fiery red one. I also got
myself three very tight tank tops and a very short bolero jacket. With my heart
beating in my throat I tried them on and checked myself in the mirror. I pulled
my hair back and checked myself from every angle, it looked nice on me I
thought and only minutes later I left the store with a bag on my arm.

I proceeded to look at shop windows for a while before I saw a sign outside a
shoe store stating they were going out of business. It was very busy inside and
to my surprise I was able to buy two pairs of high heels for a total of 15
dollars. One black pair with an 8 inch heel and one silver with a 14 inch heel
and a very thick sole. With all my new acquirement's I left the mall and drove
back home only stopping at the drive-thru for a burger and fries.

After finishing my meal I checked if every window was closed and all the doors
were locked, before I proceeded to go upstairs. I tried on my new clothes, did
my makeup and hair and put on the 8 inch heels. At first I was very wobbly on
my feet, I hardly ever wore heels let alone ones that were this high. I took a
few steps across my room until I was confident enough to do some more and I
walked outside towards the stairs. I kept on walking back and forth until I
felt more comfortable in these heels.

Back in my room I tried on the silver ones and started walking again. This time
it was a little easier and soon enough I found how to walk in such high heels.
I looked at myself in the mirror again and acted like I was standing on the
corner of a street.

"Hey honey," I whispered, "what you looking for? -- Oh, that would be 50
dollars. -- If you want the full *treatment* that would be 150. -- No sugar, I
only use protection. -- Okay, then --" I mimed I was opening a door and getting
into a car. I laughed and stared at myself in the mirror again. "No, I
couldn't" I said to myself, "Don't even think about it." I turned around and
walked towards the stairs, stopping in front of it and looking down at all
those steps. Carefully I took the first step down, holding on tightly to the
banister. I took a deep breath and stepped down another one and then another
until I reached the floor.

The clacking sound of my shoes on the hard wood floor sounded like music in my
ears. Again I acted like I was walking the street and pushed my breasts a
little forward. In the end I was walking up and down the living room, my hips
swaying and giggling as I did it. After about half an hour my feet started to
hurt and I didn't know how these girls could walk in them for as long as they
did. Back in my room I undressed, took a shower and got ready for bed as I had
to work the following morning.

My alarm clock woke me up, I showered, did my hair and makeup, ate breakfast
and went to work. On my way over there I saw just one girl there, she was being
arrested by the police and I felt so sorry for her. When I walked in the store
Miss Joyce told me all the shops in the strip mall had complained about the
girls and the police had taken action to stop them from being there.

Even though I fully understood why I also felt a little disappointed somehow.
All day long I wondered where those girls would go next and when I got off work
that afternoon I decided to look it up. It didn't take me long to find a news
article telling me this action only made the problem move to another street,
according to the journalist 64th street would now be a popular location for
them, a street at the other side of town.

As it was only 4 PM when I got home I decided to wear the clothes I got the day
before again, this time I wore the black heels. I wanted to wear them as long
as I could, I wanted to learn to walk in them for an extended period of time.
Even though it started to hurt after half an hour I pressed on until the pain
subsided a little. A few hours later it even felt rather comfortable. With a
pounding heart I got in the car and drove to another drive-thru. I was still
wearing the same outfit and when the boy in the window handed me my food I bent
over a little so he could clearly see my cleavage. I smiled as I handed him the
money and waved as I drove off. Giggling all the way home.

The next morning I woke up early and I had a few hours to spare before church.
After showering I put on the fiery red mini skirt and another tight tank top.
Completing my look with the bolero and the silver heels. I did my hair and
makeup before checking myself in the mirror once more. This time I went
downstairs again, got myself something to eat and on a whim I grabbed my purse,
got in the car and drove off. It was only 6:30 and to my surprise there were
still a few girls on the street where the police had arrested them the day
before.

I parked the car and just stared at them. The all walked up and down the same
few yards as if they all had their own little territory. I started the car
again and drove a few hundred yards to the other end of the street. I was far
enough away from the other girls I thought and with my heart beating in my
throat I got out of the car and crossed the street to be at the same side as
the other girls. My heart was throbbing as I started parading 5 yards down and
back again for almost 10 minutes. Every second scanning the road for oncoming
cars, every time one did my heart skipped a beat. It was even more scary when
one of them slowed down, clearly checking me out. I sighed a breath of relieve
when it sped up again.

I paraded the 5 yards up and down for quite some time. The more cars passed by
the more confident I got. In the end I even stared at them and stopped to pose
for them as they stared at me. I arced my back to make my breasts more
prominent and smiled. Every time they sped up again and I giggled. The longer I
was there the more exciting it became to me.

The moment I got back into the car and drove away I felt such a relieve and I
started giggling uncontrollably. It took me a few minutes before I was able to
start the car and drive home. I had to hurry to get ready for church and parked
the car close enough so the neighbors couldn't see me as I got out. I hurried
inside and got ready for church. When I was done the contrast couldn't have
been bigger, just half an hour ago I was dressed as a slut now I was the
conservative 16-year old again. Wearing a closed off dress and flat shoes. I
had put my hair in a bun on the back of my head and instead of my contacts I
wore my old glasses again and no makeup.

I got in the car again, waved to the neighbor as I drove off to church. The
pastor preached about the girls that were removed from the street I had paraded
just an hour or two earlier. I held a straight face but inside I said to myself
"If only these people knew." A few hours later I arrived home again and called
my parents to ask them when they would be home.

"Why?" my mother asked.

"Oh, just wondering if you will be home for dinner," I lied a little.

"No darling," she replied, "We will be home rather late. Aunt Lucy isn't doing
so well and we need to be in the hospital until Rose arrives and her flight
doesn't arrive until 5. If we leave at, lets say, six we should be home around
9 PM. Are you okay for another day?"

"Yes," I replied, "No problem. I need to do my homework and I might invite
Daisy over. Is that okay?"

"Sure honey," my mother replied, "Well, I got to go. Dad is pushing me to get
into the car. Talk to you later sweetie. Bye."

I put down my phone and smiled. I went back upstairs, changed into my slut
outfit again and wore it for the rest of the day. At one point I even removed
my underwear to make it a little more exciting for me. Around 4 in the
afternoon I ordered in and with my heart pounding I opened the door wearing
only the tank top and mini skirt. The boy who delivered the food was pleasantly
surprised by my outfit and I arced my back a little more. I leaned against the
door as he handed me my food, I told him to wait so I could get my purse. As I
walked away I swayed my hips a little more than I normally would do and made my
breasts bounce as I walked back.

His eyes were glued to my bouncing rack and I smiled as I handed him the money.
His face turned red a little when I bent over to pick up a note that I had
*accidentally* dropped. He got a clear view of my cleavage as I did so. During
this interaction I felt myself getting rather moist between my legs. When he
had handed me the change I gracefully closed the door, walked back to the
kitchen and started laughing. Being so overtly sexual felt so exciting to me
and I loved it.

Around eight that evening I changed into my sweats and put the slutty clothes
into a box containing some childhood memories and placed it in the back of my
closet again. Just in time I sat down on the couch and was watching TV when my
parents got home. My mother hugged me and my father asked for the keys so he
could return the neighbors car. "How was it?" My mother asked, "Did you go to
church?"

"Yes mom, I did go to church and it was nice. But I am so happy you are home
again." I replied. We talked for a while and told me Aunt Lucy wasn't doing
well and that she didn't expect for it to last much longer. Tears welled up in
my eyes and although I didn't have much contact with my great-aunt I felt sorry
for my father, she was his Aunt and the last sibling of his mother. My
grandmother had passed away a few years earlier and my father was devastated
when his mother died. My grandfather was still alive and well, but still.

As soon as my father walked in again I ran to him and hugged him. "I am so
sorry dad," I whispered. He put his arms around me and said "She's still with
us, sugar. She's still with us." I held him tight and whispered "I am glad
you're home."

A few weeks later we attended the funeral of Aunt Lucy. My father was so sad,
but he didn't cry. He said he knew she was in a better place and with his
mother in heaven. "I bet Aunt Lucy is telling God what to do." he said with a
little smile. I softly giggled as it would have been typical for Aunt Lucy to
do so. Rose, my fathers youngest sister, sat down next to me for the ceremony
and held my hand. I could see she was holding back her tears. Aunt Lucy had
passed away in her arms. "I was so happy to be there for her," she told me
later.

It was a beautiful service and we spent the rest of the day at Aunt Lucy's so
everybody who wanted to could attend after the funeral. It was quite busy in
the old house and I walked around for a while. My mother sat on a couch with
some of the other women there and smiled at me when she saw me. She gestured
for me to come closer and said "Why don't you go upstairs and look if there's
anything you want to keep to remember Aunt Lucy. Rose can help you if you want
to." I looked over to Rose and she got up immediately.

We went upstairs and to get it over with we started with the bedroom where Aunt
Lucy had spent her final hours. I looked around for a while and Rose said
"Don't you love the vanity? Aunt Lucy left it to me." I nodded and looked
around some more. "Why don't you check the other rooms?" Rose suggested, "I
will look around here some more. This is all old woman stuff. I believe she
kept some things from when she was young in the other rooms."

I went from room to room and in the last one I found an old trunk. After I
opened it I saw a box and got it out. In the box were some old photographs.
"St.Louis 1946" I said on the back. It was a photo of Aunt Lucy when she was
around my age, 16 or 17. She wore a bathing suit and was leaning against a
tree. Another photo clearly was taken a few moments later and on this one she
was topless, the next photo showed her completely naked. I got some more photos
from the box and they all were studio photos of her posing either topless or
naked.

Underneath all the photos were magazines like Esquire and others. I browsed
through them and gasped when I saw Aunt Lucy in them, she was a pinup girl back
then. And although she wore a bathing suit in all of them, they all were rather
provocative for the time. The last one was a magazine called *Teens* and in it
was a photo of Aunt Lucy laying naked on a couch, smiling as she was looking
straight at you. I put everything back in the box and took out what was
underneath the box. There they were, the old bathing suits Aunt Lucy had worn
in the photos. I felt the urge to try one on and I hurried into the bathroom.
After locking the door I undressed and tried one on. To my utter surprise it
fit and felt very comfortable. I tried to check myself as best I could in the
mirror but it was mounted just a little to high.

Quickly I got dressed again and hurried back into the room. I put everything
back into the trunk and checked some of the wardrobes in the room. They were
filled with clothes, shoes and jackets. I tried some of them and almost all of
them fit me nicely. I put on a very nice dress I found, completed it with one
of the long coats and shoes I found and walked towards Rose.

"What do you think?" I said as I showed off the outfit.

"Wow," Rose said, "Did she really keep all her old clothes. They look as if
they were new." I smiled and Rose told me to sit down at the vanity. Rose was
a hairdresser and started combing my hair. Half an hour later she had created a
period appropriate hairstyle and did my makeup like the girls would have done
back then. "Let's go downstairs," she said, "I think everybody should see
this." I clapped my hands and together we went down again.

The people who saw me appear gasped and my mother almost started to cry. My
father almost got a heart attack and said "Wow, you look just like her when she
was your age. My God you almost look the same." I smiled and thanked him. I
turned to my mother and said "I love these clothes, can I have them? Please?
They are so beautiful, Rose can teach me how to do my hair, can't you? Please?"

My mother looked at my father who said "Well, we were going to take them to the
thrift store anyway, why not make our daughter happy?" My mother sighed and
said "You can't take everything, okay? Just choose the ones you really like and
will will donate the rest."

"Oh no," I replied, "We will take it all. I can sell what I don't like online,
this is vintage mom. Some of these could be worth a lot." Rose and my father
talked for a while as they were the only two heirs to Aunt Lucy's estate. After
a few minutes Rose turned to me and said "Because you love it so much you can
have all the clothes, shoes, jewelry and stuff. But I get her wedding dress,
okay? I always wanted to get married in it, every since I was your age."

I agreed and the next few days we spent packing the clothes I wanted to take
home and donating everything that was left. In the end we had so much left my
father had to rent a trailer to get it all home. My father and I drove home a
week later, my mother stayed behind to finalize the selling of the house. The
inheritance provided my parent with something to fall back onto and they put
all the money into the bank.

My mother cleared one of the rooms for all the clothes we had brought home so I
could sort them all. For the next few weeks I was busy sorting all of them and
we got an account on e-bay in my mothers name. Everything I wanted to sell we
photographed with me as a model showing them. Some of them were sold for as
little as 10 dollars, but one of the coats was sold for almost 300. The furs we
donated to good will as neither I nor my mother wanted to sell them.

It took us weeks if not months to sell everything I wanted to sell, leaving me
with just a select few of the clothes. Still it filled a complete wardrobe. One
thing I also kept was the contents of the trunk and the trunk itself. My mother
never questioned it. But as I was sorting the clothes back in Aunt Lucy's house
I had also added 18 corsets, old stockings and some of the heels I had found.
In short that trunk contained almost everything of her old pinup days.

As far as I knew I was the only one left who knew about this part of her life
and I smiled every time I held one of them in my hands. After almost half a
year of searching online I found a picture of her holding an umbrella wearing a
corset: *Miss Daisy* it said underneath it and a short story about her.

> Miss Daisy was born in Virginia and is 18 years old. She loves milking cows
> and cooking dinner. She hopes to be a wife and a mother soon. Her brother
> died on D-day as our troops landed on the French coastlines.

"She looks so beautiful," I thought to myself and looked at the same corset
laying on my bed next to me. I got up, undressed and put the corset on. As it
was laced on the back I couldn't tighten it and because my parents were home I
really didn't want to either.

"Ana?" my mother shouted from downstairs, "Can you come down for a minute?"

As quick as I could I got into my own clothes again, hiding the corset in my
closet. I ran down the stairs to find my parents in the living room. My father
started talking. "Ana, we are so proud of you. You never complained when you
had to start working and you even handed your checks so we could get groceries.
We love you so much that we thought we wanted to surprise you. Go outside and
see what we got for you."

Anxiously I walked outside to find a car in the driveway. This wasn't my
fathers car, this was a small red one and in total disbelieve I turned to my
parents who had followed me outside. My father held up the keys and said "It's
yours. And we opened a bank account in your name with all the money you made
from the clothes. Now all the money you earn can be deposited in your own
account. The insurance is in our name and we will pay the taxes. The rest is on
you."

Even though the car was second hand I loved it so much. I jumped for joy and
into my parents arms unable to speak. "We finally found a way to shut her up,"
my father laughed. Together with my mother I took it out for a spin around the
block and just was so happy. "We turned in Aunt Lucy's car for this one," my
mother told me as we drove, "Rose thought you might like a car of your own and
we agreed."

"Thank you Aunt Lucy, thank you Rose," I yelled and hopped in my seat after I
had parked it in our driveway again. My father still stood there with a huge
smile on his face. When we sat down at the kitchen table my father told me all
about the bank account. "Now, we have total access to everything until you are
eighteen. Now let me be clear, it's your money and you can spend it how you
like it. But we will keep an eye on it, okay?" I nodded and proudly stared at
the debit card I had in my hands. "Miss Ana Davis" it said.

"I have my own checking account!" I thought to myself and felt like a true
adult. "And I've got my own car!" I thought right after. After dinner that
night I drove to my friend's house. Melissa ran out the door when she saw it
was me parking on their driveway. "What?" she shouted, "You got a car?" I just
nodded and we jumped for joy. "Mom can Ana and I drive for a while?" Melissa
said after she ran inside. Her mother smiled and nodded "Just be careful." she
shouted after us.

We drove around for a while, chatting about the car and I told her all about
the clothes I had kept from Aunt Lucy. "You should see them," I said, "they are
so beautiful." Melissa said she wanted to and half an hour later I dropped her
off at her house. Her mother invited me in "Oh no, it's almost 9 and I have to
go home. My parents will be wondering where I am by now." and I drove off.

A few weeks later my parents decided they wanted to go away for a long weekend,
because I had finals the following week I stayed home to study. They left early
that Friday, right after I got home from school. I spent all of that afternoon
and evening studying for the test I had on Monday so I could do other things
for the rest of the weekend, plus I had to work the next day.

My alarm clock woke me up at 5 AM and I got up to take a shower. I opened the
box with my slutty clothes and got them out. It was just after 6 when I got in
my car and drove to the other side of town. It took me some time to find the
right street and parked nearby. I took off the shoes I was wearing and put on
the heels. I checked my face in the rear view mirror and stepped out.

After almost 60 yards I crossed the street and stood there for a while. One of
the girls a few yards from me threw me a dirty look, but said nothing. It
didn't take long for a car to stop in front of me, the driver leaned over and
lowered the window. With my heart beating in my throat I leaned over, my
cleavage clearly showing. "How much?" the man asked me. I looked at him and
smiled "50 for a blow job." "What?" he replied astonished, "No way, that's way
too much." He waved me away and I went back to my spot on the sidewalk.

He stopped at the girl next to me and I caught what she said "20 for a blow job
and I will rock your world for 60." She threw me a dirty smile as she got into
his car and I watched them drive off. I had never intended to follow through
with any of it, just being there, dressed the way I was was enough for me. I
loved the thrill of it, the risk of getting caught by the police. Another car
stopped in front of me, this time it was an older man. He smelled awful and his
car was a total dump.

I put up my smile once more and leaned over into his opened window. I made sure
he could see down my top and told him I wanted 70 dollars for a blow job. To my
surprise he agreed and now I had no way out of this. With my heart beating out
of my chest I stepped into his car. He handed me 70 dollars when we arrived at
a out of sight spot a few blocks away. He opened his trousers and I leaned down
slowly. With a trembling hand I took hold of his penis and felt it harden in
it. With my tongue I touched him a few times before I opened my mouth. I sucked
him and felt his arm resting on my back.

Even though he smelled awe full I noticed I liked sucking his dick. I started
moaning a little, especially when he said "yeah, suck it you little whore."
After just a few minutes he came all over my face, feeling his cum landing on
my cheeks excited me even more. With a tissue I cleaned myself while he drove
me back to the street where he had picked me up. As soon as he drove off I
rushed back to the car, not believing what I had just done. As soon as I sat
down I checked my purse and started at the money inside it. I had made 70
dollars just by sucking some dude's dick.

I got the money out of my purse and put it in my glove compartment. I looked
outside and before I knew it I was back on that side of the street again. This
time I had taken off the bolero. It didn't take long for another car to stop
and ask me how much it was. This time I said "30 for a blow job and I will rock
your world for a hundred." The man told me to get in and when we arrived in a
spot where nobody could see us he handed me a hundred dollar bill. After I put
the money in my purse, he pulled down his pants and I sucked him until he was
hard and got on top of him. I slid my panties to the side and guided him inside
me. He pulled down my tank top exposing my triple-D breasts to him.

I started to bounce up and down, he buried his face in between my boobs. I
started to moan as I felt this stranger slide in and out of me. After just a
few bounces I panted "Oh I'm coming, I'm coming all over that dick of yours. Oh
yes, yes. I'm coming." Just moments after I felt him twitch and throb inside
me. He was moaning loud "Oh my, almost there."

Without thinking I panted "Come inside me. Fill me up with your cum." The man
stared into my eyes and I repeated "Yes, come inside me." He groaned loudly as
he exploded inside me, I pressed down as hard as I could making him go as deep
as he could. I felt his cum entering me "Oh my God, I'm coming again." I
pressed my boobs against his face as I came.

On the way back to the street he said "You really did rock my world." I smiled
and got out of the car. Before I did I placed my hand on his cheek and said
"Maybe we can do this again someday." He just nodded and drove off as soon as I
closed the door. Feeling his cum dripping out of me I got back into my car and
drove home. I couldn't believe what I had just done. Not only had I sucked some
weird dude, I had sex with another one. I sat down on my bed holding the money
I had earned. I looked at the clock and it was just 8 AM. I hadn't made this
much money ever.

The next morning I got up a little earlier and it was just 5 AM when I arrived
back at 64th street. This time I had brought condoms with me. I took off my
panties and put on my heels again. Minutes later I was at that corner of the
street again. This time I waved to the cars stopping near me and after a few
denied my services I got into another car. In a different spot this time I got
on top of the stranger again, guiding his cock inside my wet pussy. This time
he wore a condom and I pulled down my top myself. I had sex with seven clients
wearing protection, the seventh offered me 200 to have sex without. During the
time we had sex he offered me 100 more if he could come inside me. I agreed and
he handed me another 100 dollar bill. I rode him until he came and as he did I
came too. Feeling his cock throb inside me as he came threw me over the edge.

In church that Sunday I smiled like the innocent girl they all thought me to
be as the strangers cum dripped out of pussy. Intentionally I didn't clean
myself and feeling that dry cum on my thighs while I kissed the pastor as I was
leaving the church was another thing that excited me. "If they only knew," was
all I could think about.

I passed my finals with flying colors and during the Summer break I stopped
working for Miss Joyce as she had decided to retire. I was offered another job
at the flower shop next door, but that was just for a few hours a week. I was
looking for a full time job for during the break. "Well," I said after spending
a day searching, "I found one but I don't know what to do. They insist on
paying me in cash only and I have to start at 5 AM every morning, including the
weekends. On Sunday I om off at 9 so I can go to church."

My mother looked worried and said "Oh, I don't know Ana. I don't think we could
trust them."

"But they offer a lot of money if I work there." I replied.

"And what are you supposed to do?"

"Some administrative work, but mostly deliveries." I lied. I was amazed by how
easy it was for me to lie to my parents.

"And it's only for the Summer break?" my mother asked.

I nodded and said "Yes, when I go to school again I can start working at the
flower shop." At least that part was true, Cindy had told me as much.

"Well, okay then. But you have to promise me you will quit the moment you don't
trust it anymore."

I nodded and said "I will call them right now and tell them I can start
tomorrow." I got up and went to my room. Reached for my phone and acted like I
was calling someone just in case.

The next morning my alarm clock went off at 4 AM. I got up showered, got
dressed and put everything I needed into a bag. My mother was sitting at the
kitchen table when I got down. She had made me some breakfast and I sat down
until it was time to go. I kissed her, grabbed my bag and drove off.

It was 5:15 when I stood at that corner again. When the clock stuck 9 I had
*serviced* 10 clients, two of them had offered me money to come inside me. With
their cum dripping out of me I spent the rest of the time wandering the mall
nearby until it was time to go home again. It was almost 2 PM when I got home,
the dried cum covering my thighs.

I told my mother I wanted to shower and got into some comfortable clothes
before I went downstairs again. My mother asked me how my job was and I told
her I had to deliver small packages and how I drove all around town in one of
their delivery vans.

For the next few weeks I could be found on that street every morning and I got
myself some sexier clothes to wear and more heels. The rest of the money I put
in my account, spreading it equally over the days. I had told my parents I was
payed according to the amount of deliveries and that's why the amounts differ
from day to day.

When I went back to school I was a full blown hooker and had had sex with more
than a hundred different guys. I had a few returning customers, but not many
and none of them knew I was underage at the time. If they asked I told them I
was 18 and not a single one of them asked me for an ID.

By the time I graduated and went to college I felt lucky I hadn't been arrested
once, even though I got close a few times. Rose had offered to rent me a small
apartment near my college, she knew the Realtor she said. I moved in a few
weeks later with all the clothes Aunt Lucy had left me.

I explored the new town for a while and got a job at a *social club*, a
euphemism for what really was going on behind closed doors. I started out as a
serving girl and we walked around topless. For tips guests were allowed to
touch us and for an even bigger tip I allowed them to suck my triple-D breasts.

Soon enough I got a promotion to *socialite* and I kept our male guests company
for the time they were with us. Sometimes going to one of the backrooms for a
more *private* session.

One night while I was working two African American males entered and they chose
me to accompany them. In one of the booths they sat on either side of me and we
chatted about anything. Their hands went all over my body, finally resting at
my boobs. "We can go somewhere more *private*," I whispered. Not long after we
walked into one of the empty rooms. I crawled sensually on to the bed and
watched them undress. They laid down on either side of me and I took both their
big cocks in my hands.

They both sucked my breasts and after a few minutes I sat down on one of them.
"Oh my God, you are so big" I panted as his cock stretched my pussy. I rode
him for a while, when the other one suddenly placed his cock against my
asshole. I looked backwards and panted "That's another 200 dollars." He agreed
and pushed his cock inside my ass. I was getting double penetrated by two huge
big black cocks. I could help but scream as an orgasm rolled through my body.

The fucked me hard and long, I came multiple times and when the unloaded all
over my body I came once more. Totally  
