# Starting Over Again
_an erotic tale by TransGirl_

## Chapter one
My mother had warned me, but I just was too stubborn to listen to her. Now I
had to admit she was right, we did get married way too young. The marriage
lasted for just two years and now here I was 20 years old, recently divorced
and working a mediocre job. The apartment I rented was just a one bedroom
because I couldn't afford anything else. The walls were paper thin and
sometimes I could hear the neighbors talk, so I made sure I always had the
radio or TV on to suppress the sounds coming from the other apartments.

The neighborhood didn't give me any sense of safety, so I stayed in almost
every night. Which I wasn't used to, I was used to go out and visit friends or
family, something I hadn't done since I was forced to move there. In the
mornings I rushed to my car just to get out of there. My job started early in
the morning while it was still dark outside. At least I came home in the
afternoon when it felt relatively safe.

I needed to find me another job, one that paid more so I could get out of there
and move into a better apartment, a nicer neighborhood. But finding something
with just a high school diploma wasn't easy and I couldn't afford to go to
college although I really would have liked to go. During one of my many job
hunts on the internet I came across a site for lonely people and I sure was one
of them. As I stated I was young when I got married and had never lived on my
own before. Because I was to afraid to go out at night or to use one of those
dating apps, there was no way for me to meet someone. This all resulted in my
world getting smaller by the day.

The friends we had all were more his than mine. We had met when someone he knew
invited me to a party and as I was new in town I had been eager to go. We
started dating and just after graduation he asked me to marry him. Now that we
were divorced the people who said they would stay in contact never did and I
didn't have any friends left. So I registered an account on the site and
started chatting with people from all around the world. I started visiting the
site every night and soon enough some of them had become friends.

I had contact with one of them way more than anyone else on the site, she
called herself _Jaz208213_, Jaz for short. I still to this day do not know
whether that was her real name or not, but I didn't care she was one of the
people on the site I could really talk to, to whom I felt like I could really
open up. Maybe the anonymity was a major part of it, but it did feel safe for
me and I told them things I hadn't told anyone in my life.

"It's just that I don't think I know myself. I never have been on my own
before. I've never explored so to say, I got married right after high school. I
became the girl he wanted me to be, that's what broke us up in the end. I had
become someone who I didn't want to be: a decent soccer-mom who went to church
every Sunday and took care of her husband. If it wasn't for him going to
college I don't think he wanted me to work either. This all resulted in that I
don't really know who I am, what I want in my life." I had posted once.

To which Jaz had responded with "Them it's time you find out, isn't it? If you
go into your profile you can enable NSWF content and you can enter the more
_explicit_ content of the site. There you can talk a bit more freely about
anything you want. Just make sure you read the rules before you post, because
as I might imagine certain topic still are off limits."

I wasn't really sure I wanted to do that, I had never ever spoken about things
like sexuality before. I always had been that _good Catholic girl_ I was
brought up to be and we simply didn't speak about those things. But lately I
was even questioning my religion, I just wasn't sure about anything anymore. It
was like ending my marriage had shaken all my believes. As a little girl I had
thought I would get married and we would live happy ever after with a lot of
kids and just be happy for the rest of my life, just like my mother had done.

Her leaving my dad had certainly contributed and I learned him being unfaithful
to my mother had been the final straw for her, she packed her bags and left the
moment she learned he had a mistress. My mother had moved back to the town she
came from and we occasionally talked on the phone as she now too lived too far
away for a visit. The contact with my father deteriorated too, making me feel
more lonely.

I met him one day at the grave of my brother, he was crying and I did feel
sorry for him, but just not enough to forgive him. My brother had died of
cancer and him dying had devastated my father. They were closer than I had ever
been to my father. On top of that during that time I had to be the strongest in
our family, I had to take care of my parents and I was only 14. Shortly
thereafter we moved because my mother couldn't stay in that house anymore. I
had to go to another school, which was where I met my ex.

I tell you all of this because I wanted to make clear that I had put up walls
so I couldn't feel the pain and marrying my ex was kind of an escape from it
all. Being on my own made me confront all of my feelings and having a safe
space on the internet, hiding behind a nickname and a keyboard gave me the
opening I needed to deal with it all, somewhere I could unload some of the
burden I was carrying. Because of the anonymity I felt safe to talk about my
deepest darkest secrets and I have to admit, sharing those feelings may have
saved my life.

It took me a few days before I enabled the explicit content on the site and
reading what was posted there made me blush. I couldn't believe what people
were sharing on there, from stories about their _adventures_ to photo's of them
naked or while they were having sex. One of them was one I read with red ears.

"Finally! Here I am enjoying my first big black cock. I love it and my husband
is watching how this bull makes me come, multiple times." was the attribution
to the photo. The post thanked the community for making her open up to her
husband and how happy she was now. I went back a few of her posts and read how
lonely she felt in her marriage, her husband was working all the time and she
was a stay at home mom. How their children were off to college and how she had
started to feel lonely.

I clicked on another thread titled _Talk about yourself_ and it was full of
bios of the people on their giving their age, how tall they were, hair color or
whatever it was you wanted to share. Some of the posts were accompanied with a
photo, but most of them weren't. I collected all my courage and started a new
thread.

"Hi, this is my first post in this category. I'm not really used to talk about
things like this, we never did at home and I am a little scared sharing this,
but here I go.

Age: 23
Eyes: green
Hair: black
Height: 5"6
Weight: 147lbs
Measurements:  38L-32-36

I was married for 4 years right out of high school and now it's time for me to
discover who I really am. This is so frightening to me, I've never been this
open about myself before and I might even delete this after I thought about it,
but for now: this is me."

Within minutes after posting there quite a few responses and all of them were
positive and encouraging. They all made me feel good about myself and I thanked
them for their reactions and I started posting more things about myself, my
feelings and responding to other posts.

One man asked me to post photos and I responded with "I don't think I dare to.
This is all so overwhelming to me, I can't even believe what I'm posting let
alone uploading a photo. Maybe one day I will have collected enough courage to
do so, but not now. I just don't have the courage. Sorry."

Another member replied with "Don't ever apologize. You just take your time and
even then: don't ever to something you don't want to do. Not even for your
partner. It's your life and you decide what you do, nobody else has the right
to tell you otherwise. Just remember that. I am so proud of you already, you've
come so far since you first posted. You just be you, that's more than enough."

Others said the same and I felt the support coming from those lines of text, it
was like a best friend talking to you. It just made sense, nobody could tell me
what to do or not to do. It was my life. Somehow something clicked in me and I
felt a self awareness I had never felt before. I didn't need anyone in my life,
at least not just yet. I first wanted to get to know me, the real me.

With a renewed resilience I started looking for a new job, not just one that
paid more but also one that I wanted to do. And within a few days I had an
interview for a job in a department store. I got the job and not only did it
pay more I was finally able to move to a better apartment nearer to work and in
a nicer neighborhood. I never felt more happy than to finally leave that crummy
apartment I had been living in.

"I did it!" I posted, "I got a new job and now I've even moved. I feel much
safer here and the apartments aren't that noisy at all. The building has a
super and everything is lit up. My neighbor is a nice elderly woman and I just
feel so happy right now. If it hadn't been for you guys I don't know if I would
ever had gotten here. So thank you all for supporting me and encouraging me to
take matter into my own hands. I love you all, thank you."

The responses again were so positive and I felt more secure about myself. I had
found that opening up, letting someone in really made the best friends. Albeit
through the internet, the people on that site were the best friends I had. They
made it possible for me to also take a risk in real life and I slowly opened up
to a co-worker and she responded in the same way. Diana and I got close at work
at first, going out for coffee after and even went out shopping later. We were
becoming good friends, growing to become best friends.

On time when she visited me I showed her the site and what I had posted there,
I wanted to show her the people who had helped me so much. She was a bit
embarrassed at first, but after reading what I had posted she said "I think I
know you better now, I think I understand." I had tears in my eyes when she
hugged me and said "Now let me put my trust in you."

We talked all night, about her anxiety, her battle with an eating disorder and
how she was molested by her uncle. She told me everything and I really talked
to her. It was almost light when we noticed how long we had talked, luckily
enough it was a Sunday and we didn't have to work that day. "I am so happy I
met you," I said. She responded with "Same, I never had a friend like you. Most
people judge me somehow when I tell them about what happened. You didn't, you
just listened to me, without judgment, without making me feel victimized. I
have fought hard not to be a victim anymore, I'm a survivor not a victim."

"You're welcome," I replied, "I will never judge you. Just so you know it I
will be here for you, any time any place. Just call and I will come. Just so
you know it."

"I feel the same way," Diana replied and we just hugged. I finally had met my
soul mate, my best friend and all because a website made me feel good about
myself, helped me to get to know a part of myself. But I wasn't there yet, I
knew that and I needed to explore that part of me too. Having someone like
Diana in my life, someone who wouldn't judge me, who would support me made it
more possible for me to go that way, to turn that corner, to go where ever that
road may lead me.

A few days later I sat in my bedroom, my heart in my throat as I posed for the
camera. The shutter sound indicated the photo had been taken and as soon as it
appeared on the screen of my phone I knew it was terrible. I just looked fat in
it and it sure wasn't something I wanted anybody to see. So I deleted it and
tried again and again and again. But none of them were what I wanted so I got
up and walked to my wardrobe. I got a few shirts, skirts and other clothes but
there just wasn't anything I particularly liked. If I was going to do this I
had to do it right, I thought.

In the mall I looked at all kinds of dresses, shirts and other clothes but
still couldn't find it. I went into the underwear section as I really needed a
new bra when my eyes fell on a negligee. I had never had one and always wanted
one, this one was rather translucent and I would need to find something I could
wear underneath it. I found some really lovely lingerie and thought it would be
perfect. After fitting a new bra I walked towards the checkout feeling like my
heart was beating out of my chest.

The girl behind the counter didn't blink an eye when I handed her my choices
and a few minutes later I walked out the store with my purchases. I never
wanted to get home so fast as I did that day. I rushed inside and changed into
my new outfit, I looked at myself in the mirror and felt really sexy. If you
would have said I would own something like this a few years earlier I would
have slapped you and now here I was standing in front of a mirror wearing it.

I placed my phone on the chair in front of me and activated the self timer of
the camera app. I took a nice pose and when the photo appeared I giggled again.
I would never have taken such a photo before, I took another few photos
changing position several times until I had the picture I liked.

In a photo editor I had downloaded I learned how to blur my face and how to
change the colors a bit to make it look more vibrant. When I was satisfied with
the result I logged into the website.

"I never would have thought I would do something like this and please be kind.
I bought this outfit today and just wanted to show you." I posted with the
photo of me leaning back on both my hands, my legs a little spread and if I
hadn't blurred my face I would have looked sensually straight at you.

Within seconds the responses came. "Where did you hide that body?", "Wow,
simply wow." and "Girl, I wanted I had boobs like yours." were just a few. I
couldn't believe how many positive reactions I got. I had never felt good about
my body, I always felt fat and thought my breasts were a hindrance not an
asset. The amount of women complementing me was overwhelming and about ten
minutes later I was startled by my phone ringing.

It was Diana and she just said "Is there something you need to tell me?" I
responded I had no idea what she was talking about and then she revealed she
had joined the site too and she had seen my photo. Diana was the only one in my
real life who knew my nickname.

"Oh," I said flustered, "I didn't know."

Diana laughed "How could you? I just joined last night. I really thought about
what you said and just had to join. I'm _UnicornGurl28_, check the responses
I'm one of them."

I scrolled through the reactions and there she was _UnicornGurl28_
complementing my body and then I read "I will let you know what I think later."
I must have missed it before but now the meaning of the words were clear. "Oh,
now I understand what you meant. It was code for 'I will call you'."

"Yes," Diana said, "yes it was. And I meant what I said. Don't feel ashamed of
your body, it's wonderful. And, might I say, I really like that outfit you're
wearing. Where did you get it?"

I told her I went to the mall earlier "And it feels really comfortable too.
I've never had lingerie in my life. It just wasn't done, you know. We had sex
with the lights out. He just got on top of me, did his thing and that was it.
He turned over and went to sleep. I always thought that's how it was supposed
to be, until I read those posts."

"Oh girl, you've got so much to discover and learn." Diana replied, "There's a
whole world out there you know nothing about. It will be so much fun seeing you
explore and trying things. I'm looking forward to it already. I want to know
everything and I mean everything. Whether it's through the site or not, I don't
care."

I felt my face turning red and stuttered "You mean that? I don't want to do
anything so I might lose you."

"You won't. I might not agree with everything, but I will always support you."

"Diana, I have to admit something. I feel really bad about it, but I can't
change it. It's just how I feel."

"What?"

"I haven't been to church in weeks. I don't even think I believe anymore." It
felt like a ton of bricks had been lifted from my shoulders now I had actually
spoken those words.

"Oh, that's all? I thought you were going to say you had a crush on me.
Although it would have flattered me, I like boys. But girl, who cares? I've
stopped going to church years ago. I still think there's something more than
just this, but I have no clue on what it might be. God? Heaven? Who knows?"

I giggled and said "That's how I feel too. It feels good now I've told someone.
And welcome to the community _UnicornGurl_."

"_UnicornGurl28_ thank you very much." Diana relied, "And thank you."

I chuckled as we hung up, I walked to the kitchen to get myself a soda and sat
down on the couch. I chuckled once more thinking back to what Diana had said
and switched on the TV. I must have fallen asleep as I woke up a few hours
later feeling hungry. I got my phone, responded to a message from my mother and
ordered some food. When the doorbell rung I realized I was still wearing my
lingerie and negligee, but I didn't have time to change. With my heart beating
in my throat I got my purse and opened the door acting like it was just another
day for me.

The boy with the pizza blushed when he saw me "How much?" I asked.

"15 dollars" he stuttered with a red face. I handed him the money and took the
pizza from him "Thank you, have a great night," I said as I closed the door.
Back in the living room I burst into laughter, it had been so exciting and I
couldn't believe I had really done it. The pizza even tasted a bit better it
seemed.

A few days later I ordered in again, this time I had put on my outfit on
purpose, it felt just as exciting as the first time. Seeing their faces as I
opened the door was just so much fun.

After a few weeks I left out the negligee and opened the door in my lingerie,
the responses just were so good. I laughed every time I had done it and somehow
couldn't stop thinking about it. As a bonus the posts about them on the site
got so many nice reactions which encouraged me even more.

One night Diana was over for a visit and when it was time she said "Let's order
in." She winked as she said it and got some lingerie from her bag. We changed
into our outfits and opened the door together when the delivery boy rang the
doorbell. Diana even moved sensually as she handed him the money. At the dinner
table she burst into laughter saying "You are right, this is so much fun."

We started doing it together more often and it became a regular thing for us.
We ordered more lingerie through the internet and our outfits became more and
more revealing. Until one day I opened the door only wearing a small pair of
panties and nipple stickers on my breasts. Diana took a photo of me standing
there almost naked at the door handing my money to the delivery boy.

When I closed the door she took another one of me cheering with the bag of food
in my hand. After blurring my face once more we giggled as I uploaded the two
photos to the site. Diana had posted some photos of her to the site too and we
both giggled when it appeared on the site when the page refreshed.

One of the responses said "You have such a nice body, you could earn some
serious money on OnlyFans." I responded that I didn't know about that. I had
heard about that site and said "Oh, but then I need to show my face, don't I? I
don't think I'm ready for that."

But a seed had been planted and for the next couple of days I couldn't stop
thinking about it. What if I did do it? What if I sold my pictures in stead of
giving them away? They were just pictures, who was I hurting with them? All
those questions went through my head. For all of that to happen I needed to
take another step: revealing my face. The biggest hurdle of them all to me.

I talked to Diana about it and she said "If you think you are ready and want to
do this, then who's stopping you? I'm not. Do I agree? No. But I will support
you."

A few days later I took the time to do my makeup and hair, took a photo in a
very revealing outfit and posted it on the site. This time my face was clearly
visible. "This is me," I had posted with it, "my face and all."

The comments were exciting and ranged from "So cute!" to "I want to have
breakfast with you some morning ;)" I giggled when I read the responses and
uploaded some more photos, one more revealing than the other. Until I finally
posted the one where I exposed my pussy to the camera, spreading my lips with
my fingers. The last one I accompanied with the caption "Like what you see?
There might be more soon in a different place."

A few hours later I registered an account on OnlyFans and posted my first
picture there. "Hi, my name is _BustyLeah_ and a whole new world has opened up
to me recently. I'm new to all of this and hope you will follow me as I explore
a whole new world. More to follow."

On the site was a special section to advertise links to other sites and I
posted "Hi, you've convinced me. I've joined OnlyFans and will be uploading
there from now on. I will still be posting here too, but photos will be
exclusive to OnlyFans. I hope at least some of you will follow me there." And I
added the link to my profile on OnlyFans.

One of the first followers on OnlyFans responded with "First! And I will tell
you later what I think ;)" Just a few minutes after my phone rang.

"I can't believe you. OnlyFans? Are you sure?"

I chuckled and said "Yes, I've thought hard an long about it. I like taking
those pictures, it's so much fun and why not check it I could make some money
too? I'm not hurting anyone. It's just pictures."

"You might be right. Just make sure nothing in them can lead back to you or
where you live." Diana said.


